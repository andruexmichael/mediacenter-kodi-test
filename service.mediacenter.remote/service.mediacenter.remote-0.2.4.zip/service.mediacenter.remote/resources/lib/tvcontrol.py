# The smart remote inside Kodi: what each button does on the current screen, and typing into the TV.
# A port of homebridge/homebridge-mediacenter-tv (lib/remote.js, lib/typist.js and what lib/web.js answers), keep
# them in step. 0.4.9.9 parts ways on typing: the app's Search has no letters on the page any more, so this types
# only into Kodi's keyboard (the Docker remote's typist.js, retired since 0.4.7, still walks the letters). Everything
# goes through one function, call(method, params) -> result, which is Kodi's own JSON-RPC when the add-on runs.

import re
import threading
import time

KEYS = ("up", "down", "left", "right", "select", "back", "playpause", "info", "exit", "rewind", "fastforward", "next", "previous",
        "hold")

BUTTONS = {
    "menus": {"up": "up", "down": "down", "left": "left", "right": "right", "select": "select", "back": "back",
              "playpause": "playpause", "info": "menu", "exit": "mediacenter", "rewind": "seek:-10", "fastforward": "seek:30",
              "next": "next", "previous": "previous",
              # OK held (0.4.9.3): Kodi's context menu, which mediaCENTER's pages use for "more about this" (on a show's
              # page, the episode's full page), as a long press of OK does on a Kodi remote.
              "hold": "menu"},
    "watching": {"left": "seek:-10", "right": "seek:30", "up": "info", "down": "osd", "select": "playpause", "info": "osd",
                 "hold": "playpause"},
    "typing": {"playpause": "enter", "info": "backspace", "rewind": "action:cursorleft", "fastforward": "action:cursorright",
               "hold": "select"},
    # mediaCENTER 0.4.5's own player: arrows and OK go to it, so it can skip and show its controls.
    "player": {"playpause": "action:playpause", "next": "action:skipnext", "previous": "action:skipprevious",
               "rewind": "action:rewind", "fastforward": "action:fastforward", "hold": "select"},
}
SIMPLE = {"up": "Input.Up", "down": "Input.Down", "left": "Input.Left", "right": "Input.Right", "select": "Input.Select",
          "back": "Input.Back", "info": "Input.Info", "osd": "Input.ShowOSD", "menu": "Input.ContextMenu"}
# Buttons that do the same on every screen (the iPhone's volume buttons, its TV button, the keyboard's keys).
EXTRA = ("volumeup", "volumedown", "mute", "mediacenter", "tvbutton", "power", "enter", "backspace", "siri")
SECRET_CODES = ((("up", "up", "down", "down"), "mediacenter"),)
CODE_SECONDS = 4.0
SIRI_AGAIN = 1.0  # 0.4.9.9: one Siri press can come as two releases; a second within this long is the same press
DOUBLE_PRESS = 0.35  # 0.4.9.6: a second TV button press within this long makes two quick presses (the Guide)

TYPING_WINDOWS = (10103, 10109)  # Kodi's keyboard and number pad
# Asked when the top window isn't one of them: another dialog (a busy circle, a notice) can sit above Kodi's keyboard,
# and every text box in Kodi (a Wi-Fi password, a setting, a search in another add-on) types in one of these two.
TYPING_SHOWN = ("Window.IsVisible(virtualkeyboard)", "Window.IsVisible(numericinput)")
WATCHING_WINDOWS = (12005, 12006)  # full screen video and music
LIMIT = 60


class CantType(Exception):
    pass


def typing_shown(call, window):
    """Whether Kodi's keyboard or number pad is on the TV, whichever window is on top."""
    if window in TYPING_WINDOWS:
        return True
    try:
        answer = call("XBMC.GetInfoBooleans", {"booleans": list(TYPING_SHOWN)}) or {}
    except Exception:
        return False
    return isinstance(answer, dict) and any(answer.get(b) is True for b in TYPING_SHOWN)


class TvButton(object):
    """The iPhone remote's TV button (0.4.9.6, the design plan, owner 2026-11-26): one press opens mediaCENTER's menu
    over the screen (open=menu); two quick presses go to the Guide with what plays carried into its mini player
    (open=guide, the single press before). The iPhone may not report a held button, so two presses were chosen. A
    single press therefore waits DOUBLE_PRESS seconds in case a second follows. send(page) asks the app;
    later(seconds, fn) runs fn once after that long and returns something with cancel() (threading.Timer)."""

    def __init__(self, send, now=time.time, later=None, gap=DOUBLE_PRESS):
        self.send, self.now, self.gap = send, now, gap
        self.later = later or self._timer
        self.lock = threading.RLock()
        self.first = None  # when the press still waiting for a second one came
        self.timer = None

    @staticmethod
    def _timer(seconds, fn):
        t = threading.Timer(seconds, fn)
        t.daemon = True
        t.start()
        return t

    def press(self):
        with self.lock:
            at = self.now()
            if self.first is not None and at - self.first <= self.gap:
                self.first = None
                if self.timer is not None:
                    self.timer.cancel()
                    self.timer = None
                page = "guide"
            else:
                self.first = at
                self.timer = self.later(self.gap, self.single)
                return "waiting"
        self.send(page)
        return page

    def single(self):
        with self.lock:
            if self.first is None:
                return None  # a second press came first: that was the Guide
            self.first, self.timer = None, None
        self.send("menu")
        return "menu"


def heading(call, window):
    label = "Window(%d).Property(heading)" % window
    return (call("XBMC.GetInfoLabels", {"labels": [label]}) or {}).get(label, "")


class Remote(object):
    def __init__(self, call, now=time.time, secret_codes=False):
        self.call, self.now, self.history = call, now, []
        self.secret_codes = secret_codes  # off unless asked for: Up Up Down Down happens by itself when scrolling
        self.siri_at = None
        self.lock = threading.Lock()  # presses happen one at a time, in order
        self.tv = TvButton(lambda page: self.call("Addons.ExecuteAddon", {"addonid": "script.mediacenter", "params": ["open=%s" % page]}),
                           now=now)

    def window(self):
        return self.call("GUI.GetProperties", {"properties": ["currentwindow"]})["currentwindow"]["id"]

    def context(self):
        window = self.window()
        if typing_shown(self.call, window):
            return "typing"
        if window in WATCHING_WINDOWS:
            return "watching"
        if window >= 13000 and heading(self.call, window) == "Player":
            return "player"
        return "menus"

    def secret(self, key):
        at = self.now()
        self.history = [(k, t) for k, t in self.history if at - t <= CODE_SECONDS][-11:] + [(key, at)]
        pressed = tuple(k for k, _ in self.history)
        for keys, action in SECRET_CODES:
            if pressed[-len(keys):] == keys:
                self.history = []
                return action
        return None

    def press(self, key):
        if key not in KEYS:
            return
        with self.lock:
            action = self.secret(key) if self.secret_codes else None
            if not action:
                context = self.context()
                action = BUTTONS[context].get(key) or BUTTONS["menus"].get(key)
            if action:
                self.run(action)

    def key(self, name):
        """A button from the iPhone: the ones that follow the screen, or one of EXTRA."""
        if name in KEYS:
            return self.press(name)
        if name == "tvbutton":
            return self.tv.press()  # not under the lock: the single press is sent by a timer a moment later
        if name == "siri":
            with self.lock:
                return self.siri()
        if name in EXTRA:
            with self.lock:
                return self.run(name)
        return None

    def siri(self):
        """The iPhone remote's Siri (microphone) button (0.4.9.9, owner 2026-11-26: it opened the iPhone's own Siri
        and nothing could be typed). There is no voice to pass on, so it brings typing instead: with Kodi's keyboard
        on the TV the iPhone's keyboard comes up ("keyboard"; its mic key types what you say), on Search the keyboard
        opens ("search"), on the app's other pages Search opens with its keyboard ("menus"), and while something
        plays nothing happens ("watching"). "again": the same press counted twice."""
        at = self.now()
        if self.siri_at is not None and 0 <= at - self.siri_at < SIRI_AGAIN:
            return "again"
        self.siri_at = at
        window = self.window()
        if typing_shown(self.call, window):
            return "keyboard"
        if window in WATCHING_WINDOWS or (window >= 13000 and heading(self.call, window) == "Player"):
            return "watching"
        if window >= 13000 and heading(self.call, window) == "Search":
            self.call("Input.Info", {})  # mc_app.SearchPage: Info opens the keyboard
            return "search"
        self.call("Addons.ExecuteAddon", {"addonid": "script.mediacenter", "params": ["open=search"]})
        return "menus"

    def player(self):
        players = self.call("Player.GetActivePlayers", {}) or []
        return players[0]["playerid"] if players else None

    def run(self, action):
        if action in SIMPLE:
            return self.call(SIMPLE[action], {})
        if action in ("enter", "backspace"):
            return self.call("Input.ExecuteAction", {"action": action})
        if action.startswith("action:"):
            return self.call("Input.ExecuteAction", {"action": action[7:]})
        if action == "volumeup":
            return self.call("Application.SetVolume", {"volume": "increment"})
        if action == "volumedown":
            return self.call("Application.SetVolume", {"volume": "decrement"})
        if action == "mute":
            return self.call("Application.SetMute", {"mute": "toggle"})
        if action == "mediacenter":  # never Kodi's "home", which can strand the box away from mediaCENTER
            return self.call("Addons.ExecuteAddon", {"addonid": "script.mediacenter"})
        if action == "tvbutton":  # one press or two: TvButton (the menu, or the Guide with the picture in its mini player)
            return self.tv.press()
        if action == "power":  # mediaCENTER's power menu (Power off, Set sleep timer), or the TV back on
            return self.call("Addons.ExecuteAddon", {"addonid": "script.mediacenter", "params": ["open=power"]})
        playerid = self.player()
        if action == "playpause":
            # Nothing playing: Kodi's PlayPause, which mediaCENTER takes on a highlighted card as a held OK and opens the
            # card's hold sheet with its full name and description (0.4.9.9; the iPhone never reports a held button).
            # Before, it was OK.
            if playerid is None:
                return self.call("Input.ExecuteAction", {"action": "playpause"})
            return self.call("Player.PlayPause", {"playerid": playerid})
        if playerid is None:
            return None
        if action == "stop":
            return self.call("Player.Stop", {"playerid": playerid})
        if action in ("next", "previous"):
            return self.call("Player.GoTo", {"playerid": playerid, "to": action})
        if re.match(r"^seek:-?\d{1,4}$", action):
            return self.call("Player.Seek", {"playerid": playerid, "value": {"seconds": int(action[5:])}})
        return None


class Typist(object):
    """Typing from the iPhone's keyboard. Text goes into Kodi's keyboard (or number pad) in one go, wherever it is
    open. 0.4.9.9: mediaCENTER's Search has no letters on the page any more (owner: "the old keyboard still shows"),
    only Kodi's keyboard; text that arrives while Search shows without it opens it first."""

    def __init__(self, call, settle=0.06, patience=1.5, results_wait=1.2, pause=time.sleep):
        self.call, self.settle, self.patience, self.results_wait, self.pause = call, settle, patience, results_wait, pause

    def gui(self):
        answer = self.call("GUI.GetProperties", {"properties": ["currentwindow", "currentcontrol"]})
        return answer["currentwindow"]["id"], (answer.get("currentcontrol") or {}).get("label", "")

    def target(self):
        """("keyboard" | "search" | None, window id). "search": mediaCENTER's Search page without the keyboard."""
        window, _ = self.gui()
        if typing_shown(self.call, window):
            return "keyboard", window
        if window >= 13000 and heading(self.call, window) == "Search":
            return "search", window
        return None, window

    def where(self):
        """Where typed text would go now: "keyboard", or None. Search without Kodi's keyboard is "results": the
        iPhone's keyboard goes away there (after Return the results show), and OK, Info, Menu or the Siri button
        bring the TV's keyboard and with it the iPhone's."""
        kind, _ = self.target()
        return {"keyboard": "keyboard", "search": "results"}.get(kind)

    def type(self, text, done=False):
        kind, window = self.target()
        if kind == "search":
            self.open_keyboard()
            kind = "keyboard"
        if kind == "keyboard":
            self.call("Input.SendText", {"text": text, "done": bool(done)})
        return kind

    def wait_for(self, read, test):
        end = time.time() + self.patience
        value = read()
        while not test(value) and time.time() < end:
            self.pause(self.settle)
            value = read()
        return value

    def open_keyboard(self):
        """mediaCENTER's Search opens Kodi's keyboard on Info (mc_app.SearchPage.speak)."""
        self.call("Input.Info", {})
        if self.wait_for(lambda: self.target()[0], lambda k: k == "keyboard") != "keyboard":
            raise CantType("Press OK on the search box on the TV, then type again.")
