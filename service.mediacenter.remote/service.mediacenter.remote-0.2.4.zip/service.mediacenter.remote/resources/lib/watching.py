# What's playing on the box, for the iPhone's remote (0.4.9.3): its title, poster, length and place, playing or
# paused. The remote then shows it the way it does for an Apple TV, with back 10 / forward 10 and play / pause.
# The Apple TV side of it (the messages to the phone) is atvr4samsung/companion/nowplaying.py; this file reads Kodi
# and works its player.
#
# The poster is the app's own picture (the https address mediaCENTER put on the item, a TMDB poster), fetched here
# and sent to the phone as its bytes. The stream's own address can hold the owner's debrid key, so it is never read
# for this, never sent, and an address that matches it is never fetched. Nothing here logs a title or an address.

import asyncio
import logging
import time
import urllib.parse
import urllib.request

LOG = logging.getLogger("mediacenter-remote")
ITEM = ["title", "showtitle", "season", "episode", "art", "file", "type", "label"]
TIMES = ["time", "totaltime", "speed"]
POSTERS = ("poster", "tvshow.poster", "season.poster", "thumb")
MAX_IMAGE = 400000
EVERY, IDLE = 1.0, 3.0  # seconds between looks while an iPhone is connected / while none is


def seconds(t):
    """Kodi's {"hours", "minutes", "seconds", "milliseconds"} as seconds."""
    if not isinstance(t, dict):
        return 0.0
    return (t.get("hours", 0) * 3600 + t.get("minutes", 0) * 60 + t.get("seconds", 0)
            + t.get("milliseconds", 0) / 1000.0)


def as_time(value):
    value = max(0.0, float(value))
    whole = int(value)
    return {"hours": whole // 3600, "minutes": whole // 60 % 60, "seconds": whole % 60,
            "milliseconds": int(round((value - whole) * 1000)) % 1000}


def unwrap(art):
    """Kodi hands art back as image://<the address, escaped>/; the plain address, or "" for anything not https."""
    a = str(art or "")
    if a.startswith("image://"):
        a = urllib.parse.unquote(a[len("image://"):].rstrip("/"))
    return a if a.startswith("https://") and " " not in a else ""


def poster_of(item):
    """The app's poster for the playing item: never the stream (or anything that shares its address)."""
    stream = str(item.get("file") or "")
    art = item.get("art") or {}
    for key in POSTERS:
        url = unwrap(art.get(key))
        if url and url != stream and not (stream and (url.split("?")[0] == stream.split("?")[0].split("|")[0])):
            return url
    return ""


def fetch(url, timeout=6):
    """The picture's bytes (JPEG or PNG, at most MAX_IMAGE), or None."""
    request = urllib.request.Request(url, headers={"User-Agent": "mediaCENTER-remote"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as answer:
            if answer.headers.get_content_type() not in ("image/jpeg", "image/png"):
                return None
            data = answer.read(MAX_IMAGE + 1)
    except Exception as error:
        LOG.info("No poster for the iPhone remote (%s)", type(error).__name__)
        return None
    return data if 0 < len(data) <= MAX_IMAGE else None


def names(item):
    """(title, subtitle): an episode shows as the show with "S1, E3 · name" under it; a movie or channel as itself."""
    title = str(item.get("title") or item.get("label") or "")
    show = str(item.get("showtitle") or "")
    season, episode = item.get("season"), item.get("episode")
    if show:
        where = "S%s, E%s" % (season, episode) if isinstance(season, int) and isinstance(episode, int) and season >= 0 and episode > 0 else ""
        return show, " · ".join(p for p in (where, title) if p)
    return title, ""


class Player(object):
    """Kodi's video player, through call(method, params) (JSON-RPC)."""

    def __init__(self, call, fetch=fetch, now=time.time):
        self.call, self.fetch, self.now = call, fetch, now
        self.poster_url, self.poster = "", None

    def playerid(self):
        players = self.call("Player.GetActivePlayers", {}) or []
        for p in players:
            if p.get("type") == "video":
                return p.get("playerid")
        return None

    def read(self):
        """What's playing as (title, subtitle, duration, elapsed, playing, image, at), or None."""
        playerid = self.playerid()
        if playerid is None:
            return None
        props = self.call("Player.GetProperties", {"playerid": playerid, "properties": TIMES}) or {}
        item = (self.call("Player.GetItem", {"playerid": playerid, "properties": ITEM}) or {}).get("item") or {}
        title, subtitle = names(item)
        if not title:
            return None
        url = poster_of(item)
        if url != self.poster_url:
            self.poster_url, self.poster = url, (self.fetch(url) if url else None)
        return {"title": title, "subtitle": subtitle, "duration": seconds(props.get("totaltime")),
                "elapsed": seconds(props.get("time")), "playing": props.get("speed", 0) != 0, "image": self.poster,
                "at": self.now()}

    def command(self, name, value=0.0):
        """From the phone: play, pause, skip (signed seconds) or seek (to a place, in seconds)."""
        playerid = self.playerid()
        if playerid is None:
            return None
        if name in ("play", "pause"):
            return self.call("Player.PlayPause", {"playerid": playerid, "play": name == "play"})
        if name == "skip" and value:
            return self.call("Player.Seek", {"playerid": playerid, "value": {"seconds": int(round(value))}})
        if name == "seek":
            return self.call("Player.Seek", {"playerid": playerid, "value": {"time": as_time(value)}})
        return None


class Watcher(object):
    """Looks at the player while an iPhone is connected and tells the phones when something changes."""

    def __init__(self, player, state, make, publish, every=EVERY, idle=IDLE):
        self.player, self.state, self.make, self.publish = player, state, make, publish
        self.every, self.idle = every, idle
        self.last = None
        self.poke = asyncio.Event()

    def connected(self):
        return bool(getattr(self.state, "clients", None))

    def control(self, name, value=0.0):
        """state.now_playing_control: runs in a worker thread, then has the watcher look again straight away."""
        self.player.command(name, value)
        loop = getattr(self, "loop", None)
        if loop is not None:
            loop.call_soon_threadsafe(self.poke.set)

    async def look(self):
        try:
            found = await asyncio.to_thread(self.player.read)
        except Exception as error:  # Kodi busy or closing; the next look tries again
            LOG.debug("Player not read (%s)", type(error).__name__)
            return
        now_playing = self.make(**found) if found else None
        if now_playing is None and self.last is None:
            return
        if now_playing is not None and now_playing.same_as(self.last):
            return
        self.last = now_playing
        self.publish(self.state, now_playing)

    async def run(self):
        self.loop = asyncio.get_running_loop()
        while True:
            if self.connected():
                await self.look()
            elif self.last is not None:
                self.last = None
                self.publish(self.state, None)
            try:
                await asyncio.wait_for(self.poke.wait(), self.every if self.connected() else self.idle)
            except asyncio.TimeoutError:
                pass
            if self.poke.is_set():  # a play, pause or skip from the phone: look again once the player has moved
                self.poke.clear()
                await asyncio.sleep(0.3)


def start(state, call, fetch=fetch):
    """Wire what's playing into the remote's shared state; returns the running task."""
    from atvr4samsung.companion import nowplaying
    watcher = Watcher(Player(call, fetch=fetch), state, nowplaying.NowPlaying, nowplaying.publish)
    state.now_playing_control = watcher.control
    task = asyncio.get_running_loop().create_task(watcher.run())
    task.watcher = watcher
    return task
