# Plain-Python versions of the few pieces of cryptography the iPhone remote needs, so the remote runs on a Pi 3
# inside Kodi without compiled parts: Ed25519 (RFC 8032), X25519 (RFC 7748), ChaCha20-Poly1305 (RFC 8439) and
# HKDF-SHA512 (RFC 5869). Slower than the compiled library, but the iPhone needs the slow parts (Ed25519, X25519) only
# once each time it connects; every button press uses only ChaCha20-Poly1305 on a few hundred bytes.
# shims.py puts these behind the names the copied Apple TV code imports, only when the real library is missing.
# Tests: kodi/tests_remote/test_purecrypto.py (the RFC test vectors, and the real library where it is installed).

import hashlib
import hmac
import os
import struct

# ---------------------------------------------------------------------------------------------------- Ed25519

P = 2 ** 255 - 19
L = 2 ** 252 + 27742317777372353535851937790883648493
D = -121665 * pow(121666, P - 2, P) % P
SQRT_M1 = pow(2, (P - 1) // 4, P)


def _recover_x(y, sign):
    if y >= P:
        return None
    x2 = (y * y - 1) * pow(D * y * y + 1, P - 2, P) % P
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (P + 3) // 8, P)
    if (x * x - x2) % P:
        x = x * SQRT_M1 % P
    if (x * x - x2) % P:
        return None
    if (x & 1) != sign:
        x = P - x
    return x


_GY = 4 * pow(5, P - 2, P) % P
_GX = _recover_x(_GY, 0)
G = (_GX, _GY, 1, _GX * _GY % P)  # extended coordinates (X, Y, Z, T)
ZERO = (0, 1, 1, 0)


def _add(a, b):
    x1, y1, z1, t1 = a
    x2, y2, z2, t2 = b
    pa = (y1 - x1) * (y2 - x2) % P
    pb = (y1 + x1) * (y2 + x2) % P
    pc = 2 * t1 * t2 * D % P
    pd = 2 * z1 * z2 % P
    e, f, g, h = pb - pa, pd - pc, pd + pc, pb + pa
    return (e * f % P, g * h % P, f * g % P, e * h % P)


def _double(a):
    x1, y1, z1, _ = a
    pa = x1 * x1 % P
    pb = y1 * y1 % P
    pc = 2 * z1 * z1 % P
    h = pa + pb
    e = h - (x1 + y1) * (x1 + y1)
    g = pa - pb
    f = pc + g
    return (e * f % P, g * h % P, f * g % P, e * h % P)


def _mul(s, point):
    out = ZERO
    while s > 0:
        if s & 1:
            out = _add(out, point)
        point = _double(point)
        s >>= 1
    return out


_G_TABLE = []


def _mul_base(s):
    """s times the base point, with the base point's doublings worked out once."""
    if not _G_TABLE:
        point = G
        for _ in range(256):
            _G_TABLE.append(point)
            point = _double(point)
    out, i = ZERO, 0
    while s > 0:
        if s & 1:
            out = _add(out, _G_TABLE[i])
        s >>= 1
        i += 1
    return out


def _equal(a, b):
    return (a[0] * b[2] - b[0] * a[2]) % P == 0 and (a[1] * b[2] - b[1] * a[2]) % P == 0


def _encode(point):
    zinv = pow(point[2], P - 2, P)
    x, y = point[0] * zinv % P, point[1] * zinv % P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decode(raw):
    if len(raw) != 32:
        raise ValueError("an Ed25519 key is 32 bytes")
    y = int.from_bytes(raw, "little")
    sign, y = y >> 255, y & ((1 << 255) - 1)
    x = _recover_x(y, sign)
    if x is None:
        raise ValueError("not a point on the curve")
    return (x, y, 1, x * y % P)


def _sha512_int(*parts):
    return int.from_bytes(hashlib.sha512(b"".join(parts)).digest(), "little")


def _secret(seed):
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def ed25519_public(seed):
    return _encode(_mul_base(_secret(seed)[0]))


def ed25519_sign(seed, message, public=None):
    a, prefix = _secret(seed)
    public = public or _encode(_mul_base(a))
    r = _sha512_int(prefix, message) % L
    big_r = _encode(_mul_base(r))
    k = _sha512_int(big_r, public, message) % L
    return big_r + int.to_bytes((r + k * a) % L, 32, "little")


def ed25519_verify(public, message, signature):
    """True for a good signature, False otherwise."""
    if len(signature) != 64 or len(public) != 32:
        return False
    try:
        point_a = _decode(public)
        point_r = _decode(signature[:32])
    except ValueError:
        return False
    s = int.from_bytes(signature[32:], "little")
    if s >= L:
        return False
    k = _sha512_int(signature[:32], public, message) % L
    return _equal(_mul_base(s), _add(point_r, _mul(k, point_a)))


# ----------------------------------------------------------------------------------------------------- X25519

A24 = 121665


def _clamp(k):
    k = bytearray(k)
    k[0] &= 248
    k[31] &= 127
    k[31] |= 64
    return int.from_bytes(bytes(k), "little")


def x25519(scalar, u_bytes):
    if len(scalar) != 32 or len(u_bytes) != 32:
        raise ValueError("an X25519 key is 32 bytes")
    k = _clamp(scalar)
    u = int.from_bytes(u_bytes, "little") & ((1 << 255) - 1)
    x1, x2, z2, x3, z3, swap = u, 1, 0, u, 1, 0
    for t in range(254, -1, -1):
        bit = (k >> t) & 1
        swap ^= bit
        if swap:
            x2, x3, z2, z3 = x3, x2, z3, z2
        swap = bit
        a, b = x2 + z2, x2 - z2
        aa, bb = a * a % P, b * b % P
        e = aa - bb
        c, d = x3 + z3, x3 - z3
        da, cb = d * a % P, c * b % P
        x3 = (da + cb) * (da + cb) % P
        z3 = x1 * (da - cb) * (da - cb) % P
        x2 = aa * bb % P
        z2 = e * (aa + A24 * e) % P
    if swap:
        x2, z2 = x3, z3
    out = x2 * pow(z2, P - 2, P) % P
    return int.to_bytes(out, 32, "little")


X25519_BASE = int.to_bytes(9, 32, "little")


def x25519_shared(private, peer_public):
    shared = x25519(private, peer_public)
    if shared == bytes(32):
        raise ValueError("the other side's key is not usable")  # a low-order point: the library refuses it too
    return shared


# ------------------------------------------------------------------------------------------- ChaCha20-Poly1305

MASK = 0xFFFFFFFF
_SIGMA = struct.unpack("<4I", b"expand 32-byte k")
_WORDS = struct.Struct("<16I")


def _block(key_words, counter, nonce_words):
    state = list(_SIGMA) + list(key_words) + [counter & MASK] + list(nonce_words)
    x = list(state)
    for _ in range(10):
        for a, b, c, d in ((0, 4, 8, 12), (1, 5, 9, 13), (2, 6, 10, 14), (3, 7, 11, 15),
                           (0, 5, 10, 15), (1, 6, 11, 12), (2, 7, 8, 13), (3, 4, 9, 14)):
            xa, xb, xc, xd = x[a], x[b], x[c], x[d]
            xa = (xa + xb) & MASK
            xd ^= xa
            xd = ((xd << 16) & MASK) | (xd >> 16)
            xc = (xc + xd) & MASK
            xb ^= xc
            xb = ((xb << 12) & MASK) | (xb >> 20)
            xa = (xa + xb) & MASK
            xd ^= xa
            xd = ((xd << 8) & MASK) | (xd >> 24)
            xc = (xc + xd) & MASK
            xb ^= xc
            xb = ((xb << 7) & MASK) | (xb >> 25)
            x[a], x[b], x[c], x[d] = xa, xb, xc, xd
    return _WORDS.pack(*[(x[i] + state[i]) & MASK for i in range(16)])


def chacha20(key, counter, nonce, data):
    key_words = struct.unpack("<8I", key)
    nonce_words = struct.unpack("<3I", nonce)
    blocks = (len(data) + 63) // 64
    stream = b"".join(_block(key_words, counter + i, nonce_words) for i in range(blocks))[:len(data)]
    if not data:
        return b""
    mixed = int.from_bytes(data, "little") ^ int.from_bytes(stream, "little")
    return mixed.to_bytes(len(data), "little")


def poly1305(key, message):
    r = int.from_bytes(key[:16], "little") & 0x0FFFFFFC0FFFFFFC0FFFFFFC0FFFFFFF
    s = int.from_bytes(key[16:32], "little")
    p, acc = (1 << 130) - 5, 0
    for i in range(0, len(message), 16):
        chunk = message[i:i + 16]
        acc = (acc + int.from_bytes(chunk + b"\x01", "little")) * r % p
    return int.to_bytes((acc + s) & ((1 << 128) - 1), 16, "little")


def _pad16(data):
    return b"\x00" * (-len(data) % 16)


def _tag(key, nonce, aad, ciphertext):
    otk = chacha20(key, 0, nonce, bytes(32))
    mac_data = aad + _pad16(aad) + ciphertext + _pad16(ciphertext) + struct.pack("<QQ", len(aad), len(ciphertext))
    return poly1305(otk, mac_data)


class InvalidTag(Exception):
    """The message was changed or the key is wrong."""


def seal(key, nonce, plaintext, aad=b""):
    if len(key) != 32 or len(nonce) != 12:
        raise ValueError("ChaCha20-Poly1305 takes a 32-byte key and a 12-byte nonce")
    aad = aad or b""
    ciphertext = chacha20(key, 1, nonce, plaintext)
    return ciphertext + _tag(key, nonce, aad, ciphertext)


def open_sealed(key, nonce, data, aad=b""):
    if len(key) != 32 or len(nonce) != 12:
        raise ValueError("ChaCha20-Poly1305 takes a 32-byte key and a 12-byte nonce")
    if len(data) < 16:
        raise InvalidTag()
    aad = aad or b""
    ciphertext, tag = data[:-16], data[-16:]
    if not hmac.compare_digest(_tag(key, nonce, aad, ciphertext), tag):
        raise InvalidTag()
    return chacha20(key, 1, nonce, ciphertext)


# ------------------------------------------------------------------------------------------------ HKDF-SHA512

def hkdf_sha512(ikm, salt, info, length):
    prk = hmac.new(salt or bytes(64), ikm, hashlib.sha512).digest()
    out, block, i = b"", b"", 1
    while len(out) < length:
        block = hmac.new(prk, block + info + bytes([i]), hashlib.sha512).digest()
        out += block
        i += 1
    return out[:length]


def random_bytes(n):
    return os.urandom(n)
