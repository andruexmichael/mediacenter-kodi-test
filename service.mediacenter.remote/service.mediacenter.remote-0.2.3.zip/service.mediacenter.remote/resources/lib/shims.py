# The copied Apple TV code (atvr4samsung, copied in when the add-on is packaged) imports three libraries: cryptography,
# chacha20poly1305_reuseable and srptools. A Pi 3's Kodi has none of them, and the first needs parts compiled for the
# box. install() puts plain-Python stand-ins (purecrypto.py, hapsrp.py) behind those names, each only when the real
# library can't be loaded, so a box that has the real ones uses them. It also puts a placeholder behind zeroconf,
# which companion/discovery.py imports only for a type: the service announces itself with mdns.py instead.

import importlib
import sys
import types

import hapsrp
import purecrypto as C


def _module(name, **things):
    module = types.ModuleType(name)
    module.__dict__.update(things)
    sys.modules[name] = module
    parent, _, child = name.rpartition(".")
    if parent:
        setattr(sys.modules[parent], child, module)
    return module


def _loads(name):
    try:
        importlib.import_module(name)
        return True
    except Exception:  # a part built for another machine fails in many ways
        for loaded in [n for n in sys.modules if n == name.split(".")[0] or n.startswith(name.split(".")[0] + ".")]:
            del sys.modules[loaded]
        return False


class InvalidSignature(Exception):
    pass


class _Raw(object):
    Raw = "Raw"


class _NoEncryption(object):
    pass


class Ed25519PublicKey(object):
    def __init__(self, raw):
        self._raw = bytes(raw)

    @classmethod
    def from_public_bytes(cls, data):
        if len(data) != 32:
            raise ValueError("An Ed25519 public key is 32 bytes long")
        C._decode(bytes(data))
        return cls(data)

    def public_bytes(self, encoding=None, format=None):  # noqa: A002  (the library's name)
        return self._raw

    def verify(self, signature, data):
        if not C.ed25519_verify(self._raw, bytes(data), bytes(signature)):
            raise InvalidSignature()


class Ed25519PrivateKey(object):
    def __init__(self, seed):
        self._seed = bytes(seed)
        self._public = C.ed25519_public(self._seed)

    @classmethod
    def generate(cls):
        return cls(C.random_bytes(32))

    @classmethod
    def from_private_bytes(cls, data):
        if len(data) != 32:
            raise ValueError("An Ed25519 private key is 32 bytes long")
        return cls(data)

    def public_key(self):
        return Ed25519PublicKey(self._public)

    def private_bytes(self, encoding=None, format=None, encryption_algorithm=None):  # noqa: A002
        return self._seed

    def sign(self, data):
        return C.ed25519_sign(self._seed, bytes(data), self._public)


class X25519PublicKey(object):
    def __init__(self, raw):
        self._raw = bytes(raw)

    @classmethod
    def from_public_bytes(cls, data):
        if len(data) != 32:
            raise ValueError("An X25519 public key is 32 bytes long")
        return cls(data)

    def public_bytes(self, encoding=None, format=None):  # noqa: A002
        return self._raw


class X25519PrivateKey(object):
    def __init__(self, raw):
        self._raw = bytes(raw)

    @classmethod
    def generate(cls):
        return cls(C.random_bytes(32))

    @classmethod
    def from_private_bytes(cls, data):
        if len(data) != 32:
            raise ValueError("An X25519 private key is 32 bytes long")
        return cls(data)

    def public_key(self):
        return X25519PublicKey(C.x25519(self._raw, C.X25519_BASE))

    def private_bytes(self, encoding=None, format=None, encryption_algorithm=None):  # noqa: A002
        return self._raw

    def exchange(self, peer_public_key):
        return C.x25519_shared(self._raw, peer_public_key.public_bytes())


class SHA512(object):
    name = "sha512"
    digest_size = 64


class HKDF(object):
    def __init__(self, algorithm, length, salt, info, backend=None):
        if not isinstance(algorithm, SHA512):
            raise ValueError("only SHA-512 is here")
        self._length, self._salt, self._info, self._used = length, salt, info or b"", False

    def derive(self, key_material):
        if self._used:
            raise ValueError("already used")
        self._used = True
        return C.hkdf_sha512(bytes(key_material), self._salt, self._info, self._length)


class ChaCha20Poly1305(object):
    def __init__(self, key):
        if len(key) != 32:
            raise ValueError("ChaCha20Poly1305 key must be 32 bytes.")
        self._key = bytes(key)

    def encrypt(self, nonce, data, associated_data):
        return C.seal(self._key, bytes(nonce), bytes(data), bytes(associated_data or b""))

    def decrypt(self, nonce, data, associated_data):
        return C.open_sealed(self._key, bytes(nonce), bytes(data), bytes(associated_data or b""))


class _ServiceInfo(object):
    def __init__(self, *args, **kwargs):
        raise RuntimeError("the service announces itself with mdns.py, not zeroconf")


def _stand_in_cryptography():
    _module("cryptography")
    _module("cryptography.exceptions", InvalidSignature=InvalidSignature, InvalidTag=C.InvalidTag)
    _module("cryptography.hazmat")
    _module("cryptography.hazmat.backends", default_backend=lambda: None)
    _module("cryptography.hazmat.primitives")
    _module("cryptography.hazmat.primitives.serialization", Encoding=_Raw, PublicFormat=_Raw, PrivateFormat=_Raw,
            NoEncryption=_NoEncryption)
    _module("cryptography.hazmat.primitives.hashes", SHA512=SHA512)
    _module("cryptography.hazmat.primitives.asymmetric")
    _module("cryptography.hazmat.primitives.asymmetric.ed25519", Ed25519PrivateKey=Ed25519PrivateKey,
            Ed25519PublicKey=Ed25519PublicKey)
    _module("cryptography.hazmat.primitives.asymmetric.x25519", X25519PrivateKey=X25519PrivateKey,
            X25519PublicKey=X25519PublicKey)
    _module("cryptography.hazmat.primitives.kdf")
    _module("cryptography.hazmat.primitives.kdf.hkdf", HKDF=HKDF)
    _module("cryptography.hazmat.primitives.ciphers")
    _module("cryptography.hazmat.primitives.ciphers.aead", ChaCha20Poly1305=ChaCha20Poly1305)


NEEDED = ("cryptography.hazmat.primitives.asymmetric.ed25519", "cryptography.hazmat.primitives.asymmetric.x25519",
          "cryptography.hazmat.primitives.kdf.hkdf", "cryptography.hazmat.primitives.ciphers.aead")


def install(force=False):
    """Make the three libraries importable. Returns which ones are the stand-ins here (for the log)."""
    used = []
    if force or not all(_loads(name) for name in NEEDED):
        _stand_in_cryptography()
        used.append("cryptography")
    if force or not _loads("chacha20poly1305_reuseable"):
        aead = sys.modules["cryptography.hazmat.primitives.ciphers.aead"]
        _module("chacha20poly1305_reuseable", ChaCha20Poly1305Reusable=aead.ChaCha20Poly1305)
        used.append("chacha20poly1305_reuseable")
    if force or not _loads("srptools"):
        _module("srptools", SRPContext=hapsrp.SRPContext, SRPServerSession=hapsrp.SRPServerSession,
                constants=hapsrp.constants)
        used.append("srptools")
    if force or not _loads("zeroconf"):
        _module("zeroconf", ServiceInfo=_ServiceInfo)
        used.append("zeroconf")
    return used
