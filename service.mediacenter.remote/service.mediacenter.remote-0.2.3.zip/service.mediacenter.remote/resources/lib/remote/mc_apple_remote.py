#!/usr/bin/env python3
"""mediaCENTER Apple Remote: the iPhone's own Control Center remote, with its keyboard, for the TV box.

The iPhone only shows a keyboard for an Apple TV, so this program answers on the home network as one. The part that
speaks Apple's remote protocol is copied from vb3/atvr4samsung (MIT, vendor/). This file passes what the iPhone sends
to the mediaCENTER smart remote (../homebridge-mediacenter-tv), which chooses what each button does on the current
screen and types text into the TV, and it raises the iPhone's keyboard when the TV asks for text.

    python3 mc_apple_remote.py run --pair      start, and show a pairing code for a new iPhone
    python3 mc_apple_remote.py run             start
    python3 mc_apple_remote.py pair            show a new pairing code while it is running

Nothing typed is logged or saved. The identity and the paired iPhones live in --state (your home folder).
"""

import argparse
import asyncio
import json
import logging
import os
import secrets
import shutil
import signal
import socket
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "vendor"))

from atvr4samsung.authorization import AuthorizationRevoked, require_authorized  # noqa: E402
from atvr4samsung.bridge.keymap import Action  # noqa: E402

LOG = logging.getLogger("mediacenter-apple-remote")
SMART_REMOTE = HERE.parent / "homebridge-mediacenter-tv" / "bin" / "phone-remote.js"
STATE = "~/.mediacenter-apple-remote"

# What the iPhone sends (named by the copied key map) and the smart remote's button for it. Power opens mediaCENTER's
# power menu (owner, 2026-11-26: Power off, which turns the TV off and leaves the box on, and a sleep timer); the next
# Power after that turns the TV back on. Sleep (Power held), Wake and Guide do nothing: the box itself is never
# switched off from here, since it could not be switched on again. The TV button never sends Kodi's
# "home", which can strand the box away from mediaCENTER: it is the smart remote's "tvbutton", which opens the page
# set in its settings (tvButton; Home unless the owner picks another).
BUTTONS = {
    "KEY_UP": "up", "KEY_DOWN": "down", "KEY_LEFT": "left", "KEY_RIGHT": "right", "KEY_ENTER": "select",
    "KEY_RETURN": "back", "KEY_HOME": "tvbutton", "KEY_PLAY_BACK": "playpause", "KEY_VOLUP": "volumeup",
    "KEY_VOLDOWN": "volumedown", "KEY_MUTE": "mute", "KEY_CHUP": "next", "KEY_CHDOWN": "previous",
    "KEY_POWER": "power",
}
TEXT_SCREENS = ("keyboard", "search")
HOLD_KEYBOARD = 3.0  # after Return, a keyboard window still open on the TV doesn't bring the iPhone's keyboard back for this long
# Where the TV can't take text right now, so the iPhone's keyboard is put away: nowhere, or the Search page with the
# highlight on its results (after Return, the highlight moves there by itself).
NO_TEXT = (None, "results")


class Tv:
    """The smart remote's local web service."""

    def __init__(self, url, code, timeout=40):
        self.url, self.code, self.timeout = url.rstrip("/"), code, timeout
        self._text = None
        self._typing = None

    def _request(self, path, body=None, timeout=None):
        request = urllib.request.Request(
            self.url + path, data=None if body is None else json.dumps(body).encode("utf-8"),
            headers={"x-code": self.code, "content-type": "application/json"}, method="GET" if body is None else "POST")
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))  # always direct, never through a proxy
        try:
            with opener.open(request, timeout=timeout or self.timeout) as response:
                return response.status, json.load(response)
        except urllib.error.HTTPError as error:
            try:
                return error.code, json.load(error)
            except ValueError:
                return error.code, {}

    async def request(self, path, body=None, timeout=None):
        try:
            return await asyncio.to_thread(self._request, path, body, timeout)
        except (OSError, ValueError) as error:
            LOG.warning("The smart remote didn't answer (%s)", type(error).__name__)
            return 0, {}

    async def key(self, name):
        status, answer = await self.request("/api/key", {"key": name}, timeout=10)
        if status not in (0, 200):
            LOG.warning("Button %s: %s", name, answer.get("error", status))

    def text(self, text, authorization=None, done=False):
        """Send the whole text box. Only the newest text matters, so typing never queues up behind a slow TV. done:
        the keyboard's Return key was pressed, so the TV submits it (Search moves to its results); it is kept when a
        newer text replaces one still waiting."""
        done = bool(done or (self._text is not None and self._text[2]))
        self._text = (text, authorization, done)
        if self._typing is None or self._typing.done():
            self._typing = asyncio.get_running_loop().create_task(self._send_text())
        return self._typing

    async def _send_text(self):
        while self._text is not None:
            (text, authorization, done), self._text = self._text, None
            try:
                require_authorized(authorization)
            except AuthorizationRevoked:
                continue
            status, answer = await self.request("/api/type", {"text": text, "done": done})
            if status not in (0, 200):
                LOG.warning("Typing: %s", answer.get("error", status))

    async def target(self):
        """Where text would go on the TV: "keyboard", "search", "results", None (nowhere), "working" (the TV is busy
        typing or moving and answers again in a moment) or "busy" (can't reach it right now)."""
        status, answer = await self.request("/api/target", timeout=8)
        if status != 200 or not answer.get("online"):
            return "busy"
        target = answer.get("target")
        return "working" if target == "busy" else target


class Keyboard:
    """The iPhone's keyboard. Return puts it away straight away (owner, 2026-11-26: no closing it by hand), and it
    stays away while the TV is still on Search after Return; it comes back once the TV has moved on and then asks for
    text again (the highlight back on Search's letters, or a new keyboard on the TV)."""

    def __init__(self, clock=None):
        self.focus = None  # set once the server is up: focus("ms.remote.imeStart" | "ms.remote.imeEnd")
        self.clock = clock or time.monotonic
        self.returned_at = None

    def returned(self):
        self.returned_at = self.clock()
        if self.focus is not None:
            self.focus("ms.remote.imeEnd")

    def held(self, target):
        """Whether the keyboard stays away for this target after Return (and forget the Return once it doesn't)."""
        if self.returned_at is None:
            return False
        if target in ("search", "working", "busy") or (target == "keyboard" and self.clock() - self.returned_at < HOLD_KEYBOARD):
            return True
        self.returned_at = None
        return False


def make_dispatch(tv, keyboard=None):
    """What the protocol part calls for each button press and each change of the iPhone's text box."""

    async def run(command, authorization=None):
        require_authorized(authorization)
        if command.action is Action.SEND_TEXT and command.text is not None:
            done = getattr(command, "done", False)
            if done and keyboard is not None:
                keyboard.returned()
            tv.text(command.text, authorization, done)
        elif command.action is Action.SEND_KEY and command.samsung_key in BUTTONS:  # not Sleep (POWER_OFF)
            await tv.key(BUTTONS[command.samsung_key])

    async def dispatch(command):
        await run(command)

    async def dispatch_authorized(command, authorization):
        await run(command, authorization)

    dispatch.dispatch_authorized = dispatch_authorized
    return dispatch


async def watch_keyboard(tv, focus, every=1.5, connected=lambda: True, slow=15.0, keyboard=None):
    """Show the iPhone's keyboard while the TV can take text, and put it away when it can't (or after Return: see
    Keyboard). The TV box is small, so it is asked only while an iPhone is connected, one question at a time, and left
    alone for a while when it can't be reached. "working" (typing or moving to the results) is asked again soon."""
    while True:
        wait = every
        if connected():
            target = await tv.target()
            if keyboard is not None and keyboard.held(target):
                focus("ms.remote.imeEnd")
                if target == "busy":
                    wait = slow
            elif target in TEXT_SCREENS:
                focus("ms.remote.imeStart")  # the copied code's name for "a text box opened"
            elif target in NO_TEXT:
                focus("ms.remote.imeEnd")
            elif target == "busy":
                wait = slow
        await asyncio.sleep(wait)


def local_ip():
    """This computer's address on the home network (nothing is sent)."""
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as probe:
        try:
            probe.connect(("224.0.0.251", 5353))
            return probe.getsockname()[0]
        except OSError:
            return "0.0.0.0"


def state_folder(path):
    folder = Path(path).expanduser()
    folder.mkdir(mode=0o700, parents=True, exist_ok=True)
    folder.chmod(0o700)  # the protocol code refuses a folder others can write to
    return folder


def open_pairing(folder):
    """A five-minute pairing code for one new iPhone."""
    from atvr4samsung.companion.protocol.server_identity import load_persisted_identity_locked
    from atvr4samsung.pairing_window import DEFAULT_WINDOW_SECONDS, PairingWindowStore

    store = PairingWindowStore(folder)
    with store.transaction():
        identity = load_persisted_identity_locked(folder)
        return store.open_locked(server_identifier=identity.identifier, server_generation=identity.generation,
                                 duration_seconds=DEFAULT_WINDOW_SECONDS)


def show_pairing(window):
    until = datetime.fromtimestamp(window.expires_at).strftime("%-I:%M %p")
    print("\n  Pairing code for your iPhone: %s   (good until %s)\n"
          "  On the iPhone: Control Center > remote > choose the TV name at the top, then type the code.\n"
          % (window.pin, until), flush=True)


class Bridge:
    """The pretend Apple TV: the listener, its announcement on the network, and the keyboard watcher."""

    def __init__(self, tv, folder, name, port=0, announce=True, window_store=None):
        """window_store: where pairing codes are kept (a PairingWindowStore for folder when not given); the Kodi remote
        passes one that opens a code when an iPhone asks while mediaCENTER is signed out."""
        self.tv, self.folder, self.name, self.port, self.announce = tv, folder, name, port, announce
        self.window_store = window_store
        self.server = self.state = self.zeroconf = self.advertiser = self.watcher = self.identity = None
        self.keyboard = Keyboard()

    async def start(self):
        from atvr4samsung.bridge.gestures import GestureConfig
        from atvr4samsung.companion.protocol.paired_clients import PairedClients
        from atvr4samsung.companion.protocol.pairing_state import async_pairing_state_lock
        from atvr4samsung.companion.protocol.server_identity import load_or_create_server_identity_locked
        from atvr4samsung.companion.relay import DirectionalHoldConfig
        from atvr4samsung.companion.server import make_ime_focus_handler, serve
        from atvr4samsung.pairing_window import PairingWindowStore

        async with async_pairing_state_lock(self.folder):
            self.identity = load_or_create_server_identity_locked(self.folder)
            self.server, self.state = await serve(
                make_dispatch(self.tv, self.keyboard), host="0.0.0.0", port=self.port, device_name=self.name,
                gesture_config=GestureConfig(repeat_every=350), hold_config=DirectionalHoldConfig(enabled=True),
                unique_id=self.identity.identifier, private_key=self.identity.private_key,
                server_identity_generation=self.identity.generation,
                paired_clients=PairedClients(self.folder / "paired-clients.json"), require_paired=True,
                pairing_window=self.window_store or PairingWindowStore(self.folder))
        self.port = self.server.sockets[0].getsockname()[1]
        if self.announce:
            from atvr4samsung.companion.discovery import CompanionAdvertiser
            from zeroconf import Zeroconf
            self.zeroconf = Zeroconf()
            self.advertiser = CompanionAdvertiser(
                asyncio.get_running_loop(), self.zeroconf, port=self.port, device_name=self.name,
                identity_identifier=self.identity.identifier, model="AppleTV14,1", detect_ip=local_ip)
            await self.advertiser.start()
        self.keyboard.focus = make_ime_focus_handler(self.state)
        self.watcher = asyncio.get_running_loop().create_task(watch_keyboard(
            self.tv, self.keyboard.focus, connected=lambda: bool(self.state.active_rti_sessions()), keyboard=self.keyboard))

    async def stop(self):
        from atvr4samsung.companion.server import close_server
        if self.watcher:
            self.watcher.cancel()
        if self.advertiser:
            await self.advertiser.close()
        if self.server:
            await close_server(self.server)
        if self.zeroconf:
            await asyncio.to_thread(self.zeroconf.close)


async def start_smart_remote(tv_host, port):
    """Run the smart remote for this computer only, with a throwaway code the two programs share."""
    node = shutil.which("node") or next((str(p) for p in [Path.home() / "tools/node/bin/node"] if p.exists()), None)
    if not node or not SMART_REMOTE.exists():
        raise SystemExit("Node.js or the smart remote is missing (%s)." % SMART_REMOTE)
    code = secrets.token_hex(16)
    env = dict(os.environ, TV_HOST=tv_host, REMOTE_CODE=code, WEB_PORT=str(port), LISTEN="127.0.0.1")
    process = await asyncio.create_subprocess_exec(node, str(SMART_REMOTE), env=env, stdout=asyncio.subprocess.PIPE)
    line = await asyncio.wait_for(process.stdout.readline(), 15)
    if not line.startswith(b"ready "):
        process.terminate()
        raise SystemExit("The smart remote could not start. Is port %d already in use?" % port)
    return process, "http://127.0.0.1:%s" % line.split()[1].decode(), code


async def run(args):
    folder = state_folder(args.state)
    process = None
    if args.remote:
        url, code = args.remote, os.environ.get("REMOTE_CODE", "")
        if not code:
            raise SystemExit("With --remote, put the remote code in the REMOTE_CODE environment variable.")
    else:
        process, url, code = await start_smart_remote(args.tv, args.web_port)
    bridge = Bridge(Tv(url, code), folder, args.name, port=args.port)
    stop = asyncio.Event()
    try:
        await bridge.start()
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, stop.set)
        print("Running. The iPhone will see a TV named %r. Press Control-C to stop." % args.name, flush=True)
        await asyncio.sleep(2)
        if await bridge.tv.target() == "busy":
            print("Not connected to the TV box at %r yet; trying again by itself." % args.tv, flush=True)
        if args.pair:
            show_pairing(open_pairing(folder))
        await stop.wait()
    finally:
        await bridge.stop()
        if process and process.returncode is None:
            process.terminate()
            await process.wait()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Use the iPhone's own remote and keyboard with the mediaCENTER TV box.")
    parser.add_argument("command", choices=["run", "pair"])
    parser.add_argument("--tv", default="libreelec.local", help="the TV box's name or address")
    parser.add_argument("--name", default="mediaCENTER TV", help="the name the iPhone shows")
    parser.add_argument("--state", default=STATE, help="where the identity and paired iPhones are kept")
    parser.add_argument("--port", type=int, default=49500, help="the port the iPhone connects to")
    parser.add_argument("--web-port", type=int, default=8767, help="port for the smart remote this starts")
    parser.add_argument("--remote", help="use a smart remote that is already running, instead of starting one")
    parser.add_argument("--pair", action="store_true", help="with run: show a pairing code once started")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.WARNING, format="%(asctime)s %(levelname)s %(message)s")
    if args.command == "pair":
        try:
            show_pairing(open_pairing(state_folder(args.state)))
        except Exception as error:  # nothing secret is in these messages
            raise SystemExit("Start it first with: run (%s)" % type(error).__name__)
        return 0
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main())
