# The pairing code check (SRP-6a with SHA-512 and the 3072-bit group, as Apple's pairing uses), in plain Python.
# It stands in for the srptools library with the same names and the same way of turning numbers into bytes, so the
# copied Apple TV code (companion/protocol/auth.py) runs unchanged. Only the TV's side is here; the tests have the
# iPhone's side. shims.py uses it only when srptools is missing.

import binascii
import hashlib
import secrets


class constants(object):  # noqa: N801  (the name srptools uses)
    PRIME_3072 = (
        "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B"
        "302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE6"
        "49286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D"
        "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF695581718"
        "3995497CEA956AE515D2261898FA051015728E5A8AAAC42DAD33170D04507A33A85521ABDF1CBA64ECFB850458DBEF0A8AEA71575D060C7D"
        "B3970F85A6E1E4C7ABF5AE8CDB0933D71E8C94E04A25619DCEE3D2261AD2EE6BF12FFA06D98A0864D87602733EC86A64521F2B18177B200C"
        "BBE117577A615D6C770988C0BAD946E208E24FA074E5AB3143DB5BFCE0FD108E4B82D120A93AD2CAFFFFFFFFFFFFFFFF")
    PRIME_3072_GEN = "05"


def int_from_hex(value):
    if isinstance(value, bytes):
        value = value.decode("ascii")
    return int(value, 16)


def hex_from_int(value):
    text = "%x" % value
    return "0" + text if len(text) % 2 else text


def int_to_bytes(value):
    return binascii.unhexlify(hex_from_int(value))


class SRPContext(object):
    def __init__(self, username, password=None, prime=None, generator=None, hash_func=None, multiplier=None,
                 bits_random=1024, bits_salt=64):
        self._hash_func = hash_func or hashlib.sha1
        self._user = username
        self._password = password
        self._gen = int_from_hex(generator or constants.PRIME_3072_GEN)
        self._prime = int_from_hex(prime or constants.PRIME_3072)
        self._bits_random = bits_random
        self._bits_salt = bits_salt
        self._mult = int_from_hex(multiplier) if multiplier else self.hash(self._prime, self.pad(self._gen))

    @property
    def prime(self):
        return self._prime

    @property
    def generator(self):
        return self._gen

    def pad(self, value):
        size = len(int_to_bytes(self._prime))
        return int_to_bytes(value).rjust(size, b"\x00")

    def hash(self, *parts, **options):
        joiner = options.get("joiner", "").encode("utf-8")
        raw = []
        for part in parts:
            if isinstance(part, int):
                part = int_to_bytes(part)
            elif isinstance(part, str):
                part = part.encode("utf-8")
            raw.append(part)
        digest = self._hash_func(joiner.join(raw))
        return digest.digest() if options.get("as_bytes") else int(digest.hexdigest(), 16)

    def generate_random(self, bits):
        return secrets.randbits(bits)

    def generate_salt(self):
        return self.generate_random(self._bits_salt)

    def get_common_secret(self, server_public, client_public):
        return self.hash(self.pad(client_public), self.pad(server_public))

    def get_common_password_hash(self, salt):
        if self._password is None:
            raise ValueError("no pairing code")
        return self.hash(salt, self.hash(self._user, self._password, joiner=":", as_bytes=True))

    def get_common_password_verifier(self, password_hash):
        return pow(self._gen, password_hash, self._prime)

    def get_server_public(self, verifier, server_private):
        return (self._mult * verifier + pow(self._gen, server_private, self._prime)) % self._prime

    def get_client_public(self, client_private):
        return pow(self._gen, client_private, self._prime)

    def get_server_premaster_secret(self, verifier, server_private, client_public, common_secret):
        return pow(client_public * pow(verifier, common_secret, self._prime), server_private, self._prime)

    def get_client_premaster_secret(self, password_hash, server_public, client_private, common_secret):
        base = (server_public - self._mult * pow(self._gen, password_hash, self._prime)) % self._prime
        return pow(base, client_private + common_secret * password_hash, self._prime)

    def get_common_session_key(self, premaster_secret):
        return self.hash(premaster_secret, as_bytes=True)

    def get_common_session_key_proof(self, session_key, salt, server_public, client_public):
        h = self.hash
        return h(h(self._prime) ^ h(self._gen), h(self._user), salt, client_public, server_public, session_key, as_bytes=True)

    def get_common_session_key_proof_hash(self, session_key, session_key_proof, client_public):
        return self.hash(client_public, session_key_proof, session_key, as_bytes=True)

    def get_user_data_triplet(self, base64=False):
        salt = self.generate_salt()
        verifier = self.get_common_password_verifier(self.get_common_password_hash(salt))
        return self._user, hex_from_int(verifier), hex_from_int(salt)


class SRPServerSession(object):
    def __init__(self, srp_context, password_verifier, private=None):
        self._context = srp_context
        self._verifier = int_from_hex(password_verifier)
        self._private = int_from_hex(private) if private else srp_context.generate_random(srp_context._bits_random)
        self._public = srp_context.get_server_public(self._verifier, self._private)
        self._key = self._key_proof = self._key_proof_hash = None

    @property
    def public(self):
        return hex_from_int(self._public)

    @property
    def key(self):
        return binascii.hexlify(self._key).decode("ascii")

    @property
    def key_proof(self):
        return binascii.hexlify(self._key_proof).decode("ascii")

    @property
    def key_proof_hash(self):
        return binascii.hexlify(self._key_proof_hash).decode("ascii")

    def process(self, other_public, salt, base64=False):
        context = self._context
        client_public, salt = int_from_hex(other_public), int_from_hex(salt)
        if client_public % context.prime == 0:
            raise ValueError("the iPhone's number is not usable")
        common = context.get_common_secret(self._public, client_public)
        premaster = context.get_server_premaster_secret(self._verifier, self._private, client_public, common)
        self._key = context.get_common_session_key(premaster)
        self._key_proof = context.get_common_session_key_proof(self._key, salt, self._public, client_public)
        self._key_proof_hash = context.get_common_session_key_proof_hash(self._key, self._key_proof, client_public)
        return self.key, self.key_proof, self.key_proof_hash

    def verify_proof(self, key_proof, base64=False):
        if isinstance(key_proof, str):
            key_proof = key_proof.encode("ascii")
        if self._key_proof is None:
            return False
        return secrets.compare_digest(binascii.unhexlify(key_proof), self._key_proof)
