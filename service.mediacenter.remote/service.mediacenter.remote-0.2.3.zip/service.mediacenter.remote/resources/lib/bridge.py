# The iPhone remote inside Kodi. The Docker remote is two programs on the box: the Apple TV look-alike
# (homebridge/mediacenter-apple-remote/mc_apple_remote.py) and the smart remote it asks over the network (Node). Here
# the first one runs in Kodi's own Python, unchanged, and its questions go straight to tvcontrol.py, the smart
# remote's Python port, which works the TV through Kodi itself. mc_apple_remote.py and the Apple TV code it uses are
# copied in when the add-on is packaged (scripts/build-kodi-repo.mjs); there is no second copy to keep in step.
#
# mediaCENTER talks to this service through Home window properties (none of them holds the pairing code):
#   mediacenter.remote.status   starting | on | off | in use | broken | missing  (what the remote is doing)
#   mediacenter.remote.paired   how many iPhones are paired
#   mediacenter.remote.pairing  when the pairing code stops working (seconds since 1970), while one is open
#   mediacenter.remote.ask      set by mediaCENTER: pair | on | off; the service clears it once done
#   mediacenter.remote.welcome  set by mediaCENTER every second (seconds since 1970) while a signed-out screen shows;
#                               while it is fresh, an iPhone that asks to pair with no code open gets one (0.4.9.3)
# The pairing code itself is only in the remote's own 0600 file (pairing-window.json in its state folder), which
# mediaCENTER reads to show it on the TV. It is never logged.

import asyncio
import json
import logging
import os
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
PACKAGED = HERE / "remote"
SOURCE = HERE.parents[3] / "homebridge" / "mediacenter-apple-remote" if len(HERE.parents) > 3 else PACKAGED

import shims  # noqa: E402
import tvcontrol  # noqa: E402

NAME = "mediaCENTER TV"
PORT = 49500  # the Docker remote's port too: while it still runs, this one says "in use" rather than start a second
ASK, STATUS, PAIRED, PAIRING, WELCOME = ("mediacenter.remote." + k for k in ("ask", "status", "paired", "pairing", "welcome"))
WELCOME_FRESH = 15  # seconds mediaCENTER's last "signed out" beat counts for (a closed app stops beating)
LOG = logging.getLogger("mediacenter-remote")


def load(force_stand_ins=False):
    """Make the copied remote importable; returns (mc_apple_remote, the stand-ins in use)."""
    folder = PACKAGED if (PACKAGED / "mc_apple_remote.py").exists() else SOURCE
    if str(folder) not in sys.path:
        sys.path.insert(0, str(folder))
    used = shims.install(force=force_stand_ins)
    import mc_apple_remote
    # the parts that use the libraries, now, so a missing part shows at start and not at the first iPhone
    import atvr4samsung.companion.protocol.auth  # noqa: F401
    import atvr4samsung.companion.protocol.chacha20  # noqa: F401
    import atvr4samsung.companion.protocol.support  # noqa: F401
    import atvr4samsung.companion.server  # noqa: F401
    import atvr4samsung.companion.discovery  # noqa: F401
    return mc_apple_remote, used


def kodi_caller(execute):
    """call(method, params) through Kodi's own JSON-RPC (xbmc.executeJSONRPC)."""
    def call(method, params=None):
        answer = json.loads(execute(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}})))
        if "error" in answer:
            raise RuntimeError("%s: %s" % (method, answer["error"].get("message", "error")))
        return answer.get("result")
    return call


def raised_at(error):
    """Where an error was raised, as "file.py line 12", for the log."""
    frames = traceback.extract_tb(error.__traceback__)
    return "%s line %d" % (os.path.basename(frames[-1].filename), frames[-1].lineno) if frames else "unknown place"


def kodi_tv(base, call, secret_codes=False):
    """mc_apple_remote.Tv, answered here instead of by the smart remote's web service."""

    class KodiTv(base):
        def __init__(self):
            super(KodiTv, self).__init__("http://this-box", "")
            self.remote = tvcontrol.Remote(call, secret_codes=secret_codes)
            self.typist = tvcontrol.Typist(call)

        def answer(self, path, body):
            if path == "/api/key":
                self.remote.key(body.get("key"))
            elif path == "/api/type":
                self.typist.type(body.get("text", ""), body.get("done", False))
            elif path == "/api/target":
                return {"online": True, "target": self.typist.where()}
            return {"ok": True}

        async def request(self, path, body=None, timeout=None):
            try:
                return 200, await asyncio.to_thread(self.answer, path, body or {})
            except tvcontrol.CantType as error:
                return 409, {"error": str(error)}
            except Exception as error:  # Kodi busy or closing; the next press tries again
                LOG.warning("The TV didn't answer (%s)", type(error).__name__)
                return 0, {}

    return KodiTv()


def welcoming(home, now=None):
    """True while mediaCENTER says a signed-out screen is showing (its beat is fresh)."""
    try:
        beat = float(home.getProperty(WELCOME) or 0)
    except ValueError:
        return False
    return 0 <= (now if now is not None else time.time()) - beat <= WELCOME_FRESH


def asking_store(folder, home, opened, clock=time.time):
    """The remote's pairing codes, kept as always, with one addition for a box that isn't signed in (owner, 2026-11-26):
    when an iPhone asks to pair (pair-setup's first message) and no code is open, one is opened there and then, so the
    TV shows it while the iPhone asks for it. Only while mediaCENTER says it is signed out; otherwise a code still needs
    Pair an iPhone. opened(window) is told (never the code itself goes anywhere but the remote's own file)."""
    from atvr4samsung import pairing_window as P

    class AskingStore(P.PairingWindowStore):
        def active_for_server(self, server_identifier, server_generation):
            if not P._is_valid_binding(server_identifier, server_generation):
                return None
            with self.transaction():
                found = self._active_for_server_locked(server_identifier, server_generation)
                if found is not None or not welcoming(home, clock()):
                    return found
                try:
                    found = self.open_locked(server_identifier=server_identifier, server_generation=server_generation,
                                             duration_seconds=P.DEFAULT_WINDOW_SECONDS)
                except Exception as error:
                    LOG.warning("No pairing code for the iPhone that asked (%s)", type(error).__name__)
                    return None
            LOG.info("An iPhone asked to pair; its code is showing on the TV")
            opened(found)
            return found

    return AskingStore(Path(folder), clock=clock)


class Service(object):
    """The remote: the Apple TV look-alike, its announcement on the network, pairing, and status for mediaCENTER."""

    def __init__(self, folder, call, home, announcer=None, port=PORT, detect_ip=None):
        self.folder, self.call, self.home, self.port = Path(folder), call, home, port
        self.announcer_factory, self.detect_ip = announcer, detect_ip
        self.bridge = self.announcer = self.module = None
        self.counted_at = 0
        self.secret_codes = False

    def say(self, status):
        self.home.setProperty(STATUS, status)

    async def start(self):
        self.say("starting")
        try:
            self.module, used = load()
        except Exception as error:
            LOG.warning("The remote could not load (%s)", type(error).__name__)
            self.say("missing")
            return False
        if used:
            LOG.info("Using the built-in stand-ins for: %s", ", ".join(used))
        m = self.module
        try:
            folder = m.state_folder(str(self.folder))
            store = asking_store(folder, self.home, self.opened)
            self.bridge = m.Bridge(kodi_tv(m.Tv, self.call, self.secret_codes), folder, NAME, port=self.port, announce=False,
                                   window_store=store)
            await self.bridge.start()
        except OSError as error:
            # The reason goes in kodi.log (a number, the system's words, a file name: never a pairing code).
            LOG.warning("The remote could not start (%s, errno %s: %s%s, %s)", type(error).__name__, error.errno,
                        error.strerror or error, " [%s]" % error.filename if error.filename else "", raised_at(error))
            self.bridge = None
            self.say("in use" if error.errno in (98, 48) else "broken")
            return False
        except Exception as error:
            LOG.warning("The remote could not start (%s, %s)", type(error).__name__, raised_at(error))
            self.bridge = None
            self.say("broken")
            return False
        from atvr4samsung.companion.discovery import companion_txt_records
        import mdns
        properties = companion_txt_records(identity_identifier=self.bridge.identity.identifier)
        make = self.announcer_factory or mdns.Announcer
        self.announcer = make(NAME, self.bridge.port, properties, self.detect_ip or m.local_ip)
        await self.announcer.start()
        self.say("on")
        self.count()
        return True

    async def stop(self):
        if self.announcer is not None:
            await self.announcer.close()
            self.announcer = None
        if self.bridge is not None:
            await self.bridge.stop()
            self.bridge = None
        self.home.clearProperty(PAIRING)

    def count(self):
        """How many iPhones are paired (shown in mediaCENTER)."""
        if self.bridge is None or self.bridge.state is None:
            return 0
        try:
            from atvr4samsung.companion.protocol.paired_clients import PairedClients
            with PairedClients(self.bridge.folder / "paired-clients.json") as clients:
                number = clients.count()
        except Exception:
            number = 0
        self.home.setProperty(PAIRED, str(number))
        return number

    def pair(self):
        """Open a five-minute pairing code for one new iPhone. Returns when it stops working."""
        window = self.module.open_pairing(self.bridge.folder)
        self.home.setProperty(PAIRING, str(int(window.expires_at)))
        return window.expires_at

    def opened(self, window):
        """A code the remote opened itself (an iPhone asked while signed out): said like one mediaCENTER asked for."""
        self.home.setProperty(PAIRING, str(int(window.expires_at)))

    def tick(self, now=None):
        """Every half second: forget an expired code; keep the count of paired iPhones current (quickly while a code
        is open, so mediaCENTER can say the iPhone paired)."""
        now = now or time.time()
        until = self.home.getProperty(PAIRING)
        if until and float(until) <= now:
            self.home.clearProperty(PAIRING)
        if self.bridge is not None and now - self.counted_at >= (1 if until else 30):
            self.counted_at = now
            self.count()


def state_folder(profile):
    return os.path.join(profile, "state")


async def run(service, settings, home, aborted, wait=asyncio.sleep):
    """The service's life: on unless switched off, and it does what mediaCENTER asks."""
    on = settings.get("enabled", "true") != "false"
    service.secret_codes = settings.get("secret_codes", "false") == "true"
    started = False
    if on:
        started = await service.start()
    else:
        service.say("off")
    try:
        while not aborted():
            ask = home.getProperty(ASK)
            if ask:
                home.clearProperty(ASK)
                if ask == "off" and on:
                    on = False
                    settings.set("enabled", "false")
                    await service.stop()
                    started = False
                    service.say("off")
                elif ask == "on" and not started:
                    on = True
                    settings.set("enabled", "true")
                    started = await service.start()
                elif ask == "pair":
                    if not started:
                        on = True
                        settings.set("enabled", "true")
                        started = await service.start()
                    if started:
                        try:
                            service.pair()
                        except Exception as error:
                            LOG.warning("No pairing code (%s)", type(error).__name__)
            if started:
                service.tick()
            await wait(0.5)
    finally:
        await service.stop()
