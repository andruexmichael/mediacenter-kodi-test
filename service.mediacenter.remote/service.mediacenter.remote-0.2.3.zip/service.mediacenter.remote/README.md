# mediaCENTER Remote (service.mediacenter.remote)

The iPhone's own Control Center remote and keyboard for a mediaCENTER box, run by Kodi itself: no Docker container,
no extra computer, nothing to install on the iPhone. It comes with the app and updates with it (0.4.7 and later).

## How it fits together
- `service.py` connects it to Kodi: JSON-RPC, the Home window, its on/off setting, its log and shutdown.
- `resources/lib/bridge.py` runs the Apple TV look-alike (`homebridge/mediacenter-apple-remote/mc_apple_remote.py`
  and its `vendor/` code, copied in by `scripts/build-kodi-repo.mjs`; there is no second copy) and answers it with
  `resources/lib/tvcontrol.py`, the smart remote's buttons and live typing ported to Python.
- `resources/lib/shims.py` puts plain-Python stand-ins (`purecrypto.py`, `hapsrp.py`) behind the crypto libraries the
  copied code imports, only where the real ones can't load (a Pi 3's Kodi has none). `mdns.py` announces the remote
  to iPhones on the Wi-Fi in place of the zeroconf library.
- mediaCENTER talks to it through Home window properties (listed in `bridge.py`). The pairing code is only in the
  remote's own 0600 file in its state folder; mediaCENTER reads it to show it on the TV. It is never logged.

## In mediaCENTER
- First-run setup, step 2, and Settings > Remotes and controllers > iPhone remote: Pair an iPhone shows a four-digit
  code on the TV for five minutes; the page says when the iPhone has paired. Turn the remote off or on there too.
- The power button opens the power menu (Power off: the TV off over HDMI, playback stopped, the box stays on; Set
  sleep timer: 15 minutes to 2 hours, a notice a minute before). The next power press turns the TV back on.
- The keyboard shows on the iPhone wherever Kodi asks for text (its keyboard or number pad, also under another
  dialog), and on mediaCENTER's Search; Return puts it away.

## Updates
`plugin.video.mediacenter` names this add-on as an optional part, so a box updating from 0.4.6 (whose updater doesn't
know it) still updates; the app's service then adds it from the same update list on its own (mc_updates.add_needed)
and turns it on. Later updates replace it like the other parts.

## Moving off the Docker remote
Both answer on port 49500, so while the Docker remote still runs this one waits ("in use"), and Settings shows how
to remove the old one (`docker rm -f mediacenter-remote` over SSH, then a restart). iPhones pair once more after.

## Tests
`python3 -m unittest discover -s kodi/tests_remote` (no installs needed; a pretend TV stands in for Kodi).
Not checked yet on a Pi 3 with a real iPhone: speed of the plain-Python crypto while pairing, and memory while video
plays.
