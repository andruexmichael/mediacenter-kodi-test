# How the iPhone finds the remote: a small Bonjour (multicast DNS) responder that announces one service,
# "<name>._companion-link._tcp.local." with Apple-TV-like TXT records, and answers the iPhone's questions about it.
# It stands in for the zeroconf library the Docker remote uses, with the same records (the copied
# companion/discovery.py's companion_txt_records) and the same record lifetimes. It shares port 5353 with the box's
# own Bonjour service (LibreELEC's Avahi), as zeroconf does. Nothing but these records is ever sent.

import asyncio
import logging
import time
import socket
import struct

GROUP = "224.0.0.251"
PORT = 5353
SERVICE = "_companion-link._tcp.local."
BROWSE = "_services._dns-sd._udp.local."
TTL = 4500  # the Docker remote's lifetime for every record (discovery._HOST_TTL_SECONDS)
A, PTR, TXT, SRV, ANY = 1, 12, 16, 33, 255
IN, FLUSH, UNICAST = 1, 0x8000, 0x8000
MAX_PACKET = 9000
LOG = logging.getLogger("mediacenter-remote")
REJOIN_AFTER = 300.0  # refresh multicast membership after a Wi-Fi reconnect


def encode_name(name):
    out = b""
    for label in name.rstrip(".").split("."):
        raw = label.encode("utf-8")[:63]
        out += bytes([len(raw)]) + raw
    return out + b"\x00"


def read_name(packet, offset, depth=0):
    """A name from a packet, following compression pointers. Returns (name, offset after it)."""
    labels, end = [], None
    while True:
        if offset >= len(packet) or depth > 20:
            raise ValueError("bad name")
        size = packet[offset]
        if size & 0xC0 == 0xC0:
            if offset + 1 >= len(packet):
                raise ValueError("bad name")
            pointer = ((size & 0x3F) << 8) | packet[offset + 1]
            if end is None:
                end = offset + 2
            offset, depth = pointer, depth + 1
            continue
        offset += 1
        if size == 0:
            break
        labels.append(packet[offset:offset + size].decode("utf-8", "replace"))
        offset += size
    return ".".join(labels) + ".", end if end is not None else offset


def questions(packet):
    """[(name, type, wants a direct answer)] from a query; [] for anything that isn't one."""
    if len(packet) < 12:
        return []
    flags, count = struct.unpack("!HH", packet[2:6])
    if flags & 0x8000:  # an answer, not a question
        return []
    out, offset = [], 12
    try:
        for _ in range(min(count, 50)):
            name, offset = read_name(packet, offset)
            qtype, qclass = struct.unpack("!HH", packet[offset:offset + 4])
            offset += 4
            out.append((name.lower(), qtype, bool(qclass & UNICAST)))
    except (ValueError, struct.error):
        return out
    return out


def record(name, rtype, data, ttl, unique):
    return encode_name(name) + struct.pack("!HHIH", rtype, IN | (FLUSH if unique else 0), ttl, len(data)) + data


def txt_data(properties):
    out = b""
    for key, value in properties.items():
        item = ("%s=%s" % (key, value)).encode("utf-8")[:255]
        out += bytes([len(item)]) + item
    return out or b"\x00"


class Announcement(object):
    """The records for one service."""

    def __init__(self, device_name, port, properties, address):
        self.instance = "%s.%s" % (device_name, SERVICE)
        self.host = self.instance  # what zeroconf picks for the Docker remote (ServiceInfo.set_server_if_missing)
        self.port, self.properties, self.address = port, properties, address

    def records(self, ttl=TTL):
        srv = struct.pack("!HHH", 0, 0, self.port) + encode_name(self.host)
        return {
            "ptr": record(SERVICE, PTR, encode_name(self.instance), ttl, False),
            "srv": record(self.instance, SRV, srv, ttl, True),
            "txt": record(self.instance, TXT, txt_data(self.properties), ttl, True),
            "a": record(self.host, A, socket.inet_aton(self.address), ttl, True),
            "browse": record(BROWSE, PTR, encode_name(SERVICE), ttl, False),
        }

    def answer(self, asked, ttl=TTL):
        """(answers, extras) for a list of questions; None when none of them is about this service."""
        records, answers = self.records(ttl), []
        instance, host = self.instance.lower(), self.host.lower()
        for name, qtype, _ in asked:
            if name == SERVICE.lower() and qtype in (PTR, ANY):
                answers.append("ptr")
            elif name == BROWSE.lower() and qtype in (PTR, ANY):
                answers.append("browse")
            elif name == instance and qtype in (SRV, TXT, ANY):
                answers += ["srv", "txt"] if qtype == ANY else ["srv" if qtype == SRV else "txt"]
            if name == host and qtype in (A, ANY):
                answers.append("a")
        if not answers:
            return None
        answers = list(dict.fromkeys(answers))
        extras = [k for k in ("srv", "txt", "a") if k not in answers and ("ptr" in answers or "srv" in answers)]
        return [records[k] for k in answers], [records[k] for k in extras]

    def everything(self, ttl=TTL):
        records = self.records(ttl)
        return [records[k] for k in ("ptr", "srv", "txt", "a", "browse")], []


def packet(answers, extras, ident=0, echo=b""):
    """A response. echo: the question section of a direct (unicast, not port 5353) query, which it repeats."""
    count = 1 if echo else 0
    head = struct.pack("!HHHHHH", ident, 0x8400, count, len(answers), 0, len(extras))
    return head + echo + b"".join(answers) + b"".join(extras)


def first_question(query):
    try:
        _, offset = read_name(query, 12)
        return query[12:offset + 4]
    except ValueError:
        return b""


class Responder(asyncio.DatagramProtocol):
    def __init__(self, announcement):
        self.announcement, self.transport = announcement, None

    def connection_made(self, transport):
        self.transport = transport

    def datagram_received(self, data, sender):
        asked = questions(data)
        if not asked:
            return
        reply = self.announcement.answer(asked)
        if reply is None:
            return
        answers, extras = reply
        if sender[1] != PORT:  # a one-shot question (not from a Bonjour service): answer it directly, with its id
            self.send(packet(answers, extras, struct.unpack("!H", data[:2])[0], first_question(data)), sender)
            return
        self.send(packet(answers, extras), (GROUP, PORT))
        if any(direct for _, _, direct in asked):
            self.send(packet(answers, extras), sender)

    def send(self, data, to):
        if self.transport is not None and len(data) <= MAX_PACKET:
            try:
                self.transport.sendto(data, to)
            except OSError:
                pass

    def announce(self, ttl=TTL):
        answers, extras = self.announcement.everything(ttl)
        self.send(packet(answers, extras), (GROUP, PORT))

    def error_received(self, exc):
        pass


def open_socket(address):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    if hasattr(socket, "SO_REUSEPORT"):
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        except OSError:
            pass
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 255)
    sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_LOOP, 1)
    sock.bind(("", PORT))
    try:
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(address))
    except OSError:
        pass
    membership = socket.inet_aton(GROUP) + socket.inet_aton(address)
    try:
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, membership)
    except OSError:
        sock.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, socket.inet_aton(GROUP) + socket.inet_aton("0.0.0.0"))
    sock.setblocking(False)
    return sock


class Announcer(object):
    """Announces the service while the remote runs, follows a change of the box's address, and says goodbye."""

    def __init__(self, device_name, port, properties, detect_ip, every=45.0, sleep=asyncio.sleep, opener=open_socket):
        self.device_name, self.port, self.properties = device_name, port, properties
        self.detect_ip, self.every, self.sleep, self.opener = detect_ip, every, sleep, opener
        self.transport = self.responder = self.task = None
        self.address = None
        self.opened_at = 0.0

    async def start(self):
        self.task = asyncio.get_running_loop().create_task(self.keep_up())

    def healthy(self):
        return (self.task is not None and not self.task.done()
                and self.transport is not None and not self.transport.is_closing())

    async def open(self, address):
        self.close_socket(goodbye=True)
        announcement = Announcement(self.device_name, self.port, self.properties, address)
        loop = asyncio.get_running_loop()
        self.transport, self.responder = await loop.create_datagram_endpoint(
            lambda: Responder(announcement), sock=self.opener(address))
        self.address = address
        self.opened_at = time.monotonic()
        for wait in (0, 1, 2):  # three announcements, a second or two apart, as Bonjour does
            await self.sleep(wait)
            self.responder.announce()

    async def keep_up(self):
        while True:
            try:
                address = self.detect_ip()
                if address != "0.0.0.0":
                    if (address != self.address or self.transport is None
                            or self.transport.is_closing()
                            or time.monotonic() - self.opened_at >= REJOIN_AFTER):
                        await self.open(address)
                    else:
                        # Refresh discovery even when the IP stays the same. An iPhone may
                        # have missed startup announcements while asleep or off Wi-Fi.
                        self.responder.announce()
            except Exception as error:
                # A transient address/socket failure must not silently kill discovery
                # while the TCP listener still makes the remote appear healthy.
                LOG.warning("Remote discovery retry (%s)", type(error).__name__)
                self.close_socket()
                self.address = None
            await self.sleep(self.every)

    def close_socket(self, goodbye=False):
        if self.responder is not None and goodbye:
            self.responder.announce(ttl=0)
        if self.transport is not None:
            self.transport.close()
        self.transport = self.responder = None

    async def close(self):
        if self.task is not None:
            task, self.task = self.task, None
            task.cancel()
            try:
                await task
            except BaseException as error:
                # Kodi can surface cancellation from a different embedded asyncio
                # module instance. Suppress that cancellation, not shutdown signals.
                if not isinstance(error, Exception) and type(error).__name__ != "CancelledError":
                    raise
        self.close_socket(goodbye=True)
