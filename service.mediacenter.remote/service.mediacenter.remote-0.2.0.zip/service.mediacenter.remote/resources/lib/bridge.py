# The iPhone remote inside Kodi. The Docker remote is two programs on the box: the Apple TV look-alike
# (homebridge/mediacenter-apple-remote/mc_apple_remote.py) and the smart remote it asks over the network (Node). Here
# the first one runs in Kodi's own Python, unchanged, and its questions go straight to tvcontrol.py, the smart
# remote's Python port, which works the TV through Kodi itself. mc_apple_remote.py and the Apple TV code it uses are
# copied in when the add-on is packaged (scripts/build-kodi-repo.mjs); there is no second copy to keep in step.
#
# mediaCENTER talks to this service through Home window properties (none of them holds the pairing code):
#   mediacenter.remote.status   starting | on | off | in use | broken | missing  (what the remote is doing)
#   mediacenter.remote.paired   how many iPhones are paired
#   mediacenter.remote.pairing  when the pairing code stops working (seconds since 1970), while one is open
#   mediacenter.remote.ask      set by mediaCENTER: pair | on | off; the service clears it once done
# The pairing code itself is only in the remote's own 0600 file (pairing-window.json in its state folder), which
# mediaCENTER reads to show it on the TV. It is never logged.

import asyncio
import json
import logging
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
PACKAGED = HERE / "remote"
SOURCE = HERE.parents[3] / "homebridge" / "mediacenter-apple-remote" if len(HERE.parents) > 3 else PACKAGED

import shims  # noqa: E402
import tvcontrol  # noqa: E402

NAME = "mediaCENTER TV"
PORT = 49500  # the Docker remote's port too: while it still runs, this one says "in use" rather than start a second
ASK, STATUS, PAIRED, PAIRING = ("mediacenter.remote." + k for k in ("ask", "status", "paired", "pairing"))
LOG = logging.getLogger("mediacenter-remote")


def load(force_stand_ins=False):
    """Make the copied remote importable; returns (mc_apple_remote, the stand-ins in use)."""
    folder = PACKAGED if (PACKAGED / "mc_apple_remote.py").exists() else SOURCE
    if str(folder) not in sys.path:
        sys.path.insert(0, str(folder))
    used = shims.install(force=force_stand_ins)
    import mc_apple_remote
    # the parts that use the libraries, now, so a missing part shows at start and not at the first iPhone
    import atvr4samsung.companion.protocol.auth  # noqa: F401
    import atvr4samsung.companion.protocol.chacha20  # noqa: F401
    import atvr4samsung.companion.protocol.support  # noqa: F401
    import atvr4samsung.companion.server  # noqa: F401
    import atvr4samsung.companion.discovery  # noqa: F401
    return mc_apple_remote, used


def kodi_caller(execute):
    """call(method, params) through Kodi's own JSON-RPC (xbmc.executeJSONRPC)."""
    def call(method, params=None):
        answer = json.loads(execute(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}})))
        if "error" in answer:
            raise RuntimeError("%s: %s" % (method, answer["error"].get("message", "error")))
        return answer.get("result")
    return call


def kodi_tv(base, call):
    """mc_apple_remote.Tv, answered here instead of by the smart remote's web service."""

    class KodiTv(base):
        def __init__(self):
            super(KodiTv, self).__init__("http://this-box", "")
            self.remote, self.typist = tvcontrol.Remote(call), tvcontrol.Typist(call)

        def answer(self, path, body):
            if path == "/api/key":
                self.remote.key(body.get("key"))
            elif path == "/api/type":
                self.typist.type(body.get("text", ""), body.get("done", False))
            elif path == "/api/target":
                return {"online": True, "target": self.typist.where()}
            return {"ok": True}

        async def request(self, path, body=None, timeout=None):
            try:
                return 200, await asyncio.to_thread(self.answer, path, body or {})
            except tvcontrol.CantType as error:
                return 409, {"error": str(error)}
            except Exception as error:  # Kodi busy or closing; the next press tries again
                LOG.warning("The TV didn't answer (%s)", type(error).__name__)
                return 0, {}

    return KodiTv()


class Service(object):
    """The remote: the Apple TV look-alike, its announcement on the network, pairing, and status for mediaCENTER."""

    def __init__(self, folder, call, home, announcer=None, port=PORT, detect_ip=None):
        self.folder, self.call, self.home, self.port = Path(folder), call, home, port
        self.announcer_factory, self.detect_ip = announcer, detect_ip
        self.bridge = self.announcer = self.module = None
        self.counted_at = 0

    def say(self, status):
        self.home.setProperty(STATUS, status)

    async def start(self):
        self.say("starting")
        try:
            self.module, used = load()
        except Exception as error:
            LOG.warning("The remote could not load (%s)", type(error).__name__)
            self.say("missing")
            return False
        if used:
            LOG.info("Using the built-in stand-ins for: %s", ", ".join(used))
        m = self.module
        folder = m.state_folder(str(self.folder))
        self.bridge = m.Bridge(kodi_tv(m.Tv, self.call), folder, NAME, port=self.port, announce=False)
        try:
            await self.bridge.start()
        except OSError as error:
            self.bridge = None
            self.say("in use" if getattr(error, "errno", None) in (98, 48) else "broken")
            return False
        except Exception as error:
            LOG.warning("The remote could not start (%s)", type(error).__name__)
            self.bridge = None
            self.say("broken")
            return False
        from atvr4samsung.companion.discovery import companion_txt_records
        import mdns
        properties = companion_txt_records(identity_identifier=self.bridge.identity.identifier)
        make = self.announcer_factory or mdns.Announcer
        self.announcer = make(NAME, self.bridge.port, properties, self.detect_ip or m.local_ip)
        await self.announcer.start()
        self.say("on")
        self.count()
        return True

    async def stop(self):
        if self.announcer is not None:
            await self.announcer.close()
            self.announcer = None
        if self.bridge is not None:
            await self.bridge.stop()
            self.bridge = None
        self.home.clearProperty(PAIRING)

    def count(self):
        """How many iPhones are paired (shown in mediaCENTER)."""
        if self.bridge is None or self.bridge.state is None:
            return 0
        try:
            from atvr4samsung.companion.protocol.paired_clients import PairedClients
            with PairedClients(self.bridge.folder / "paired-clients.json") as clients:
                number = clients.count()
        except Exception:
            number = 0
        self.home.setProperty(PAIRED, str(number))
        return number

    def pair(self):
        """Open a five-minute pairing code for one new iPhone. Returns when it stops working."""
        window = self.module.open_pairing(self.bridge.folder)
        self.home.setProperty(PAIRING, str(int(window.expires_at)))
        return window.expires_at

    def tick(self, now=None):
        """Every half second: forget an expired code; keep the count of paired iPhones current (quickly while a code
        is open, so mediaCENTER can say the iPhone paired)."""
        now = now or time.time()
        until = self.home.getProperty(PAIRING)
        if until and float(until) <= now:
            self.home.clearProperty(PAIRING)
        if self.bridge is not None and now - self.counted_at >= (1 if until else 30):
            self.counted_at = now
            self.count()


def state_folder(profile):
    return os.path.join(profile, "state")


async def run(service, settings, home, aborted, wait=asyncio.sleep):
    """The service's life: on unless switched off, and it does what mediaCENTER asks."""
    on = settings.get("enabled", "true") != "false"
    started = False
    if on:
        started = await service.start()
    else:
        service.say("off")
    try:
        while not aborted():
            ask = home.getProperty(ASK)
            if ask:
                home.clearProperty(ASK)
                if ask == "off" and on:
                    on = False
                    settings.set("enabled", "false")
                    await service.stop()
                    started = False
                    service.say("off")
                elif ask == "on" and not started:
                    on = True
                    settings.set("enabled", "true")
                    started = await service.start()
                elif ask == "pair":
                    if not started:
                        on = True
                        settings.set("enabled", "true")
                        started = await service.start()
                    if started:
                        try:
                            service.pair()
                        except Exception as error:
                            LOG.warning("No pairing code (%s)", type(error).__name__)
            if started:
                service.tick()
            await wait(0.5)
    finally:
        await service.stop()
