# mediaCENTER Remote: the iPhone's own Control Center remote and keyboard, run by Kodi itself (no Docker).
# Kodi starts this when the box starts. The work is in resources/lib/bridge.py; this file connects it to Kodi:
# its JSON-RPC, its Home window (where mediaCENTER asks for a pairing code), its settings, its log and its shutdown.

import asyncio
import logging
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("service.mediacenter.remote")
HERE = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
sys.path.insert(0, os.path.join(HERE, "resources", "lib"))

import bridge  # noqa: E402

LEVELS = {logging.DEBUG: xbmc.LOGDEBUG, logging.INFO: xbmc.LOGINFO, logging.WARNING: xbmc.LOGWARNING,
          logging.ERROR: xbmc.LOGERROR}


class KodiLog(logging.Handler):
    def emit(self, record):
        try:
            xbmc.log("[mediaCENTER Remote] " + record.getMessage(), LEVELS.get(record.levelno, xbmc.LOGINFO))
        except Exception:
            pass


class Settings(object):
    def get(self, key, default=""):
        return ADDON.getSetting(key) or default

    def set(self, key, value):
        ADDON.setSetting(key, value)


def main():
    root = logging.getLogger()
    root.handlers[:] = [KodiLog()]
    root.setLevel(logging.INFO)
    os.makedirs(PROFILE, exist_ok=True)
    home = xbmcgui.Window(10000)
    monitor = xbmc.Monitor()
    try:
        # 0.5.0.1 (owner, 2026-11-27: the remote stopped by itself and only a Kodi restart brought it back): if the
        # remote's loop ever ends with an error, the reason goes in kodi.log and it starts again 5 s later.
        while not monitor.abortRequested():
            service = bridge.Service(bridge.state_folder(PROFILE), bridge.kodi_caller(xbmc.executeJSONRPC), home)
            try:
                asyncio.run(bridge.run(service, Settings(), home, monitor.abortRequested))
                break
            except Exception as error:
                xbmc.log("[mediaCENTER Remote] The remote stopped (%s: %s, %s); starting it again in 5 s"
                         % (type(error).__name__, str(error)[:120], bridge.raised_at(error)), xbmc.LOGWARNING)
                if monitor.waitForAbort(5):
                    break
    finally:
        for key in (bridge.STATUS, bridge.PAIRING, bridge.ASK):
            home.clearProperty(key)


if __name__ == "__main__":
    main()
