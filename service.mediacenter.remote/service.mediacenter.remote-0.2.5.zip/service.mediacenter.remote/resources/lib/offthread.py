# Runs a blocking call on a plain thread and gives the asyncio loop a future for it, without asyncio's
# run_in_executor, to_thread or wrap_future.
#
# Why (0.5.0.1, the owner's box, 2026-11-27): Kodi runs each add-on's Python side by side in one process, and
# LibreELEC's own settings service uses asyncio too. Depending on which started first, asyncio's check that an
# executor's future "is a concurrent.futures.Future" failed in the remote ("concurrent.futures.Future is expected,
# got <Future ... state=running>"), the remote's loop died on its first call to Kodi, and the iPhone could no longer
# connect until Kodi was restarted (and sometimes not then). Nothing here checks the future's class.
import asyncio
import threading


def in_thread(fn, *args):
    """An asyncio future for fn(*args), run on a new daemon thread. Cancelling the future does not stop fn."""
    loop = asyncio.get_running_loop()
    future = loop.create_future()

    def settle(ok, value):
        if future.done():
            return
        if ok:
            future.set_result(value)
        else:
            future.set_exception(value)

    def work():
        try:
            value, ok = fn(*args), True
        except BaseException as error:  # handed to the waiting side, as run_in_executor does
            value, ok = error, False
        try:
            loop.call_soon_threadsafe(settle, ok, value)
        except RuntimeError:  # the loop closed while fn ran
            pass

    threading.Thread(target=work, name="mediacenter-remote-kodi", daemon=True).start()
    return future
