# mediaCENTER launcher: opens the app full screen (plugin.video.mediacenter/resources/lib/mc_app.py).
# The mediaCENTER skin runs this at start-up and whenever its Home is shown, so the box never shows anything else.
# It requires nothing but Python: plugin.video.mediacenter requires this launcher, never the other way round, so
# updates bring the newest launcher without the two depending on each other in a loop. The app's screens, settings
# and sign-in always come from plugin.video.mediacenter, named here and in mc_views, whoever started it.

import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

APP = "plugin.video.mediacenter"
PAGES = ("guide", "power")  # open=<page>: the iPhone remote's TV button asks for the Guide (mc_pages.PAGES), its
# power button for the power menu (mc_power.py), which opens over whatever is on the TV


def asked_page(argv):
    """open=guide or open=power in the arguments (Addons.ExecuteAddon params), or ''."""
    for arg in argv[1:]:
        key, _, value = str(arg).partition("=")
        if key == "open" and value in PAGES:
            return value
    return ""


def rpc(method, params):
    """Kodi's JSON-RPC from inside Kodi. The answer, or None when Kodi said no or answered oddly."""
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    except (RuntimeError, ValueError, TypeError):
        return None
    return answer if isinstance(answer, dict) and "error" not in answer else None


def app_state():
    """How Kodi has the app: "on", "off" (installed but switched off) or "missing"."""
    answer = rpc("Addons.GetAddonDetails", {"addonid": APP, "properties": ["enabled"]})
    result = answer.get("result") if answer else None
    addon = result.get("addon") if isinstance(result, dict) else None
    if not isinstance(addon, dict) or "enabled" not in addon:
        return "missing"
    return "on" if addon.get("enabled") else "off"


def switch_app_on():
    """0.4.9.2: an update can leave the app installed but switched off (the owner's Pi after 0.4.9), and Kodi then
    says "Unknown addon id". Switch it back on, have Kodi look again, and check. True when it is on."""
    for _ in range(3):
        rpc("Addons.SetAddonEnabled", {"addonid": APP, "enabled": True})
        xbmc.executebuiltin("UpdateLocalAddons", True)
        if app_state() == "on":
            return True
        xbmc.sleep(500)
    return False


def app_path():
    """The app's folder. When Kodi doesn't know the app, a switched-off app is switched back on ("Finishing the
    update…"); "still being set up" is said only when it isn't installed at all. None: it can't be opened now."""
    try:
        return xbmcvfs.translatePath(xbmcaddon.Addon(APP).getAddonInfo("path"))
    except RuntimeError:
        pass
    state = app_state()
    if state == "missing":
        # Not on the box: ask for the app from the box's repository, and say so in mediaCENTER's words.
        xbmc.executebuiltin("InstallAddon(%s)" % APP)
        xbmcgui.Dialog().ok("mediaCENTER", "mediaCENTER is still being set up. Try again in a minute.")
        return None
    xbmc.log("[mediaCENTER] the app was switched off; switching it on", xbmc.LOGINFO)
    progress = xbmcgui.DialogProgress()
    progress.create("mediaCENTER", "Finishing the update…")
    try:
        on = state == "on" or switch_app_on()
    finally:
        progress.close()
    if on:
        try:
            return xbmcvfs.translatePath(xbmcaddon.Addon(APP).getAddonInfo("path"))
        except RuntimeError:
            pass
    xbmcgui.Dialog().ok("mediaCENTER", "mediaCENTER couldn't finish its update. Restart the box to try again.")
    return None


def main():
    if xbmcgui.Window(10000).getProperty("mediacenter.update.stop"):
        return  # the skin can ask to reopen Home while the installer is closing it
    path = app_path()
    if not path:
        return
    sys.path.insert(0, os.path.join(path, "resources", "lib"))
    home = xbmcgui.Window(10000)
    home.clearProperty("mediacenter.launch.failed")
    try:
        page = asked_page(sys.argv)
        if page == "power":
            import mc_power  # noqa: E402
            return mc_power.open_menu()
        import mc_app  # noqa: E402
        mc_app.run(page) if page else mc_app.run()
    except Exception as error:
        # Keep account details and exception messages out of logs. Do not automatically retry a broken app.
        xbmc.log("[mediaCENTER] app stopped: %s" % type(error).__name__, xbmc.LOGERROR)
        home.setProperty("mediacenter.launch.failed", "1")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        if xbmc.getSkinDir() == "skin.mediacenter":
            xbmc.executebuiltin("ActivateWindow(Home)")
        else:
            xbmcgui.Dialog().ok("mediaCENTER", "Something went wrong. Open mediaCENTER to try again.")


if __name__ == "__main__":
    main()
