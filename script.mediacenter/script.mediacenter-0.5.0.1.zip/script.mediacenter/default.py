# mediaCENTER launcher: opens the app full screen (plugin.video.mediacenter/resources/lib/mc_app.py).
# The mediaCENTER skin runs this at start-up and whenever its Home is shown, so the box never shows anything else.
# It requires nothing but Python: plugin.video.mediacenter requires this launcher, never the other way round, so
# updates bring the newest launcher without the two depending on each other in a loop. The app's screens, settings
# and sign-in always come from plugin.video.mediacenter, named here and in mc_views, whoever started it.

import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

APP = "plugin.video.mediacenter"
PAGES = ("guide", "menu", "power", "search")  # open=<page>: the iPhone remote's TV button asks for the menu (one press)
# or the Guide (two quick presses; mc_pages.PAGES), its power button for the power menu (mc_power.py), which opens over
# whatever is on the TV, and its Siri button for Search with its keyboard (0.4.9.9)


def asked_page(argv):
    """open=guide, open=menu, open=power or open=search in the arguments (Addons.ExecuteAddon params), or ''."""
    for arg in argv[1:]:
        key, _, value = str(arg).partition("=")
        if key == "open" and value in PAGES:
            return value
    return ""


def rpc(method, params):
    """Kodi's JSON-RPC from inside Kodi. The answer, or None when Kodi said no or answered oddly."""
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    except (RuntimeError, ValueError, TypeError):
        return None
    return answer if isinstance(answer, dict) and "error" not in answer else None


def app_state():
    """How Kodi has the app: "on", "off" (installed but switched off) or "missing"."""
    answer = rpc("Addons.GetAddonDetails", {"addonid": APP, "properties": ["enabled"]})
    result = answer.get("result") if answer else None
    addon = result.get("addon") if isinstance(result, dict) else None
    if not isinstance(addon, dict) or "enabled" not in addon:
        return "missing"
    return "on" if addon.get("enabled") else "off"


def switch_app_on():
    """0.4.9.2: an update can leave the app installed but switched off (the owner's Pi after 0.4.9), and Kodi then
    says "Unknown addon id". Switch it back on, have Kodi look again, and check. True when it is on."""
    for _ in range(3):
        rpc("Addons.SetAddonEnabled", {"addonid": APP, "enabled": True})
        xbmc.executebuiltin("UpdateLocalAddons", True)
        if app_state() == "on":
            return True
        xbmc.sleep(500)
    return False


FORCED_GAP = 6 * 3600  # the launcher restarts the box to bring the app on at most this often, so it can't loop


def database_file():
    """Kodi's add-on table, the newest AddonsNN.db (Addons33.db in Kodi 20 and 21), or None."""
    import re
    folder = xbmcvfs.translatePath("special://database")
    try:
        names = [n for n in os.listdir(folder) if re.fullmatch(r"Addons\d{2,3}\.db", n)]
    except OSError:
        return None
    return os.path.join(folder, max(names, key=lambda n: int(n[6:-3]))) if names else None


def mark_app_on(path, connect=None):
    """0.4.9.6: when Kodi answers OK to switching the app on and it stays off (the owner's Pi after 0.4.9.3), mark it
    on in Kodi's add-on table, as the owner did by hand. Only when Kodi has it off for no reason or because it was
    switched off (never when Kodi found it can't run it). True when the table was changed: a restart brings it on."""
    if connect is None:
        import sqlite3
        connect = lambda p: sqlite3.connect(p, timeout=10)
    db = connect(path)
    try:
        where = "addonID=? AND enabled=0 AND disabledReason IN (0,1)"
        if not db.execute("SELECT 1 FROM installed WHERE " + where, (APP,)).fetchall():
            return False
        db.execute("UPDATE installed SET enabled=1, disabledReason=0 WHERE " + where, (APP,))
        db.commit()
        return True
    finally:
        db.close()


def restart_into_app(now=None):
    """Mark the app on and restart the box, at most once every FORCED_GAP. True when the restart was asked for."""
    import time
    now = time.time() if now is None else now
    profile = xbmcvfs.translatePath("special://profile/addon_data/script.mediacenter")
    note = os.path.join(profile, "forced-on.json")
    try:
        with open(note) as f:
            if now - float(json.load(f).get("at") or 0) < FORCED_GAP:
                return False
    except (OSError, ValueError, AttributeError, TypeError):
        pass
    path = database_file()
    try:
        if not path or not mark_app_on(path):
            return False
    except Exception as error:
        xbmc.log("[mediaCENTER] the app could not be marked on: %s" % type(error).__name__, xbmc.LOGINFO)
        return False
    try:
        os.makedirs(profile, exist_ok=True)
        with open(note, "w") as f:
            json.dump({"at": now}, f)
    except OSError:
        return False  # without the note a restart could repeat; leave it to the next start
    try:
        with open("/etc/os-release") as f:
            box = "ELEC" in f.read()
    except OSError:
        box = False
    xbmc.log("[mediaCENTER] the app was marked on; restarting to bring it in", xbmc.LOGINFO)
    xbmc.executebuiltin("Reboot" if box else "RestartApp")
    return True


def app_path():
    """The app's folder. When Kodi doesn't know the app, a switched-off app is switched back on ("Finishing the
    update…"); "still being set up" is said only when it isn't installed at all. None: it can't be opened now."""
    try:
        return xbmcvfs.translatePath(xbmcaddon.Addon(APP).getAddonInfo("path"))
    except RuntimeError:
        pass
    state = app_state()
    if state == "missing":
        # Not on the box: ask for the app from the box's repository, and say so in mediaCENTER's words.
        xbmc.executebuiltin("InstallAddon(%s)" % APP)
        xbmcgui.Dialog().ok("mediaCENTER", "mediaCENTER is still being set up. Try again in a minute.")
        return None
    xbmc.log("[mediaCENTER] the app was switched off; switching it on", xbmc.LOGINFO)
    progress = xbmcgui.DialogProgress()
    progress.create("mediaCENTER", "Finishing the update…")
    try:
        on = state == "on" or switch_app_on()
    finally:
        progress.close()
    if on:
        try:
            return xbmcvfs.translatePath(xbmcaddon.Addon(APP).getAddonInfo("path"))
        except RuntimeError:
            pass
    if restart_into_app():
        progress = xbmcgui.DialogProgress()
        progress.create("mediaCENTER", "Finishing the update… The box restarts in a moment.")
        return None
    xbmcgui.Dialog().ok("mediaCENTER", "mediaCENTER couldn't finish its update. Restart the box to try again.")
    return None


FAILED = "mediacenter.launch.failed"  # "" opening, "retrying" (opens again in a moment), "1" (stopped: OK on Home tries)
TRIES = "mediacenter.launch.tries"    # "<count> <first try's time>"
RUNNING = "mediacenter.app.open"      # mc_app.RUNNING: an app is open already
TRY_AGAIN = 3        # 0.4.9.9: times the launcher opens the app again by itself after it failed or closed at once
TRY_WINDOW = 600     # seconds those tries are counted over
QUICK_END = 10       # an app that closes this soon after opening counts as failed (no loop of quick opens)
ALARM = "mediacenteropen"


def note_try(home, now):
    """One more failed or short open; True while the launcher may open the app again by itself."""
    count, first = 0, now
    try:
        c, f = home.getProperty(TRIES).split()
        count, first = int(c), float(f)
    except ValueError:
        pass
    if now - first > TRY_WINDOW:
        count, first = 0, now
    count += 1
    home.setProperty(TRIES, "%d %s" % (count, first))
    return count <= TRY_AGAIN


def open_again(home, now, seconds):
    """0.4.9.9 (owner, 2026-11-26): no "Open mediaCENTER" menu. On the box the app is opened again by itself in a
    moment; after TRY_AGAIN tries in TRY_WINDOW it stops and Home says OK tries again."""
    if note_try(home, now):
        home.setProperty(FAILED, "retrying")
        xbmc.executebuiltin("CancelAlarm(%s,true)" % ALARM)
        xbmc.executebuiltin("AlarmClock(%s,RunScript(script.mediacenter),00:%02d,silent)" % (ALARM, seconds))
    else:
        home.setProperty(FAILED, "1")


def main():
    import time
    home = xbmcgui.Window(10000)
    if home.getProperty("mediacenter.update.installing"):
        return  # the skin can ask to open Home while the installer is putting new files in place
    if home.getProperty(FAILED) == "1":
        home.clearProperty(TRIES)  # OK on Home after the launcher stopped trying: a fresh set of tries
    path = app_path()
    if not path:
        return
    sys.path.insert(0, os.path.join(path, "resources", "lib"))
    home.clearProperty(FAILED)
    box = xbmc.getSkinDir() == "skin.mediacenter"
    page = asked_page(sys.argv)
    already = bool(home.getProperty(RUNNING))
    began = time.time()
    try:
        if page == "power":
            import mc_power  # noqa: E402
            return mc_power.open_menu()
        import mc_app  # noqa: E402
        mc_app.run(page) if page else mc_app.run()
    except Exception as error:
        # Keep account details and exception messages out of logs. On the box the app is opened again a few times.
        xbmc.log("[mediaCENTER] app stopped: %s" % type(error).__name__, xbmc.LOGERROR)
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        if box:
            open_again(home, time.time(), 5)
            xbmc.executebuiltin("ActivateWindow(Home)")
        else:
            home.setProperty(FAILED, "1")
            xbmcgui.Dialog().ok("mediaCENTER", "Something went wrong. Open mediaCENTER to try again.")
        return
    if not box or already or xbmc.Monitor().abortRequested() or home.getProperty("mediacenter.update.installing"):
        return  # off the box closing is allowed; an app already open, a restart or an update isn't a close
    # The app closed on the box: there is nothing behind it, so it opens again (after a quick close, a few times).
    if time.time() - began >= QUICK_END:
        home.clearProperty(TRIES)
    open_again(home, time.time(), 2)


if __name__ == "__main__":
    main()
