# mediaCENTER launcher: opens the app full screen (plugin.video.mediacenter/resources/lib/mc_app.py).
# The mediaCENTER skin runs this at start-up and whenever its Home is shown, so the box never shows anything else.
# It requires nothing but Python: plugin.video.mediacenter requires this launcher, never the other way round, so
# updates bring the newest launcher without the two depending on each other in a loop. The app's screens, settings
# and sign-in always come from plugin.video.mediacenter, named here and in mc_views, whoever started it.

import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

APP = "plugin.video.mediacenter"


def main():
    try:
        path = xbmcvfs.translatePath(xbmcaddon.Addon(APP).getAddonInfo("path"))
    except RuntimeError:
        # Mid-install: ask for the app from the box's repository, and say so in mediaCENTER's words.
        xbmc.executebuiltin("InstallAddon(%s)" % APP)
        xbmcgui.Dialog().ok("mediaCENTER", "mediaCENTER is still being set up. Try again in a minute.")
        return
    sys.path.insert(0, os.path.join(path, "resources", "lib"))
    home = xbmcgui.Window(10000)
    home.clearProperty("mediacenter.launch.failed")
    try:
        import mc_app  # noqa: E402
        mc_app.run()
    except Exception as error:
        # Keep account details and exception messages out of logs. Do not automatically retry a broken app.
        xbmc.log("[mediaCENTER] app stopped: %s" % type(error).__name__, xbmc.LOGERROR)
        home.setProperty("mediacenter.launch.failed", "1")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        if xbmc.getSkinDir() == "skin.mediacenter":
            xbmc.executebuiltin("ActivateWindow(Home)")
        else:
            xbmcgui.Dialog().ok("mediaCENTER", "Something went wrong. Open mediaCENTER to try again.")


if __name__ == "__main__":
    main()
