# mediaCENTER launcher: opens the app full screen (plugin.video.mediacenter/resources/lib/mc_app.py).
# The mediaCENTER skin runs this at start-up and whenever its Home is shown, so the box never shows anything else.
# It requires nothing but Python: plugin.video.mediacenter requires this launcher, never the other way round, so
# updates bring the newest launcher without the two depending on each other in a loop. The app's screens, settings
# and sign-in always come from plugin.video.mediacenter, named here and in mc_views, whoever started it.

import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

APP = "plugin.video.mediacenter"


def main():
    try:
        path = xbmcvfs.translatePath(xbmcaddon.Addon(APP).getAddonInfo("path"))
    except RuntimeError:
        # Mid-install: ask for the app from the box's repository, and say so in mediaCENTER's words.
        xbmc.executebuiltin("InstallAddon(%s)" % APP)
        xbmcgui.Dialog().ok("mediaCENTER", "mediaCENTER is still being set up. Try again in a minute.")
        return
    sys.path.insert(0, os.path.join(path, "resources", "lib"))
    import mc_app  # noqa: E402
    mc_app.run()


if __name__ == "__main__":
    main()
