# mediaCENTER for Kodi: opens the app full screen in mediaCENTER's own look (resources/lib/mc_app.py).
# Started from the add-on's entry in Kodi, and by service.py when Kodi starts (setting "Open mediaCENTER when Kodi starts").

import os
import sys

import xbmcaddon
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon("plugin.video.mediacenter").getAddonInfo("path")), "resources", "lib"))

import mc_app  # noqa: E402

if __name__ == "__main__":
    mc_app.run()
