# mediaCENTER for Kodi: the plugin's entry point. Kodi runs this once per screen or action, with
# sys.argv = [plugin address, handle, "?action=...&..."]; it picks the screen and draws it (resources/lib).

import os
import sys

import xbmcaddon
import xbmcvfs

HERE = xbmcvfs.translatePath(xbmcaddon.Addon("plugin.video.mediacenter").getAddonInfo("path"))
sys.path.insert(0, os.path.join(HERE, "resources", "lib"))

import mc_views as V  # noqa: E402
import mc_play as P  # noqa: E402
import mc_launch  # noqa: E402
from mc_api import SignedOut, ServerError  # noqa: E402

SCREENS = {
    "": V.root, "home": V.home, "row": V.row, "sports": V.sports, "game": V.game, "guide": V.guide, "live": V.live,
    "categories": V.categories, "category": V.category, "library": V.library, "mylist": V.mylist, "title": V.title,
    "season": V.season, "similar": V.similar, "search": V.search, "account": V.account, "mrow": V.mrow,
    "movies": lambda v: V.rows_page(v, "movie", V.MOVIE_ROWS), "shows": lambda v: V.rows_page(v, "series", V.SHOW_ROWS),
}
ACTIONS = {"signin": V.signin, "signout": V.signout, "pin": V.pin, "tvguide": V.tvguide,
           "settings": lambda v: V.ADDON.openSettings()}
PLAYERS = {"play": P.play, "play_live": P.play_live}


def run(argv):
    v = V.View(argv)
    action = v.params.get("action", "")
    if action == "" and len(argv) > 2 and not argv[2].strip("?"):
        # Opening mediaCENTER from Kodi's add-ons opens the app full screen (the lists below are its plumbing).
        V.xbmc.executebuiltin(mc_launch.open_app(HERE))
        return v.fail()
    if action == "menu":
        action = ""
    if action in PLAYERS:
        return PLAYERS[action](v)
    if action in ACTIONS:
        return ACTIONS[action](v)
    screen = SCREENS.get(action, V.root)
    if action and not v.api.signed_in:
        return V.root(v)
    try:
        screen(v)
    except SignedOut:
        v.api.forget()
        V.notify("Your session ended. Sign in again.")
        v.fail()
    except ServerError as e:
        V.log("screen %s failed: HTTP %s %s" % (action, e.status, e.code))
        V.notify("Couldn't load this right now. Try again in a moment.")
        v.fail()
    except OSError as e:
        V.log("screen %s failed: %s" % (action, type(e).__name__))
        V.notify("Can't reach mediaCENTER. Check this device's internet connection.")
        v.fail()


if __name__ == "__main__":
    run(sys.argv)
