# mediaCENTER for Kodi: scores while watching (0.4.9). While a channel plays full screen the menu key opens a narrow
# drawer down the right side with the scores (mediacenter-scores.xml, kodi/tools/sports_windows.py): your teams' games
# first, then the other live games, then the next ones to start. The picture keeps playing behind it; Back or the menu
# key closes it. OK on a game opens its stats page. The scores update every 30 seconds while the drawer is open.

import threading
import time

import xbmc
import xbmcgui

import mc_sports as S
import mc_views as V
import mc_pages as pages
from mc_api import SignedOut, ServerError

LIST = 50
CLOSE_KEYS = (9, 10, 92, 247, 117)  # back, and the menu key that opened it
REFRESH = 30
SHOWN = 14


def order(games, now=None):
    """What the drawer lists: live games (mine first, then close games), then the next games today, at most 14."""
    now = now or time.time()
    live = sorted([g for g in games if g.get("state") == "in"],
                  key=lambda g: (0 if g.get("mine") else 1, 0 if S.close_game(g) else 1))
    soon = sorted([g for g in games if g.get("state") == "pre" and (g.get("start") or 0) / 1000.0 - now < 12 * 3600],
                  key=lambda g: (0 if g.get("mine") else 1, g.get("start") or 0))
    return (live + soon)[:SHOWN]


def row(game, now=None):
    away, home = S.sides(game)
    li = xbmcgui.ListItem(game.get("title") or S.title(game), S.status(game, now))
    started = game.get("state") != "pre"
    li.setProperties({"id": str(game.get("id")), "league": game.get("leagueLabel") or "", "tag": S.tag(game, now),
                      "live": "1" if game.get("state") == "in" else "", "mine": "1" if game.get("mine") else "",
                      "away": ((away or {}).get("abbr") or "")[:4], "home": ((home or {}).get("abbr") or "")[:4],
                      "away.score": str((away or {}).get("score") or "") if started else "",
                      "home.score": str((home or {}).get("score") or "") if started else "",
                      "c1": S.zone_color(away) if away else "FF3A3A44", "c2": S.zone_color(home) if home else "FF3A3A44"})
    return li


class ScoresDrawer(xbmcgui.WindowXMLDialog):
    @classmethod
    def open(cls, api):
        w = cls("mediacenter-scores.xml", V.HERE, "Default", "1080i")
        w.api = api
        pages.modal(w)  # on the page stack, so the TV button closes it before the player under it
        w.closing = True
        chosen = getattr(w, "chosen", None)
        del w
        return chosen

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started, self.closing, self.shown, self.chosen = True, False, [], None
        self.fill()
        self.setFocusId(LIST)
        t = threading.Thread(target=self.keep_up)
        t.daemon = True
        t.start()

    def fill(self):
        import mc_sports_page as SP
        try:
            games, _ = SP.load(self.api)
        except (ServerError, SignedOut, OSError):
            games = None
        control = self.getControl(LIST)
        pos = control.getSelectedPosition() if control.size() else 0
        control.reset()
        if games is None:
            self.shown = []
            return self.setProperty("empty", "Couldn't load the scores right now.")
        now = time.time()
        self.shown = order(games, now)
        control.addItems([row(g, now) for g in self.shown])
        if self.shown:
            self.clearProperty("empty")
            control.selectItem(min(pos, len(self.shown) - 1))
        else:
            self.setProperty("empty", "No games on right now.")
        self.setProperty("counts", S.counts(games))

    def keep_up(self):
        monitor = xbmc.Monitor()
        while not self.closing and not monitor.waitForAbort(REFRESH):
            if self.closing:
                return
            V.drop_cache("sports-active")
            V.drop_cache("sports")
            self.fill()

    def onClick(self, control_id):
        if control_id == LIST:
            i = self.getControl(LIST).getSelectedPosition()
            if 0 <= i < len(self.shown):
                self.chosen = self.shown[i]
                self.closing = True
                self.close()

    def onAction(self, action):
        if action.getId() in CLOSE_KEYS:
            self.closing = True
            self.close()


def open_over(player):
    """The player's hook (mc_player.PlayerPage, live channels only): the drawer, then a chosen game's stats page."""
    game = ScoresDrawer.open(player.api)
    if game is not None:
        import mc_sports_page as SP
        SP.GamePage.open(player.api, game, over=True)
