# mediaCENTER for Kodi: the iPhone remote built into the box (the add-on service.mediacenter.remote), as Settings and
# first-run setup show it. The remote is a separate service that runs while Kodi runs; the two talk through Home window
# properties (service.mediacenter.remote/resources/lib/bridge.py has the list). The pairing code is never in one of
# them: it is only in the remote's own file (pairing-window.json, readable by this box's Kodi only), which is read here
# to show the code on the TV while the iPhone pairing page is open. It is never logged.

import json
import time

ASK, STATUS, PAIRED, PAIRING = ("mediacenter.remote." + k for k in ("ask", "status", "paired", "pairing"))
CODE_FILE = "special://profile/addon_data/service.mediacenter.remote/state/pairing-window.json"
DOCKER = "docker rm -f mediacenter-remote"
ADDON = "service.mediacenter.remote"
MISSING = "The iPhone remote isn't on this box yet. Choose Settings, Software update, then Check for updates."
STUCK = "Kodi didn't switch the remote on. Restart the box and try again."


def _rpc(execute, method, params):
    try:
        answer = json.loads(execute(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    except (RuntimeError, ValueError, TypeError):
        return None
    return answer if isinstance(answer, dict) else None


def addon_state(execute):
    """How Kodi has the remote add-on: "on", "off" (installed but switched off), "missing", or "" when Kodi won't say."""
    answer = _rpc(execute, "Addons.GetAddonDetails", {"addonid": ADDON, "properties": ["enabled"]})
    if answer is None:
        return ""
    if "error" in answer:
        return "missing"
    result = answer.get("result")
    addon = result.get("addon") if isinstance(result, dict) else None
    if not isinstance(addon, dict):
        return ""
    return "on" if addon.get("enabled") else "off"


def switch_on(execute):
    """Switch the remote add-on on in Kodi when it is installed but off (seen on a box after its first copy, where it
    was never switched on). Returns how Kodi has it afterwards."""
    found = addon_state(execute)
    if found != "off":
        return found
    _rpc(execute, "Addons.SetAddonEnabled", {"addonid": ADDON, "enabled": True})
    return addon_state(execute)


def ask(window, what):
    """Ask the remote for something: pair (a new pairing code), on or off."""
    window.setProperty(ASK, what)


def paired(window):
    try:
        return max(0, int(window.getProperty(PAIRED) or 0))
    except ValueError:
        return 0


def state(window):
    return window.getProperty(STATUS) or ""


def summary(window, addon=""):
    """The short line under "iPhone remote". addon: addon_state(), used when the remote itself says nothing."""
    s, n = state(window), paired(window)
    if s == "on":
        return "On, %d iPhone%s paired" % (n, "" if n == 1 else "s") if n else "On, no iPhone paired yet"
    return {"off": "Off", "starting": "Starting…", "in use": "Waiting for the old remote to be removed",
            "broken": "Not working right now", "missing": "Not working right now"}.get(
                s, {"off": "Switched off", "missing": "Not installed"}.get(addon, "Not running"))


def explain(window, addon=""):
    """What the iPhone remote page says about it, on the right."""
    s = state(window)
    steps = ("Use your iPhone's own remote and keyboard with this box, with nothing to install on the iPhone.\n\n"
             "1. Choose Pair an iPhone. A four-digit code shows here.\n"
             "2. On the iPhone, open Control Center and tap the remote.\n"
             "3. At the top, choose mediaCENTER TV, then type the code.\n\n"
             "The iPhone needs to be on the same Wi-Fi as this box.")
    if s == "in use":
        return ("The remote that ran in Docker on this box is still running, so this one can't start.\n\n"
                "Remove the old one over SSH with:\n%s\n\nthen restart the box. You'll pair your iPhone once more." % DOCKER)
    if s in ("broken", "missing"):
        return "The iPhone remote couldn't start. Restart the box and try again.\n\n" + steps
    if s == "":
        if addon == "missing":
            return MISSING
        if addon == "off":
            return "The iPhone remote is switched off on this box. Choose Pair an iPhone to switch it on."
        return "The iPhone remote hasn't started on this box. Choose Pair an iPhone, or restart the box."
    return steps


def read_code(path, now=None):
    """(the four-digit code, when it stops working) from the remote's file, or None when no code is open."""
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        pin, until = str(data.get("pin", "")), float(data.get("expires_at", 0))
    except (OSError, ValueError, TypeError, AttributeError):
        return None
    if len(pin) != 4 or not pin.isdigit() or until <= (now or time.time()):
        return None
    return pin, until


def spaced(pin):
    return " ".join(pin)


def until_text(until):
    clock = time.strftime("%I:%M %p", time.localtime(until)).lstrip("0")
    return "Works until %s" % clock
