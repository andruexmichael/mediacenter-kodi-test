# mediaCENTER for Kodi: signing in with a phone (src/ba-device-pairing.js). The TV asks for a code, draws the QR code
# itself (mc_qr, so no QR service sees the code), and asks every few seconds until the phone has approved it; then the
# answer carries this TV's own session. The short code can only approve; only the long device code, which never leaves
# the TV, can collect the session.

import binascii
import json
import os

import mc_qr
from mc_api import cookie_from_headers, ServerError, SignedOut

QR_PREFIX = "device-sign-in-"  # a new file name for every code: Kodi keeps pictures by name, so a reused name shows the old code


def start(api, folder):
    """A new code: {userCode, verificationUri, deviceCode, expiresIn, interval, image (the QR code's PNG on the box)}."""
    data = api.call("POST", "/access/device/start", body={})
    if not isinstance(data, dict) or data.get("verificationUri") != api.base + "/access/device":
        raise ValueError("unexpected sign-in address")
    code = str(data.get("userCode", ""))
    if len(code) != 9 or code[4] != "-" or not code.replace("-", "").isalnum():
        raise ValueError("unexpected code")
    forget(folder)
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, QR_PREFIX + binascii.hexlify(os.urandom(6)).decode() + ".png")
    with open(path, "wb") as f:
        f.write(mc_qr.png(mc_qr.encode(data["verificationUri"] + "#" + code)))
    data["image"] = path
    data["address"] = data["verificationUri"].split("://", 1)[-1]
    return data


def poll(api, device_code):
    """'pending', 'expired' or 'approved' (then the Api holds the new session, saved like a typed sign-in)."""
    status, raw, headers = api.raw("POST", "/access/device/poll", body={"deviceCode": device_code}, timeout=15)
    if status in (202, 429):
        return "pending"
    if status == 410:
        return "expired"
    if status in (401, 403):
        raise SignedOut()
    if status != 200:
        raise ServerError(status, "")
    data = json.loads(raw.decode("utf-8"))
    cookie = cookie_from_headers(headers.get_all("Set-Cookie") if headers is not None and hasattr(headers, "get_all") else [])
    if not cookie or not data.get("username"):
        raise ValueError("no session in the answer")
    api.cookie, api.username = cookie, data["username"]
    if getattr(api, "session", None):
        api.session.save({"cookie": cookie, "username": api.username})
    return "approved"


def forget(folder):
    """The QR pictures go once the code is used or abandoned."""
    try:
        names = os.listdir(folder)
    except OSError:
        return
    for name in names:
        if name.startswith(QR_PREFIX) and name.endswith(".png"):
            try:
                os.remove(os.path.join(folder, name))
            except OSError:
                pass
