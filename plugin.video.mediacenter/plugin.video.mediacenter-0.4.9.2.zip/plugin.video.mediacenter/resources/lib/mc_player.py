# mediaCENTER for Kodi: the player, in mediaCENTER's own screen (0.4.5).
#
# Every movie, episode and channel plays here, never through Kodi's own player screens:
#   - a loading screen like the web's TitleLoading (web-v27/js/player.js): the steps with how far along it is, and a
#     rotating line from design/experience.json "loading";
#   - each link is checked before the player opens it (mc_api.link_works / live_plays), links that failed on this box
#     are remembered (mc_versions.FailedLinks) and the next source is tried by itself, as web-v27/js/playvod.js does;
#   - Kodi's "One or more items failed to play" box is closed before it shows; mediaCENTER says what happened and
#     offers what to do next;
#   - controls like the web player and the Roku's PlayerScreen: title and clock at the top, the bar and the buttons at
#     the bottom, Left/Right to skip 10 seconds; Up Next after an episode.
#
# The picture is drawn by a videowindow control in this page (windowed playback), so the page that opened the player
# stays where it was underneath: Back after a film or a channel returns to the same title page or Guide position (owner,
# 2026-11-25: it used to drop to Home). The Guide uses the same Playback for its mini player.
#
# On a box that draws video on its own layer (a Raspberry Pi, "Direct to plane"), Kodi places the picture once, when a
# video opens, from where a shown video control last drew; mc_picture makes sure that is full screen first (0.4.9.2:
# the first video after Kodi started played sound over black).
#
# Progress is saved by service.py as before: PLAYING_KEY says what is playing and where to start.

import json
import os
import threading
import time

try:
    import queue
except ImportError:  # pragma: no cover
    import Queue as queue

import xbmc
import xbmcgui

import mc_logic as L
import mc_versions as MV
import mc_picture as MP
import mc_views as V
import mc_pages as pages
import mc_watching as W
from mc_api import SignedOut, ServerError

# The web's loading steps (player.js TitleLoading), as (percent, words).
STAGES = [(0, "Finding your title"), (15, "Checking the available links"), (25, "Picking the best source"),
          (40, "Connecting to the stream"), (65, "Buffering the first scenes"), (90, "Starting playback")]
LIVE_STAGES = [(0, "Finding the channel"), (15, "Checking the feed"), (40, "Connecting to the stream"),
               (65, "Buffering"), (90, "Starting playback")]
START_WAIT = 45  # seconds the last link to try gets to show a picture
NEXT_WAIT = 20  # seconds a link gets when there are others behind it (owner, 2026-11-26: move on to a working one quickly)
PICTURE_WAIT = 4  # seconds after the sound starts for a movie's or episode's picture track to show up
HUD_SECONDS = 5
SCRUB_HUD_SECONDS = 10  # the controls stay up longer while a time is picked on the timeline
SCRUB_GAP = 0.8  # presses closer together than this count as one run, and the step grows (ScrubStepper)
SCRUB_AUTO = 1.2  # the fast-forward and rewind keys jump to the picked time by themselves this long after the last press
UP_NEXT_SECONDS = 10
CACHE_SECONDS = 600  # versions found for a title are reused for 10 minutes (the versions page and the player share them)

VOD_FAILED = "This version didn't start."
LIVE_FAILED = "This channel isn't playing right now."

# Kodi action ids
LEFT, RIGHT, UP, DOWN, SELECT = 1, 2, 3, 4, 7
BACK = (9, 10, 92, 247)
PAUSE, STOP, NEXT_ITEM, PREV_ITEM, FORWARD, REWIND, PLAYPAUSE, PLAY = 12, 13, 14, 15, 77, 78, 229, 68
MENU_KEYS = (11, 117)  # info, context menu
SCORES_KEY = 117  # on a live channel the menu key opens the scores instead of the controls (0.4.9, mc_scores)

# Control ids in mediacenter-player.xml (kodi/tools/make_windows.py player_window). The controls, left to right
# (owner, 2026-11-26): Play/Pause first, -10 s beside it, no +10 s button (Right still skips 10 s with the controls
# hidden), then Next Episode, Episodes (0.4.9), Audio, Subtitles, Versions.
HUD = 600
B_BACK10, B_PLAYPAUSE, B_NEXT, B_AUDIO, B_SUBS, B_VERSIONS, B_EPISODES = 601, 602, 604, 605, 606, 607, 608
SCRUB, SCRUB_BAR = 610, 611  # the timeline (focus it with Up from the buttons) and the bar that shows the picked time
ERR = 700
E_OTHER, E_RETRY, E_NEXT, E_CLOSE = 701, 702, 703, 704
ASK = 800
A_RESUME, A_START = 801, 802
UPNEXT = 900
U_PLAY, U_CANCEL = 901, 902

HOME_PROPS = ("mc.dock", "mc.full")
FOCUS_TRIES = 20  # Kodi ignores focus on a control that is still hidden: a new layer shows only on the next frame
FOCUS_STEP = 0.05
KODI_PAUSE_WAIT = 0.8  # seconds Kodi gets to pause by itself before the page does (PlayerPage.kodi_paused)
# What a player hands on with its picture (PlayerPage.picture), so the full screen opened again from the Guide's mini
# player knows the title, its versions and the next episode.
CARRIED = ("mode", "kind", "tmdb", "season", "episode", "pick", "fresh", "t", "versions", "others", "feeds", "episode_name",
           "channel_id", "channel_name", "alts", "now_title", "eps_cache")


# ---- pure helpers (tested off the box) ---------------------------------------------------------------------------------

class ScrubStepper(object):
    """How far one Left/Right press on the timeline, or one fast-forward/rewind press, moves the picked time: 10 s at
    first, then 30, 60 and 120 s the more presses come in a row. The same rule as Apple TV (tvos/Sources/ScrubStepper.swift)."""

    def __init__(self, now=time.time):
        self.now = now
        self.reset()

    def step(self, forward):
        at = self.now()
        self.streak = self.streak + 1 if at - self.last < SCRUB_GAP else 0
        self.last = at
        size = 10 if self.streak < 2 else 30 if self.streak < 5 else 60 if self.streak < 9 else 120
        return size if forward else -size

    def reset(self):
        self.streak, self.last = 0, -1e9


def clock(seconds):
    t = int(max(0, seconds))
    return "%d:%02d:%02d" % (t // 3600, t // 60 % 60, t % 60) if t >= 3600 else "%02d:%02d" % (t // 60, t % 60)


def stage_text(stages, pct):
    """The step a percentage is at, and every step marked done, now or to come (✓ ● ○ on the screen)."""
    current = 0
    for i, (p, _) in enumerate(stages):
        if pct >= p:
            current = i
    return [(words, "done" if i < current else "now" if i == current else "todo") for i, (_, words) in enumerate(stages)]


MARK = {"done": u"✓", "now": u"●", "todo": u"○"}


def loading_lines(kind):
    lines = ((V.experience().get("loading") or {}).get("live" if kind == "live" else "movie") or {}).get("lines") or []
    return lines or [u"Starting in a moment…"]


def next_episode(season, episode, episodes_of, seasons):
    """The episode after (season, episode): the next in the season, else the next season's first. episodes_of(n) gives
    that season's episode numbers (aired ones only). Returns (season, episode) or None."""
    eps = sorted(int(n) for n in episodes_of(season) or [])
    later = [n for n in eps if n > int(episode)]
    if later:
        return int(season), later[0]
    for s in sorted(int(x) for x in seasons or []):
        if s > int(season):
            nxt = sorted(int(n) for n in episodes_of(s) or [])
            if nxt:
                return s, nxt[0]
    return None


def number(value):
    """A season or episode number from the server ("2", 2, None) as an int; 0 when it isn't one."""
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def play_target(history, tmdb, seasons):
    """What Play does on a show's page, as on the web (vod.js): the episode left part-way ("Resume S1 E2"), else the one
    after the last one finished ("Play S1 E3"), else the first ("Play S1 E1"). Returns (label, season, episode, resume)."""
    first = (sorted(int(s) for s in seasons or [1]) or [1])[0]
    rows = [h for h in history or [] if str(h.get("seriesId") or "") == "tmdb-%s" % tmdb and h.get("season") is not None]
    if not rows:
        return "Play S%d E1" % first, first, 1, False
    last = max(rows, key=lambda h: (L.when_seconds(h.get("updatedAt")), number(h.get("season")), number(h.get("episode"))))
    s, e = int(last["season"]), int(last["episode"])
    if not last.get("finished") and float(last.get("position") or 0) >= 30:
        return "Resume S%d E%d" % (s, e), s, e, True
    if last.get("finished"):
        return "Play S%d E%d" % (s, e + 1), s, e + 1, False
    return "Play S%d E%d" % (s, e), s, e, False


def split_versions(versions, caps):
    """(versions this box plays, best first; versions it may not play)."""
    ranked, _ = L.rank_versions(versions, caps)
    others = [v for v in versions or [] if L.play_level(v, caps) == "no"]
    return ranked, others


_found = {}


def found_versions(api, kind, tmdb, season=None, episode=None, now=time.time):
    """Every version of a title (mc_play.gather), kept for 10 minutes so the versions page and the player agree."""
    import mc_play
    key = (kind, str(tmdb), str(season or ""), str(episode or ""))
    hit = _found.get(key)
    if hit and now() - hit[0] < CACHE_SECONDS:
        return hit[1], hit[2]
    versions, name = mc_play.gather(api, kind, tmdb, season, episode)
    _found[key] = (now(), versions, name)
    return versions, name


def forget_found():
    _found.clear()


def busy(on):
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)" if on else "Dialog.Close(busydialognocancel)")


def failed_links():
    return MV.FailedLinks(V.PROFILE)


def check_answer(answer):
    """A link check's answer as (True|False|None, why): link_works gives a pair, live_plays a bare answer."""
    if isinstance(answer, tuple):
        return answer[0], (answer[1] if len(answer) > 1 else "")
    return answer, ""


# ---- Playback: one try after another, with Kodi's own messages kept off the screen ---------------------------------------

def kodi_setting(key):
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
                                                            "params": {"setting": key}})) or "{}")
        return (answer.get("result") or {}).get("value", "?") if isinstance(answer.get("result"), dict) else "?"
    except (ValueError, TypeError, AttributeError):
        return "?"


def describe_picture():
    """One line in kodi.log on how Kodi decodes and draws what is playing (no link, only the formats), so a black
    picture can be told apart from a slow decoder: e.g. "h264 1920x1080, decoder v4l2m2m-h264 (hardware), drm_prime"."""
    def later():
        time.sleep(2)
        info = lambda k: str(xbmc.getInfoLabel(k) or "")
        hw = xbmc.getCondVisibility("Player.Process(videohwdecoder)")
        V.log("picture: %s %sx%s, decoder %s (%s), %s, %s fps" % (
            info("VideoPlayer.VideoCodec") or "?", info("Player.Process(videowidth)") or "?", info("Player.Process(videoheight)") or "?",
            info("Player.Process(videodecoder)") or "?", "hardware" if hw else "software", info("Player.Process(pixformat)") or "?",
            info("Player.Process(videofps)") or "?"))
        V.log("video settings: %s" % ", ".join("%s=%s" % (k.split(".")[-1], kodi_setting(k)) for k in
                                              ("videoplayer.useprimedecoder", "videoplayer.useprimerenderer", "videoplayer.usev4l2m2mdecoder")))
    th = threading.Thread(target=later)
    th.daemon = True
    th.start()


LAST_PLAY = {"by": None}  # the Playback that last asked Kodi to play (every Watcher hears every playback's events)


class Watcher(xbmc.Player):
    def __init__(self, owner):
        super(Watcher, self).__init__()
        self.owner = owner
        self.toggled_at = 0.0  # when Kodi last paused or resumed (PlayerPage.kodi_paused)

    def onPlayBackPaused(self):
        self.toggled_at = time.time()

    def onPlayBackResumed(self):
        self.toggled_at = time.time()

    def onAVStarted(self):
        if self.owner.cancelled and LAST_PLAY.get("by") is self.owner:
            # Back (or Close) came while Kodi was still opening this link: Kodi starts it a moment later all the same,
            # and the sound played on with nothing on screen (owner, 2026-11-26). Stop it now.
            try:
                self.stop()
            except RuntimeError:
                pass
            return
        self.owner.event("started")

    def onPlayBackError(self):
        self.owner.event("error")

    def onPlayBackStopped(self):
        self.owner.event("stopped")

    def onPlayBackEnded(self):
        self.owner.event("ended")


def close_kodi_messages():
    """Kodi's own "failed to play" box and its busy spinner: closed as soon as they appear (the rig showed this keeps
    them off the screen). Returns True when the failure box was there."""
    seen = False
    if xbmc.getCondVisibility("Window.IsActive(okdialog)"):
        xbmc.executebuiltin("Dialog.Close(okdialog,true)")
        seen = True
    if xbmc.getCondVisibility("Window.IsActive(busydialog)"):
        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
    return seen


class Playback(object):
    """Plays a list of feeds in order until one shows a picture. ui gets: stage(pct, words, detail), toast(words),
    started(feed), failed(), ended(), stopped(). Feeds are dicts: url, li, key (for FailedLinks), check (a function
    giving True/False/None, or None to skip the check), entry (what service.py saves, or None), resume."""

    def __init__(self, ui, windowed=True):
        self.ui = ui
        self.windowed = windowed
        self.q = queue.Queue()
        self.player = Watcher(self)
        self.cancelled = False
        self.playing = None  # the feed that is showing
        self.thread = None
        self.remembered = []

    def event(self, name):
        self.q.put(name)

    def drain(self):
        while True:
            try:
                self.q.get_nowait()
            except queue.Empty:
                return

    def start(self, feeds, stages=STAGES):
        if self.cancelled:
            return  # stopped (Back) before its links were known: it must not start afterwards
        self.thread = threading.Thread(target=self.run, args=(list(feeds), stages))
        self.thread.daemon = True
        self.thread.start()

    def stop(self):
        """Stop playing and stop trying (Back, Close, leaving the Guide). A link Kodi is still opening is stopped too:
        play() only queues the link, so Watcher.onAVStarted stops it again if it starts after Back."""
        self.cancelled = True
        self.playing = None
        if LAST_PLAY["by"] not in (None, self):
            return  # another Playback asked Kodi to play after this one: the player is its now
        V.WINDOW.clearProperty(V.PLAYING_KEY)
        try:
            # Always: a link Kodi is still opening isn't "playing" yet, and it would start after Back.
            self.player.stop()
        except RuntimeError:
            pass

    def remember(self, feed, why):
        if feed.get("key"):
            failed_links().remember(feed["key"], why)
            self.remembered.append(feed["key"])

    def precheck(self, feeds):
        """Every link's check at once (each takes up to 8 s), so a dead link further down is already known when its
        turn comes and the player goes straight past it. Returns a list of Events, each set once that check is done."""
        done = []
        for feed in feeds:
            ev = threading.Event()
            done.append(ev)
            check = feed.get("check")
            if check is None:
                ev.set()
                continue

            def ask(f=feed, e=ev, c=check):
                try:
                    f["checked"] = c()
                except Exception:
                    f["checked"] = None
                e.set()
            th = threading.Thread(target=ask)
            th.daemon = True
            th.start()
        return done

    def run(self, feeds, stages):
        n = len(feeds)
        checks = self.precheck(feeds)
        for i, feed in enumerate(feeds):
            if self.cancelled:
                return
            if feed.get("check") is not None:
                self.ui.stage(stages[1][0], stages[1][1], "%d of %d" % (i + 1, n) if n > 1 else "")
                while not checks[i].wait(0.1):
                    if self.cancelled:
                        return
                ok, why = check_answer(feed.get("checked"))
                if ok is False:
                    V.log("link %d of %d does not answer (%s); next" % (i + 1, n, why or "dead"))
                    self.remember(feed, why or "dead")
                    continue
            if i:
                self.ui.toast("Trying the next source")
            result = self.try_one(feed, stages, NEXT_WAIT if i < n - 1 else START_WAIT)
            if result == "started":
                return self.watch(feed)
            if self.cancelled:
                return
            V.log("link %d of %d did not start (%s)" % (i + 1, n, result))
            self.remember(feed, {"failed": "couldn't be played", "no picture": "no picture"}.get(result, "temporary"))
        if not self.cancelled:
            self.ui.failed()

    def try_one(self, feed, stages, wait=START_WAIT):
        if self.windowed:
            V.WINDOW.clearProperty(V.PLAYING_KEY)  # the clip mc_picture may play is nothing service.py should save
            MP.prepare(self.player, V.WINDOW, kodi_setting, lambda: MP.clip(V.PROFILE), log=V.log,
                       cancelled=lambda: self.cancelled, listitem=xbmcgui.ListItem())
        if self.player.isPlaying():
            self.player.stop()
            end = time.time() + 3
            while self.player.isPlaying() and time.time() < end:
                xbmc.sleep(50)
        self.drain()
        self.ui.stage(stages[-3][0], stages[-3][1], "")
        if self.cancelled:
            return "cancelled"
        if feed.get("entry"):
            V.WINDOW.setProperty(V.PLAYING_KEY, json.dumps({"entry": feed["entry"], "resume": feed.get("resume") or 0}))
        else:
            V.WINDOW.clearProperty(V.PLAYING_KEY)
        LAST_PLAY["by"] = self
        self.player.play(feed["url"], feed["li"], self.windowed)
        began, buffering = time.time(), False
        while time.time() - began < wait:
            if self.cancelled:
                if LAST_PLAY["by"] is self:
                    self.stop_quietly()
                return "cancelled"
            if close_kodi_messages():
                return "failed"
            try:
                e = self.q.get(timeout=0.05)
            except queue.Empty:
                e = None
            if e == "started":
                if feed.get("version") is not None and not self.picture_shows():
                    self.stop_quietly()
                    return "no picture"
                self.playing = feed
                return "started"
            if e in ("error", "stopped", "ended"):
                # Stopping before any picture is how Kodi says a link failed (onPlayBackError rarely comes).
                end = time.time() + 1.5
                while time.time() < end:  # its "failed to play" box comes a moment later
                    close_kodi_messages()
                    xbmc.sleep(50)
                return "failed"
            if not buffering and time.time() - began > 2:
                buffering = True
                self.ui.stage(stages[-2][0], stages[-2][1], "")
        self.stop_quietly()
        return "timeout"

    def picture_shows(self):
        """After the sound starts: whether this link has a picture at all (a file with only a sound track would play
        over black), so the next link is tried instead. The format is not judged here: Kodi on the box decodes what it
        can, in hardware or in software (the owner played these links on his Pi 3 before 0.4.5)."""
        end = time.time() + PICTURE_WAIT
        while time.time() < end and not self.cancelled:
            if xbmc.getCondVisibility("Player.HasVideo") or xbmc.getInfoLabel("VideoPlayer.VideoCodec"):
                return True
            time.sleep(0.1)
        if not self.cancelled:
            V.log("this link has no picture; next")
        return self.cancelled

    def stop_quietly(self):
        """Stop a try without the page hearing about it as the end of playback."""
        try:
            self.player.stop()
        except RuntimeError:
            pass
        end = time.time() + 3
        while self.player.isPlaying() and time.time() < end:
            xbmc.sleep(50)
        self.drain()

    def watch(self, feed):
        self.ui.stage(100, "", "")
        self.ui.started(feed)
        describe_picture()
        looked = time.time()
        while not self.cancelled:
            try:
                e = self.q.get(timeout=0.25)
            except queue.Empty:
                close_kodi_messages()
                if time.time() - looked >= 1:  # live TV: a picture standing still too long takes a backup feed (0.4.9)
                    looked = time.time()
                    if self.lost(feed, "stall"):
                        return
                continue
            if self.cancelled:
                return
            if e in ("ended", "stopped", "error") and self.lost(feed, "drop"):
                return  # a live channel that dropped mid-stream: its next feed is being tried
            if e == "ended":
                self.playing = None
                return self.ui.ended()
            if e in ("stopped", "error"):
                self.playing = None
                return self.ui.stopped()

    def lost(self, feed, why):
        """Asks the player page whether a live channel should go on with a backup feed (mc_watching.PlayerExtras):
        why is "stall" (looked at once a second) or "drop" (Kodi stopped it). The Guide's mini player has no backups."""
        extras = getattr(self.ui, "extras", None)
        if extras is None or self.cancelled:
            return False
        try:
            if why == "stall" and not extras.stalled(self.player):
                return False
            return bool(extras.backup(feed, why))
        except Exception as e:  # never let a check end the playback
            V.log("backup check failed (%s)" % type(e).__name__)
            return False


# ---- feeds for movies, episodes and channels ---------------------------------------------------------------------------

def vod_feeds(api, versions, pick, t, season, episode, episode_name, resume):
    """The links to try for a movie or episode (mc_versions.feeds), each checked first."""
    failed = failed_links()
    entry = L.history_entry(t, season, episode, episode_name)
    out = []
    for v in MV.feeds(versions, pick, failed.has):
        url = api.kodi_url(v["url"], cookie=bool(v.get("cookie")))
        li = xbmcgui.ListItem(episode_name or t.get("name", ""), path=url)
        li.setArt({"poster": t.get("poster"), "thumb": t.get("poster"), "fanart": t.get("backdrop")})
        info = {"title": episode_name or t.get("name", ""), "mediatype": "episode" if t.get("type") == "series" else "movie",
                "plot": t.get("overview", "")}
        if t.get("type") == "series":
            info.update(tvshowtitle=t.get("name", ""), season=season, episode=episode)
        V.set_info(li, info)
        if v.get("container") == "m3u8" or ".m3u8" in url.split("|")[0]:
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setContentLookup(False)
        out.append({"url": url, "li": li, "key": MV.link_key(v), "version": v, "entry": entry, "resume": resume,
                    "check": (lambda u=url: api.link_works(u))})
    return out


def live_feeds(api, channel_id, name, alts):
    """A channel and its backup feeds (up to five), each checked first, as the web player switches by itself."""
    out = []
    for sid in [str(channel_id)] + [a for a in (alts or []) if str(a).isdigit()][:5]:
        try:
            url = api.live_url(sid)
        except ValueError:
            continue
        li = xbmcgui.ListItem(name or "Live TV", path=url)
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
        V.set_info(li, {"title": name or "Live TV", "mediatype": "video"})
        out.append({"url": url, "li": li, "key": "", "entry": None, "resume": 0, "id": sid,
                    "check": (lambda s=sid: api.live_plays(s))})
    return out


# ---- the player page ---------------------------------------------------------------------------------------------------

class PlayerPage(xbmcgui.WindowXMLDialog):
    """The full-screen player (mediacenter-player.xml). Opened with one of the classmethods below."""

    @classmethod
    def movie(cls, api, kind, tmdb, season=None, episode=None, pick=None, fresh=False, art=None):
        """art: what the page that opened it already knows ({name, backdrop, ...}), so the loading screen shows the
        title's picture at once instead of after the server answers."""
        w = cls("mediacenter-player.xml", V.HERE, "Default", "1080i")
        w.setup(api, "vod")
        w.kind, w.tmdb, w.season, w.episode, w.pick, w.fresh = kind, str(tmdb), season, episode, pick, fresh
        w.art = dict(art or {})
        pages.modal(w)
        result = w.result
        del w
        return result

    @classmethod
    def live(cls, api, channel_id, name="", alts=None, now_title="", dock=False, game=None, logo=""):
        """dock: opened from the Guide, so Back hands the channel to its mini player instead of stopping it.
        game: the Sports answer's game this channel is showing, for a loading screen with both teams and their logos.
        logo: the channel's own logo, shown on the loading screen instead of mediaCENTER's."""
        w = cls("mediacenter-player.xml", V.HERE, "Default", "1080i")
        w.setup(api, "live")
        w.channel_id, w.channel_name, w.alts, w.now_title = str(channel_id), name, list(alts or []), now_title
        w.game, w.channel_logo = game, logo or ""
        w.dock_on_back = dock
        pages.modal(w)
        result = w.result
        del w
        return result

    @classmethod
    def attach(cls, api, playback, name="", now_title="", carry=None):
        """Full screen for what the Guide's mini player is showing; Back returns to the Guide with it still playing.
        carry: what the player that first played it knew (picture()), so a movie's controls work again."""
        w = cls("mediacenter-player.xml", V.HERE, "Default", "1080i")
        w.setup(api, (carry or {}).get("mode") or "live")
        for key, value in (carry or {}).items():
            if key in CARRIED:
                setattr(w, key, value)
        w.attached, w.playback = True, playback
        w.channel_name, w.now_title = name, now_title
        pages.modal(w)
        result = w.result
        del w
        return result

    def setup(self, api, mode):
        self.api, self.mode = api, mode
        self.attached = False
        self.dock_on_back = False
        self.kind = None
        self.playback = None
        self.result = "closed"
        self.layer = ""
        self.t = {}
        self.hud_until = 0
        self.scrub_target = None  # the time picked on the timeline, in seconds; None when nothing is being moved
        self.scrub_auto = 0  # counts fast-forward/rewind runs, so only the newest one jumps by itself
        self.stepper = ScrubStepper()
        self.ask_event = threading.Event()
        self.ask_answer = None
        self.upnext_target = None
        self.upnext_cancel = threading.Event()
        self.feeds, self.versions, self.others = [], [], []
        self.ticker = None
        self.closing = False
        self.season = self.episode = None
        self.episode_name = ""
        self.art, self.game, self.channel_logo, self.meta = {}, None, "", None
        self.extras = W.PlayerExtras(self)  # 0.4.9: skip offers, Episodes, Subtitles and Audio, live backups

    # -- layers --

    def show_layer(self, name, focus=None):
        self.layer = name
        self.setProperty("layer", name)
        if focus:
            self.focus_on(focus, name)

    def focus_on(self, cid, layer):
        """Put the highlight on a control of the layer just shown. Kodi shows the layer only on its next frame and
        ignores focus on a control that is still hidden, so the highlight stayed on the invisible button (699): the
        controls showed but OK and the arrows did nothing on the box. Tried again for up to a second, until it holds."""
        self.focus_want = cid  # a newer focus_on wins over an older one still retrying
        self.setFocusId(cid)
        if self.getFocusId() == cid:
            return None

        def again():
            for _ in range(FOCUS_TRIES):
                time.sleep(FOCUS_STEP)
                if self.closing or self.layer != layer or getattr(self, "focus_want", cid) != cid:
                    return
                self.setFocusId(cid)
                if self.getFocusId() == cid:
                    return
        th = threading.Thread(target=again)
        th.daemon = True
        th.start()
        return th

    def stage(self, pct, words, detail):
        if pct >= 100:
            self.clearProperty("loading")
            return
        stages = LIVE_STAGES if self.mode == "live" else STAGES
        self.setProperty("loading", "1")
        if self.layer not in ("", "loading"):
            return
        self.show_layer("loading")
        self.setProperty("load.pct", str(int(pct)))
        try:
            self.getControl(510).setPercent(pct)
        except RuntimeError:
            pass
        self.setProperty("load.text", (words + u"…") if words else "")
        self.setProperty("load.detail", (u"%s · %s" % (words, detail)) if detail else "")
        self.setProperty("load.when", "%d%% · %ds" % (int(pct), int(time.time() - self.began)))
        for i, (text, state) in enumerate(stage_text(stages, pct), 1):
            self.setProperty("step.%d" % i, u"%s  %s" % (MARK[state], text))
            self.setProperty("step.%d.state" % i, state)
        for i in range(len(stages) + 1, 7):
            self.clearProperty("step.%d" % i)

    def toast(self, words):
        self.setProperty("toast", words)
        stamp = time.time()
        self.toast_at = stamp

        def clear():
            if getattr(self, "toast_at", 0) == stamp:
                self.clearProperty("toast")
        timer = threading.Timer(3.5, clear)
        timer.daemon = True
        timer.start()

    def started(self, feed):
        self.clearProperty("loading")
        self.show_layer("")
        self.setProperty("playing", "1")
        self.show_hud()
        self.extras.started(feed)

    def failed(self):
        self.clearProperty("loading")
        self.clearProperty("playing")
        live = self.mode == "live"
        self.setProperty("err.title", LIVE_FAILED if live else VOD_FAILED)
        self.setProperty("err.reason", "None of its feeds answered. Try again in a few minutes, or pick another channel." if live else
                         "mediaCENTER tried %d source%s for this title and none of them started. Another version may work, "
                         "or try again in a few minutes." % (len(self.feeds), "" if len(self.feeds) == 1 else "s"))
        self.setProperty("err.other", "" if live or not self.versions else "1")
        self.show_layer("error", E_OTHER if self.getProperty("err.other") else E_RETRY)

    def ended(self):
        self.clearProperty("playing")
        if self.mode == "vod" and self.kind == "series" and not self.extras.tracker.held:
            # (Cancel on the Next Episode countdown means no switch by itself, as on the web: the episode just ends.)
            nxt = self.find_next()
            if nxt:
                return self.up_next(nxt)
        self.finish("ended")

    def stopped(self):
        self.clearProperty("playing")
        self.finish("stopped")

    def finish(self, why):
        self.result = why
        self.closing = True
        self.close()

    # -- opening --

    def onInit(self):
        if getattr(self, "started_once", False):
            return
        self.started_once = True
        self.began = time.time()
        for k in HOME_PROPS:
            V.WINDOW.clearProperty(k)
        V.WINDOW.setProperty("mc.full", "1")
        self.setProperty("mode", self.mode)
        # The Homebridge remote (homebridge/homebridge-mediacenter-tv) reads this to switch to its playback buttons.
        self.setProperty("heading", "Player")
        self.lines = loading_lines(self.mode)
        if self.attached:
            self.playback.ui = self
            self.setProperty("title", self.channel_name)
            self.setProperty("sub", self.now_title)
            if self.mode == "live":
                self.setProperty("live", "1")
            elif self.kind == "series":
                self.setProperty("series", "1")
            if self.playback.playing is None:  # docked while it was still starting: the loading screen until it shows
                self.setProperty("load.title", self.channel_name)
                self.setProperty("load.sub", self.now_title or ("Live TV" if self.mode == "live" else ""))
                self.show_layer("loading")
                self.stage(LIVE_STAGES[2][0] if self.mode == "live" else STAGES[3][0],
                           LIVE_STAGES[2][1] if self.mode == "live" else STAGES[3][1], "")
            else:
                self.setProperty("playing", "1")
                self.show_layer("")
                self.show_hud()
                self.extras.started(self.playback.playing)
        else:
            self.playback = Playback(self)
            self.dress()
            self.show_layer("loading")
            self.stage(0, (LIVE_STAGES if self.mode == "live" else STAGES)[0][1], "")
            self.worker = threading.Thread(target=self.prepare_live if self.mode == "live" else self.prepare_vod)
            self.worker.daemon = True
            self.worker.start()
        self.ticker = threading.Thread(target=self.tick)
        self.ticker.daemon = True
        self.ticker.start()

    def tick(self):
        """Once a second: the rotating loading line, the time on the loading screen, and hiding the controls."""
        k = 0
        while not self.closing:
            time.sleep(1)
            k += 1
            if self.getProperty("loading"):
                self.setProperty("load.line", self.lines[(k // 2) % len(self.lines)])
                self.setProperty("load.when", "%s%% · %ds" % (self.getProperty("load.pct") or "0", int(time.time() - self.began)))
            if self.layer == "hud" and time.time() > self.hud_until:
                self.hide_hud()
            try:
                self.extras.tick()  # Skip Intro, Skip Credits, the Next Episode countdown
            except Exception as e:  # never stop the ticker
                V.log("offers: %s" % type(e).__name__)

    # -- what the loading screen shows: the title's own picture, or the two teams --

    def dress(self):
        """Before anything is asked of the server: what the page that opened the player already knew. A movie or episode
        shows its backdrop (the same TMDB picture as its title page, so Kodi has it cached) and name; a game both teams
        with their ESPN logos; a channel its own logo. The title's logo and facts follow from /meta/title, off the main
        thread. Nothing here is required: a missing picture leaves the plain loading screen."""
        if self.mode == "live":
            self.setProperty("load.title", self.channel_name)
            self.setProperty("load.sub", self.now_title or "Live TV")
            if self.channel_logo.startswith(("https://", "http://", L.SAMPLE_ART)):
                self.setProperty("load.chlogo", self.channel_logo)
            g = L.game_loading(self.game, self.channel_name) if self.game else None
            if g:
                self.setProperty("load.game", "1")
                self.setProperty("load.gline", g["line"])
                self.setProperty("load.middle", g["middle"])
                for side in ("away", "home"):
                    for key, value in g[side].items():
                        self.setProperty("load.%s.%s" % (side, key), value)
            return
        art = self.art or {}
        if art.get("backdrop"):
            self.setProperty("load.fanart", art["backdrop"])
        if art.get("name"):
            self.setProperty("load.title", art["name"])
        if art.get("logo"):
            self.setProperty("load.logo", art["logo"])
        th = threading.Thread(target=self.dress_vod)
        th.daemon = True
        th.start()

    def dress_vod(self):
        """The title's logo (TMDB, drawn in place of its name, as the web's TitleLoading does) and its facts line."""
        try:
            m = self.api.get("/meta/title", type=self.kind, tmdb=self.tmdb) or {}
        except (ServerError, SignedOut, OSError, ValueError):
            return
        if self.closing or not isinstance(m, dict):
            return
        logo = L.picture(m.get("logo"), "w500")
        if logo and not self.getProperty("load.logo"):
            self.setProperty("load.logo", logo)
        if not self.getProperty("load.fanart"):
            back = L.picture(m.get("backdrop") or m.get("card"), "w1280")
            if back:
                self.setProperty("load.fanart", back)
        self.meta = m
        self.setProperty("load.facts", L.loading_facts(self.t or self.art or {}, m))

    def prepare_live(self):
        self.setProperty("live", "1")
        self.setProperty("title", self.channel_name)
        self.setProperty("sub", self.now_title)
        playback = self.playback
        try:
            self.feeds = live_feeds(self.api, self.channel_id, self.channel_name, self.alts)
        except SignedOut:
            return self.signed_out() if playback.ui is self else playback.ui.failed()
        if playback.cancelled:
            return  # Back while the feeds were looked up
        if not self.feeds:
            return playback.ui.failed()  # docked in the Guide by then: its mini player says so
        if len(self.feeds) == 1:
            self.feeds[0]["check"] = None  # one feed: the player tries it straight away
        playback.start(self.feeds, LIVE_STAGES)

    def prepare_vod(self):
        import mc_play
        kind, tmdb = self.kind, self.tmdb
        try:
            info = self.api.get("/api/roku/title", type=kind, tmdb=tmdb) or {}
            t = L.title_of(dict(info.get("title") or {}, type=kind, tmdb=tmdb)) or {"tmdb": tmdb, "type": kind, "name": "", "poster": ""}
            self.t = t
            if t.get("backdrop"):
                self.setProperty("load.fanart", t["backdrop"])
            if t.get("name"):
                self.setProperty("load.title", t["name"])
            self.setProperty("load.facts", L.loading_facts(t, self.meta))
            self.about_title(t)
            if kind == "series":
                self.episode_name = self.episode_title(self.season, self.episode)
                self.setProperty("load.sub", u"Season %s · Episode %s" % (self.season, self.episode) +
                                 (u" · " + self.episode_name if self.episode_name else ""))
            self.stage(STAGES[1][0], STAGES[1][1], "")
            versions, name = found_versions(self.api, kind, tmdb, self.season, self.episode)
        except SignedOut:
            return self.signed_out()
        except (ServerError, OSError) as e:
            V.log("play: versions not found (%s)" % type(e).__name__)
            versions, name = [], ""
        if self.closing:
            return
        if not t.get("name"):
            t["name"] = name or "mediaCENTER"
            self.setProperty("load.title", t["name"])
        self.versions, self.others = split_versions(versions, mc_play.caps())
        if not self.versions and self.others:
            # Only versions above what this box is set to look for (4K, AV1): try them anyway, the lightest first,
            # rather than saying no (owner, 2026-11-26: "if it can do 4K, then it should do 4K").
            self.versions = sorted(self.others, key=lambda v: L.RES_ORDER.get(v.get("res") or "", 2))
            self.others = []
            V.log("play: only bigger versions found; trying them")
        V.log("play %s: %d versions, %d play here" % (kind, len(versions), len(self.versions)))
        self.set_titles()
        if not self.versions:
            self.setProperty("err.title", "No versions for this title yet." if not versions else "This title doesn't play on this box yet.")
            self.setProperty("err.reason", "Try again later: new versions are found all the time." if not versions else
                             "%d version%s need a stronger box than this one." % (len(self.others), "" if len(self.others) == 1 else "s"))
            self.setProperty("err.other", "")
            self.clearProperty("loading")
            return self.show_layer("error", E_CLOSE)
        resume = 0 if self.fresh else self.ask_resume()
        if resume is None or self.closing:
            return
        self.stage(STAGES[2][0], STAGES[2][1], "")
        self.feeds = vod_feeds(self.api, self.versions, self.pick, t, self.season, self.episode, self.episode_name, resume)
        if self.closing:
            return
        self.playback.start(self.feeds, STAGES)

    def about_title(self, t):
        """What the loading screen adds once the server has described the title: its poster and what it's about."""
        self.setProperty("load.poster", t.get("poster") or "")
        self.setProperty("load.plot", t.get("overview") or "")

    def episode_title(self, season, episode):
        try:
            eps = (self.api.get("/api/roku/episodes", tmdb=self.tmdb, season=season) or {}).get("episodes") or []
        except (ServerError, SignedOut, OSError):
            return ""
        self.eps_cache = getattr(self, "eps_cache", {})
        self.eps_cache[int(season)] = eps
        return next((e.get("name", "") for e in eps if int(e.get("n") or 0) == int(episode)), "")

    def set_titles(self):
        t = self.t
        if self.kind == "series":
            self.setProperty("title", t.get("name", ""))
            self.setProperty("sub", u"S%s · E%s%s" % (self.season, self.episode, (u" · " + self.episode_name) if self.episode_name else ""))
            self.setProperty("series", "1")
        else:
            self.setProperty("title", t.get("name", ""))
            self.setProperty("sub", L.title_line(t))
            self.clearProperty("series")

    def ask_resume(self):
        """Resume or start over, asked in mediaCENTER's own screen. Returns seconds, or None when Back was pressed."""
        try:
            hist = (self.api.get("/api/history", limit=300) or {}).get("items") or []
        except (ServerError, SignedOut, OSError):
            return 0
        item_id = L.history_key(self.kind, self.tmdb, self.season, self.episode)
        row = next((h for h in hist if h.get("itemId") == item_id), None)
        if not row or row.get("finished") or float(row.get("position") or 0) < 30:
            return 0
        pos = float(row["position"])
        self.setProperty("ask.resume", "Resume from %s" % L.clock_text(pos))
        self.ask_event.clear()
        self.clearProperty("loading")
        self.show_layer("ask", A_RESUME)
        self.ask_event.wait()
        if self.ask_answer is None:
            return None
        self.show_layer("loading")
        self.setProperty("loading", "1")
        return pos if self.ask_answer == "resume" else 0

    def signed_out(self):
        self.clearProperty("loading")
        self.setProperty("err.title", "Your session ended.")
        self.setProperty("err.reason", "Sign in again from Settings, then play this again.")
        self.setProperty("err.other", "")
        self.show_layer("error", E_CLOSE)

    # -- Up Next --

    def find_next(self):
        try:
            seasons = (self.t or {}).get("seasonList") or []
            if not seasons:
                info = self.api.get("/api/roku/title", type="series", tmdb=self.tmdb) or {}
                seasons = (info.get("title") or {}).get("seasonList") or [self.season]
            cache = getattr(self, "eps_cache", {})

            def numbers(s):
                if int(s) not in cache:
                    cache[int(s)] = (self.api.get("/api/roku/episodes", tmdb=self.tmdb, season=s) or {}).get("episodes") or []
                return [e.get("n") for e in cache[int(s)] if e.get("n")]
            self.eps_cache = cache
            return next_episode(self.season, self.episode, numbers, seasons)
        except (ServerError, SignedOut, OSError, ValueError):
            return None

    def up_next(self, target):
        s, e = target
        name = next((x.get("name", "") for x in getattr(self, "eps_cache", {}).get(int(s), []) if int(x.get("n") or 0) == e), "")
        self.upnext_target = target
        self.setProperty("upnext.title", u"S%d · E%d%s" % (s, e, (u" · " + name) if name else ""))
        self.setProperty("upnext.show", self.t.get("name", ""))
        self.setProperty("upnext.fanart", self.t.get("backdrop") or "")
        self.upnext_cancel.clear()
        self.show_layer("upnext", U_PLAY)

        def count():
            for left in range(UP_NEXT_SECONDS, 0, -1):
                if self.upnext_cancel.is_set() or self.closing:
                    return
                self.setProperty("upnext.count", "UP NEXT · %d" % left)
                time.sleep(1)
            if not self.upnext_cancel.is_set() and not self.closing:
                self.play_next()
        th = threading.Thread(target=count)
        th.daemon = True
        th.start()

    def play_next(self, target=None):
        """Next Episode (the button, the remote's next key, Up Next). Finding it asks the server, so a press with no
        Up Next showing looks it up away from Kodi's button thread and the button answers at once."""
        target = target or self.upnext_target
        if not target:
            def find():
                found = self.find_next()
                if self.closing:
                    return
                if not found:
                    return V.notify("This is the last episode.")
                self.play_next(found)
            th = threading.Thread(target=find)
            th.daemon = True
            th.start()
            return th
        self.upnext_cancel.set()
        if self.playback:
            self.playback.stop()
        self.clearProperty("playing")
        self.clearProperty("offer")
        self.season, self.episode = target
        self.pick, self.fresh = None, True
        self.playback = Playback(self)
        self.began = time.time()
        self.show_layer("loading")
        self.setProperty("loading", "1")
        self.worker = threading.Thread(target=self.prepare_vod)
        self.worker.daemon = True
        self.worker.start()

    # -- the controls --

    def show_hud(self, seconds=HUD_SECONDS):
        self.hud_until = time.time() + seconds
        if self.layer != "hud":
            self.setProperty("pp", "Play" if xbmc.getCondVisibility("Player.Paused") else "Pause")
            self.show_layer("hud", B_PLAYPAUSE)

    def hide_hud(self):
        self.scrub_cancel()
        if self.layer == "hud":
            self.show_layer("")
            self.setFocusId(HUD + 99)  # an invisible button, so OK on a hidden control does nothing

    def seek(self, seconds):
        p = self.playback.player if self.playback else None
        if not p or not p.isPlaying() or self.mode == "live":
            return
        try:
            p.seekTime(max(0, p.getTime() + seconds))
        except RuntimeError:
            pass
        self.show_hud()

    def scrub_by(self, seconds, auto=False):
        """Move the picked time on the timeline by seconds; the picture keeps playing until OK (scrub_jump). auto: the
        fast-forward and rewind keys, which jump by themselves SCRUB_AUTO seconds after the last press. Live TV has no
        timeline, so nothing moves there."""
        p = self.playback.player if self.playback else None
        if not p or self.mode == "live":
            return False
        try:
            if not p.isPlaying():
                return False
            now, length = p.getTime(), p.getTotalTime()
        except RuntimeError:
            return False
        if length <= 0:
            return False  # a stream with no known length: no timeline to move along
        start = now if self.scrub_target is None else self.scrub_target
        target = min(max(0, start + seconds), max(0, length - 1))
        self.scrub_target = target
        delta = int(round(target - now))
        self.setProperty("scrub", "1")
        self.setProperty("scrub.time", clock(target))
        self.setProperty("scrub.left", "-" + clock(length - target))
        self.setProperty("scrub.delta", ("+" if delta >= 0 else u"\u2212") + clock(abs(delta)))
        self.setProperty("scrub.hint", "Jumping there" if auto else "OK to jump, Back to cancel")
        try:
            self.getControl(SCRUB_BAR).setPercent(100.0 * target / length)
        except (RuntimeError, AttributeError):
            pass
        if self.layer != "hud":
            self.show_hud(SCRUB_HUD_SECONDS)
        self.hud_until = time.time() + SCRUB_HUD_SECONDS
        if self.getFocusId() != SCRUB:
            self.focus_on(SCRUB, "hud")
        if auto:
            self.scrub_auto += 1
            run = self.scrub_auto
            th = threading.Thread(target=self.scrub_later, args=(run,))
            th.daemon = True
            th.start()
        return True

    def scrub_later(self, run):
        time.sleep(SCRUB_AUTO)
        if run == self.scrub_auto and not self.closing and self.scrub_target is not None:
            self.scrub_jump()

    def scrub_jump(self):
        """OK on the timeline (or the keys' own pause): play from the picked time."""
        target = self.scrub_target
        self.scrub_cancel()
        p = self.playback.player if self.playback else None
        if target is None or not p:
            return
        try:
            p.seekTime(target)
        except RuntimeError:
            pass
        self.show_hud()

    def scrub_cancel(self):
        if self.scrub_target is None and not self.getProperty("scrub"):
            return
        self.scrub_target = None
        self.scrub_auto += 1  # a waiting automatic jump no longer fires
        self.stepper.reset()
        for key in ("scrub", "scrub.time", "scrub.left", "scrub.delta", "scrub.hint"):
            self.clearProperty(key)

    def toggle_pause(self):
        if self.playback:
            self.playback.player.pause()
        xbmc.sleep(150)
        self.setProperty("pp", "Play" if xbmc.getCondVisibility("Player.Paused") else "Pause")
        self.show_hud()

    def kodi_paused(self, a):
        """The Pause, Play/Pause and Play keys (the remotes, the controller): Kodi pauses on these by itself, after this
        page has seen them, so pausing here too undid it. Only when Kodi did nothing (no pause or resume came within a
        moment) does the page pause; Play only ever resumes. Then the button's label follows."""
        asked = time.time()
        player = self.playback.player if self.playback else None

        def check():
            end = asked + KODI_PAUSE_WAIT
            while time.time() < end and not self.closing:
                if player is not None and player.toggled_at >= asked - KODI_PAUSE_WAIT:
                    break
                time.sleep(0.05)
            else:
                if player is not None and not self.closing and (a != PLAY or xbmc.getCondVisibility("Player.Paused")):
                    player.pause()
                    time.sleep(0.15)
            self.setProperty("pp", "Play" if xbmc.getCondVisibility("Player.Paused") else "Pause")
            self.show_hud()
        th = threading.Thread(target=check)
        th.daemon = True
        th.start()
        return th

    def normal_speed(self):
        """Fast-forward and rewind keys: Kodi also changes the play speed on these; the page skips instead, so the
        speed goes back to normal."""
        def check():
            time.sleep(0.3)
            if not self.closing and str(xbmc.getInfoLabel("Player.PlaySpeed") or "1").strip() not in ("1", "1.0", "1.00", ""):
                xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Player.SetSpeed", "params": {"playerid": 1, "speed": 1}}))
        th = threading.Thread(target=check)
        th.daemon = True
        th.start()
        return th

    def choose_stream(self, audio):
        p = self.playback.player if self.playback else None
        if not p or not p.isPlaying():
            return
        try:
            names = p.getAvailableAudioStreams() if audio else p.getAvailableSubtitleStreams()
        except RuntimeError:
            names = []
        names = [n or "Track %d" % (i + 1) for i, n in enumerate(names or [])]
        if audio:
            if not names:
                return V.notify("This version has one sound track.")
            i = xbmcgui.Dialog().select("Audio", names)
            if i >= 0:
                p.setAudioStream(i)
        else:
            if not names:
                return V.notify("This version has no subtitles.")
            i = xbmcgui.Dialog().select("Subtitles", ["Off"] + names)
            if i == 0:
                p.showSubtitles(False)
            elif i > 0:
                p.setSubtitleStream(i - 1)
                p.showSubtitles(True)
        self.show_hud()

    def other_version(self):
        """Choose another version: the versions page, then the player starts again with that one first."""
        if self.mode != "vod" or not self.versions:
            return
        import mc_versions_page as VP
        pick = VP.VersionsPage.choose(self.versions, self.others, title=self.t.get("name", ""),
                                      subtitle=self.getProperty("sub") if self.kind == "series" else "")
        if pick is None:
            return self.show_hud() if self.getProperty("playing") else None
        if self.playback:
            self.playback.stop()
        self.pick = pick
        self.playback = Playback(self)
        self.began = time.time()
        self.show_layer("loading")
        self.setProperty("loading", "1")
        self.feeds = vod_feeds(self.api, self.versions, pick, self.t, self.season, self.episode, self.episode_name, 0)
        self.playback.start(self.feeds, STAGES)

    def retry(self, skip_first=False):
        """Retry: the same sources again, checked again. Try the next source: the first one goes to the back."""
        self.playback = Playback(self)
        self.began = time.time()
        self.show_layer("loading")
        self.setProperty("loading", "1")
        feeds = self.feeds[1:] + self.feeds[:1] if skip_first else self.feeds
        self.playback.start(feeds, LIVE_STAGES if self.mode == "live" else STAGES)

    def retry_with(self, feeds, words):
        """A live channel's backup feeds, after the one showing dropped or stalled (mc_watching.PlayerExtras.backup).
        self.feeds keeps every feed, so a later drop goes on to the one after."""
        old = self.playback
        if old:
            old.stop()
        self.toast(words)
        self.clearProperty("playing")
        self.playback = Playback(self)
        self.began = time.time()
        self.show_layer("loading")
        self.setProperty("loading", "1")
        self.playback.start(feeds, LIVE_STAGES)

    def leave(self):
        """Back with nothing on screen: stop and go back where the player was opened from (from the Guide, what is
        playing carries on in its mini player: handed over through mc_pages)."""
        self.closing = True
        self.upnext_cancel.set()
        self.ask_answer = None
        self.ask_event.set()
        if (self.attached or self.dock_on_back) and self.dockable():
            pages.hand_over(**self.picture())
            self.result = "docked"
        else:
            if self.playback:
                self.playback.stop()
            self.result = "stopped"
        self.close()

    def dockable(self):
        """Back from a Guide channel puts it in the Guide's mini player (owner's choice), also while it is still starting:
        it was stopped then, and a link Kodi had already been given could start a moment later with sound and no
        picture anywhere. Not after it failed (the error screen) or once stopped."""
        pb = self.playback
        if pb is None or pb.cancelled:
            return False
        return pb.playing is not None or self.layer == "loading"

    def goto_close(self):
        """The iPhone remote's TV button (mc_pages.go): what is playing goes to the Guide's mini player; anything still
        loading stops."""
        if self.playback is not None and self.playback.playing is not None and self.layer != "error":
            self.closing = True
            self.upnext_cancel.set()
            self.ask_answer = None
            self.ask_event.set()
            pages.hand_over(**self.picture())
            self.result = "docked"
            return self.close()
        self.leave()

    def picture(self):
        """What the Guide's mini player needs to carry on with this picture, and to bring it back full screen."""
        live = self.mode == "live"
        return {"playback": self.playback, "name": self.getProperty("title") or getattr(self, "channel_name", "") or "",
                "sub": self.getProperty("sub") or getattr(self, "now_title", "") or "", "live": live,
                "channel": getattr(self, "channel_id", None) if live else None,
                "carry": dict((k, getattr(self, k)) for k in CARRIED if hasattr(self, k))}

    def onClick(self, cid):
        if self.extras.on_click(cid):
            return
        if cid == SCRUB:
            return self.scrub_jump() if self.scrub_target is not None else self.toggle_pause()
        if cid == B_BACK10:
            return self.seek(-10)
        if cid == B_PLAYPAUSE:
            return self.toggle_pause()
        if cid == B_NEXT:
            return self.play_next()
        if cid in (B_AUDIO, B_SUBS):
            return self.choose_stream(cid == B_AUDIO)
        if cid in (B_VERSIONS, E_OTHER):
            return self.other_version()
        if cid == E_RETRY:
            return self.retry()
        if cid == E_NEXT:
            return self.retry(skip_first=True)
        if cid == E_CLOSE:
            return self.leave()
        if cid in (A_RESUME, A_START):
            self.ask_answer = "resume" if cid == A_RESUME else "start"
            return self.ask_event.set()
        if cid == U_PLAY:
            return self.play_next()
        if cid == U_CANCEL:
            self.upnext_cancel.set()
            return self.finish("ended")

    def onAction(self, action):
        a = action.getId()
        layer = self.layer
        if self.extras.on_action(a, layer):
            return
        if a in BACK:
            if layer == "hud" and self.scrub_target is not None:
                self.scrub_cancel()  # Back puts the timeline back where playback is; the controls stay
                self.hud_until = time.time() + HUD_SECONDS
                return
            if layer == "hud":
                return self.hide_hud()
            if layer == "upnext":
                self.upnext_cancel.set()
                return self.finish("ended")
            return self.leave()
        if a == STOP:
            return self.leave()
        if layer in ("loading", "error", "ask", "upnext"):
            return
        if a == SCORES_KEY and self.mode == "live":  # 0.4.9: scores while watching, a drawer over the picture (mc_scores)
            import mc_scores
            return mc_scores.open_over(self)
        if layer == "offer" and a in (LEFT, RIGHT, UP, DOWN):
            self.show_layer("")  # the offer stays on screen; the arrows work as with nothing showing
        if a in (PAUSE, PLAYPAUSE, PLAY):
            return self.kodi_paused(a)
        if a in (FORWARD, REWIND):
            # Fast forward and rewind (the TV remote's keys, the iPhone remote's): move along the timeline, faster
            # the more presses in a row, and jump there once the presses stop. Kodi's own fast play is undone.
            self.normal_speed()
            if not self.scrub_by(self.stepper.step(a == FORWARD), auto=True) and self.mode == "live":
                V.notify("Live TV can't be skipped.")
            return
        if a == NEXT_ITEM and self.mode == "vod" and self.kind == "series":
            return self.play_next()
        if layer == "hud":
            self.hud_until = time.time() + HUD_SECONDS
            focus = self.getFocusId()
            if focus == HUD + 99 and a in (LEFT, RIGHT, UP, DOWN, SELECT):
                self.focus_on(B_PLAYPAUSE, "hud")  # the highlight missed the controls: put it on them
            elif focus == SCRUB and a in (LEFT, RIGHT):
                self.scrub_by(self.stepper.step(a == RIGHT))
            elif a == DOWN and self.scrub_target is not None:
                self.scrub_cancel()  # left the timeline without jumping
            return
        if a == LEFT:
            return self.seek(-10)
        if a == RIGHT:
            return self.seek(10)
        if a in (UP, DOWN, SELECT) or a in MENU_KEYS:
            return self.show_hud()

    def close(self):
        self.closing = True
        V.WINDOW.clearProperty("mc.full")
        xbmcgui.WindowXMLDialog.close(self)


# ---- what the other pages call -----------------------------------------------------------------------------------------

def play_title(api, kind, tmdb, season=None, episode=None, choose=False, fresh=False, art=None):
    """Play a movie or an episode from any page; with choose, the versions page comes first. art: what the page knows
    about the title ({name, backdrop, logo}), for the loading screen."""
    pick = None
    if choose:
        import mc_play
        import mc_versions_page as VP
        busy(True)
        try:
            versions, _ = found_versions(api, kind, tmdb, season, episode)
        except SignedOut:
            busy(False)
            return xbmcgui.Dialog().ok("mediaCENTER", "Your session ended. Sign in again from Settings.")
        except (ServerError, OSError):
            versions = []
        finally:
            busy(False)
        ranked, others = split_versions(versions, mc_play.caps())
        pick = VP.VersionsPage.choose(ranked, others)
        if pick is None:
            return None
    return PlayerPage.movie(api, kind, tmdb, season, episode, pick=pick, fresh=fresh, art=art)


def play_channel(api, channel_id, name="", alts=None, now_title="", dock=False, game=None, logo=""):
    return PlayerPage.live(api, channel_id, name, alts, now_title, dock, game=game, logo=logo)
