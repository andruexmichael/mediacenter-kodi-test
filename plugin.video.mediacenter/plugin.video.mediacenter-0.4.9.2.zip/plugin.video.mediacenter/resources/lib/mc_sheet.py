# mediaCENTER for Kodi: the panel on the right over the playing picture (0.4.9, mediacenter-sheet.xml), as the web
# player's Episodes, Subtitles and Audio panels (web-v27/js/views/player-episodes.js, player.js). The video keeps
# playing on the left while it is open. Tabs along the top (the seasons; or Subtitles, Size, Look), a list under them.

import xbmcgui

import mc_views as V
import mc_pages as pages

TABS = 12
LIST = 50
BACK = (9, 10, 92, 247)


class SheetPage(xbmcgui.WindowXMLDialog):
    """Opened with choose(). tabs: [(key, words)] or None; rows_for(tab_key) -> [row]; a row is a dict with key, label,
    label2, thumb, on (a check mark) and optional current (shown, not pickable). Returns (tab_key, row) or None."""

    @classmethod
    def choose(cls, heading, rows_for, tabs=None, tab=None, subheading="", empty="Nothing here."):
        w = cls("mediacenter-sheet.xml", V.HERE, "Default", "1080i")
        w.heading, w.subheading, w.rows_for, w.tabs, w.tab, w.empty_words = heading, subheading, rows_for, list(tabs or []), tab, empty
        w.picked = None
        pages.modal(w)
        picked = w.picked
        del w
        return picked

    def onInit(self):
        self.setProperty("heading", self.heading)
        self.setProperty("subheading", self.subheading)
        for i in range(1, TABS + 1):
            if i <= len(self.tabs):
                self.setProperty("tab.%d" % i, self.tabs[i - 1][1])
            else:
                self.clearProperty("tab.%d" % i)
        if self.tabs and self.tab is None:
            self.tab = self.tabs[0][0]
        self.draw()

    def draw(self):
        try:
            self.rows = list(self.rows_for(self.tab) or [])
        except Exception as e:  # a lookup that failed shows as an empty list, never a crash over the video
            V.log("sheet: rows not found (%s)" % type(e).__name__)
            self.rows = []
        control = self.getControl(LIST)
        control.reset()
        first = 0
        for i, r in enumerate(self.rows):
            li = xbmcgui.ListItem(r.get("label", ""), r.get("label2", ""))
            if r.get("thumb"):
                li.setArt({"thumb": r["thumb"]})
            li.setProperty("mark", u"✓" if r.get("on") or r.get("current") else "")
            control.addItem(li)
            if r.get("on") or r.get("current"):
                first = i
        if self.rows:
            self.clearProperty("empty")
            control.selectItem(first)
            self.setFocusId(LIST)
        else:
            self.setProperty("empty", self.empty_words)
            self.setFocusId(100 + 1 + self.tab_index() if self.tabs else LIST)

    def tab_index(self):
        return next((i for i, (k, _) in enumerate(self.tabs) if k == self.tab), 0)

    def onClick(self, cid):
        if 101 <= cid < 101 + len(self.tabs):
            self.tab = self.tabs[cid - 101][0]
            return self.draw()
        if cid == LIST:
            pos = self.getControl(LIST).getSelectedPosition()
            if 0 <= pos < len(self.rows) and not self.rows[pos].get("current"):
                self.picked = (self.tab, self.rows[pos])
                self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()

    def goto_close(self):
        self.close()
