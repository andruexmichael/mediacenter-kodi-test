# mediaCENTER for Kodi: QR codes drawn on the box itself, for phone sign-in (mc_pairing). The address and code never go
# to a QR service, and the server needs no QR library. Byte mode, error correction level M, versions 1 to 10 (up to 213
# bytes), the eight masks scored as the QR standard (ISO/IEC 18004) says. Laid out after Project Nayuki's QR Code
# generator (MIT); checked against npm's bundled encoder by kodi/tests/test_device.py.

import struct
import zlib

# Version: (error correction codewords per block, [data codewords of each block]) at level M.
BLOCKS = {1: (10, [16]), 2: (16, [28]), 3: (26, [44]), 4: (18, [32, 32]), 5: (24, [43, 43]), 6: (16, [27] * 4),
          7: (18, [31] * 4), 8: (22, [38, 38, 39, 39]), 9: (22, [36, 36, 36, 37, 37]), 10: (26, [43] * 4 + [44])}
ALIGN = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42],
         9: [6, 26, 46], 10: [6, 28, 50]}
LEVEL_M = 0  # format bits of level M


def _gf_mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z & 0xFF


def _divisor(degree):
    result = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(degree):
            result[j] = _gf_mul(result[j], root)
            if j + 1 < degree:
                result[j] ^= result[j + 1]
        root = _gf_mul(root, 0x02)
    return result


def reed_solomon(data, degree):
    """The error correction codewords of one block."""
    div = _divisor(degree)
    result = [0] * degree
    for b in data:
        factor = b ^ result.pop(0)
        result.append(0)
        for i, coef in enumerate(div):
            result[i] ^= _gf_mul(coef, factor)
    return result


def codewords(text, version):
    """The data and error correction codewords, interleaved as they are placed."""
    data = text.encode("utf-8")
    ec, blocks = BLOCKS[version]
    capacity = sum(blocks)
    bits = []

    def put(value, n):
        bits.extend((value >> i) & 1 for i in range(n - 1, -1, -1))
    put(0b0100, 4)
    put(len(data), 8 if version < 10 else 16)
    for b in data:
        put(b, 8)
    if len(bits) > capacity * 8:
        raise ValueError("too long for this version")
    put(0, min(4, capacity * 8 - len(bits)))
    put(0, (-len(bits)) % 8)
    words = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(words) < capacity:
        words.append(pad)
        pad ^= 0xEC ^ 0x11
    split, at = [], 0
    for n in blocks:
        split.append(words[at:at + n])
        at += n
    out = []
    for i in range(max(blocks)):
        out.extend(b[i] for b in split if i < len(b))
    fixes = [reed_solomon(b, ec) for b in split]
    for i in range(ec):
        out.extend(f[i] for f in fixes)
    return out


def format_bits(mask, level=LEVEL_M):
    data = level << 3 | mask
    rem = data
    for _ in range(10):
        rem = (rem << 1) ^ ((rem >> 9) * 0x537)
    return (data << 10 | rem) ^ 0x5412


def version_bits(version):
    rem = version
    for _ in range(12):
        rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
    return version << 12 | rem


MASKS = [lambda x, y: (x + y) % 2 == 0, lambda x, y: y % 2 == 0, lambda x, y: x % 3 == 0, lambda x, y: (x + y) % 3 == 0,
         lambda x, y: (x // 3 + y // 2) % 2 == 0, lambda x, y: x * y % 2 + x * y % 3 == 0,
         lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0, lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0]


class Matrix(object):
    def __init__(self, version):
        self.version = version
        self.size = version * 4 + 17
        self.dark = [[False] * self.size for _ in range(self.size)]
        self.fixed = [[False] * self.size for _ in range(self.size)]

    def set(self, x, y, dark):
        self.dark[y][x] = bool(dark)
        self.fixed[y][x] = True

    def patterns(self):
        n = self.size
        for i in range(n):
            self.set(6, i, i % 2 == 0)
            self.set(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (n - 4, 3), (3, n - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < n and 0 <= y < n:
                        self.set(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        pos = ALIGN[self.version]
        last = len(pos) - 1
        for i, ax in enumerate(pos):
            for j, ay in enumerate(pos):
                if (i, j) in ((0, 0), (0, last), (last, 0)):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.set(ax + dx, ay + dy, max(abs(dx), abs(dy)) != 1)
        self.format(0)
        if self.version >= 7:
            bits = version_bits(self.version)
            for i in range(18):
                b = (bits >> i) & 1
                a, c = n - 11 + i % 3, i // 3
                self.set(a, c, b)
                self.set(c, a, b)

    def format(self, mask):
        n, bits = self.size, format_bits(mask)
        bit = [(bits >> i) & 1 for i in range(15)]
        for i in range(6):
            self.set(8, i, bit[i])
        self.set(8, 7, bit[6])
        self.set(8, 8, bit[7])
        self.set(7, 8, bit[8])
        for i in range(9, 15):
            self.set(14 - i, 8, bit[i])
        for i in range(8):
            self.set(n - 1 - i, 8, bit[i])
        for i in range(8, 15):
            self.set(8, n - 15 + i, bit[i])
        self.set(8, n - 8, True)

    def place(self, words):
        n, i, total = self.size, 0, len(words) * 8
        right = n - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(n):
                for j in range(2):
                    x = right - j
                    y = n - 1 - vert if ((right + 1) & 2) == 0 else vert
                    if not self.fixed[y][x] and i < total:
                        self.dark[y][x] = bool((words[i >> 3] >> (7 - (i & 7))) & 1)
                        i += 1
            right -= 2

    def masked(self, mask):
        m = Matrix(self.version)
        m.fixed = self.fixed
        f = MASKS[mask]
        m.dark = [[self.dark[y][x] ^ (not self.fixed[y][x] and f(x, y)) for x in range(self.size)] for y in range(self.size)]
        m.format(mask)
        return m


def penalty(rows):
    n, score = len(rows), 0
    lines = rows + [list(c) for c in zip(*rows)]
    for line in lines:
        run, color = 0, None
        for d in line:
            if d == color:
                run += 1
            else:
                if run >= 5:
                    score += run - 2
                run, color = 1, d
        if run >= 5:
            score += run - 2
        s = "".join("1" if d else "0" for d in line)
        for pattern in ("10111010000", "00001011101"):
            at = s.find(pattern)
            while at >= 0:
                score += 40
                at = s.find(pattern, at + 1)
    for y in range(n - 1):
        for x in range(n - 1):
            if rows[y][x] == rows[y][x + 1] == rows[y + 1][x] == rows[y + 1][x + 1]:
                score += 3
    dark = sum(map(sum, rows))
    score += abs(dark * 20 - n * n * 10) // (n * n) * 10
    return score


def encode(text, mask=None):
    """The QR code of text as rows of True (dark) and False, without the quiet zone."""
    size = len(text.encode("utf-8"))
    version = next((v for v in BLOCKS if size + (3 if v < 10 else 4) <= sum(BLOCKS[v][1])), None)
    if version is None:
        raise ValueError("too long for a sign-in code")
    base = Matrix(version)
    base.patterns()
    base.place(codewords(text, version))
    options = [base.masked(m) for m in range(8)]
    best = options[mask] if mask is not None else min(options, key=lambda m: penalty(m.dark))
    return best.dark


def png(rows, scale=8, quiet=4):
    """A black-on-white PNG of the code with its quiet zone (no picture library on the box)."""
    n = len(rows)
    width = (n + quiet * 2) * scale
    raw = bytearray()
    for y in range(-quiet, n + quiet):
        line = bytearray()
        for x in range(-quiet, n + quiet):
            dark = 0 <= x < n and 0 <= y < n and rows[y][x]
            line.extend((b"\x00" if dark else b"\xff") * scale)
        raw.extend((b"\x00" + bytes(line)) * scale)

    def chunk(kind, data):
        return struct.pack("!I", len(data)) + kind + data + struct.pack("!I", zlib.crc32(kind + data) & 0xFFFFFFFF)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack("!2I5B", width, width, 8, 0, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b""))
