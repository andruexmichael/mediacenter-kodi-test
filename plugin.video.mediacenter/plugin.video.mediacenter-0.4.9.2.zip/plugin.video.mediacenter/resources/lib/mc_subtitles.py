# mediaCENTER for Kodi: subtitles and sound tracks (0.4.9), as the web player does them (web-v27/js/subtitles.js,
# audio-tracks.js, player.js):
#   - the account's saved audio and subtitle language (audioLanguage, subtitleLanguage in /api/prefs, shared with the web,
#     the iPhone, the Mac and the Apple TV) is turned on by itself when a movie or episode starts;
#   - choosing a track in the player remembers its language for the next time, on every device;
#   - subtitles found online (the server's /meta/subs, OpenSubtitles) when the version has none in that language;
#   - the subtitle size and look (subtitleSize, subtitleStyle) are put into Kodi's own subtitle settings.
# Kept free of Kodi windows so it can be tested; `call` is Kodi's JSON-RPC (method, params) -> result.

import json
import os
import re
import time

SUB_LANGUAGES = [("en", "English"), ("es", "Spanish"), ("fr", "French"), ("pt", "Portuguese"), ("de", "German"), ("it", "Italian")]
NAMES = {"eng": "English", "spa": "Spanish", "fre": "French", "fra": "French", "por": "Portuguese", "ger": "German", "deu": "German",
         "ita": "Italian", "jpn": "Japanese", "kor": "Korean", "chi": "Chinese", "zho": "Chinese", "hin": "Hindi", "ara": "Arabic",
         "rus": "Russian"}
TO2 = {"eng": "en", "spa": "es", "fre": "fr", "fra": "fr", "por": "pt", "ger": "de", "deu": "de", "ita": "it",
       "english": "en", "spanish": "es", "french": "fr", "portuguese": "pt", "german": "de", "italian": "it"}
SIZES = [("small", "Small"), ("medium", "Medium"), ("large", "Large"), ("xl", "Extra large")]
STYLES = [("shadow", "White with a shadow"), ("box", "On a dark box"), ("yellow", "Yellow")]
PREF_KEYS = ("audioLanguage", "subtitleLanguage", "subtitleSize", "subtitleStyle", "automaticBackups")
DEFAULTS = {"audioLanguage": "en", "subtitleLanguage": "off", "subtitleSize": "medium", "subtitleStyle": "shadow",
            "automaticBackups": True}
MAX_SUBS = 2 * 1024 * 1024
PREFS_TTL = 60


def lang2(code):
    """"eng", "en-US" or "English" -> "en" (two-letter codes are what the account remembers)."""
    c = re.split(r"[-_]", str(code or "").strip().lower())[0]
    return TO2.get(c, c)


def lang_name(code):
    c = str(code or "").strip().lower()
    two = lang2(c)
    for k, name in SUB_LANGUAGES:
        if k == two:
            return name
    return NAMES.get(c) or (c.upper() if c else "Unknown")


# ---- the account's choices --------------------------------------------------------------------------------------------

_prefs = {"at": 0.0, "value": None}


def prefs(api, now=time.time, fresh=False):
    """The playback choices saved on the account (with the defaults the web uses). Read at most once a minute."""
    if not fresh and _prefs["value"] is not None and now() - _prefs["at"] < PREFS_TTL:
        return dict(_prefs["value"])
    out = dict(DEFAULTS)
    try:
        saved = (api.get("/api/prefs") or {}).get("prefs") or {}
    except Exception:
        saved = {}
    for key in PREF_KEYS:
        entry = saved.get(key)
        if isinstance(entry, dict) and entry.get("value") is not None:
            out[key] = entry["value"]
    _prefs.update(at=now(), value=dict(out))
    return out


def remember(api, key, value, now=time.time):
    """Save one choice on the account (newest change wins on every device, as prefs-sync.js merges)."""
    if _prefs["value"] is not None:
        _prefs["value"][key] = value
    try:
        api.call("PUT", "/api/prefs", body={"prefs": {key: {"value": value, "updatedAt": int(now() * 1000)}}})
        return True
    except Exception:
        return False


def forget_prefs():
    _prefs.update(at=0.0, value=None)


# ---- the tracks of what is playing (Kodi JSON-RPC) -----------------------------------------------------------------

def tracks(call, playerid=1):
    """{"audio": [{index, lang, label, on}], "subs": [...], "subs_on": bool} for what is playing."""
    try:
        r = call("Player.GetProperties", {"playerid": playerid, "properties": [
            "audiostreams", "currentaudiostream", "subtitles", "currentsubtitle", "subtitleenabled"]}) or {}
    except Exception:
        r = {}
    if not isinstance(r, dict):
        r = {}
    cur_a = (r.get("currentaudiostream") or {}).get("index")
    cur_s = (r.get("currentsubtitle") or {}).get("index")
    subs_on = bool(r.get("subtitleenabled"))

    def rows(items, current, on=True):
        out = []
        for i, s in enumerate(items or []):
            if not isinstance(s, dict):
                continue
            idx = s.get("index", i)
            lang = lang2(s.get("language"))
            name = str(s.get("name") or "").strip()
            words = lang_name(s.get("language")) if s.get("language") else ""
            label = name if name and words and words.lower() in name.lower() else " · ".join(p for p in [words, name] if p) or "Track %d" % (i + 1)
            out.append({"index": idx, "lang": lang, "label": label, "on": on and idx == current})
        return out
    return {"audio": rows(r.get("audiostreams"), cur_a), "subs": rows(r.get("subtitles"), cur_s, subs_on), "subs_on": subs_on}


def choose_audio(audio, wanted):
    """The track to switch to so the saved language plays: its index, or None (one track, no wish, already on, missing)."""
    if not wanted or wanted == "off" or len(audio or []) < 2:
        return None
    match = next((t for t in audio if t["lang"] == lang2(wanted)), None)
    return match["index"] if match and not match["on"] else None


def choose_subtitle(subs, wanted):
    """("track", index) for a subtitle in the version, ("online", lang) to look online, or None (off, or on already)."""
    if not wanted or wanted == "off":
        return None
    want = lang2(wanted)
    match = next((t for t in subs or [] if t["lang"] == want), None)
    if match:
        return None if match["on"] else ("track", match["index"])
    return ("online", want)


def menu(t, imdb):
    """The Subtitles choices: Off, the version's own tracks, then each language online (when the title is known)."""
    rows = [{"key": "off", "label": "Off", "label2": "", "on": not t["subs_on"]}]
    for s in t["subs"]:
        rows.append({"key": "track:%s" % s["index"], "lang": s["lang"], "label": s["label"], "label2": "In this version", "on": s["on"]})
    if imdb:
        for code, name in SUB_LANGUAGES:
            rows.append({"key": "online:" + code, "lang": code, "label": name, "label2": "Find online", "on": False})
    return rows


# ---- subtitles from the server (OpenSubtitles through /meta/subs) -------------------------------------------------------

def online(api, folder, imdb, lang, season=None, episode=None):
    """Download the subtitles for a movie (imdb) or an episode (the show's imdb, season, episode) in one language to a
    file Kodi can show. Returns its path, or "" when none were found."""
    if not re.match(r"^tt\d{1,10}$", str(imdb or "")) or not re.match(r"^[a-z]{2}$", str(lang or "")):
        return ""
    query = {"imdb": imdb, "lang": lang}
    if season is not None and episode is not None:
        query.update(season=int(season), episode=int(episode))
    name = "%s-%s%s.srt" % (imdb, lang, "-s%se%s" % (int(season), int(episode)) if season is not None and episode is not None else "")
    path = os.path.join(folder, "subtitles", name)
    if os.path.isfile(path) and os.path.getsize(path) > 20:
        return path
    try:
        status, text, _ = api.raw("GET", "/meta/subs", query, timeout=20)
    except Exception:
        return ""
    if status != 200 or not text or len(text) <= 20 or len(text) > MAX_SUBS:
        return ""
    body = text.lstrip(b"\xef\xbb\xbf")
    if body.lstrip()[:1] in (b"{", b"<"):  # an error page, not subtitles
        return ""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "wb") as f:
            f.write(body)
        os.replace(tmp, path)
    except OSError:
        return ""
    prune(os.path.dirname(path))
    return path


def prune(folder, keep=40):
    """Keep the newest few downloaded subtitles, so the box's card never fills up."""
    try:
        names = sorted((os.path.join(folder, n) for n in os.listdir(folder) if n.endswith(".srt")), key=os.path.getmtime, reverse=True)
    except OSError:
        return
    for old in names[keep:]:
        try:
            os.remove(old)
        except OSError:
            pass


# ---- the look (Kodi's own subtitle settings) ----------------------------------------------------------------------------

FONT_SIZE = {"small": 34, "medium": 42, "large": 52, "xl": 62}  # Kodi's default is 42


def style_settings(size, style):
    """Kodi 21's subtitle settings for the web's size and look (Settings > Player > Subtitles on the box)."""
    out = [("subtitles.fontsize", FONT_SIZE.get(size, 42))]
    if style == "box":
        out += [("subtitles.colorpick", "FFFFFFFF"), ("subtitles.backgroundtype", 2), ("subtitles.bgcolorpick", "FF000000"),
                ("subtitles.bgopacity", 70)]
    elif style == "yellow":
        out += [("subtitles.colorpick", "FFFFFF00"), ("subtitles.backgroundtype", 1)]
    else:
        out += [("subtitles.colorpick", "FFFFFFFF"), ("subtitles.backgroundtype", 1)]
    return out


def apply_style(call, size, style, window=None):
    """Put the look into Kodi's settings once (window: Window(Home), which remembers what was put last). Returns how
    many settings Kodi took; a setting this Kodi doesn't have is skipped."""
    stamp = "%s/%s" % (size, style)
    if window is not None and window.getProperty("mc.substyle") == stamp:
        return 0
    took = 0
    for setting, value in style_settings(size, style):
        try:
            if call("Settings.SetSettingValue", {"setting": setting, "value": value}) is not None:
                took += 1
        except Exception:
            pass
    if window is not None:
        window.setProperty("mc.substyle", stamp)
    return took


def rpc(execute):
    """Kodi's JSON-RPC as call(method, params) -> result (None on an error)."""
    def call(method, params=None):
        answer = json.loads(execute(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}})) or "{}")
        return answer.get("result")
    return call
