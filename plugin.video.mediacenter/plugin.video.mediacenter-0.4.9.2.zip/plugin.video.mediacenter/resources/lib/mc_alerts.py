# mediaCENTER for Kodi: game alerts for My Teams (0.4.9). The service asks every two minutes while the account has
# teams picked (Settings, "Game alerts for My Teams", on by default): a note when one of their games is about to start
# (15 minutes before), when it starts and the final score. Nothing is said twice; what was said is kept in the
# profile (game-alerts.json), so a restart does not repeat it. The rules are mc_sports.alerts.

import json
import os
import time

import mc_sports as S

EVERY = 120  # seconds between looks
KEEP = 200  # games remembered


def path(profile):
    return os.path.join(profile, "game-alerts.json")


def read_seen(profile):
    try:
        with open(path(profile), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def write_seen(profile, seen):
    try:
        if not os.path.isdir(profile):
            os.makedirs(profile)
        keep = dict(list(seen.items())[-KEEP:])
        with open(path(profile), "w", encoding="utf-8") as f:
            json.dump(keep, f)
    except OSError:
        pass


def check(api, profile, notify, now=None):
    """One look: the account's teams and today's games, then a note for each new thing. Returns the texts said.
    The first look after a start only remembers what is already on, so the box doesn't announce old news."""
    prefs = (api.get("/api/prefs") or {}).get("prefs") or {}
    entry = prefs.get("myTeams")
    mine = [str(k) for k in (entry.get("value") or [])] if isinstance(entry, dict) and isinstance(entry.get("value"), list) else []
    if not mine:
        return []
    active = api.get("/api/sports/active")
    try:
        roku = api.get("/api/roku/sports")
    except Exception:  # the channels are only for "on ESPN"; the alert goes without them
        roku = None
    games = S.join(active, roku, mine)
    first = not os.path.isfile(path(profile))
    seen = read_seen(profile)
    said = S.alerts(games, mine, seen, now or time.time())
    write_seen(profile, seen)
    if first:
        return []
    for _, text in said:
        notify(text)
    return [text for _, text in said]
