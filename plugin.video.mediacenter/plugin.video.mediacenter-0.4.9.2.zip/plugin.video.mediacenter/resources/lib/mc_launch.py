# mediaCENTER for Kodi: how to open the full-screen app.
#
# The launcher add-on (script.mediacenter) is what the mediaCENTER skin opens. The add-on (plugin.video.mediacenter)
# requires it, so every update from the repository brings the newest launcher along; the launcher requires nothing
# back, so the two never depend on each other in a loop. If the launcher is missing (an add-on installed from a zip
# file, mid-update), the add-on's own app.py opens the same app.

import os

import xbmc

LAUNCHER = "script.mediacenter"


def open_app(addon_path):
    """The Kodi command that opens the app."""
    if xbmc.getCondVisibility("System.HasAddon(%s)" % LAUNCHER):
        return "RunScript(%s)" % LAUNCHER
    return "RunScript(%s)" % os.path.join(addon_path, "app.py")
