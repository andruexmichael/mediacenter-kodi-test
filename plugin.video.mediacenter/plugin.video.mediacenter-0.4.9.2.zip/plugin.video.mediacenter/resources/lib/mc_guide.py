# mediaCENTER for Kodi: the TV guide grid.
#
# Kodi draws a real guide (channels down the side, a timeline across, channel up/down while watching) for any "PVR
# client". We use Kodi's own IPTV Simple Client (pvr.iptvsimple) and give it two files this add-on writes into its private
# folder: a channel list (M3U) whose links point back to this add-on (action=play_live, so playing still goes through
# the account's session or signed links), and the guide (XMLTV) cut down to those channels and a window around now
# (the server's guide is about 11 MB; a Raspberry Pi 3 would be slow with all of it). The service refreshes both every
# few hours. Which channels: Locals and Cable (the web's and the Roku's default list) or every channel (a setting).

import os
import re
import time
import xml.etree.ElementTree as ET

KEEP_BEFORE = 4 * 3600
KEEP_AFTER = 30 * 3600
REFRESH_EVERY = 4 * 3600
XTREAM = {"username": "STAGING_TESTER", "password": "STAGING_PROXY"}


# ---- pure parts (tested off the box) ---------------------------------------------------------------------------------

def xmltv_time(s):
    """ "20261011170000 +0000" -> seconds since 1970 (None when it can't be read)."""
    m = re.match(r"^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)\s*([+-])(\d\d)(\d\d)", s or "")
    if not m:
        return None
    import calendar
    utc = calendar.timegm((int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4)), int(m.group(5)), int(m.group(6)), 0, 0, 0))
    off = (int(m.group(8)) * 60 + int(m.group(9))) * 60 * (1 if m.group(7) == "+" else -1)
    return utc - off


def pick_channels(channels, categories, everything=False):
    """Locals and Cable (the provider's categories named local or cable; when there are none, the US channels, as
    src/ba-roku.js localsAndCable does), or every channel. Each keeps its category's name for Kodi's channel groups."""
    names = {str(c.get("category_id")): str(c.get("category_name") or "") for c in categories or [] if isinstance(c, dict)}
    if everything:
        picked = list(channels)
    else:
        named = {cid for cid, name in names.items() if re.search(r"local|cable", name, re.I)}
        if named:
            picked = [c for c in channels if c["category"] in named]
        else:
            picked = [c for c in channels if c.get("us") and not re.search(r"\b(ppv|event|alt)\b", c["name"], re.I)]
        picked = sorted(picked, key=lambda c: c["num"] or 10 ** 9)[:200]
    for c in picked:
        c["group"] = names.get(c["category"], "")
    return picked


def m3u_text(channels, plugin_base):
    """The channel list for IPTV Simple. Links go back to this add-on, never straight to the server."""
    from urllib.parse import urlencode
    lines = ["#EXTM3U"]
    for c in channels:
        attrs = ['tvg-id="%s"' % _attr(c.get("epgId", "")), 'tvg-chno="%s"' % (c.get("num") or ""), 'tvg-name="%s"' % _attr(c["name"])]
        if c.get("logo", "").startswith("http"):
            attrs.append('tvg-logo="%s"' % _attr(c["logo"]))
        if c.get("group"):
            attrs.append('group-title="%s"' % _attr(c["group"]))
        lines.append("#EXTINF:-1 %s,%s" % (" ".join(attrs), c["name"].replace("\n", " ")))
        lines.append(plugin_base + "?" + urlencode({"action": "play_live", "id": c["id"], "name": c["name"]}))
    return "\n".join(lines) + "\n"


def _attr(s):
    return str(s).replace('"', "'").replace("\n", " ")


def trim_guide(src, dst, keep_ids, now=None):
    """Copy only the kept channels' <channel> and <programme> entries in [now - 4 h, now + 30 h] from the XMLTV file
    `src` to `dst`, reading it piece by piece (memory stays small). Returns how many programmes were kept."""
    now = now or time.time()
    lo, hi = now - KEEP_BEFORE, now + KEEP_AFTER
    keep = set(i for i in keep_ids if i)
    kept = 0
    root = ET.Element("tv", {"generator-info-name": "mediaCENTER"})
    for _, el in ET.iterparse(src, events=("end",)):
        if el.tag == "channel":
            if el.get("id") in keep:
                root.append(el)
            else:
                el.clear()
        elif el.tag == "programme":
            start, stop = xmltv_time(el.get("start")), xmltv_time(el.get("stop"))
            if el.get("channel") in keep and start is not None and stop is not None and stop > lo and start < hi:
                root.append(el)
                kept += 1
            else:
                el.clear()
    tmp = dst + ".tmp"
    ET.ElementTree(root).write(tmp, encoding="utf-8", xml_declaration=True)
    os.replace(tmp, dst)
    return kept


def read_guide(path, now=None):
    """The box's own guide file (written by refresh) as {epgId: [{"start", "stop", "title", "desc"}]} (seconds), for the
    Guide screen; {} when there is none yet or it can't be read. Only programmes from an hour ago on."""
    now = now or time.time()
    out = {}
    try:
        for _, el in ET.iterparse(path, events=("end",)):
            if el.tag != "programme":
                continue
            start, stop = xmltv_time(el.get("start")), xmltv_time(el.get("stop"))
            if start is not None and stop is not None and stop > now - 3600:
                out.setdefault(el.get("channel") or "", []).append({
                    "start": start, "stop": stop, "title": (el.findtext("title") or "").strip(), "desc": (el.findtext("desc") or "").strip()})
            el.clear()
    except (OSError, ET.ParseError):
        return {}
    for progs in out.values():
        progs.sort(key=lambda p: p["start"])
    return out


IPTV_SETTINGS = """<settings version="2">
    <setting id="kodi_addon_instance_name">mediaCENTER</setting>
    <setting id="kodi_addon_instance_enabled">true</setting>
    <setting id="m3uPathType">0</setting>
    <setting id="m3uPath">{m3u}</setting>
    <setting id="m3uCache">false</setting>
    <setting id="epgPathType">0</setting>
    <setting id="epgPath">{epg}</setting>
    <setting id="epgCache">false</setting>
    <setting id="logoFromEpg">1</setting>
    <setting id="numberByOrder">false</setting>
</settings>
"""


def iptv_settings(m3u, epg):
    from xml.sax.saxutils import escape
    return IPTV_SETTINGS.format(m3u=escape(m3u), epg=escape(epg))


# ---- on the box ------------------------------------------------------------------------------------------------------

def folder(profile):
    path = os.path.join(profile, "guide")
    if not os.path.isdir(path):
        os.makedirs(path)
    return path


def refresh(api, profile, plugin_base, everything=False, log=lambda m: None):
    """Write channels.m3u and guide.xml for IPTV Simple. Returns (channels, programmes)."""
    import mc_logic as L
    out = folder(profile)
    categories = api.get("/player_api.php", action="get_live_categories", **XTREAM) or []
    streams = api.get("/player_api.php", action="get_live_streams", **XTREAM) or []
    channels = pick_channels(L.fold_lineup(streams), categories, everything)
    with open(os.path.join(out, "channels.m3u.tmp"), "w", encoding="utf-8") as f:
        f.write(m3u_text(channels, plugin_base))
    os.replace(os.path.join(out, "channels.m3u.tmp"), os.path.join(out, "channels.m3u"))
    raw = os.path.join(out, "full.xml")
    status, body, _ = api.raw("GET", "/xmltv.php", XTREAM, timeout=90)
    programmes = 0
    if status == 200 and body:
        with open(raw, "wb") as f:
            f.write(body)
        body = None
        try:
            programmes = trim_guide(raw, os.path.join(out, "guide.xml"), [c.get("epgId") for c in channels])
        except ET.ParseError:
            log("guide: the server's guide could not be read; keeping the last one")
        finally:
            try:
                os.remove(raw)
            except OSError:
                pass
    else:
        log("guide: HTTP %s" % status)
    with open(os.path.join(out, "updated"), "w") as f:
        f.write(str(int(time.time())))
    return len(channels), programmes


def due(profile):
    try:
        with open(os.path.join(profile, "guide", "updated")) as f:
            return time.time() - int(f.read().strip() or 0) > REFRESH_EVERY
    except (OSError, ValueError):
        return False  # never set up: only the Guide screen sets it up


def set_up_pvr(profile, translate):
    """Point IPTV Simple at our files and restart it, so Kodi's TV guide shows mediaCENTER's channels.
    Returns "" or what is missing."""
    import json
    import xbmc
    import xbmcaddon
    try:
        xbmcaddon.Addon("pvr.iptvsimple")
    except RuntimeError:
        xbmc.executebuiltin("InstallAddon(pvr.iptvsimple)", True)
        try:
            xbmcaddon.Addon("pvr.iptvsimple")
        except RuntimeError:
            return "The TV guide isn't set up on this box yet. Ask whoever set it up to add the TV guide part."
    out = folder(profile)
    m3u, epg = os.path.join(out, "channels.m3u"), os.path.join(out, "guide.xml")
    settings_dir = translate("special://profile/addon_data/pvr.iptvsimple")
    if not os.path.isdir(settings_dir):
        os.makedirs(settings_dir)
    with open(os.path.join(settings_dir, "instance-settings-1.xml"), "w", encoding="utf-8") as f:
        f.write(iptv_settings(m3u, epg))
    try:  # Kodi 19 keeps one set of settings per add-on
        a = xbmcaddon.Addon("pvr.iptvsimple")
        for key, value in (("m3uPathType", "0"), ("m3uPath", m3u), ("epgPathType", "0"), ("epgPath", epg)):
            a.setSetting(key, value)
    except Exception:
        pass
    for enabled in (False, True):
        xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
                                        "params": {"addonid": "pvr.iptvsimple", "enabled": enabled}}))
        xbmc.sleep(1500)
    return ""
