# mediaCENTER for Kodi: "Picked for you" (0.4.9), as the website makes it (web-v27/js/taste.js, views/picks.js).
# A short survey (genres you like, genres to skip, movies or shows) kept with the account as the synced setting
# "tasteSurvey" (/api/prefs, web-v27/js/prefs-sync.js), and the personal collections built from it: each liked genre is
# one collection, with a title with some personality that changes by the day, and its titles mixed from TMDB's genre rows
# (/meta/row?type=...&row=genre:N, the same rows the Movies and TV Shows pages use).
#
# The lists below are taste.js's, word for word; kodi/tests/test_more.py reads taste.js and fails when they differ.
# Pure: no Kodi here, so it is tested on its own.

import time

PREF = "tasteSurvey"

# (key, name, TMDB movie genre, TMDB show genre); 0 means that kind has no such genre.
GENRES = [
    ("action", "Action", 28, 10759),
    ("comedy", "Comedy", 35, 35),
    ("crime", "Crime", 80, 80),
    ("drama", "Drama", 18, 18),
    ("horror", "Horror", 27, 0),
    ("romance", "Romance", 10749, 0),
    ("scifi", "Sci-fi and fantasy", 878, 10765),
    ("reality", "Reality", 0, 10764),
    ("animation", "Animation", 16, 16),
    ("documentary", "Documentary", 99, 99),
    ("thriller", "Thrillers", 53, 9648),
    ("family", "Family", 10751, 10751),
]
KEYS = [g[0] for g in GENRES]
NAMES = {g[0]: g[1] for g in GENRES}

VOICE = {
    "action": ["Things blow up so you can relax", "Explosions you can feel fine about later", "Buckle up, the couch is staying put"],
    "comedy": ["Funnier than your group chat", "Laughs for people who skip the small talk", "Comfort comedy for a long day"],
    "crime": ["You said crime. We heard crimes. Plural.", "Whodunit? Let us help you guess wrong", "Cases to ignore your plans for"],
    "drama": ["Feelings, but make it prestige", "Bring tissues, no judgment", "Plot twists with good lighting"],
    "horror": ["Lights on is allowed", "Scary enough for one hand over the eyes", "Sleep is overrated anyway"],
    "romance": ["Swoon responsibly", "Butterflies, minus the dating apps", "Happily ever after, give or take a plot twist"],
    "scifi": ["Other planets, same problems", "The future, but make it someone else's problem", "Dragons optional, wonder required"],
    "reality": ["Guilty pleasure, zero guilt", "Other people's drama, delivered", "Reality, but with better lighting"],
    "animation": ["Cartoons, and you're allowed", "Drawn to your attention", "Grown-up feelings, hand-drawn"],
    "documentary": ["Learn something while pretending to relax", "True stories, no popcorn judgment", "Facts, but fun"],
    "thriller": ["Nail-biters, bring snacks", "Edge-of-your-seat, seat optional", "Keep guessing, keep watching"],
    "family": ["Safe for the whole couch", "Something everyone agrees on, for once", "Movie night, negotiated"],
}

KINDS = [("movie", "Movies"), ("series", "Shows"), ("both", "Both")]

# The survey's three steps, as the website words them (views/picks.js TasteSurvey).
STEPS = [
    ("What do you like to watch?", "Pick up to six. We make collections from them, only for you."),
    ("Anything to skip?", "Optional. These stay out of your picks."),
    ("Movies, shows, or both?", "You can change this any time."),
]
MAX_LIKED = 6


def _hash(text):
    """taste.js hash(): FNV-1a, 32 bits, over each character's first UTF-16 unit (charCodeAt(0) of each code point)."""
    h = 2166136261
    for ch in text:
        n = ord(ch)
        unit = n if n < 0x10000 else 0xD800 + ((n - 0x10000) >> 10)
        h = ((h ^ unit) * 16777619) & 0xFFFFFFFF
    return h


def day_number(now=None):
    return int((time.time() if now is None else now) * 1000 // 86400000)


def clean(raw):
    """What the survey keeps: {"liked", "skip", "kind", "doneAt"}, or None when nothing is liked (taste.js cleanSurvey)."""
    raw = raw if isinstance(raw, dict) else {}
    liked = []
    for k in raw.get("liked") or []:
        if k in KEYS and k not in liked:
            liked.append(k)
    liked = liked[:MAX_LIKED]
    skip = []
    for k in raw.get("skip") or []:
        if k in KEYS and k not in liked and k not in skip:
            skip.append(k)
    kind = raw.get("kind") if raw.get("kind") in ("movie", "series", "both") else "both"
    try:
        done = int(raw.get("doneAt") or 0)
    except (TypeError, ValueError):
        done = 0
    return {"liked": liked, "skip": skip, "kind": kind, "doneAt": done} if liked else None


def picks(survey, day=None):
    """The personal collections, most-liked first: [{id, title, blurb, genre, rows: [(type, genre id)]}] (buildPicks)."""
    s = clean(survey)
    if not s:
        return []
    day = day_number() if day is None else day
    out = []
    for key in s["liked"]:
        _, name, movie, show = next(g for g in GENRES if g[0] == key)
        rows = []
        if s["kind"] != "series" and movie:
            rows.append(("movie", movie))
        if s["kind"] != "movie" and show:
            rows.append(("series", show))
        if not rows:
            rows.append(("movie", movie) if movie else ("series", show))
        lines = VOICE[key]
        out.append({"id": key, "title": lines[_hash("%d|%s" % (day, key)) % len(lines)], "blurb": "%s, picked for you" % name,
                    "genre": name, "rows": rows})
    return out


def mix(lists, limit=24):
    """One list from a collection's rows, taking turns, with no title twice (mixTitles). Titles: mc_logic.title_of dicts."""
    out, seen = [], set()
    i = 0
    while len(out) < limit and any(i < len(l) for l in lists):
        for l in lists:
            t = l[i] if i < len(l) else None
            if t is None:
                continue
            key = (t.get("type"), t.get("tmdb") or t.get("name"))
            if key not in seen:
                seen.add(key)
                out.append(t)
                if len(out) >= limit:
                    break
        i += 1
    return out


def from_prefs(prefs):
    """The survey kept with the account, from an /api/prefs answer's "prefs"."""
    entry = (prefs or {}).get(PREF)
    return clean(entry.get("value")) if isinstance(entry, dict) else None


def body(survey, now=None):
    """What PUT /api/prefs sends for a finished survey."""
    at = int((time.time() if now is None else now) * 1000)
    return {"prefs": {PREF: {"value": survey, "updatedAt": at}}}


class Survey(object):
    """The survey's steps on the TV (mc_more.CardPage draws them): the same three steps and words as the website."""

    def __init__(self, start=None):
        s = clean(start) or {}
        self.liked = list(s.get("liked") or [])
        self.skip = list(s.get("skip") or [])
        self.kind = s.get("kind") or "both"
        self.step = 0

    def chips(self):
        """[(key, label, on)] for this step."""
        if self.step == 0:
            return [(k, NAMES[k], k in self.liked) for k in KEYS]
        if self.step == 1:
            return [(k, NAMES[k], k in self.skip) for k in KEYS if k not in self.liked]
        return [(k, label, self.kind == k) for k, label in KINDS]

    def toggle(self, key):
        if self.step == 0 and key in KEYS:
            if key in self.liked:
                self.liked.remove(key)
            elif len(self.liked) < MAX_LIKED:
                self.liked.append(key)
            self.skip = [k for k in self.skip if k not in self.liked]
        elif self.step == 1 and key in KEYS and key not in self.liked:
            if key in self.skip:
                self.skip.remove(key)
            else:
                self.skip.append(key)
        elif self.step == 2 and key in ("movie", "series", "both"):
            self.kind = key

    def buttons(self):
        """(back label, next label, next allowed)."""
        back = "Back" if self.step > 0 else "Not now"
        nxt = "Make my picks" if self.step == len(STEPS) - 1 else "Next"
        return back, nxt, not (self.step == 0 and not self.liked)

    def back(self):
        """False when the survey closes (Not now)."""
        if self.step == 0:
            return False
        self.step -= 1
        return True

    def next(self):
        """True when the survey is finished."""
        if self.step == 0 and not self.liked:
            return False
        if self.step < len(STEPS) - 1:
            self.step += 1
            return False
        return True

    def result(self, now=None):
        return clean({"liked": self.liked, "skip": self.skip, "kind": self.kind,
                      "doneAt": int((time.time() if now is None else now) * 1000)})
