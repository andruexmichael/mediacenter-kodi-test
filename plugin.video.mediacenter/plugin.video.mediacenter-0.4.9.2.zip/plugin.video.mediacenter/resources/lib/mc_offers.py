# mediaCENTER for Kodi: when to offer Skip Intro, Skip Credits or Next Episode (0.4.9).
#
# The same rules as the web player (web-v27/js/offers.js) and the Apple players (OfferTracker in
# shared/MediaCore/PlaybackOffers.swift); all three are checked against design/offer-cases.json
# (kodi/tests/test_watching.py). The player calls update() about once a second and draws the offer its own way.
#
# An offer is None, or one of: {"kind": "skipIntro", "to": s}, {"kind": "skipCredits"},
# {"kind": "nextEpisode", "countdown": n}, {"kind": "nextEpisodeHeld"} (Cancel was pressed: no countdown, no automatic
# switch, the button stays). Skip times come from the server's /api/segments (TheIntroDB, IntroDB), as on the web.

import math

COUNTDOWN_START = 15
INF = float("inf")


def _finite(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


class OfferTracker(object):
    def __init__(self, segments=None):
        self.segments = list(segments or [])
        self.offer = None
        self.countdown = COUNTDOWN_START
        self.dismissed = False
        self.held = False

    def set_segments(self, segments):
        self.segments = list(segments or [])

    def reset(self):
        self.offer, self.segments, self.countdown, self.dismissed, self.held = None, [], COUNTDOWN_START, False, False

    def clear(self):
        """Nothing to offer (live TV, a failed source, still loading)."""
        self.offer = None

    def update(self, t, length, is_episode, paused):
        """Returns "playNext" when the countdown ran out, else "none"."""
        if not _finite(t) or not t > 0:
            return "none"
        nxt = None
        intro = next((s for s in self.segments if s["type"] in ("Intro", "Recap") and s["start"] <= t < s["end"] - 1), None)
        if intro:
            nxt = {"kind": "skipIntro", "to": intro["end"]}
        elif _finite(length) and length > 300:
            marked = [s["start"] for s in self.segments if s["type"] in ("Outro", "Credits")]
            credits = min(marked) if marked else (length - 60 if is_episode else length * 0.96)
            if t >= credits and not self.dismissed:
                if is_episode:
                    if self.held:
                        nxt = {"kind": "nextEpisodeHeld"}
                    else:
                        if not paused:
                            self.countdown -= 1
                        if self.countdown <= 0:
                            self.offer, self.dismissed = None, True
                            return "playNext"
                        nxt = {"kind": "nextEpisode", "countdown": self.countdown}
                else:
                    nxt = {"kind": "skipCredits"}
        if nxt != self.offer:
            self.offer = nxt
        return "none"

    def take(self, length=None):
        """The viewer took the current offer: {"kind": "seek", "to": s} | "finish" | "playNext" | "nothing"."""
        o = self.offer
        if not o:
            return "nothing"
        if o["kind"] == "skipIntro":
            self.offer = None
            return {"kind": "seek", "to": min(o["to"], length - 5) if _finite(length) else min(o["to"], 600)}
        if o["kind"] == "skipCredits":
            self.offer, self.dismissed = None, True
            return "finish"
        self.offer, self.dismissed = None, True
        return "playNext"

    def cancel_countdown(self):
        """Cancel on the Next Episode countdown: stop counting, keep the Next Episode button until it is pressed."""
        if (self.offer or {}).get("kind") != "nextEpisode":
            return
        self.held = True
        self.offer = {"kind": "nextEpisodeHeld"}

    def dismiss(self):
        """Hides the offer for the rest of this playback."""
        self.offer, self.dismissed = None, True

    def take_next_episode(self):
        """The controls' own Next Episode button."""
        self.offer, self.dismissed = None, True


def segments_from(items):
    """Skip times from the server's /api/segments answer ([{type, start, end|None}]) as tracker segments."""
    out = []
    for s in items if isinstance(items, list) else []:
        if not isinstance(s, dict) or not isinstance(s.get("type"), str):
            continue
        try:
            start = float(s.get("start") if s.get("start") is not None else 0)
            end = INF if s.get("end") is None else float(s["end"])
        except (TypeError, ValueError):
            continue
        if not math.isfinite(start):
            continue
        out.append({"type": s["type"], "start": start, "end": end})
    return out


def load_segments(api, imdb, season=None, episode=None):
    """Skip times for a movie or an episode from the server. Never raises: no answer means only the default offers
    near the end."""
    import re
    if not re.match(r"^tt\d{1,10}$", str(imdb or "")):
        return []
    query = {"imdb": imdb}
    if season is not None and episode is not None:
        query.update(season=int(season), episode=int(episode))
    try:
        answer = api.get("/api/segments", **query) or {}
    except Exception:
        return []
    return segments_from(answer.get("segments") if isinstance(answer, dict) else None)


def label(offer):
    """The words on the offer's button (the web's offer card), or ""."""
    kind = (offer or {}).get("kind")
    if kind == "skipIntro":
        return "Skip Intro"
    if kind == "skipCredits":
        return "Skip Credits"
    if kind == "nextEpisode":
        return "Next Episode in %d" % offer["countdown"]
    if kind == "nextEpisodeHeld":
        return "Next Episode"
    return ""
