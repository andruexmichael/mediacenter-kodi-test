# mediaCENTER for Kodi: the power menu (mediacenter-power.xml), opened by the iPhone remote's power button (owner,
# 2026-11-26). "Power off" stops what's playing and turns the TV off over HDMI (CEC); the box itself stays on, so the
# next power press turns the TV back on. "Set sleep timer" does the same after 15 minutes to 2 hours, with a notice a
# minute before. The timer lives in Home window properties, so it lasts while Kodi runs and the app's service
# (plugin.video.mediacenter/service.py) ends it; a restart forgets it.

import time

SLEEP_AT, SLEEP_WARNED, TV_OFF, OPEN = ("mediacenter." + k for k in ("sleep.at", "sleep.warned", "tv.off", "power.open"))
CHOICES = (15, 30, 45, 60, 90, 120)  # minutes
WARN = 60  # seconds before the end
LIST = 50
BACK = (9, 10, 92, 247)


def minutes_text(minutes):
    hours, rest = divmod(int(minutes), 60)
    parts = (["%d hour%s" % (hours, "" if hours == 1 else "s")] if hours else []) + \
            (["%d minute%s" % (rest, "" if rest == 1 else "s")] if rest or not hours else [])
    return " ".join(parts)


def clock(at):
    return time.strftime("%I:%M %p", time.localtime(at)).lstrip("0")


def timer_at(home):
    try:
        at = float(home.getProperty(SLEEP_AT) or 0)
    except ValueError:
        return 0
    return at if at > 0 else 0


def timer_line(home, now=None):
    """What the sleep timer row says: Off, or when it ends and how long is left."""
    at, now = timer_at(home), now or time.time()
    if not at or at <= now:
        return "Off"
    left = max(1, int((at - now + 59) // 60))
    return "Ends at %s, %s left" % (clock(at), minutes_text(left))


def set_timer(home, minutes, now=None):
    at = (now or time.time()) + int(minutes) * 60
    home.setProperty(SLEEP_AT, str(int(at)))
    home.clearProperty(SLEEP_WARNED)
    return at


def cancel_timer(home):
    home.clearProperty(SLEEP_AT)
    home.clearProperty(SLEEP_WARNED)


def due(home, now=None):
    """What the timer needs now: "warn" (a minute left), "end", or None. The service asks every second."""
    at, now = timer_at(home), now or time.time()
    if not at:
        return None
    if now >= at:
        cancel_timer(home)
        return "end"
    if at - now <= WARN and not home.getProperty(SLEEP_WARNED):
        home.setProperty(SLEEP_WARNED, "1")
        return "warn"
    return None


def power_off(home, builtin, rpc):
    """Stop what's playing and turn the TV off. The box stays on, listening for the remote."""
    try:
        for player in rpc("Player.GetActivePlayers", {}) or []:
            rpc("Player.Stop", {"playerid": player["playerid"]})
    except Exception:
        pass  # the TV still goes off
    cancel_timer(home)
    home.setProperty(TV_OFF, "1")
    builtin("CECStandby")


def tv_on(home, builtin):
    home.clearProperty(TV_OFF)
    builtin("CECActivateSource")


def tick(home, builtin, rpc, notify, now=None):
    """The service's every-second look at the sleep timer."""
    step = due(home, now)
    if step == "warn":
        notify("Sleep timer: the TV turns off in a minute.")
    elif step == "end":
        power_off(home, builtin, rpc)
    return step


def rows(home, now=None):
    """The menu's rows: (label, label2, action)."""
    out = [("Power off", "Turns off the TV and stops what's playing", "off"),
           ("Set sleep timer", timer_line(home, now), "timer")]
    if timer_at(home) > (now or time.time()):
        out.append(("Turn off the sleep timer", "", "cancel"))
    return out + [("Cancel", "", "close")]


def timer_rows():
    return [(minutes_text(m), "", "set:%d" % m) for m in CHOICES] + [("Back", "", "back")]


def open_menu():
    """The power button: the menu, or, when the TV was turned off from here, the TV back on."""
    import json

    import xbmc
    import xbmcgui
    home = xbmcgui.Window(10000)
    builtin = xbmc.executebuiltin
    if home.getProperty(TV_OFF):
        return tv_on(home, builtin)
    if home.getProperty(OPEN):
        return None  # already showing
    import mc_views as V
    home.setProperty(OPEN, "1")
    try:
        w = PowerMenu("mediacenter-power.xml", V.HERE, "Default", "1080i")
        w.home, w.builtin = home, builtin
        w.rpc = lambda method, params: json.loads(xbmc.executeJSONRPC(json.dumps(
            {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))).get("result")
        w.doModal()
        del w
    finally:
        home.clearProperty(OPEN)


try:
    import xbmcgui as _gui
    _Dialog = _gui.WindowXMLDialog
except ImportError:  # outside Kodi (the timer's own tests)
    _gui, _Dialog = None, object


class PowerMenu(_Dialog):
    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started = True
        self.show("menu")

    def show(self, page, focus=0):
        self.page = page
        self.setProperty("heading", "Sleep timer" if page == "timer" else "Power")
        self.setProperty("subheading", "The TV turns off when the time is up." if page == "timer" else
                         "The box stays on, so the power button turns the TV back on.")
        self.items = timer_rows() if page == "timer" else rows(self.home)
        control = self.getControl(LIST)
        control.reset()
        control.addItems([_gui.ListItem(a, b) for a, b, _ in self.items])
        control.selectItem(focus)
        self.setFocusId(LIST)

    def onClick(self, control_id):
        if control_id != LIST:
            return
        action = self.items[self.getControl(LIST).getSelectedPosition()][2]
        if action == "off":
            self.close()
            return power_off(self.home, self.builtin, self.rpc)
        if action == "timer":
            return self.show("timer")
        if action == "cancel":
            cancel_timer(self.home)
            self.close()
            return _gui.Dialog().notification("mediaCENTER", "Sleep timer is off.")
        if action.startswith("set:"):
            at = set_timer(self.home, int(action[4:]))
            self.close()
            return _gui.Dialog().notification("mediaCENTER", "Sleep timer set. The TV turns off at %s." % clock(at))
        if action == "back":
            return self.show("menu", focus=1)
        self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            if self.page == "timer":
                return self.show("menu", focus=1)
            return self.close()
