# mediaCENTER for Kodi: the website's colour themes (Settings > Appearance on the web, web-v27/js/look.js).
#
# The themes come from design/tokens.json ("themes", the web's list: mediaCENTER, Ocean, Ember, Forest), copied into
# resources/data/themes.json by kodi/tools/make_windows.py. The choice follows the account: the web app keeps it in
# /api/prefs as "webTheme" (web-v27/js/prefs-sync.js), so a theme picked on the website shows here too, and one
# picked here shows on the website. The newer choice wins, as every synced setting does.
#
# The windows never hold a colour of a theme: they read Window(Home) properties (mc.accent, mc.base, mc.glow1..4 and a
# few shades), which apply() sets. Kodi's CGUIInfoColor reads "$INFO[...]" in textcolor and colordiffuse, so a change
# shows at once on every open page. The few colours Python writes into labels ([COLOR ...]) come from color().

import json
import os
import time

PREF = "webTheme"
DEFAULT = "original"
HOME = 10000


def _here():
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def load_themes(path=None):
    """[{"id", "name", "accent", "accentDeep", "base", "glow": [4], "mark": [4]}] in the web's order."""
    path = path or os.path.join(_here(), "resources", "data", "themes.json")
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        themes = [t for t in data.get("themes", []) if isinstance(t, dict) and t.get("id")]
        if themes:
            return themes
    except (OSError, ValueError, AttributeError):
        pass
    return [{"id": DEFAULT, "name": "mediaCENTER", "accent": "#e51c23", "accentDeep": "#cc0f21", "base": "#090809",
             "glow": ["#ff4545", "#4d85ff", "#ffd95c", "#6bdb7a"]}]


THEMES = load_themes()


def find(theme_id):
    return next((t for t in THEMES if t["id"] == theme_id), THEMES[0])


def argb(hex_color, alpha="FF"):
    h = str(hex_color or "").lstrip("#")
    if len(h) == 3:
        h = "".join(ch * 2 for ch in h)
    return (alpha + h).upper() if len(h) == 6 else alpha + "FFFFFF"


def light(hex_color):
    """Whether text on this colour should be dark (a pale accent, as the Poster theme's white)."""
    h = str(hex_color or "").lstrip("#")
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except (ValueError, IndexError):
        return False
    return (0.299 * r + 0.587 * g + 0.114 * b) > 186


def palette(theme):
    """The Window(Home) properties a theme sets. The glows are the web's background (appearance.css: four soft radial
    glows at 26, 24, 18 and 18 per cent over the theme's base colour)."""
    glow = (list(theme.get("glow") or []) + ["#000000"] * 4)[:4]
    accent = theme.get("accent", "#e51c23")
    out = {
        "mc.theme": theme["id"],
        "mc.accent": argb(accent),
        "mc.accentdeep": argb(theme.get("accentDeep", accent)),
        "mc.accent.soft": argb(accent, "33"),   # a chip or row that is on but not focused
        "mc.accent.half": argb(accent, "80"),
        "mc.accentdeep.73": argb(theme.get("accentDeep", accent), "73"),  # the opening's glow
        "mc.onaccent": "FF09090A" if light(accent) else "FFFFFFFF",
        "mc.base": argb(theme.get("base", "#090809")),
        "mc.base.e6": argb(theme.get("base", "#090809"), "E6"),  # the sidebar over the hero
        "mc.base.cc": argb(theme.get("base", "#090809"), "CC"),
    }
    for i, (color, alpha) in enumerate(zip(glow, ("42", "3D", "2E", "2E")), 1):
        out["mc.glow%d" % i] = argb(color, alpha)
    return out


def apply(theme_id, window=None):
    """Put a theme's colours where the windows read them (Window(Home) properties); returns the theme used."""
    theme = find(theme_id)
    if window is None:
        import xbmcgui
        window = xbmcgui.Window(HOME)
    for key, value in palette(theme).items():
        window.setProperty(key, value)
    return theme


def color(name, window=None):
    """A theme colour as Kodi's [COLOR ...] takes it ("accent", "onaccent", "base"...), from what apply() set."""
    if window is None:
        import xbmcgui
        window = xbmcgui.Window(HOME)
    value = window.getProperty("mc." + name)
    if value:
        return value
    return palette(find(DEFAULT)).get("mc." + name, "FFFFFFFF")


def ensure(addon, window=None):
    """Apply this box's theme when no theme is applied yet (the app opened before the service, or Kodi restarted)."""
    if window is None:
        import xbmcgui
        window = xbmcgui.Window(HOME)
    if not window.getProperty("mc.accent"):
        apply(chosen(addon), window)


# ---- the choice: this box's setting, kept in step with the account -------------------------------------------------

def chosen(addon):
    value = addon.getSetting("theme")
    return value if any(t["id"] == value for t in THEMES) else DEFAULT


def stamp(addon):
    try:
        return int(addon.getSetting("theme_stamp") or 0)
    except ValueError:
        return 0


def merge(local_id, local_stamp, server):
    """Which theme wins between this box and the account (newer wins, prefs-sync.js): ("id", stamp, push) where push
    says the account should get this box's choice. server: the account's {"value", "updatedAt"} or None."""
    known = lambda v: any(t["id"] == v for t in THEMES)
    value = (server or {}).get("value") if isinstance(server, dict) else None
    try:
        at = int((server or {}).get("updatedAt") or 0) if isinstance(server, dict) else 0
    except (TypeError, ValueError):
        at = 0
    if known(value) and at >= local_stamp:
        return value, at, False
    if local_stamp and known(local_id):
        return local_id, local_stamp, value != local_id
    if known(value):
        return value, at, False
    return local_id, local_stamp, False


def sync(api, addon, prefs=None, window=None):
    """At start: take the account's theme when it is newer, send this box's when it is newer; then apply."""
    if prefs is None:
        try:
            prefs = (api.get("/api/prefs") or {}).get("prefs") or {}
        except Exception:
            prefs = {}
    theme_id, at, push = merge(chosen(addon), stamp(addon), (prefs or {}).get(PREF))
    if theme_id != addon.getSetting("theme") or str(at) != addon.getSetting("theme_stamp"):
        addon.setSetting("theme", theme_id)
        addon.setSetting("theme_stamp", str(at))
    if push:
        send(api, theme_id, at)
    return apply(theme_id, window)


def send(api, theme_id, at):
    try:
        api.call("PUT", "/api/prefs", body={"prefs": {PREF: {"value": theme_id, "updatedAt": int(at)}}})
        return True
    except Exception:
        return False


def choose(api, addon, theme_id, window=None):
    """Settings > Appearance: this box and the account now use this theme (shows at once on every page)."""
    theme = find(theme_id)
    at = int(time.time() * 1000)
    addon.setSetting("theme", theme["id"])
    addon.setSetting("theme_stamp", str(at))
    send(api, theme["id"], at)
    return apply(theme["id"], window)
