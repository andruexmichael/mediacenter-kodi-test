# mediaCENTER for Kodi: playing movies, episodes and live channels.
#
# Movies and episodes: GET /api/roku/play gives the versions the server found (TorBox, the library, the provider's
# own copy; signed links or paths on our server) and the account's Stremio add-ons, which this box asks itself (add-ons
# refuse our servers), the same way the Roku app does. The versions are ranked for this box (mc_logic.rank_versions):
# on a Raspberry Pi 3, H.264 up to 1080p first. "Choose a version" lists them; Play takes the best one.
# What is playing is left in a window property for service.py, which saves progress to /api/history.

import json
import threading

import xbmc
import xbmcgui
import xbmcplugin

import mc_logic as L
from mc_views import ADDON, WINDOW, PLAYING_KEY, notify, set_info, log
from mc_api import SignedOut, ServerError


def caps():
    pi = xbmc.getCondVisibility("System.Platform.Linux.RaspberryPi")
    max_res = {"0": "720p", "1": "1080p", "2": "2160p"}.get(ADDON.getSetting("max_res") or "1", "1080p")
    hevc_setting = ADDON.getSetting("hevc") or "auto"
    hevc = None if hevc_setting == "auto" else hevc_setting == "true"
    return L.device_caps(raspberry_pi=pi, max_res=max_res, hevc=hevc)


PLAY_WAIT = 50  # seconds /api/roku/play gets (it asks TorBox, the library and the provider one after the other)
SIDE_WAIT = 20  # seconds the add-on list and the title's IMDb number get, asked beside it


def side_answer(api, kind, tmdb):
    """The title's IMDb number and the account's add-ons from the routes every app uses (/meta/title, /api/addon-link),
    asked beside /api/roku/play: when that is slow or fails (The Walking Dead, 2026-11-26: no links for any episode),
    the add-ons are still asked."""
    imdb, addons = "", []
    try:
        m = api.call("GET", "/meta/title", {"type": kind, "tmdb": tmdb}, timeout=SIDE_WAIT) or {}
        imdb = str((m.get("ids") or {}).get("imdb") or m.get("imdb") or "")
    except Exception:
        pass
    try:
        addons = (api.call("GET", "/api/addon-link", timeout=SIDE_WAIT) or {}).get("addons") or []
    except Exception:
        pass
    return imdb, addons


def gather(api, kind, tmdb, season=None, episode=None):
    """Every version for one movie or episode: the server's (/api/roku/play) and the account's add-ons', asked in
    parallel. The add-ons are asked as soon as their list is known, without waiting for the server's answer; only
    when the server's answer fails and no add-on gave anything does the server's error come back to the page."""
    query = {"type": kind, "tmdb": tmdb}
    if kind == "series":
        query.update(season=season, episode=episode)
    box = {"answer": None, "error": None, "side": ("", [])}

    def ask_server():
        try:
            box["answer"] = api.call("GET", "/api/roku/play", query, timeout=PLAY_WAIT) or {}
        except Exception as e:
            box["error"] = e

    def ask_side():
        box["side"] = side_answer(api, kind, tmdb)
    main = threading.Thread(target=ask_server)
    side = threading.Thread(target=ask_side)
    for t in (main, side):
        t.daemon = True
        t.start()
    side.join(SIDE_WAIT * 2 + 5)
    imdb, side_addons = box["side"]
    asked, found, threads = set(), [], []

    def ask_addons(addons, imdb):
        if not imdb:
            return
        stream_id = imdb if kind == "movie" else "%s:%s:%s" % (imdb, season, episode)
        for a in addons or []:
            base = str((a or {}).get("base", "")) if isinstance(a, dict) else ""
            if not base.startswith("https://") or base in asked:
                continue
            asked.add(base)
            slot = []
            found.append(slot)
            th = threading.Thread(target=lambda b=base, s=slot: s.extend(L.addon_versions(api.addon_streams(b, kind, stream_id))))
            th.daemon = True
            th.start()
            threads.append(th)
    ask_addons(side_addons, imdb)
    main.join(PLAY_WAIT + 5)
    answer = box["answer"] or {}
    ask_addons(answer.get("addons"), answer.get("imdb") or imdb)
    for t in threads:
        t.join(35)
    versions = list(answer.get("versions") or [])
    for f in found:
        versions.extend(f)
    if box["error"] is not None and not versions:
        raise box["error"]
    return versions, answer.get("name") or ""


def resolve(handle, url, li=None):
    li = li or xbmcgui.ListItem(path=url)
    li.setPath(url)
    xbmcplugin.setResolvedUrl(handle, True, li)


def fail(handle, message):
    notify(message, 6000)
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def play(v):
    kind = "series" if v.params.get("type") == "series" else "movie"
    tmdb = v.params.get("tmdb", "")
    season = int(v.params["season"]) if v.params.get("season") else None
    episode = int(v.params["episode"]) if v.params.get("episode") else None
    choose = v.params.get("choose") == "1"
    progress = xbmcgui.DialogProgressBG()
    progress.create("mediaCENTER", "Finding the best version...")
    try:
        versions, name = gather(v.api, kind, tmdb, season, episode)
        info_answer = v.api.get("/api/roku/title", type=kind, tmdb=tmdb) or {}
    except SignedOut:
        progress.close()
        return fail(v.handle, "Sign in to mediaCENTER again.")
    except ServerError as e:
        progress.close()
        return fail(v.handle, "Couldn't reach mediaCENTER (%s)." % e.status)
    progress.close()
    ranked, hidden = L.rank_versions(versions, caps())
    log("play %s: %d versions, %d playable here, %d hidden" % (kind, len(versions), len(ranked), hidden))
    if not ranked:
        msg = "No version of this title plays on this device yet."
        if hidden:
            msg += " (%d need a stronger box.)" % hidden
        return fail(v.handle, msg)
    pick = ranked[0]
    if choose:
        labels = []
        for x in ranked:
            label = L.version_label(x)
            if x.get("level") == "maybe":
                label += "  [COLOR grey](may stutter)[/COLOR]"
            labels.append(xbmcgui.ListItem(label, L.PROVIDERS.get(x.get("provider"), "") + ("  " + x.get("name", "") if x.get("name") else "")))
        i = xbmcgui.Dialog().select("Choose a version" + (" (%d hidden)" % hidden if hidden else ""), labels, useDetails=True)
        if i < 0:
            return xbmcplugin.setResolvedUrl(v.handle, False, xbmcgui.ListItem())
        pick = ranked[i]
    url = v.api.kodi_url(pick["url"], cookie=bool(pick.get("cookie")))
    t = L.title_of(dict(info_answer.get("title") or {}, type=kind, tmdb=tmdb)) or {"tmdb": tmdb, "type": kind, "name": name or "", "poster": ""}
    if not t.get("name"):
        t["name"] = name or "mediaCENTER"
    episode_name = ""
    if kind == "series":
        try:
            eps = (v.api.get("/api/roku/episodes", tmdb=tmdb, season=season) or {}).get("episodes") or []
            episode_name = next((e.get("name", "") for e in eps if e.get("n") == episode), "")
        except (ServerError, SignedOut):
            pass
    entry = L.history_entry(t, season, episode, episode_name)
    resume = resume_point(v, entry["itemId"])
    li = xbmcgui.ListItem(path=url)
    li.setArt({"poster": t.get("poster"), "thumb": t.get("poster"), "fanart": t.get("backdrop")})
    info = {"title": episode_name or t["name"], "mediatype": "episode" if kind == "series" else "movie", "plot": t.get("overview", "")}
    if kind == "series":
        info.update(tvshowtitle=t["name"], season=season, episode=episode)
    set_info(li, info)
    if pick.get("container") == "m3u8" or ".m3u8" in url.split("|")[0]:
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
    WINDOW.setProperty(PLAYING_KEY, json.dumps({"entry": entry, "resume": resume}))
    resolve(v.handle, url, li)


def resume_point(v, item_id):
    """Where to start: ask "Resume from 12:34" when this title was left part-way (the same row every app uses)."""
    if v.params.get("fresh") == "1":
        return 0
    try:
        hist = (v.api.get("/api/history", limit=300) or {}).get("items") or []
    except (ServerError, SignedOut):
        return 0
    row = next((h for h in hist if h.get("itemId") == item_id), None)
    if not row or row.get("finished") or float(row.get("position") or 0) < 30:
        return 0
    pos = float(row["position"])
    i = xbmcgui.Dialog().contextmenu(["Resume from %s" % L.clock_text(pos), "Start from the beginning"])
    return pos if i == 0 else 0


def play_live(v):
    """A live channel through the relay. When the channel has backup feeds (alts=ID,ID from the game or the Guide) and
    the main one gives no playlist, the first one that does plays instead, as the web player switches on its own."""
    feeds = [v.params.get("id", "")] + [a for a in v.params.get("alts", "").split(",") if a.isdigit()][:5]
    try:
        chosen = feeds[0]
        if len(feeds) > 1:
            for k, sid in enumerate(feeds):
                ok = v.api.live_plays(sid)
                if ok is None and k == 0:
                    break  # no answer in time: let the player try the main feed itself
                if ok:
                    chosen = sid
                    if k:
                        notify("Trying a backup feed")
                    break
            else:
                return fail(v.handle, "This channel isn't playing right now.")
        url = v.api.live_url(chosen)
    except (ValueError, ServerError):
        return fail(v.handle, "This channel can't be played.")
    except SignedOut:
        return fail(v.handle, "Sign in to mediaCENTER again.")
    li = xbmcgui.ListItem(v.params.get("name", "Live TV"), path=url)
    li.setMimeType("application/vnd.apple.mpegurl")
    li.setContentLookup(False)
    set_info(li, {"title": v.params.get("name", "Live TV"), "mediatype": "video"})
    WINDOW.clearProperty(PLAYING_KEY)  # live TV has no progress to save
    resolve(v.handle, url, li)
