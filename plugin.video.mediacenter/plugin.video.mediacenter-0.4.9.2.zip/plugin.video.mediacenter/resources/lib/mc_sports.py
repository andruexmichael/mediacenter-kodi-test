# mediaCENTER for Kodi: the Sports data, the same as the website's Sports page (web-v27/js/views/sports.js), kept free
# of Kodi so it can be tested. Used by the Sports page (mc_sports_page), the Guide's Sports section (mc_app.GuidePage),
# the scores over the player (mc_scores) and game alerts (mc_alerts).
#
# Two server answers are joined, both read-only routes every app already uses:
#   - /api/sports/active: every league's games today with team logos, colours, records and the ball for football
#     (src/ba-sports.js; the website reads exactly this);
#   - /api/roku/sports: the channels in this account's lineup that carry each game, best first (src/ba-roku.js).
# My Teams are the account's own list (/api/prefs "myTeams", "League|ABBR"), shared with the website and the Apple apps.

import datetime
import re
import time

DOT = u" · "

# The website's league chips (views/sports.js FILTERS); a chip shows only when a game of that league is on today.
FILTERS = [("all", "All"), ("mine", "My Teams"), ("nfl", "NFL"), ("cfb", "College Football"), ("nba", "NBA"),
           ("nhl", "NHL"), ("mlb", "MLB"), ("soccer", "Soccer"), ("ufc", "UFC")]
# The leagues teams can be picked from (views/sports.js TEAM_LEAGUES, the apps' TeamStore.leagues).
TEAM_LEAGUES = ["NFL", "NBA", "MLB", "NHL", "College Football", "MLS", "Premier League"]
LABEL_TO_KEY = {"NFL": "nfl", "College Football": "cfb", "NBA": "nba", "NHL": "nhl", "MLB": "mlb",
                "Premier League": "soccer", "MLS": "mls", "Soccer": "soccer", "UFC": "ufc"}
# How long a game usually runs, for the Guide's timeline (hours).
LENGTH = {"nfl": 3.5, "cfb": 3.5, "nba": 2.5, "nhl": 2.5, "mlb": 3.0, "soccer": 2.0, "mls": 2.0, "ufc": 4.0}
# design/experience.json sports.scores.close (kept here too in case the shared file is older than the app).
CLOSE_MARGIN = {"nfl": 8, "cfb": 8, "nba": 6, "nhl": 1, "mlb": 2, "soccer": 1, "mls": 1}
CLOSE_LATE = {"nfl": r"4th|OT", "cfb": r"4th|OT", "nba": r"4th|OT", "nhl": r"3rd|OT|SO",
              "mlb": r"(7th|8th|9th|1\dth)", "soccer": r"\b(8\d|9\d)'", "mls": r"\b(8\d|9\d)'"}


# ---- pictures and colours ---------------------------------------------------------------------------------------------

def small_logo(url, px=96):
    """An ESPN logo at a size the Pi 3 can afford: ESPN's own resizer (the website's "combiner") instead of the 500 px
    original, so a page of cards stays a few hundred KB of textures. Other https addresses unchanged; "" otherwise."""
    u = str(url or "")
    if not u.startswith("https://"):
        return ""
    m = re.match(r"^https://a\.espncdn\.com(/i/[A-Za-z0-9_/.\-]+\.(?:png|jpg))$", u)
    if m:
        return "https://a.espncdn.com/combiner/i?img=%s&w=%d&h=%d" % (m.group(1), px, px)
    return u


def _hex(c):
    c = str(c or "").lstrip("#")
    return c.upper() if re.match(r"^[0-9a-fA-F]{6}$", c) else None


def _lum(h):
    def ch(v):
        v /= 255.0
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    n = int(h, 16)
    r, g, b = (n >> 16) & 255, (n >> 8) & 255, n & 255
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)


def _dim(h, k):
    n = int(h, 16)
    return "".join("%02X" % int(round(((n >> s) & 255) * k)) for s in (16, 8, 0))


def zone_color(team):
    """A team's half of a score card, as Kodi's AARRGGBB (views/field3d.js zoneColor): its colour darkened, or its
    alternate when the main one is nearly black; a grey when ESPN gives neither."""
    c = _hex((team or {}).get("color"))
    if not c or _lum(c) < 0.02:
        c = _hex((team or {}).get("altColor"))
    if not c or _lum(c) < 0.02:
        c = "3A3A44"
    return "FF" + _dim(c, 0.5 if _lum(c) > 0.35 else 0.78)


def ring_color(team):
    """The ball's ring on the field: the team's own colour, never too dark to see (views/field3d.js streakColor)."""
    c = _hex((team or {}).get("color"))
    if not c or _lum(c) < 0.08:
        c = _hex((team or {}).get("altColor"))
    if not c or _lum(c) < 0.08:
        c = "FFFFFF"
    return "FF" + c


# ---- the games --------------------------------------------------------------------------------------------------------

def sides(game):
    """(away, home); (None, None) for a game without two teams (a UFC card)."""
    teams = [t for t in (game.get("teams") or []) if isinstance(t, dict)]
    if len(teams) < 2:
        return None, None
    away = next((t for t in teams if not t.get("home")), teams[0])
    home = next((t for t in teams if t.get("home") and t is not away), teams[1] if teams[1] is not away else teams[0])
    return away, home


def team_key(game, team):
    return "%s|%s" % (game.get("leagueLabel") or "", team.get("abbr") or "")


def involves(game, mine):
    mine = set(mine or [])
    return any(team_key(game, t) in mine for t in game.get("teams") or [])


def title(game):
    away, home = sides(game)
    if away is None:
        return str(game.get("title") or "")
    if game.get("league") in ("soccer", "mls"):
        return u"%s vs. %s" % (home.get("name", ""), away.get("name", ""))
    return u"%s at %s" % (away.get("name", ""), home.get("name", ""))


def _int(v):
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return None


def close_game(game):
    """A live game within a few points late on (sports.js closeGame, design/close-game-cases.json)."""
    if game.get("state") != "in":
        return False
    scores = [_int(t.get("score")) for t in game.get("teams") or []]
    if len(scores) < 2 or None in scores[:2]:
        return False
    margin = CLOSE_MARGIN.get(game.get("league"))
    late = CLOSE_LATE.get(game.get("league"))
    return margin is not None and abs(scores[0] - scores[1]) <= margin and bool(late and re.search(late, game.get("detail") or "", re.I))


def clock(ms):
    if not ms:
        return ""
    t = time.localtime(float(ms) / 1000.0)
    return "%d:%02d %s" % (t.tm_hour % 12 or 12, t.tm_min, "PM" if t.tm_hour >= 12 else "AM")


def day_title(ms, now=None):
    d = datetime.datetime.fromtimestamp(float(ms) / 1000.0).date()
    today = datetime.datetime.fromtimestamp(now or time.time()).date()
    days = (d - today).days
    if days == 0:
        return "Today"
    if days == 1:
        return "Tomorrow"
    return datetime.datetime.fromtimestamp(float(ms) / 1000.0).strftime("%A, %b ") + str(d.day)


def when_short(ms, now=None):
    """ "7:00 PM", "Tmrw 7:00 PM", "Sun 4:25 PM" (views/sports.js whenShort)."""
    d = datetime.datetime.fromtimestamp(float(ms) / 1000.0)
    today = datetime.datetime.fromtimestamp(now or time.time()).date()
    days = (d.date() - today).days
    c = clock(ms)
    if days == 0:
        return c
    if days == 1:
        return "Tmrw " + c
    return d.strftime("%a") + " " + c


def status(game, now=None):
    """What a card says under the score: "3:35 – 4th · 1st & 10", "Final", "7:00 PM"."""
    if game.get("state") == "in":
        sit = game.get("situation") or {}
        return DOT.join(p for p in [game.get("detail") or "LIVE", sit.get("downText") or ""] if p)
    if game.get("state") == "post":
        return "Final"
    return when_short(game.get("start") or 0, now)


def tag(game, now=None):
    """The card's corner tag: CLOSE GAME, LIVE, FINAL or the start time."""
    if close_game(game):
        return "CLOSE GAME"
    if game.get("state") == "in":
        return "LIVE"
    if game.get("state") == "post":
        return "FINAL"
    return when_short(game.get("start") or 0, now)


def channel_name(name):
    return re.sub(r"^(US|TV)\| ", "", str(name or "")).strip()


def where(game):
    """What a card says it's on: "503 · NFL 01", else the networks ESPN lists (sports.js gameWhere)."""
    chans = game.get("channels") or []
    if chans:
        ch = chans[0]
        return DOT.join(p for p in [str(ch.get("num") or ""), channel_name(ch.get("name"))] if p)
    return ", ".join(game.get("networks") or []) or "Not in the lineup"


def no_channel_message(game, wording=None):
    w = wording or {}
    nets = ", ".join(game.get("networks") or [])
    text = (w.get("noChannelOn") if nets else w.get("noChannel")) or ("Couldn't find a channel showing {game}. Open the Guide and pick one.")
    return text.replace("{game}", title(game)).replace("{networks}", nets)


def _from_roku(g):
    """A /api/roku/sports game in /api/sports/active's shape (used when only the Roku answer came back)."""
    label = g.get("league") or ""
    return {"id": str(g.get("id")), "league": LABEL_TO_KEY.get(label, label.lower()), "leagueLabel": label,
            "state": g.get("state"), "detail": g.get("detail") or "", "start": g.get("start") or 0,
            "teams": [dict(t) for t in g.get("teams") or []], "networks": g.get("networks") or [], "situation": None}


def join(active, roku, mine=None):
    """The games the Sports page shows: /api/sports/active's games (logos, colours, ball) with each game's channels and
    "one of mine" from /api/roku/sports. Either answer may be missing; nothing raises."""
    roku_games = dict((str(g.get("id")), g) for g in ((roku or {}).get("games") or []) if isinstance(g, dict))
    mine = list(mine if mine is not None else (roku or {}).get("myTeams") or [])
    base = [g for g in ((active or {}).get("all") or []) if isinstance(g, dict)]
    if not base:
        base = [_from_roku(g) for g in roku_games.values()]
    out, seen = [], set()
    for g in base:
        gid = str(g.get("id"))
        if gid in seen:
            continue
        seen.add(gid)
        game = dict(g, id=gid)
        if not game.get("leagueLabel"):
            game["leagueLabel"] = game.get("league", "").upper()
        r = roku_games.get(gid) or {}
        game["channels"] = [c for c in r.get("channels") or [] if isinstance(c, dict) and c.get("id")]
        game["mine"] = involves(game, mine) or bool(r.get("mine"))
        game["title"] = title(game)
        out.append(game)
    return out


def matches(game, f, mine=()):
    if f == "all":
        return True
    if f == "mine":
        return game.get("mine") or involves(game, mine)
    if f == "soccer":
        return game.get("league") in ("soccer", "mls")
    return game.get("league") == f


def chips(games):
    """The league chips that have a game today (All and My Teams always)."""
    has = set("soccer" if g.get("league") == "mls" else g.get("league") for g in games)
    return [(k, n) for k, n in FILTERS if k in ("all", "mine") or k in has]


SECTION = {"live": "LIVE NOW", "later": "STARTING SOON", "final": "FINAL"}


def sections(games, f="all", mine=(), finals=12, now=None):
    """The page's games in the website's order: live (close games first), then later by start time (grouped by day),
    then the last finals. Returns [(section_title, count, [game])]."""
    shown = [g for g in games if matches(g, f, mine)]
    live = sorted([g for g in shown if g.get("state") == "in"], key=lambda g: (0 if close_game(g) else 1, 0 if g.get("mine") else 1))
    later = sorted([g for g in shown if g.get("state") == "pre"], key=lambda g: (g.get("start") or 0))
    final = [g for g in shown if g.get("state") == "post"][:finals]
    out = []
    if live:
        out.append((SECTION["live"], len(live), live))
    days = []
    for g in later:
        t = day_title(g.get("start") or 0, now)
        if days and days[-1][0] == t:
            days[-1][1].append(g)
        else:
            days.append((t, [g]))
    for i, (t, items) in enumerate(days):
        out.append((SECTION["later"] if t == "Today" else t.upper(), len(items), items))
    if final:
        out.append((SECTION["final"], len(final), final))
    return out


def counts(games):
    """ "6 live now · 86 later today" (the page's line under Sports)."""
    live = sum(1 for g in games if g.get("state") == "in")
    later = sum(1 for g in games if g.get("state") == "pre")
    return "%d live now%s%d later today" % (live, DOT, later)


def ball(game):
    """Where the ball is for a live football game, 0..20 in steps of 5 yards (the card's field strip), or ""."""
    sit = game.get("situation") or {}
    try:
        x = float(sit.get("ballX"))
    except (TypeError, ValueError):
        return ""
    if game.get("state") != "in":
        return ""
    return str(int(round(max(0.0, min(100.0, x)) / 5.0)))


def next_game(games, key):
    """A pinned team's next or current game, for its My Teams chip."""
    found = [g for g in games if g.get("state") != "post" and any(team_key(g, t) == key for t in g.get("teams") or [])]
    found.sort(key=lambda g: (0 if g.get("state") == "in" else 1, g.get("start") or 0))
    return found[0] if found else None


def team_of(games, key):
    """What the games know about a pinned team (name, logo), for its chip before its team list has loaded."""
    for g in games:
        for t in g.get("teams") or []:
            if team_key(g, t) == key:
                return {"key": key, "name": t.get("name") or key.split("|")[-1], "logo": t.get("logo") or ""}
    return {"key": key, "name": key.split("|")[-1], "logo": ""}


def chip_text(game, now=None):
    if game is None:
        return "No game"
    return "LIVE" if game.get("state") == "in" else when_short(game.get("start") or 0, now)


def toggle(mine, key):
    mine = [str(k) for k in mine or []]
    return sorted([k for k in mine if k != key] if key in mine else mine + [key])


# ---- the Guide's Sports section ---------------------------------------------------------------------------------------

def guide_rows(games, now=None):
    """Every game from the Sports tab as Guide rows: a channel-like row per game (its best channel to play), with the
    game as the one programme on the timeline. Live first, then by start time, finals last."""
    now = now or time.time()
    order = {"in": 0, "pre": 1, "post": 2}
    rows = []
    for g in sorted(games, key=lambda g: (order.get(g.get("state"), 3), g.get("start") or 0)):
        chans = g.get("channels") or []
        ch = chans[0] if chans else {}
        away, home = sides(g)
        start = int((g.get("start") or 0) // 1000)
        stop = start + int(LENGTH.get(g.get("league"), 3.0) * 3600)
        if g.get("state") == "in":
            stop = max(stop, int(now) + 1800)  # still on: keep it under the now line
        elif g.get("state") == "post":
            stop = min(stop, int(now) - 60)
        score = ""
        if away is not None and g.get("state") != "pre":
            score = u"%s %s – %s %s" % (away.get("abbr", ""), away.get("score", ""), home.get("score", ""), home.get("abbr", ""))
        rows.append({
            "id": str(ch.get("id") or ""), "name": g.get("title") or title(g), "num": g.get("leagueLabel") or "",
            "logo": small_logo((home or {}).get("logo") or (away or {}).get("logo"), 96), "alts": ch.get("alts") or [],
            "channel": channel_name(ch.get("name")) if ch else "", "game": g,
            "programmes": [{"start": start, "stop": stop, "title": score or g.get("title") or title(g),
                            "sub": status(g, now), "desc": game_desc(g)}],
        })
    return rows


def game_desc(game):
    lines = [game.get("leagueLabel") or "", status(game)]
    chans = game.get("channels") or []
    lines.append(("On " + DOT.join(p for p in [str(chans[0].get("num") or ""), channel_name(chans[0].get("name"))] if p)) if chans
                 else ", ".join(game.get("networks") or []) or "No channel in your lineup shows this game yet.")
    return DOT.join(p for p in lines if p)


def pin_favorites(channels, favorites):
    """Favourite channels first (in channel order), then the rest: the Guide pins them to the top of every group."""
    favs = set(str(f) for f in favorites or [])
    return [c for c in channels if str(c.get("id")) in favs] + [c for c in channels if str(c.get("id")) not in favs]


def last_channel(recent, tuned=None):
    """The channel watched before the one on now (recentChannels is newest first); None when there's none."""
    recent = [str(r) for r in recent or []]
    tuned = str(tuned) if tuned else (recent[0] if recent else None)
    for r in recent:
        if r != tuned:
            return r
    return None


# ---- game alerts ------------------------------------------------------------------------------------------------------

SOON = 15 * 60  # seconds before the start a "starting soon" alert goes


def alerts(games, mine, seen, now=None):
    """What to tell the viewer about their teams' games since the last look. seen: {game id: what was said} (updated
    in place). Returns [(game, text)]: starting soon, started, final. Nothing is said twice."""
    now = now or time.time()
    out = []
    for g in games:
        if not (involves(g, mine) or g.get("mine")):
            continue
        gid, state = str(g.get("id")), g.get("state")
        said = seen.get(gid, "")
        away, home = sides(g)
        start = (g.get("start") or 0) / 1000.0
        if state == "pre" and 0 < start - now <= SOON and said == "":
            seen[gid] = "soon"
            out.append((g, "%s starts at %s%s" % (g.get("title") or title(g), clock(g.get("start")), _on(g))))
        elif state == "in" and said in ("", "soon"):
            seen[gid] = "in"
            out.append((g, "%s has started%s" % (g.get("title") or title(g), _on(g))))
        elif state == "post" and said in ("soon", "in"):
            seen[gid] = "post"
            if away is not None:
                out.append((g, u"Final: %s %s, %s %s" % (away.get("name", ""), away.get("score", ""), home.get("name", ""), home.get("score", ""))))
            else:
                out.append((g, "Final: %s" % (g.get("title") or "")))
        elif state == "post" and said == "":
            seen[gid] = "post"  # finished before we looked: nothing to say
    return out


def _on(game):
    chans = game.get("channels") or []
    return (" on " + channel_name(chans[0].get("name"))) if chans else ""


# ---- the game page (/api/sports/game) --------------------------------------------------------------------------------

def game_rows(detail, tab):
    """One tab of the game page as rows (label, away, home, kind). kind: "head" for a heading, "row" for a stat line,
    "text" for a sentence (a play), "team" for a team's line in the standings. Kept short for the Pi 3."""
    d = detail or {}
    teams = d.get("teams") or []
    away = teams[0] if teams else {}
    home = teams[1] if len(teams) > 1 else {}
    rows = []
    if tab == "overview":
        for side in d.get("leaders") or []:
            rows.append(("%s leaders" % side.get("team", ""), "", "", "head"))
            for item in (side.get("items") or [])[:4]:
                rows.append((item.get("label", ""), item.get("athlete", ""), item.get("value", ""), "row"))
        scoring = d.get("scoring") or []
        if scoring:
            rows.append(("Scoring", away.get("abbr", ""), home.get("abbr", ""), "head"))
            for p in scoring[-10:]:
                rows.append((DOT.join(x for x in [p.get("period", ""), p.get("clock", ""), p.get("text", "")] if x),
                             _s(p.get("away")), _s(p.get("home")), "text"))
        if d.get("venue"):
            rows.append(("Where", DOT.join(x for x in [d.get("venue"), d.get("city")] if x), "", "text"))
    elif tab == "plays":
        if (d.get("drive") or {}).get("description"):
            rows.append(("Drive: %s %s" % (d["drive"].get("team", ""), d["drive"]["description"]), "", "", "head"))
        for p in (d.get("plays") or [])[:25]:
            rows.append((DOT.join(x for x in [p.get("period", ""), p.get("clock", ""), p.get("text", "")] if x),
                         _s(p.get("away")), _s(p.get("home")), "text"))
    elif tab == "stats":
        if d.get("teamStats"):
            rows.append(("Team stats", away.get("abbr", ""), home.get("abbr", ""), "head"))
            for s in d["teamStats"][:20]:
                rows.append((s.get("label", ""), s.get("away", ""), s.get("home", ""), "row"))
        for p in d.get("players") or []:
            for grp in (p.get("groups") or [])[:3]:
                labels = grp.get("labels") or []
                rows.append(("%s %s" % (p.get("team", ""), grp.get("name", "")), "  ".join(labels[:4]), "", "head"))
                for a in (grp.get("rows") or [])[:5]:
                    rows.append((a.get("name", ""), "  ".join((a.get("stats") or [])[:4]), "", "row"))
    elif tab == "standings":
        for grp in d.get("standings") or []:
            rows.append((grp.get("name", ""), "", "", "head"))
            for r in grp.get("rows") or []:
                rows.append((("> " if r.get("mine") else "") + r.get("team", ""), r.get("record", ""), "", "team"))
    return rows


def _s(v):
    return "" if v is None else str(v)


GAME_TABS = [("overview", "Overview"), ("plays", "Plays"), ("stats", "Box score"), ("standings", "Standings")]


def field_marks(detail):
    """The flat field on the game page: ball and first-down line as percentages of the field's width (0..100 between
    the goal lines), who has it and the down; None when the game isn't football or ESPN gives no position."""
    f = (detail or {}).get("field")
    if not isinstance(f, dict):
        return None
    try:
        bx = max(0.0, min(100.0, float(f.get("ballX"))))
        fx = max(0.0, min(100.0, float(f.get("firstDownX", bx))))
    except (TypeError, ValueError):
        return None
    last = f.get("lastPlay") or {}
    return {"ball": bx, "first": fx, "possession": f.get("possession") or "", "down": f.get("downText") or "",
            "idle": bool(f.get("idle")), "last": last.get("label") or last.get("text") or "", "direction": f.get("direction") or ""}
