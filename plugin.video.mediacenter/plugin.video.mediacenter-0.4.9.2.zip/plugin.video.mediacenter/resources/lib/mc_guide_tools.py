# mediaCENTER for Kodi: the Guide's extras in 0.4.9, kept free of Kodi so they can be tested. The website's Guide
# (web-v27/js/views/guide.js, guide-layout.js) has them all: a Sports group after Favorites, favourite channels pinned
# to the top of every other group, the last channel (key 0), Jump to times, and Live TV categories hidden in Settings
# (the account's "hiddenCategories", shared with the website and the iPhone).

import time

HALF_HOUR = 1800
SPORTS = {"id": "sports", "name": "Sports"}
NO_PIN = ("fav", "recent", "sports")  # groups whose own order is the point


def with_sports(pills):
    """The Guide's pills with Sports right after Favorites (at the end when there is no Favorites)."""
    out = [p for p in pills if p.get("id") != SPORTS["id"]]
    at = next((i + 1 for i, p in enumerate(out) if p.get("id") == "fav"), len(out))
    return out[:at] + [dict(SPORTS)] + out[at:]


def pinned(channels, pill, favorites):
    """A group's channels with the favourites first (mc_sports.pin_favorites), except Favorites, Recent and Sports."""
    if pill in NO_PIN or not favorites:
        return list(channels)
    favs = set(str(f) for f in favorites)
    return [c for c in channels if str(c.get("id")) in favs] + [c for c in channels if str(c.get("id")) not in favs]


def _clock(seconds):
    t = time.localtime(seconds)
    return "%d:%02d %s" % (t.tm_hour % 12 or 12, t.tm_min, "PM" if t.tm_hour >= 12 else "AM")


def jump_times(now, start=None, clock=_clock):
    """The Guide's "Jump to" list (guide-layout.js jumpTimes): Now, the next six hours on the hour after this half
    hour, then "Tonight at 8:00 PM" while it is still to come. [(label, seconds)]."""
    half = int(now // HALF_HOUR) * HALF_HOUR
    out = [("Now", half)]
    for h in range(1, 7):
        at = half + h * 3600
        out.append((clock(at), at))
    lt = time.localtime(now)
    tonight = time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 20, 0, 0, 0, 0, -1))
    if tonight > now:
        out.append(("Tonight at " + clock(tonight), int(tonight)))
    return out


def hidden_after(categories, shown_positions):
    """What the account hides once the viewer has ticked the categories to show: every other category's id, sorted
    (the website keeps them sorted, prefs-sync.js). categories: [{"id", "name"}] in the provider's order."""
    keep = set(int(i) for i in shown_positions or [])
    return sorted(str(c["id"]) for i, c in enumerate(categories) if i not in keep)


def shown_positions(categories, hidden):
    """The ticks to start the category list with: every category that is not hidden."""
    gone = set(str(h) for h in hidden or [])
    return [i for i, c in enumerate(categories) if str(c["id"]) not in gone]


def shown_count(categories, hidden):
    gone = set(str(h) for h in hidden or [])
    n = sum(1 for c in categories if str(c["id"]) not in gone)
    return "%d of %d shown" % (n, len(categories))
