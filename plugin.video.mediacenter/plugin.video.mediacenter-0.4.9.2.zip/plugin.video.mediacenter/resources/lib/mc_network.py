"""LibreELEC connectivity without exposing its settings app. Arguments never use a shell."""
import os
import re
import select
import shutil
import subprocess
import time


def command(args, timeout=15):
    if not shutil.which(args[0]):
        raise RuntimeError('This device does not support this connection setting.')
    result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, text=True)
    if result.returncode:
        raise RuntimeError('The connection request failed. Try again.')
    return result.stdout


def wifi_scan():
    command(['connmanctl', 'enable', 'wifi'])
    command(['connmanctl', 'scan', 'wifi'], 30)
    return parse_wifi(command(['connmanctl', 'services']))


def parse_wifi(text):
    networks = []
    for line in text.splitlines():
        match = re.search(r'\b(wifi_[A-Za-z0-9_]+)\s*$', line)
        if not match:
            continue
        name = re.sub(r'^\*[A-Z]{1,2}\s+', '', line[:match.start()].strip()).strip()
        networks.append({'id':match.group(1), 'name':name or 'Hidden network',
                         'secure':not match.group(1).endswith('_none')})
    return networks


def wifi_connect(network, password='', timeout=60):
    """ConnMan's interactive agent reads the password from a private PTY, never argv or a config/log file."""
    import termios
    if not re.fullmatch(r'wifi_[A-Za-z0-9_]+', network):
        raise ValueError('Invalid network')
    if any(c in password for c in '\r\n\x00'):
        raise ValueError('Unsupported password')
    if not shutil.which('connmanctl'):
        raise RuntimeError('Wi-Fi settings are unavailable on this device.')
    master, slave = os.openpty()
    attrs = termios.tcgetattr(slave)
    attrs[3] &= ~(termios.ECHO | termios.ECHONL)
    termios.tcsetattr(slave, termios.TCSANOW, attrs)
    proc = subprocess.Popen(['connmanctl'], stdin=slave, stdout=slave, stderr=slave, close_fds=True)
    os.close(slave)
    buffer = ''
    phase = 0
    deadline = time.monotonic() + timeout
    try:
        while time.monotonic() < deadline:
            if not select.select([master], [], [], .25)[0]:
                if proc.poll() is not None:
                    break
                continue
            try:
                buffer += os.read(master, 4096).decode('utf-8', 'replace')
            except OSError:
                break
            buffer = buffer[-8192:]
            if phase == 0 and 'connmanctl>' in buffer:
                os.write(master, b'agent on\n'); buffer = ''; phase = 1
            elif phase == 1 and 'connmanctl>' in buffer:
                os.write(master, ('connect ' + network + '\n').encode()); buffer = ''; phase = 2
            elif phase == 2 and re.search(r'(?:Passphrase|Password)\?\s*$', buffer, re.I):
                os.write(master, (password + '\n').encode()); buffer = ''; phase = 3
            if phase >= 2 and ('Connected ' in buffer or 'Already connected' in buffer):
                return
            if phase >= 2 and re.search(r'Error |connect-failed|invalid-key|not supported', buffer, re.I):
                raise RuntimeError('Could not join this network. Check the password and try again.')
        raise RuntimeError('Connection timed out. Check the network and try again.')
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait()
        os.close(master)


def bluetooth_scan():
    command(['bluetoothctl', 'power', 'on'])
    command(['bluetoothctl', '--timeout', '8', 'scan', 'on'], 15)
    text = command(['bluetoothctl', 'devices'])
    return [{'id':m.group(1), 'name':m.group(2)} for line in text.splitlines()
            if (m := re.match(r'Device ([0-9A-Fa-f:]{17}) (.+)$', line))]


def bluetooth_connect(address):
    if not re.fullmatch(r'(?:[0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}', address):
        raise ValueError('Invalid Bluetooth address')
    # Controllers using Just Works pairing (including supported Xbox controllers). PIN entry is not guessed.
    text = command(['bluetoothctl', '--agent', 'NoInputNoOutput', '--timeout', '30', 'pair', address], 35)
    if 'Pairing successful' not in text and 'AlreadyExists' not in text:
        raise RuntimeError('Could not pair. Put the controller in pairing mode and try again.')
    command(['bluetoothctl', 'trust', address])
    text = command(['bluetoothctl', '--timeout', '15', 'connect', address], 20)
    if 'Connection successful' not in text and 'AlreadyConnected' not in text:
        raise RuntimeError('Paired, but not connected. Wake the controller and try again.')
