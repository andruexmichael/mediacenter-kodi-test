# mediaCENTER for Kodi: sample-data mode, for screenshots on a test box without anyone's account.
#
# On only when the folder resources/data/sample exists inside the installed add-on. Nothing ships with it:
# scripts/build-kodi-repo.mjs leaves that folder out of every zip, and only kodi/tools/rig.py copies it in (from
# kodi/tools/sample). The answers have the same shapes as the live routes; nothing is sent anywhere.

import json
import os

from mc_api import Api
from mc_logic import SAMPLE_ART


def folder(addon_path):
    """The sample folder of an installed add-on, or None when sample-data mode is off (every release)."""
    path = os.path.join(addon_path, "resources", "data", "sample")
    return path if os.path.isdir(path) else None


HISTORY = {"items": [
    {"itemId": "tmdb-11-s1-e2", "kind": "episode", "title": "Deadline", "seriesId": "tmdb-11", "seriesName": "City Desk",
     "season": 1, "episode": 2, "image": "", "position": 600, "duration": 2700, "finished": False},
    {"itemId": "tmdb-1-movie", "kind": "movie", "title": "The Long Night", "image": "", "position": 3000, "duration": 6720, "finished": False},
]}
# Channels and a schedule for the Guide (each programme is made up, set around the time the box asks).
GUIDE_CHANNELS = [
    (201, 4, "NBC 6 Miami", "8", "wtvj.us", ["Today Tonight", "Local News at 11", "The Late Show Tonight", "Late Night Talk", "Overnight News"]),
    (202, 10, "CBS 10 Tampa", "8", "wtsp.us", ["10 News Tonight", "Late Night Comedy", "Second Look", "Up All Night", "CBS Overnight"]),
    (203, 28, "ABC Action News", "8", "wfts.us", ["Prime Time Mystery", "Action News at 11", "Night Line", "Movie of the Week"]),
    (204, 13, "FOX 13 Tampa", "8", "wtvt.us", ["Animated Sunday", "FOX 13 News", "Comedy Hour", "Paid Programming"]),
    (205, 3, "PBS WEDU", "8", "wedu.us", ["Nature Hour", "Great Performances", "World News", "Antiques Roadshow"]),
    (101, 30, "ESPN", "7", "espn.us", ["SportsCenter", "NBA Tonight", "College Hoops", "SportsCenter Overnight"]),
    (102, 31, "ESPN2", "7", "espn2.us", ["Around the Horn", "Pardon the Interruption", "NFL Live", "Poker Classics"]),
    (103, 32, "FS1", "7", "fs1.us", ["Speak", "The Herd", "College Football Classics", "Pro Wrestling"]),
    (104, 40, "NBA TV", "7", "nbatv.us", ["NBA Gametime", "Heat at Celtics", "Hardwood Classics"]),
    (301, 50, "CNN", "9", "cnn.us", ["Newsroom", "Evening Report", "World Today", "Special Report"]),
    (302, 51, "MSNBC", "9", "msnbc.us", ["The Evening Hour", "Primetime", "Late Edition", "Morning Rundown"]),
    (401, 60, "TNT", "10", "tnt.us", ["Movie: The Long Night", "Inside the Game", "Drama Marathon"]),
    (402, 61, "AMC", "10", "amc.us", ["Movie: Harbor Lights", "Movie: North Shore", "Classic Westerns"]),
    (403, 62, "HGTV", "10", "hgtv.us", ["Home Again", "Fixer Hour", "House Hunters", "Dream Builds"]),
]
GUIDE_CATEGORIES = [{"category_id": "8", "category_name": "US Locals"}, {"category_id": "7", "category_name": "US Sports"},
                    {"category_id": "9", "category_name": "US News"}, {"category_id": "10", "category_name": "US Entertainment"}]


def sample_guide(now):
    """/api/roku/guide's answer, made up around now: half-hour and hour-long shows from an hour ago on."""
    start = int(now // 1800) * 1800 - 1800
    out = {}
    for sid, num, name, cat, epg, titles in GUIDE_CHANNELS:
        t, k, progs = start - (sid % 2) * 900, 0, []
        while t < now + 6 * 3600:
            length = 3600 if (k + sid) % 3 == 0 else 1800
            progs.append({"start": t, "stop": t + length, "title": titles[k % len(titles)]})
            t, k = t + length, k + 1
        out[epg] = progs
    return {"guide": out}


class SampleApi(Api):
    """An Api that is always signed in as "Sample" and answers from the sample folder instead of the server."""

    def __init__(self, sample_folder):
        Api.__init__(self)
        self.sample = sample_folder
        self.cookie = "sample"
        self.username = "Sample"
        self.prefs = {"myList": {"value": [], "updatedAt": 1}}

    def demo(self, name):
        with open(os.path.join(self.sample, "demo-%s.json" % name), encoding="utf-8") as f:
            return self.pictures(json.load(f))

    def pictures(self, answer):
        """Fill empty posters and wide pictures from the sample art (kodi/tools/make_sample_art.py), when the test box
        has it, so cards show a picture."""
        art = os.path.join(self.sample, "art")
        if not os.path.isdir(art):
            return answer

        def slug(name):
            return "".join(ch if ch.isalnum() else "-" for ch in str(name).lower()).strip("-")

        def walk(o):
            if isinstance(o, dict):
                name = o.get("name") or o.get("seriesName") or o.get("title")
                for key in ("poster", "backdrop", "image"):
                    if key in o and not o[key] and name:
                        kind = "backdrop" if key == "backdrop" else "poster"
                        name_ = "%s-%s.jpg" % (kind, slug(name))
                        if os.path.isfile(os.path.join(art, name_)):
                            o[key] = SAMPLE_ART + name_
                for v in o.values():
                    walk(v)
            elif isinstance(o, list):
                for v in o:
                    walk(v)
            return o
        return walk(answer)

    def raw(self, method, path, query=None, body=None, timeout=None):
        if path == "/access/device/poll":
            return 202, b'{"status":"pending"}', None  # the phone sign-in waits for ever, for its screenshot
        raise OSError("sample-data mode sends nothing")

    def call(self, method, path, query=None, body=None, timeout=None):
        q = query or {}
        if path == "/api/roku/play" and self.clip():
            answer = self.demo("play")
            answer["versions"][-1]["url"] = self.clip()  # the last version is the test clip; the others are made up
            return answer
        for route in ("home", "sports", "live", "search", "episodes", "play"):
            if path == "/api/roku/" + route:
                return self.demo(route)
        if path == "/api/sports/active":
            return self.demo("sports-active")
        if path == "/api/sports/teams":
            return dict(self.demo("sports-teams"), league=q.get("league"))
        if path == "/api/sports/game":
            return self.demo("sports-game")
        if path == "/api/browse":
            if q.get("genre"):
                return dict(self.demo("browse-genre"), kind=q.get("kind"), genre=q.get("genre"))
            return self.demo("browse-series" if q.get("kind") == "series" else "browse-movie")
        if path == "/api/roku/title":
            t = dict(self.demo("title")["title"])
            if q.get("type") == "series":
                t.update(type="series", name="City Desk", seasonList=[1, 2])
            return {"title": t}
        if path == "/meta/title":
            return {"certification": "PG-13", "imdbRating": "7.4", "ids": {}}
        if path in ("/meta/row", "/meta/similar"):
            return {"items": [{"type": "movie", "title": "Harbor Lights", "year": 2026, "ids": {"tmdb": 2}, "poster": ""}]}
        if path == "/api/history":
            return self.pictures(json.loads(json.dumps(HISTORY))) if method == "GET" else {"ok": True}
        if path == "/api/prefs":
            if method != "GET" and isinstance(body, dict):
                self.prefs.update(body.get("prefs") or {})
            return {"prefs": self.prefs}
        if path == "/player_api.php":
            if q.get("action") == "get_live_categories":
                return GUIDE_CATEGORIES
            art = os.path.join(self.sample, "art")
            return [{"stream_id": sid, "num": num, "name": "US| " + name, "category_id": cat, "epg_channel_id": epg,
                     "stream_icon": SAMPLE_ART + "logo-%s.png" % epg if os.path.isfile(os.path.join(art, "logo-%s.png" % epg)) else ""}
                    for sid, num, name, cat, epg, _ in GUIDE_CHANNELS]
        if path == "/api/roku/guide":
            import time
            return sample_guide(time.time())
        if path == "/access/session":
            return {"username": "sample", "displayName": "Sample"}
        if path == "/access/device/start":
            return {"deviceCode": "S" * 43, "userCode": "K7QM-4TXP", "verificationUri": self.base + "/access/device",
                    "expiresIn": 600, "interval": 5}
        if path in ("/access/logout", "/api/share"):
            return {"ok": True}
        return {}

    def clip(self):
        """A test box can play a local test clip: its address in the sample folder's clip.txt (nothing ships with it)."""
        try:
            with open(os.path.join(self.sample, "clip.txt"), encoding="utf-8") as f:
                url = f.read().strip()
        except OSError:
            return ""
        return url if url.startswith("http://127.0.0.1:") else ""

    def live_plays(self, stream_id):
        return True

    def live_url(self, stream_id):
        return self.clip() or Api.live_url(self, stream_id)

    def link_works(self, link, timeout=8):
        if link.startswith("http://127.0.0.1:"):
            return True, ""
        return False, "not found"  # the sample's made-up addresses: the player moves on to the clip

    def addon_streams(self, base, kind, stream_id, timeout=30):
        return []

    def forget(self):
        pass


class SampleNetwork(object):
    """Made-up Wi-Fi networks and controllers for the Network and Remotes screens; nothing is joined or paired."""

    @staticmethod
    def wifi_scan():
        return [{"id": "wifi_sample_home_managed_psk", "name": "Home Wi-Fi", "secure": True},
                {"id": "wifi_sample_guest_managed_psk", "name": "Guest", "secure": True},
                {"id": "wifi_sample_cafe_managed_none", "name": "Corner Cafe", "secure": False}]

    @staticmethod
    def wifi_connect(network, password="", timeout=60):
        return None

    @staticmethod
    def bluetooth_scan():
        return [{"id": "AA:BB:CC:00:11:22", "name": "Xbox Wireless Controller"},
                {"id": "AA:BB:CC:00:11:33", "name": "Living Room Remote"}]

    @staticmethod
    def bluetooth_connect(address):
        return None


class SampleUpdates(object):
    """A made-up newer version for the Software update screen; nothing is downloaded or installed."""

    @staticmethod
    def check(channel, have, fetch=None):
        return {"channel": channel, "version": "9.9.9", "available": True, "packages": [],
                "notes": "Sign in with your phone. New Settings, Wi-Fi and controller setup."}
