# mediaCENTER for Kodi: small pure helpers (no Kodi, no network), so they can be tested off the box (kodi/tests).
# Wording follows the web app and the Roku app (roku/app/source/logic.brs) where the same thing is said.

import re
import time
import datetime

DOT = u" · "

# ---- Pictures and titles ----------------------------------------------------------------------------------------------

def picture(url, size):
    """A TMDB picture at the given size ("w342", "w1280"); other https addresses unchanged; "" for anything else."""
    u = str(url or "")
    if not u.startswith("https://"):
        return ""
    return re.sub(r"(image\.tmdb\.org/t/p/)(?:w\d+|original)/", r"\g<1>%s/" % size, u)


def title_of(t):
    """Any title shape the server sends (/api/roku/*, /meta/*, My List) as one dict; None when it has no TMDB id."""
    if not isinstance(t, dict):
        return None
    ids = t.get("ids") if isinstance(t.get("ids"), dict) else {}
    tmdb = str(ids.get("tmdb") or t.get("tmdb") or "")
    raw_type = str(t.get("type") or "").lower()
    kind = "series" if raw_type in ("series", "tv", "show") else "movie" if raw_type == "movie" else ""
    if not tmdb.isdigit() or not kind:
        return None
    name = str(t.get("name") or t.get("title") or "")
    if not name:
        return None
    year = str(t.get("year") or "")[:4]
    return {
        "tmdb": tmdb, "type": kind, "name": name, "year": year if year.isdigit() else "",
        "poster": picture(t.get("poster") or t.get("image"), "w342"),
        "backdrop": picture(t.get("backdrop") or t.get("card"), "w1280"),
        "overview": str(t.get("overview") or ""),
        "imdb": str(ids.get("imdb") or t.get("imdb") or ""),
        "rating": str(t.get("imdbRating") or t.get("rating") or ""),
        "certification": str(t.get("certification") or ""),
        "runtime": int(t.get("runtime") or 0) if str(t.get("runtime") or "0").isdigit() else 0,
        "seasonList": [int(n) for n in (t.get("seasonList") or []) if str(n).isdigit()],
    }


def titles_of(items, limit=60):
    out = []
    for item in items or []:
        t = title_of(item)
        if t:
            out.append(t)
        if len(out) >= limit:
            break
    return out


def title_line(t):
    """ "2024 · Movie · 2h 10m" / "2019 · TV Show · 3 seasons" (any part may be missing)."""
    parts = []
    if t.get("year"):
        parts.append(t["year"])
    parts.append("Movie" if t.get("type") == "movie" else "TV Show")
    runtime = t.get("runtime") or 0
    if runtime > 0:
        h, m = divmod(runtime, 60)
        parts.append("%dh %dm" % (h, m) if h else "%dm" % m)
    seasons = len(t.get("seasonList") or [])
    if seasons:
        parts.append("1 season" if seasons == 1 else "%d seasons" % seasons)
    return DOT.join(parts)


# ---- My List (the same shape the Apple apps and the web keep under the "myList" preference) ----------------------------

def pin_of(t):
    return {"id": "meta:%s:%s" % (t["type"], t["tmdb"]), "name": t["name"], "type": "Series" if t["type"] == "series" else "Movie",
            "year": int(t["year"]) if t.get("year") else 0, "image": t.get("poster") or None, "backdrop": t.get("backdrop") or None,
            "tmdb": t["tmdb"], "imdb": t.get("imdb") or None, "metadataOnly": True}


def is_pinned(pins, t):
    key = "meta:%s:%s" % (t["type"], t["tmdb"])
    return any(isinstance(p, dict) and (p.get("id") == key or (str(p.get("tmdb")) == t["tmdb"] and title_of(p) and title_of(p)["type"] == t["type"])) for p in pins or [])


def toggle_pin(pins, t):
    """My List with this title added (at the front) or removed; returns (new list, now pinned?)."""
    pins = [p for p in (pins or []) if isinstance(p, dict)]
    if is_pinned(pins, t):
        keep = [p for p in pins if not (title_of(p) and title_of(p)["tmdb"] == t["tmdb"] and title_of(p)["type"] == t["type"])]
        return keep, False
    return [pin_of(t)] + pins, True


# ---- Continue Watching (watch history, the same rows as every other app) ---------------------------------------------

HISTORY_ID = re.compile(r"^tmdb-(\d+)-(?:movie|s(\d+)-e(\d+))$")


def history_key(kind, tmdb, season=None, episode=None):
    """The history row id the web uses for a catalog title (web-v27/js/history.js historyEntry)."""
    return "tmdb-%s-s%d-e%d" % (tmdb, int(season), int(episode)) if kind == "series" else "tmdb-%s-movie" % tmdb


def history_entry(t, season=None, episode=None, episode_name=""):
    """What /api/history stores for one movie or episode (positions are added by the player service)."""
    series = t["type"] == "series"
    entry = {"itemId": history_key(t["type"], t["tmdb"], season, episode), "kind": "episode" if series else "movie",
             "title": (episode_name or "Episode %s" % episode) if series else t["name"],
             "seriesId": "tmdb-%s" % t["tmdb"] if series else None, "seriesName": t["name"] if series else None,
             "season": int(season) if series else None, "episode": int(episode) if series else None}
    if t.get("poster"):
        entry["image"] = t["poster"]
    return entry


def continue_items(history):
    """Unfinished catalog titles from GET /api/history, newest first, as playable rows."""
    out = []
    for h in history or []:
        if not isinstance(h, dict) or h.get("finished"):
            continue
        m = HISTORY_ID.match(str(h.get("itemId") or ""))
        if not m:
            continue  # Jellyfin-only rows: the other apps play those from the library
        duration = float(h.get("duration") or 0)
        position = float(h.get("position") or 0)
        if duration <= 0 or position < 30:
            continue
        episode = m.group(2) is not None
        out.append({
            "itemId": h["itemId"], "tmdb": m.group(1), "type": "series" if episode else "movie",
            "season": int(m.group(2)) if episode else None, "episode": int(m.group(3)) if episode else None,
            "name": (h.get("seriesName") or h.get("title") or "") if episode else (h.get("title") or ""),
            "episodeName": h.get("title") or "" if episode else "",
            "image": picture(h.get("image"), "w342"), "position": position, "duration": duration,
            "progress": min(1.0, position / duration),
        })
    return out


def clock_text(seconds):
    s = int(max(0, seconds))
    h, rest = divmod(s, 3600)
    m, s = divmod(rest, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


# ---- Choose a version ------------------------------------------------------------------------------------------------

def describe_source(name, description, filename):
    """Container, video codec, audio codecs and resolution from a Stremio add-on stream's text (logic.brs mcDescribeSource)."""
    text = "\n".join([name or "", description or "", filename or ""])
    m = re.search(r"\.(mkv|mp4|m4v|avi|webm|ts|mov)\b", filename or "", re.I) or re.search(r"\.(mkv|mp4|m4v|avi|webm|ts|mov)\b", text, re.I)
    container = m.group(1).lower() if m else ""
    if container == "m4v":
        container = "mp4"
    video = ""
    if re.search(r"\b(hevc|x\.?265|h\.?265)\b", text, re.I):
        video = "hevc"
    elif re.search(r"\bav1\b", text, re.I):
        video = "av1"
    elif re.search(r"\b(avc|x\.?264|h\.?264)\b", text, re.I):
        video = "h264"
    audio = []
    if re.search(r"\b(dd\+|ddp|e-?ac-?3|atmos)", text, re.I):
        audio.append("eac3")
    if re.search(r"\b(dd(?!\+)|ac-?3|dolby digital)\b", text, re.I):
        audio.append("ac3")
    if re.search(r"\baac\b", text, re.I):
        audio.append("aac")
    if re.search(r"\btruehd\b", text, re.I):
        audio.append("truehd")
    if re.search(r"\bdts", text, re.I):
        audio.append("dts")
    res = ""
    if re.search(r"\b(2160p|4k|uhd)\b", text, re.I):
        res = "2160p"
    elif re.search(r"\b1080p\b", text, re.I):
        res = "1080p"
    elif re.search(r"\b720p\b", text, re.I):
        res = "720p"
    elif re.search(r"\b480p\b", text, re.I):
        res = "480p"
    return {"container": container, "video": video, "audio": audio, "res": res}


def addon_versions(streams, limit=60):
    """Stremio add-on streams as versions (only http(s) links; magnets and the rest are skipped)."""
    out = []
    for s in streams or []:
        if len(out) >= limit:
            break
        if not isinstance(s, dict):
            continue
        url = str(s.get("url") or "")
        if not (url.startswith("https://") or url.startswith("http://")):
            continue
        hints = s.get("behaviorHints") if isinstance(s.get("behaviorHints"), dict) else {}
        name = str(s.get("name") or "")
        d = describe_source(name, str(s.get("description") or s.get("title") or ""), str(hints.get("filename") or ""))
        size = hints.get("videoSize") or 0
        out.append(dict(d, provider="addon", name=name.split("\n")[0], size=size if isinstance(size, (int, float)) else 0, url=url))
    return out


PROVIDERS = {"torbox": "TorBox", "jellyfin": "Library", "regular": "Regular stream", "addon": "Add-on"}


def version_label(v):
    """ "1080p · H.264 · MKV · 2.1 GB" (logic.brs mcVersionLabel), with where it comes from."""
    parts = []
    res = v.get("res") or ""
    if res == "2160p":
        parts.append("4K")
    elif res:
        parts.append(res)
    video = v.get("video") or ""
    if video == "h264":
        parts.append("H.264")
    elif video:
        parts.append(video.upper())
    if v.get("container"):
        parts.append(str(v["container"]).upper())
    size = v.get("size") or 0
    if size > 0:
        gb = size / 1e9
        parts.append("%d GB" % round(gb) if gb >= 10 else "%.1f GB" % gb)
    label = DOT.join(parts) or "Version"
    return label


def device_caps(raspberry_pi=False, max_res="1080p", hevc=None):
    """What this box plays well. A Raspberry Pi 3 decodes H.264 up to 1080p in hardware; HEVC only in software (may
    stutter). Other Kodi boxes: H.264 and HEVC; 4K only if the setting allows it."""
    if hevc is None:
        hevc = not raspberry_pi
    return {"max_res": max_res, "hevc": bool(hevc), "av1": not raspberry_pi}


RES_ORDER = {"480p": 0, "720p": 1, "1080p": 2, "2160p": 3}


def play_level(v, caps):
    """ "yes", "maybe" or "no": how well this box plays one version (Kodi plays every container and sound format)."""
    res = v.get("res") or ""
    limit = RES_ORDER.get(caps.get("max_res") or "1080p", 2)
    if res and RES_ORDER.get(res, 0) > limit:
        return "no"
    video = v.get("video") or ""
    if video == "hevc" and not caps.get("hevc"):
        return "maybe"
    if video == "av1" and not caps.get("av1"):
        return "no"
    if video in ("", "hevc", "av1", "h264"):
        return "yes" if video else "maybe"
    return "maybe"


def rank_versions(versions, caps):
    """The versions this box can play, best first: plays well, then may play; within that the best picture the
    setting allows (1080p first, then 720p, unknown, 480p), then the server's own order (TorBox, library, provider,
    then add-ons). Returns (list, how many were hidden)."""
    limit = caps.get("max_res") or "1080p"
    want = [limit, "1080p", "720p", "", "480p"]
    scored, hidden = [], 0
    for i, v in enumerate(versions or []):
        level = play_level(v, caps)
        if level == "no":
            hidden += 1
            continue
        res = v.get("res") or ""
        res_score = want.index(res) if res in want else len(want)
        scored.append(((0 if level == "yes" else 1) * 100000 + res_score * 1000 + i, dict(v, level=level)))
    scored.sort(key=lambda x: x[0])
    return [v for _, v in scored], hidden


# ---- Live TV and sports ----------------------------------------------------------------------------------------------

def clock(ms):
    """ "8:00 PM" from a time in milliseconds, in this box's local time."""
    if not ms:
        return ""
    t = time.localtime(float(ms) / 1000.0)
    h = t.tm_hour % 12 or 12
    return "%d:%02d %s" % (h, t.tm_min, "PM" if t.tm_hour >= 12 else "AM")


def channel_label(ch):
    num = ch.get("num") or 0
    name = str(ch.get("name") or "")
    return ("%s  %s" % (num, name)) if num else name


def channel_plot(ch):
    lines = []
    now, nxt = ch.get("now"), ch.get("next")
    if isinstance(now, dict) and now.get("title"):
        lines.append("Now: %s (until %s)" % (now["title"], clock(now.get("stop"))))
    if isinstance(nxt, dict) and nxt.get("title"):
        lines.append("Next: %s at %s" % (nxt["title"], clock(nxt.get("start"))))
    return "\n".join(lines)


def now_title(ch):
    now = ch.get("now")
    return now.get("title", "") if isinstance(now, dict) else ""


WHY = {"best": "Most likely showing this game", "guide": "The guide says it is on here", "feed": "A feed of this game",
       "network": "Listed for this game", "shared": "May be showing another game", "backup": "Backup feed"}


def why_line(why):
    return WHY.get(why or "", "")


def _sides(game):
    teams = game.get("teams") or []
    if len(teams) < 2:
        return None, None
    away, home = teams[0], teams[1]
    if teams[0].get("home"):
        away, home = teams[1], teams[0]
    return away, home


def matchup(game):
    """ "Heat at Celtics" (away at home)."""
    away, home = _sides(game)
    return "%s at %s" % (away.get("name", ""), home.get("name", "")) if away else ""


def score_line(game):
    """ "MIA 78 – 71 BOS" with the away team first; "" before the game starts."""
    if game.get("state") == "pre":
        return ""
    away, home = _sides(game)
    if not away:
        return ""
    return u"%s %s – %s %s" % (away.get("abbr", ""), away.get("score", ""), home.get("score", ""), home.get("abbr", ""))


def when(game, now=None):
    """ "LIVE · Q3 4:12" while on, else "Tonight 8:00 PM" / "Tomorrow 1:00 PM" / "Sun 1:00 PM"."""
    if game.get("state") == "in":
        return "LIVE" + (DOT + game["detail"] if game.get("detail") else "")
    start = game.get("start")
    if not start:
        return game.get("detail") or ""
    when_dt = datetime.datetime.fromtimestamp(float(start) / 1000.0)
    today = datetime.datetime.fromtimestamp(now) if now else datetime.datetime.now()
    days = (when_dt.date() - today.date()).days
    c = clock(start)
    if days == 0:
        return ("Tonight " if when_dt.hour >= 17 else "Today ") + c
    if days == 1:
        return "Tomorrow " + c
    return when_dt.strftime("%a") + " " + c


def game_label(game):
    score = score_line(game)
    head = score or matchup(game)
    return DOT.join([p for p in [when(game), game.get("league") or "", head] if p])


def greeting(hour):
    if hour < 12:
        return "Good morning"
    if hour < 17:
        return "Good afternoon"
    return "Good evening"


# ---- Live channel list from the provider (Guide, all channels) --------------------------------------------------------

ALT = re.compile(r"^(.*?)\s*·\s*Alt\s+\d+$")


def fold_lineup(streams):
    """The provider's channels with "· Alt N" feeds folded under their channel (src/ba-roku.js foldLineup)."""
    channels, lead = [], {}
    for s in streams if isinstance(streams, list) else []:
        if not isinstance(s, dict):
            continue
        name = str(s.get("name") or "")
        m = ALT.match(name)
        key = "%s|%s|%s" % (s.get("category_id"), s.get("num"), m.group(1) if m else name)
        if m and key in lead:
            lead[key]["alts"].append(str(s.get("stream_id")))
            continue
        try:
            num = int(s.get("num") or 0)
        except (TypeError, ValueError):
            num = 0
        ch = {"id": str(s.get("stream_id")), "num": num, "name": re.sub(r"^(US|TV)\| ", "", name).strip(),
              "category": str(s.get("category_id")), "logo": str(s.get("stream_icon") or ""), "alts": [],
              "epgId": str(s.get("epg_channel_id") or ""), "us": name.startswith("US| ")}
        lead[key] = ch
        channels.append(ch)
    channels.sort(key=lambda c: (c["num"] or 1e9, c["name"]))
    return channels


# ---- Seasonal row (web Home: Halloween in October, Holiday movies Nov-Dec, Family Picks the rest of the year) --------

def seasonal_row(today=None):
    d = today or datetime.date.today()
    if d.month == 10:
        return "halloween", "Halloween Movies"
    if d.month in (11, 12):
        return "holiday", "Holiday Movies"
    return "family", "Family Picks"
