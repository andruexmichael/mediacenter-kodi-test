# mediaCENTER for Kodi: sample-data mode, for screenshots on a test box without anyone's account.
#
# On only when the folder resources/data/sample exists inside the installed add-on. Nothing ships with it:
# scripts/build-kodi-repo.mjs leaves that folder out of every zip, and only kodi/tools/rig.py copies it in (from
# kodi/tools/sample). The answers have the same shapes as the live routes; nothing is sent anywhere.

import json
import os

from mc_api import Api


def folder(addon_path):
    """The sample folder of an installed add-on, or None when sample-data mode is off (every release)."""
    path = os.path.join(addon_path, "resources", "data", "sample")
    return path if os.path.isdir(path) else None


HISTORY = {"items": [
    {"itemId": "tmdb-11-s1-e2", "kind": "episode", "title": "Deadline", "seriesId": "tmdb-11", "seriesName": "City Desk",
     "season": 1, "episode": 2, "image": "", "position": 600, "duration": 2700, "finished": False},
    {"itemId": "tmdb-1-movie", "kind": "movie", "title": "The Long Night", "position": 3000, "duration": 6720, "finished": False},
]}
CHANNELS = [{"stream_id": 101, "num": 30, "name": "US| ESPN", "category_id": "7", "epg_channel_id": "espn.us"},
            {"stream_id": 201, "num": 4, "name": "US| NBC (WTVJ)", "category_id": "8", "epg_channel_id": "wtvj.us"}]
CATEGORIES = [{"category_id": "7", "category_name": "US Sports"}, {"category_id": "8", "category_name": "US Locals"}]


class SampleApi(Api):
    """An Api that is always signed in as "Sample" and answers from the sample folder instead of the server."""

    def __init__(self, sample_folder):
        Api.__init__(self)
        self.sample = sample_folder
        self.cookie = "sample"
        self.username = "Sample"
        self.prefs = {"myList": {"value": [], "updatedAt": 1}}

    def demo(self, name):
        with open(os.path.join(self.sample, "demo-%s.json" % name), encoding="utf-8") as f:
            return json.load(f)

    def raw(self, method, path, query=None, body=None, timeout=None):
        raise OSError("sample-data mode sends nothing")

    def call(self, method, path, query=None, body=None, timeout=None):
        q = query or {}
        for route in ("home", "sports", "live", "search", "episodes", "play"):
            if path == "/api/roku/" + route:
                return self.demo(route)
        if path == "/api/browse":
            if q.get("genre"):
                return dict(self.demo("browse-genre"), kind=q.get("kind"), genre=q.get("genre"))
            return self.demo("browse-series" if q.get("kind") == "series" else "browse-movie")
        if path == "/api/roku/title":
            t = dict(self.demo("title")["title"])
            if q.get("type") == "series":
                t.update(type="series", name="City Desk", seasonList=[1, 2])
            return {"title": t}
        if path == "/meta/title":
            return {"certification": "PG-13", "imdbRating": "7.4", "ids": {}}
        if path in ("/meta/row", "/meta/similar"):
            return {"items": [{"type": "movie", "title": "Harbor Lights", "year": 2026, "ids": {"tmdb": 2}, "poster": ""}]}
        if path == "/api/history":
            return HISTORY if method == "GET" else {"ok": True}
        if path == "/api/prefs":
            if method != "GET" and isinstance(body, dict):
                self.prefs.update(body.get("prefs") or {})
            return {"prefs": self.prefs}
        if path == "/player_api.php":
            return CATEGORIES if q.get("action") == "get_live_categories" else CHANNELS
        if path == "/access/session":
            return {"username": "sample", "displayName": "Sample"}
        if path in ("/access/logout", "/api/share"):
            return {"ok": True}
        return {}

    def addon_streams(self, base, kind, stream_id, timeout=30):
        return []

    def forget(self):
        pass
