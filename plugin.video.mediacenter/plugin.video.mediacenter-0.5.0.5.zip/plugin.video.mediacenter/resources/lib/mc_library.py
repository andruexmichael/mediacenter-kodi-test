"""Account Library in a themed desktop popup; existing routes, no new persistence."""
import xbmcgui
import mc_views as V
import mc_pages as pages
from mc_api import ServerError, SignedOut

class LibraryPage(xbmcgui.WindowXMLDialog):
    goto_name = 'library'
    @classmethod
    def open(cls, app):
        w=cls('mediacenter-library.xml', V.HERE, 'Default', '1080i')
        w.app, w.api = app, app.api
        pages.modal(w)
        del w
    def onInit(self):
        if getattr(self,'ready',False): return
        self.ready=True
        self.spec=(V.experience().get('app') or {}).get('presentation') or {}
        self.tabs=self.spec.get('library') or ['My List','Continue Watching','Watch History','Watchlist','Trakt']
        for i, title in enumerate(self.tabs,1):self.setProperty('tab.%d'%i,title)
        self.choose(0)
        self.setFocusId(101)
    def choose(self, index):
        if index == 2:
            self.app.watch_history()
            return
        self.selected = index
        self.setProperty('section',self.tabs[index])
        self.clearProperty('empty')
        control=self.getControl(501);control.reset()
        if index>=3:
            return self.setProperty('empty',self.spec.get('nextUpdate','Coming in the next update'))
        try:
            cards=self.app.my_list_cards() if index==0 else self.app.continue_cards()
            control.addItems(cards)
            if not cards:self.setProperty('empty','Nothing here yet.')
        except SignedOut:self.setProperty('empty','Sign in again from Settings.')
        except (ServerError,OSError):self.setProperty('empty',"Can't reach mediaCENTER right now. Try again.")
    def onClick(self,cid):
        if 101<=cid<=105:return self.choose(cid-101)
        if cid==501:
            import mc_app
            item=self.getControl(501).getSelectedItem()
            if item is not None:mc_app.open_item(self.api,item,win=self)
    def onAction(self,action):
        if action.getId() in (9,10,92,247):return self.close()
        import mc_hold
        if self.getFocusId() == 501 and mc_hold.wants_hold(action.getId()):
            item=self.getControl(501).getSelectedItem()
            if item is not None:
                if item.getProperty('kind') == 'continue':mc_hold.continue_hold(self.api,item)
                else:
                    import mc_app
                    mc_app.hold_card(self,501,item)
                self.choose(self.selected)
