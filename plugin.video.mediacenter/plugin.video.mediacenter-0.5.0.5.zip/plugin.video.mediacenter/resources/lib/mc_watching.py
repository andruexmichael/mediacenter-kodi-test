# mediaCENTER for Kodi: the watching features of 0.4.9, as on the website.
#
#   PlayerExtras (one per player page, mc_player.PlayerPage.extras):
#     - Skip Intro, Skip Credits and the Next Episode countdown (mc_offers, the website's rules and skip times);
#     - Episodes inside the player: any season and episode, picked over the playing picture (mc_sheet);
#     - Subtitles: the version's own, or found online; their size and look; Audio: the version's tracks;
#       the account's saved audio and subtitle language turned on by itself (mc_subtitles);
#     - live TV: a backup feed taken by itself when the channel stalls or drops mid-stream (automaticBackups, on unless
#       turned off on the account, as the web player's backupFeeds).
#   Continue Watching that follows the other devices: refreshed when you come back to Home, a card can be removed, and
#   the Watch history page (remove an item and it leaves Continue Watching too; the web's views/watch-history.js).

import os
import threading
import time

import xbmc
import xbmcgui

import mc_logic as L
import mc_offers as O
import mc_picture as MP
import mc_subdraw as D
import mc_subtitles as S
import mc_views as V
import mc_pages as pages
from mc_api import SignedOut, ServerError

OFFER = 950  # the offer button in mediacenter-player.xml (kodi/tools/watching_windows.py)
B_EPISODES = 608
B_AUDIO, B_SUBS = 605, 606
U_PLAY, U_CANCEL = 901, 902
UP, SELECT = 3, 7
BACK = (9, 10, 92, 247)
STALL_SECONDS = 20  # a live picture still this long (not paused) counts as stalled; the web waits 15 s on faster boxes
TRACKS_WAIT = 2.5  # seconds after the picture starts before the tracks are read (Kodi lists them a moment later)
HISTORY_FRESH = 60  # Continue Watching on Home is asked again after this long (the web's FRESH_MS)
SKIP_SETTLE = 6.0  # seconds Kodi gets to land on the end of the intro before playback is made to carry on


def carry_on(player, paused, sleep=time.sleep, now=time.time, most=SKIP_SETTLE, log=lambda line: None):
    """0.4.9.9 (owner, 2026-11-26: "after Skip intro, it doesn't carry on playing"): after the jump past the intro,
    playback plays by itself. On the Pi a jump into a part of the link not yet read leaves Kodi waiting with the
    picture held, and a jump made while paused stays paused. Done when the clock moves unpaused ("played"); else, after
    most seconds, a paused player is resumed ("resumed") or a held one asked to play at normal speed ("still").
    "gone": nothing is playing any more."""
    end = now() + most
    try:
        last = player.getTime()
    except RuntimeError:
        return "gone"
    while now() < end:
        sleep(0.25)
        try:
            if not player.isPlaying():
                return "gone"
            t = player.getTime()
        except RuntimeError:
            return "gone"
        if not paused() and abs(t - last) > 0.2:
            return "played"
        last = t
    try:
        if not player.isPlaying():
            return "gone"
        if paused():
            player.pause()  # Kodi's pause() toggles: resumes a paused player
            log("skip: playback was held after the jump; resumed")
            return "resumed"
    except RuntimeError:
        return "gone"
    log("skip: playback still standing after the jump; asked Kodi to play at normal speed")
    try:
        xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Player.SetSpeed","params":{"playerid":1,"speed":1}}')
    except Exception:
        pass
    return "still"


# ---- live: stalls -------------------------------------------------------------------------------------------------

class StallWatch(object):
    """Whether a live picture has stood still too long. update(position, paused) once in a while: True once stalled."""

    def __init__(self, seconds=STALL_SECONDS, clock=time.time):
        self.seconds, self.clock = seconds, clock
        self.reset()

    def reset(self):
        self.last, self.moved_at = None, self.clock()

    def update(self, position, paused):
        now = self.clock()
        if paused or position is None or self.last is None or abs(position - self.last) > 0.05:
            self.last, self.moved_at = position, now
            return False
        return now - self.moved_at >= self.seconds


def after(feeds, feed):
    """The feeds after the one that was showing (the backups still to try)."""
    for i, f in enumerate(feeds or []):
        if f is feed:
            return list(feeds[i + 1:])
    return []


# ---- episodes ------------------------------------------------------------------------------------------------------

def aired(e, today=None):
    day = str(e.get("air_date") or e.get("aired") or e.get("air") or "")[:10]
    if len(day) != 10 or day[4] != "-":
        return True
    return day <= (today or time.strftime("%Y-%m-%d"))


def episode_rows(api, tmdb, season, now_season=None, now_episode=None, today=None):
    """One season's episodes for the Episodes panel: aired ones only (the web's rule), with stills where known."""
    try:
        eps = (api.get("/meta/episodes", tmdb=tmdb, season=season) or {}).get("episodes") or []
    except (ServerError, OSError, ValueError):
        eps = []
    if not eps:
        try:
            eps = (api.get("/api/roku/episodes", tmdb=tmdb, season=season) or {}).get("episodes") or []
        except (ServerError, OSError, ValueError):
            eps = []
    rows = []
    for e in eps:
        try:
            n = int(e.get("n"))
        except (TypeError, ValueError):
            continue
        if n < 1 or not aired(e, today):
            continue
        current = now_season is not None and int(season) == int(now_season) and n == int(now_episode or 0)
        rows.append({"key": n, "label": u"%d. %s" % (n, e.get("name") or "Episode %d" % n),
                     "label2": "Now playing" if current else L.DOT.join(p for p in [L.date_text(e.get("air_date") or "") if e.get("air_date") else ""] if p),
                     "thumb": L.picture(e.get("still"), "w300") if e.get("still") else "", "current": current})
    return sorted(rows, key=lambda r: r["key"])


def season_tabs(seasons):
    nums = sorted(set(int(s) for s in seasons or [] if str(s).lstrip("-").isdigit() and int(s) >= 0))
    return [(n, "Specials" if n == 0 else "Season %d" % n) for n in nums]


# ---- the player's extras -------------------------------------------------------------------------------------------

class PlayerExtras(object):
    def __init__(self, page, call=None):
        self.page = page
        self.call = call or S.rpc(xbmc.executeJSONRPC)
        self.tracker = O.OfferTracker()
        self.stall = StallWatch()
        self.imdb = ""
        self.counting = False
        self.next_target = None
        self.generation = 0
        self.drawer = None  # mc_subdraw.Drawer: the subtitles this page draws itself (a box with video on its own layer)
        self.drawn = ""  # the language it is drawing
        self.layer_own = None

    @property
    def player(self):
        pb = self.page.playback
        return pb.player if pb else None

    def vod(self):
        return self.page.mode == "vod"

    def own_layer(self):
        """Whether Kodi draws video on its own layer here (the Pi, "Direct to plane"): then Kodi shows no subtitles in
        this page, and the page draws them itself (mc_subdraw). Asked once per player page."""
        if self.layer_own is None:
            def setting(key):
                try:
                    r = self.call("Settings.GetSettingValue", {"setting": key})
                except Exception:
                    return "?"
                return r.get("value", "?") if isinstance(r, dict) else "?"
            self.layer_own = MP.own_layer(setting)
        return self.layer_own

    def stop_drawing(self):
        if self.drawer is not None:
            self.drawer.stop()
        self.drawer, self.drawn = None, ""

    def position(self):
        p = self.player
        try:
            return p.getTime() if p is not None and p.isPlaying() else None
        except RuntimeError:
            return None

    def draw_file(self, path, lang, gen=None):
        """Show a subtitle file in this page (on a box where Kodi can't). False when it holds no lines."""
        cues = D.load(path)
        if not len(cues):
            return False
        self.stop_drawing()
        try:  # Kodi's own subtitles off: they show nowhere here, and a second set must never appear on top
            self.call("Player.SetSubtitle", {"playerid": 1, "subtitle": "off"})
        except Exception:
            pass
        gen = self.generation if gen is None else gen
        prefs = S.prefs(self.page.api)
        self.drawer = D.Drawer(self.page, cues, self.position,
                               alive=lambda: gen == self.generation and not self.page.closing,
                               size=prefs.get("subtitleSize"), style=prefs.get("subtitleStyle"))
        self.drawn = lang
        self.drawer.start()
        return True

    def episode(self):
        return self.vod() and self.page.kind == "series"

    # -- a picture started --

    def started(self, feed):
        self.generation += 1
        gen = self.generation
        self.stop_drawing()  # a new picture: the saved language is put on again below (auto_tracks)
        self.counting = False
        self.next_target = None
        self.page.clearProperty("offer")
        self.stall.reset()
        if not self.vod():
            return
        self.tracker.reset()
        th = threading.Thread(target=self.prepare, args=(gen,))
        th.daemon = True
        th.start()
        return th

    def prepare(self, gen):
        """Skip times, then the saved languages: in the background, so the picture is never held up."""
        self.imdb = self.imdb or self.find_imdb()
        if gen != self.generation:
            return
        season, episode = (self.page.season, self.page.episode) if self.episode() else (None, None)
        self.tracker.set_segments(O.load_segments(self.page.api, self.imdb, season, episode))
        time.sleep(TRACKS_WAIT)
        if gen == self.generation and not self.page.closing:
            self.auto_tracks()

    def find_imdb(self):
        imdb = str((self.page.t or {}).get("imdb") or "")
        if imdb:
            return imdb
        try:
            m = self.page.api.get("/meta/title", type=self.page.kind, tmdb=self.page.tmdb) or {}
        except (ServerError, SignedOut, OSError, ValueError):
            return ""
        return str((m.get("ids") or {}).get("imdb") or m.get("imdb") or "")

    def auto_tracks(self):
        """The account's audio and subtitle language, and the subtitle look, as the web turns them on."""
        prefs = S.prefs(self.page.api)
        S.apply_style(self.call, prefs.get("subtitleSize"), prefs.get("subtitleStyle"), V.WINDOW)
        t = S.tracks(self.call)
        index = S.choose_audio(t["audio"], prefs.get("audioLanguage"))
        if index is not None:
            self.call("Player.SetAudioStream", {"playerid": 1, "stream": index})
        wanted = prefs.get("subtitleLanguage")
        if self.own_layer():
            if wanted and wanted != "off":
                self.load_online(S.lang2(wanted), quiet=True)
            return
        pick = S.choose_subtitle(t["subs"], wanted)
        if pick and pick[0] == "track":
            self.call("Player.SetSubtitle", {"playerid": 1, "subtitle": pick[1], "enable": True})
        elif pick and pick[0] == "online":
            self.load_online(pick[1], quiet=True)

    # -- once a second (PlayerPage.tick) --

    def tick(self):
        if not self.vod() or not self.page.getProperty("playing") or self.page.closing:
            return
        p = self.player
        if p is None:
            return
        try:
            if not p.isPlaying():
                return
            t, length = p.getTime(), p.getTotalTime()
        except RuntimeError:
            return
        paused = xbmc.getCondVisibility("Player.Paused")
        outcome = self.tracker.update(t, length or None, self.episode(), paused)
        if outcome == "playNext":
            self.counting = False
            return self.page.play_next(self.next_target)
        self.draw()

    def draw(self):
        offer = self.tracker.offer
        page = self.page
        kind = (offer or {}).get("kind")
        if kind == "nextEpisode":
            if self.next_target is None:
                self.next_target = page.find_next() or False
            if not self.next_target:  # the last episode: nothing to count down to
                self.tracker.dismiss()
                return self.draw()
            if page.layer in ("", "offer", "upnext"):
                if not self.counting:
                    self.counting = True
                    s, e = self.next_target
                    name = next((x.get("name", "") for x in getattr(page, "eps_cache", {}).get(int(s), []) if int(x.get("n") or 0) == e), "")
                    page.upnext_target = self.next_target
                    page.setProperty("upnext.title", u"S%d · E%d%s" % (s, e, (u" · " + name) if name else ""))
                    page.setProperty("upnext.show", (page.t or {}).get("name", ""))
                    page.setProperty("upnext.fanart", (page.t or {}).get("backdrop") or "")
                    page.clearProperty("offer")
                    page.show_layer("upnext", U_PLAY)
                page.setProperty("upnext.count", "NEXT EPISODE IN %d" % offer["countdown"])
            return
        if self.counting:  # the countdown card goes once the offer moved on (seeked back, Cancel)
            self.counting = False
            if page.layer == "upnext":
                page.show_layer("")
        words = O.label(offer)
        if words:
            page.setProperty("offer", words)
            if page.layer == "":
                page.show_layer("offer", OFFER)
        else:
            page.clearProperty("offer")
            if page.layer == "offer":
                page.show_layer("")
                page.setFocusId(699)

    # -- presses --

    def take_offer(self):
        p = self.player
        length = None
        try:
            length = p.getTotalTime() if p else None
        except RuntimeError:
            pass
        taken = self.tracker.take(length or None)
        self.page.clearProperty("offer")
        if self.page.layer == "offer":
            self.page.show_layer("")
            self.page.setFocusId(699)
        if isinstance(taken, dict) and taken.get("kind") == "seek" and p is not None:
            try:
                p.seekTime(taken["to"])
            except RuntimeError:
                return taken
            threading.Thread(target=carry_on, args=(p, lambda: xbmc.getCondVisibility("Player.Paused")),
                             kwargs={"log": V.log}, name="mediacenter-skip").start()
        elif taken == "finish":
            if self.page.playback:
                self.page.playback.stop()
            self.page.finish("ended")
        elif taken == "playNext":
            self.counting = False
            self.page.play_next(self.next_target or None)
        return taken

    def cancel_countdown(self):
        self.tracker.cancel_countdown()
        self.counting = False
        self.page.show_layer("")
        self.draw()

    def on_click(self, cid):
        """True when the press was the extras' own."""
        if cid == OFFER:
            self.take_offer()
            return True
        if cid == U_CANCEL and self.counting:
            self.cancel_countdown()
            return True
        if cid == U_PLAY and self.counting:
            self.counting = False
            self.tracker.take_next_episode()
            self.page.play_next(self.next_target or None)
            return True
        if cid == B_EPISODES:
            self.episodes()
            return True
        if cid == B_SUBS and self.vod():
            self.subtitles()
            return True
        if cid == B_AUDIO and self.vod():
            self.audio()
            return True
        return False

    def on_action(self, a, layer):
        """True when the key was the extras' own (the page then leaves it)."""
        if layer == "upnext" and self.counting and a in BACK:
            self.cancel_countdown()
            return True
        if layer == "offer":
            if a in BACK:  # Back puts the offer away for this playback; Back again leaves as before
                self.tracker.dismiss()
                self.draw()
                return True
            if a == SELECT:
                return True  # the button's own click takes it
        # With the controls up the offer is reached by Up from the timeline (mediacenter-player.xml, 610 onup 950).
        return False

    # -- the panels over the picture --

    def episodes(self):
        page = self.page
        if not self.episode():
            return
        import mc_sheet
        seasons = (page.t or {}).get("seasonList") or []
        if not seasons:
            try:
                seasons = ((page.api.get("/api/roku/title", type="series", tmdb=page.tmdb) or {}).get("title") or {}).get("seasonList") or []
            except (ServerError, SignedOut, OSError):
                seasons = []
        tabs = season_tabs(seasons or [page.season])
        picked = mc_sheet.SheetPage.choose(
            "Episodes", lambda s: episode_rows(page.api, page.tmdb, s, page.season, page.episode), tabs=tabs,
            tab=int(page.season), subheading=(page.t or {}).get("name", ""), empty="No episodes listed for this season.")
        page.show_hud()
        if picked:
            season, row = picked
            self.tracker.take_next_episode()
            page.play_next((int(season), int(row["key"])))  # the best match, as Play (0.4.9.8)

    def subtitles(self):
        import mc_sheet
        page = self.page
        self.imdb = self.imdb or self.find_imdb()  # needed to find any online (the menu offers none without it)
        prefs = S.prefs(page.api)

        def rows(tab):
            if tab == "size":
                return [{"key": k, "label": w, "on": prefs.get("subtitleSize") == k} for k, w in S.SIZES]
            if tab == "look":
                return [{"key": k, "label": w, "on": prefs.get("subtitleStyle") == k} for k, w in S.STYLES]
            return S.menu(S.tracks(self.call), self.imdb, drawn=self.drawn if self.own_layer() else None)
        picked = mc_sheet.SheetPage.choose("Subtitles", rows, tabs=[("subs", "Subtitles"), ("size", "Size"), ("look", "Look")],
                                           subheading=page.getProperty("title"))
        page.show_hud()
        if not picked:
            return
        tab, row = picked
        if tab in ("size", "look"):
            key = "subtitleSize" if tab == "size" else "subtitleStyle"
            S.remember(page.api, key, row["key"])
            prefs[key] = row["key"]
            V.WINDOW.clearProperty("mc.substyle")
            S.apply_style(self.call, prefs.get("subtitleSize"), prefs.get("subtitleStyle"), V.WINDOW)
            if self.drawer is not None:
                self.drawer.restyle(prefs.get("subtitleSize"), prefs.get("subtitleStyle"))
            return page.toast("Subtitles: " + row["label"])
        key = row["key"]
        if key == "off":
            self.stop_drawing()
            self.call("Player.SetSubtitle", {"playerid": 1, "subtitle": "off"})
            S.remember(page.api, "subtitleLanguage", "off")
            return page.toast("Subtitles off")
        if key.startswith("track:") and self.own_layer() and row.get("lang"):
            # Not offered on these boxes (mc_subtitles.menu); if it ever is, the same language from online is shown.
            if self.load_online(row["lang"]):
                S.remember(page.api, "subtitleLanguage", row["lang"])
            return
        if key.startswith("track:"):
            self.call("Player.SetSubtitle", {"playerid": 1, "subtitle": int(key[6:]), "enable": True})
            if row.get("lang"):
                S.remember(page.api, "subtitleLanguage", row["lang"])
            return page.toast("Subtitles: " + row["label"])
        if key.startswith("online:"):
            if self.load_online(key[7:]):
                S.remember(page.api, "subtitleLanguage", key[7:])

    def load_online(self, lang, quiet=False):
        page = self.page
        if not quiet:
            page.toast("Looking for %s subtitles" % S.lang_name(lang))
        season, episode = (page.season, page.episode) if self.episode() else (None, None)
        gen = self.generation
        path = S.online(page.api, V.PROFILE, self.imdb, lang, season, episode)
        p = self.player
        if gen != self.generation or page.closing:
            return False  # another picture started while the file came
        if not path or p is None:
            if not quiet:
                page.toast("No %s subtitles found online for this title" % S.lang_name(lang))
            V.log("subtitles: none found online for %s" % lang)
            return False
        if self.own_layer():
            if not self.draw_file(path, lang, gen):
                if not quiet:
                    page.toast("The %s subtitles found online couldn't be read" % S.lang_name(lang))
                V.log("subtitles: the %s file had no lines" % lang)
                return False
            V.log("subtitles: %s, drawn by the player page (video on its own layer)" % lang)
            if not quiet:
                page.toast("Subtitles: %s (online)" % S.lang_name(lang))
            return True
        try:
            p.setSubtitles(path)
            p.showSubtitles(True)
        except (RuntimeError, AttributeError):
            return False
        if not quiet:
            page.toast("Subtitles: %s (online)" % S.lang_name(lang))
        return True

    def audio(self):
        import mc_sheet
        page = self.page
        t = S.tracks(self.call)
        if len(t["audio"]) < 2:
            return V.notify("This version has one sound track.")
        picked = mc_sheet.SheetPage.choose("Audio", lambda _: [{"key": a["index"], "lang": a["lang"], "label": a["label"], "on": a["on"]} for a in t["audio"]],
                                           subheading=page.getProperty("title"))
        page.show_hud()
        if picked:
            row = picked[1]
            self.call("Player.SetAudioStream", {"playerid": 1, "stream": row["key"]})
            if row.get("lang"):
                S.remember(page.api, "audioLanguage", row["lang"])
            page.toast("Audio: " + row["label"])

    # -- live: backups mid-stream --

    def backups_on(self):
        return S.prefs(self.page.api).get("automaticBackups") is not False

    def backup(self, feed, why):
        """The channel dropped or stalled while playing: the next feed, by itself (True), or nothing (False)."""
        page = self.page
        if page.mode != "live" or page.closing:
            return False
        hold = getattr(page, "held", None)
        if hold is not None and hold.lost_hold():
            # 0.4.9.6: paused too long for the channel, or it gave out right after Play: the same channel from now,
            # with "Back to live", rather than a backup feed (full screen from the Guide too).
            again = [feed] + after(page.feeds, feed) if feed in (page.feeds or []) else [feed]
            page.back_to_live(again)
            return True
        if page.attached:
            return False
        rest = after(page.feeds, feed)
        if not rest or not self.backups_on():
            return False
        V.log("live feed %s (%s); trying a backup" % ("stalled" if why == "stall" else "dropped", why))
        page.retry_with(rest, "The channel stalled. Trying a backup feed" if why == "stall" else "The channel dropped. Trying a backup feed")
        return True

    def stalled(self, player):
        """Asked by Playback while live TV plays: True once the picture has stood still too long."""
        if self.page.mode != "live":
            return False
        try:
            position = player.getTime()
        except RuntimeError:
            position = None
        return self.stall.update(position, xbmc.getCondVisibility("Player.Paused"))


# ---- Continue Watching and the watch history ------------------------------------------------------------------------

def history(api, limit=300):
    return (api.get("/api/history", limit=limit) or {}).get("items") or []


def remove(api, item_id, whole_series=False, rows=None):
    """Take an item (or every episode of its show) off the account's history and Continue Watching, on every device
    (DELETE /api/history?itemId=, as the web's removeHistory). Returns how many were removed."""
    rows = rows if rows is not None else history(api)
    item = next((h for h in rows if h.get("itemId") == item_id), None)
    ids = [item_id]
    if whole_series and item and item.get("seriesId"):
        ids = [h["itemId"] for h in rows if h.get("seriesId") == item["seriesId"] and h.get("itemId")]
    done = 0
    for i in ids:
        api.call("DELETE", "/api/history", {"itemId": str(i)})
        done += 1
    return done


def history_line(h):
    """The second line of a history row: what it is, and how far along (the web's watch-history.js)."""
    if h.get("seriesName"):
        what = u"S%s · E%s · %s" % (h.get("season") if h.get("season") is not None else u"—",
                                    h.get("episode") if h.get("episode") is not None else u"—", h.get("title") or "")
    else:
        what = "Movie"
    duration = float(h.get("duration") or 0)
    done = "Finished" if h.get("finished") else "%d%% watched" % min(100, round(100 * float(h.get("position") or 0) / max(1.0, duration)))
    return L.DOT.join([what, done])


class HistoryPage(xbmcgui.WindowXMLDialog):
    """Watch history (mediacenter-list.xml): everything watched on the account, newest first. OK on a row: play or
    resume it, or remove it (it leaves Continue Watching too; watching it again adds it back)."""
    TABS = [("all", "All"), ("open", "Not finished"), ("done", "Finished")]

    @classmethod
    def open(cls, api):
        w = cls("mediacenter-history.xml", V.HERE, "Default", "1080i")
        w.api, w.tab, w.rows, w.changed = api, "all", [], False
        pages.modal(w)
        changed = w.changed
        del w
        return changed

    def onInit(self):
        self.setProperty("heading", "Watch history")
        for i, (_, words) in enumerate(self.TABS, 1):
            self.setProperty("tab.%d" % i, words)
        self.load()

    def load(self):
        try:
            self.all = history(self.api)
        except SignedOut:
            self.all = []
            self.setProperty("empty", "Your session ended. Sign in again from Settings.")
        except (ServerError, OSError):
            self.all = []
            self.setProperty("empty", "Can't reach mediaCENTER right now. Check the internet connection and try again.")
        self.draw()

    def draw(self):
        want = {"all": lambda h: True, "open": lambda h: not h.get("finished"), "done": lambda h: bool(h.get("finished"))}[self.tab]
        self.rows = [h for h in self.all if isinstance(h, dict) and want(h)]
        control = self.getControl(50)
        control.reset()
        for h in self.rows:
            li = xbmcgui.ListItem(h.get("seriesName") or h.get("title") or ("Episode" if h.get("kind") == "episode" else "Movie"), history_line(h))
            li.setProperties({"num": "", "eyebrow": "WATCHED " + L.date_text(str(h.get("updatedAt") or "")[:10]).upper() if h.get("updatedAt") else "WATCHED",
                              "detail": "Remove an item to clear its saved progress and take it off Continue Watching. Watching it again adds it back."})
            control.addItem(li)
        if self.rows:
            self.clearProperty("empty")
            self.setFocusId(50)
        else:
            if not self.getProperty("empty") or self.getProperty("empty") == "No watch history yet.":
                self.setProperty("empty", "No watch history yet.")
            self.setFocusId(101)

    def onClick(self, cid):
        if 101 <= cid <= 100 + len(self.TABS):
            self.tab = self.TABS[cid - 101][0]
            self.clearProperty("empty")
            return self.draw()
        if cid == 50:
            pos = self.getControl(50).getSelectedPosition()
            if 0 <= pos < len(self.rows):
                self.act(self.rows[pos])

    def act(self, h):
        import mc_sheet
        item = L.continue_items([dict(h, finished=False, position=max(30, float(h.get("position") or 0)), duration=max(31, float(h.get("duration") or 0)))])
        choices = []
        if item:
            resume = not h.get("finished") and float(h.get("position") or 0) >= 30
            choices.append({"key": "play", "label": ("Resume from " + L.clock_text(float(h["position"]))) if resume else "Play from the beginning"})
        choices.append({"key": "remove", "label": "Remove from watch history", "label2": "Also takes it off Continue Watching"})
        if h.get("seriesId"):
            choices.append({"key": "show", "label": "Remove the whole show", "label2": "Every episode of %s" % (h.get("seriesName") or "this show")})
        picked = mc_sheet.SheetPage.choose(h.get("seriesName") or h.get("title") or "", lambda _: choices, subheading=history_line(h))
        if not picked:
            return
        key = picked[1]["key"]
        if key == "play" and item:
            import mc_player
            it = item[0]
            mc_player.play_title(self.api, it["type"], it["tmdb"], it.get("season"), it.get("episode"))
            self.changed = True
            return self.load()
        try:
            remove(self.api, h["itemId"], whole_series=key == "show", rows=self.all)
        except SignedOut:
            return V.notify("Your session ended. Sign in again from Settings.")
        except (ServerError, OSError):
            return V.notify("Could not remove saved progress. Please try again.")
        self.changed = True
        V.notify("Removed from watch history")
        self.load()

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()


class Freshness(object):
    """When Home's Continue Watching was last asked for; it is asked again after a playback or after a minute."""

    def __init__(self, clock=time.time):
        self.clock, self.at, self.dirty = clock, 0.0, True

    def asked(self):
        self.at, self.dirty = self.clock(), False

    def touch(self):
        self.dirty = True

    def due(self):
        return self.dirty or self.clock() - self.at >= HISTORY_FRESH
