# mediaCENTER for Kodi: starting straight into mediaCENTER on the box (0.4.5, owner 2026-11-25: no LibreELEC or Kodi
# logos, no Kodi wording "for the most part").
#
# On the box only (LibreELEC, the Pi), service.py calls prepare() at start-up:
#   1. the start-up picture: Kodi shows special://home/media/splash.png instead of its own logo while it starts. Until
#      the box has a snapshot of its own opening (mc_opening.py, with the account's posters), mediaCENTER's opening
#      without posters is put there (resources/media/splash.png);
#   2. the mediaCENTER look (skin.mediacenter): installed from the update list when it's missing, then switched to.
#      Kodi asks "Keep this change?" after a skin change and goes back after 10 seconds without an answer, so the
#      answer is given here (Yes, button 11 of that dialog). A box where the switch didn't hold is tried again at the
#      next start, three times per version at most, so a broken skin can never loop.
# LibreELEC's own boot logo sits on the card's boot partition, read-only while the box runs; that one is a manual step
# (docs/KODI-0.4.5-HANDOFF.md).

import json
import os
import shutil

import xbmc
import xbmcvfs

SKIN = "skin.mediacenter"
TRIES = 3


def on_box():
    """LibreELEC (the Pi), never Kodi on a computer."""
    try:
        with open("/etc/os-release") as f:
            return "libreelec" in f.read().lower()
    except OSError:
        return False


def ensure_splash(addon_path, home=None):
    """Put mediaCENTER's start-up picture where Kodi looks first, unless the box already keeps its own (a snapshot of
    the opening). Returns True when it was written."""
    src = os.path.join(addon_path, "resources", "media", "splash.png")
    folder = os.path.join(home or xbmcvfs.translatePath("special://home"), "media")
    dst = os.path.join(folder, "splash.png")
    if not os.path.isfile(src):
        return False
    try:
        if os.path.isfile(dst):
            with open(src, "rb") as source, open(dst, "rb") as target:
                if source.read() == target.read():
                    return False
        if not os.path.isdir(folder):
            os.makedirs(folder)
        shutil.copyfile(src, dst)
        return True
    except OSError as e:
        xbmc.log("[mediaCENTER] start-up picture not written: %s" % type(e).__name__, xbmc.LOGINFO)
        return False


def tries(profile, version, add=False):
    path = os.path.join(profile, "skin-tries.json")
    try:
        with open(path) as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    n = int(data.get(version, 0)) if isinstance(data, dict) else 0
    if add:
        try:
            if not os.path.isdir(profile):
                os.makedirs(profile)
            with open(path, "w") as f:
                json.dump({version: n + 1}, f)
        except OSError:
            pass
        return n + 1
    return n


def rpc(method, params):
    return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))


def answer_yes(monitor, seconds):
    """Say Yes to the confirmation Kodi shows (install, or keep the new look). Returns True when one was answered."""
    for _ in range(int(seconds * 10)):
        if xbmc.getCondVisibility("Window.IsActive(yesnodialog)"):
            xbmc.executebuiltin("SendClick(yesnodialog,11)")
            return True
        if monitor.waitForAbort(0.1):
            return False
    return False


def ensure_skin(monitor, profile, version):
    """Install and switch to the mediaCENTER look. Returns "active", "switching", "missing" or "gave up"."""
    if xbmc.getSkinDir() == SKIN:
        return "active"
    if tries(profile, version) >= TRIES:
        return "gave up"
    tries(profile, version, add=True)
    if not xbmc.getCondVisibility("System.HasAddon(%s)" % SKIN):
        xbmc.log("[mediaCENTER] installing the mediaCENTER look", xbmc.LOGINFO)
        xbmc.executebuiltin("InstallAddon(%s,true)" % SKIN)
        answer_yes(monitor, 5)
        for _ in range(1200):  # up to two minutes on a slow card
            if xbmc.getCondVisibility("System.HasAddon(%s)" % SKIN) or monitor.waitForAbort(0.1):
                break
        if not xbmc.getCondVisibility("System.HasAddon(%s)" % SKIN):
            return "missing"
    rpc("Addons.SetAddonEnabled", {"addonid": SKIN, "enabled": True})
    xbmc.log("[mediaCENTER] switching to the mediaCENTER look", xbmc.LOGINFO)
    rpc("Settings.SetSettingValue", {"setting": "lookandfeel.skin", "value": SKIN})
    answer_yes(monitor, 15)
    return "switching"


def prepare(monitor, addon_path, profile, version):
    """What the box does at start-up before the app opens. Returns what ensure_skin said, or "" off the box."""
    if not on_box():
        return ""
    ensure_splash(addon_path)
    return ensure_skin(monitor, profile, version)
