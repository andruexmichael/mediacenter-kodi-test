# mediaCENTER for Kodi: the opening (0.4.5), as the Apple TV's (tvos/Sources/Splash.swift): about four seconds each
# time the app opens, posters from the last time drifting behind the mark, the name and "YOUR CHANNEL. TONIGHT.", with
# the Apple TV's opening sound. Back or OK skips it.
#
# Kodi itself can only show a still picture while it starts. So on the box, once the opening has drawn its posters, a
# snapshot of it is kept as Kodi's start-up picture (special://home/media/splash.png): from the next power-on the box
# shows mediaCENTER's poster wall instead of Kodi's logo, and it follows the newest posters (at most once a day).

import json
import os
import shutil
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

import mc_logic as L
import mc_views as V

SECONDS = 4.2
SNAP_AT = 3.4  # everything is on screen by then
POSTERS = 45
BACK = (9, 10, 92, 247)
SELECT = (7, 100)


def posters_file():
    return os.path.join(V.PROFILE, "opening-posters.json")


def remember(urls):
    """Keep the posters of this visit for the next opening (SplashPosters.remember on the Apple TV)."""
    keep = []
    for u in list(urls) + remembered():  # the newest first, then the ones kept before
        u = L.picture(u, "w342")
        if u and u not in keep:
            keep.append(u)
        if len(keep) >= POSTERS:
            break
    if len(keep) < 6 or keep == remembered():
        return False
    try:
        if not os.path.isdir(V.PROFILE):
            os.makedirs(V.PROFILE)
        with open(posters_file(), "w", encoding="utf-8") as f:
            json.dump(keep, f)
        return True
    except OSError:
        return False


def remembered():
    try:
        with open(posters_file(), encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return []
    return [u for u in data if isinstance(u, str)] if isinstance(data, list) else []


def snapshot_due(now=time.time):
    """A new start-up picture at most once a day, and only on the box."""
    import mc_boot
    if not mc_boot.on_box():
        return False
    try:
        return now() - os.path.getmtime(os.path.join(xbmcvfs.translatePath("special://home"), "media", "splash.png")) > 86400
    except OSError:
        return True


def keep_snapshot():
    """Kodi saves a screenshot of the opening; it becomes the start-up picture (only once it has been written)."""
    home_media = os.path.join(xbmcvfs.translatePath("special://home"), "media")
    tmp = os.path.join(V.PROFILE, "opening-snapshot.png")
    try:
        if os.path.exists(tmp):
            os.remove(tmp)
    except OSError:
        pass
    xbmc.executebuiltin("TakeScreenshot(%s,sync)" % tmp)
    for _ in range(30):
        if os.path.isfile(tmp) and os.path.getsize(tmp) > 10000:
            break
        xbmc.sleep(100)
    else:
        return False
    try:
        if not os.path.isdir(home_media):
            os.makedirs(home_media)
        shutil.move(tmp, os.path.join(home_media, "splash.png"))
        return True
    except OSError:
        return False


class Opening(xbmcgui.WindowXMLDialog):
    @classmethod
    def show(cls):
        w = cls("mediacenter-opening.xml", V.HERE, "Default", "1080i")
        w.doModal()
        del w

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started, self.done = True, threading.Event()
        urls = remembered()
        for i in range(POSTERS):
            if urls:
                self.setProperty("p.%d" % (i + 1), urls[i % len(urls)])
        if V.ADDON.getSetting("opening_sound") != "false":
            sound = os.path.join(V.HERE, "resources", "media", "opening.wav")
            if os.path.isfile(sound):
                xbmc.playSFX(sound, False)
        snap = False  # boot art is deliberate; never replace it with a black GPU screenshot

        def run():
            if self.done.wait(1.5):
                return self.close()
            self.setProperty("boot.loading", "1")
            if not self.done.wait(SNAP_AT if snap else SECONDS - 1.5):
                if snap:
                    keep_snapshot()
                    self.done.wait(SECONDS - SNAP_AT)
            self.close()
        th = threading.Thread(target=run)
        th.daemon = True
        th.start()
        self.thread = th

    def onAction(self, action):
        if action.getId() in BACK + SELECT:
            self.done.set()
            self.close()
