"""Pi Search result rows and their full-screen category views. No work is left on UI threads after close."""
import xbmcgui
import mc_logic as L
import mc_more as more
import mc_pages as pages
import mc_views as V

SPEC = V.experience().get("app", {}).get("presentation", {}).get("searchResults", {})
CATEGORIES = SPEC.get("categories") or (("movies", "Movies"), ("shows", "Shows"), ("games", "Games"), ("channels", "Channels"))
PREVIEW = int(SPEC.get("previewCount") or 5)

def groups(answer):
    """Also understand the previous Worker while a box update and Worker deploy are being coordinated."""
    supplied = {g.get("id"): g for g in answer.get("groups", []) if isinstance(g, dict)}
    if not supplied:
        titles = answer.get("titles") or []
        supplied = {"movies": {"items": [t for t in titles if t.get("type") == "movie"]},
                    "shows": {"items": [t for t in titles if t.get("type") == "series"]},
                    "games": {"items": answer.get("games") or []}, "channels": {"items": answer.get("channels") or []}}
    return [dict(id=key, title=label, items=(supplied.get(key, {}).get("items") or [])[:200]) for key, label in CATEGORIES]

def cards(group, api=None):
    app = more.app()
    out = []
    for t in group["items"]:
        if group["id"] in ("movies", "shows"):
            if not t.get("name") or t.get("type") not in ("movie", "series"):
                continue
            item = dict(t, tmdb=str(t.get("tmdb") or ""))
            if api and item.get("poster") and "/jellyfin/Items/" in item["poster"]:
                item["poster"] = api.kodi_url(item["poster"], cookie=True)
            li = app.title_card(item)
            if not str(t.get("tmdb") or "").isdigit():
                li.setProperty("kind", "searchlibrary")
            li.setProperty("search.provider.logo", t.get("providerLogo") or "")
            if t.get("inLibrary"):
                li.setProperty("plot", "In your connected library" + ("\n" + t["overview"] if t.get("overview") else ""))
        elif group["id"] == "games":
            li = app.game_card(t)
        else:
            li = app.channel_card(t)
            programme = t.get("programme") or t.get("now") or {}
            li.setLabel2(L.now_title(t))
            li.setProperty("meta", programme.get("title") or "Live TV")
            li.setProperty("sub", programme.get("title") or "")
            li.setProperty("search.provider.logo", t.get("logo") or "")
            if t.get("programme"):
                li.setProperty("plot", "Matching programme: " + programme.get("title", "") + "\n" + L.channel_plot(t))
        out.append(li)
    return out

def rows(answer, api=None):
    result = []
    for group in groups(answer):
        items = cards(dict(group, items=group["items"][:PREVIEW]), api)
        if items:
            li = xbmcgui.ListItem(SPEC.get("seeMore") or "See more")
            li.setProperties({"kind": "searchmore", "category": group["id"], "plot": "All matching " + group["title"].lower() + "."})
            items.append(li)
            result.append((group["title"], items))
    return result

class SearchGrid(more.GridPage):
    @classmethod
    def show(cls, api, query, group):
        w = cls("mediacenter-grid.xml", V.HERE, "Default", "1080i")
        w.api, w.query, w.group = api, query, group
        pages.modal(w)
        del w

    def fill(self):
        self.setProperty("button", SPEC.get("back") or "Back to search")
        self.setProperty("heading", self.group["title"])
        self.setProperty("sub", "Results for “%s”" % self.query)
        group = self.group
        more.app().busy(True)
        try:
            answer = self.api.get("/api/roku/search", q=self.query, view="pi", category=group["id"]) or {}
            group = next((g for g in groups(answer) if g["id"] == group["id"]), group)
            # Old Worker fallback can still supply this category.
            if not group["items"]:
                group = self.group
        except more.ERRORS:
            self.setProperty("sub", "Saved results for “%s” — couldn't refresh." % self.query)
        finally:
            more.app().busy(False)
        grid = self.getControl(self.GRID)
        grid.reset()
        items = cards(group, self.api)
        grid.addItems(items)
        if not items:
            self.setProperty("empty", "No matches in this category.")
        self.setFocusId(self.GRID if items else 85)
        more.app().show_details(self, items[0] if items else None)

    def onClick(self, control_id):
        if control_id == self.GRID:
            li = self.getControl(self.GRID).getSelectedItem()
            if li is not None:
                open_result(self.api, li, self.query, [], self)
        elif control_id == self.BUTTON:
            self.close()

def open_result(api, li, query, result_groups, win):
    app = more.app()
    kind = li.getProperty("kind")
    if kind == "searchmore":
        group = next((g for g in result_groups if g["id"] == li.getProperty("category")), None)
        if group:
            return SearchGrid.show(api, query, group)
    elif kind == "searchlibrary":
        app.busy(True)
        try:
            answer = api.get("/api/roku/title", find=li.getLabel(), type=li.getProperty("type")) or {}
            t = L.title_of(answer.get("title"))
        except more.ERRORS:
            t = None
        finally:
            app.busy(False)
        same_name = lambda value: "".join(c for c in str(value).casefold() if c.isalnum())
        same_year = not t or not t.get("year") or not li.getLabel2() or t["year"] == li.getLabel2()
        if t and t["type"] == li.getProperty("type") and same_name(t["name"]) == same_name(li.getLabel()) and same_year:
            return app.TitlePage.open(api, t["type"], t["tmdb"])
        return xbmcgui.Dialog().ok("mediaCENTER", "This library title has no matching catalogue entry yet.")
    else:
        return app.open_item(api, li, win=win)
