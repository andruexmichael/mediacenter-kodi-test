# mediaCENTER for Kodi: Play and Pause, shared by the full-screen player (mc_player.PlayerPage.kodi_paused) and the
# Guide's mini player (mc_app.GuidePage). Kept free of Kodi so it can be tested: Kodi's own calls come in as arguments.
#
# Kodi pauses by itself on the Pause, Play/Pause and Play keys, a moment after the page has seen them, so pausing here
# too would undo it. Only when Kodi did nothing (no pause or resume came within `wait` seconds) does this pause. Play
# only ever resumes. Owner, 2026-11-26: live TV would not pause. If Kodi still isn't paused after a pause was asked for,
# the answer is "refused", so the page can say so and kodi.log records it (the cause needs the box's log).

import time

PAUSE, PLAYPAUSE, PLAY = 12, 229, 68
KEYS = (PAUSE, PLAYPAUSE, PLAY)
SETTLE = 1.0  # seconds Kodi gets to report the pause before it counts as refused


def toggle(watcher, key, wait, paused, closing=lambda: False, sleep=time.sleep, clock=time.time, settle=None):
    """watcher: the Playback's xbmc.Player (toggled_at, pause()); paused(): Kodi's Player.Paused. Returns "paused",
    "playing" or "refused" (a pause was wanted and Kodi stayed playing)."""
    was = bool(paused())
    asked = clock()
    end = asked + wait
    kodi_did = False
    while clock() < end and not closing():
        if watcher is not None and getattr(watcher, "toggled_at", 0) >= asked - wait:
            kodi_did = True
            break
        sleep(0.05)
    if not kodi_did and watcher is not None and not closing() and (key != PLAY or paused()):
        watcher.pause()
        sleep(0.15)
    wanted_pause = key != PLAY and not was
    if wanted_pause:
        stop = clock() + (SETTLE if settle is None else settle)
        while not paused() and clock() < stop and not closing():
            sleep(0.1)
        if not paused():
            return "refused"
    return "paused" if paused() else "playing"
