# mediaCENTER for Kodi: the player, in mediaCENTER's own screen (0.4.5).
#
# Every movie, episode and channel plays here, never through Kodi's own player screens:
#   - a loading screen like the web's TitleLoading (web-v27/js/player.js): the steps with how far along it is, and a
#     rotating line from design/experience.json "loading";
#   - each link is checked before the player opens it (mc_api.link_works / live_plays), links that failed on this box
#     are remembered (mc_versions.FailedLinks) and the next source is tried by itself, as web-v27/js/playvod.js does;
#   - Kodi's "One or more items failed to play" box is closed before it shows; mediaCENTER says what happened and
#     offers what to do next;
#   - controls like the web player and the Roku's PlayerScreen: title and clock at the top, the bar and the buttons at
#     the bottom, Left/Right to skip 10 seconds; Up Next after an episode.
#
# The picture is drawn by a videowindow control in this page (windowed playback), so the page that opened the player
# stays where it was underneath: Back after a film or a channel returns to the same title page or Guide position (owner,
# 2026-11-25: it used to drop to Home). The Guide uses the same Playback for its mini player.
#
# On a box that draws video on its own layer (a Raspberry Pi, "Direct to plane"), Kodi places the picture once, when a
# video opens, from where a shown video control last drew; mc_picture makes sure that is full screen first (0.4.9.2:
# the first video after Kodi started played sound over black).
#
# Progress is saved by service.py as before: PLAYING_KEY says what is playing and where to start.

import json
import os
import threading
import time

try:
    import queue
except ImportError:  # pragma: no cover
    import Queue as queue

import xbmc
import xbmcgui

import mc_logic as L
import mc_versions as MV
import mc_picture as MP
import mc_views as V
import mc_pages as pages
import mc_watching as W
import mc_admin_trace as AT
import mc_live_pause as LP
from mc_api import SignedOut, ServerError

# The web's loading steps (player.js TitleLoading), as (percent, words).
STAGES = [(0, "Finding your title"), (15, "Checking the available links"), (25, "Picking the best source"),
          (40, "Connecting to the stream"), (65, "Buffering the first scenes"), (90, "Starting playback")]
LIVE_STAGES = [(0, "Finding the channel"), (15, "Checking the feed"), (40, "Connecting to the stream"),
               (65, "Buffering"), (90, "Starting playback")]
# How long a link gets to show a picture. 0.4.9.5 (owner, 2026-11-26: "media centers should not be giving up so
# quickly ... we're passing up on playable links"): slow links on a Pi 3 were given up on and then started behind
# "This version didn't start". A link that is only slow is never written down as failed (FailedLinks), and the last one
# is not stopped: if it starts after the message, it plays (LATE_WAIT).
START_WAIT = 120  # seconds the last link to try gets
NEXT_WAIT = 60  # seconds a link gets when there are others behind it
LATE_WAIT = 180  # after "didn't start", how long a last link still opening may take to start and play after all
PICTURE_WAIT = 4  # seconds after the sound starts for a movie's or episode's picture track to show up
# 0.4.9.3 (owner, 2026-11-26: the automatic pick "seemed playable" and then stopped): a movie or episode whose picture
# stands still this long (not paused) in its first VOD_SETTLE seconds gives way to the next source, at the same place.
VOD_STALL = 15
VOD_SETTLE = 120
HUD_SECONDS = 5
SCRUB_HUD_SECONDS = 10  # the controls stay up longer while a time is picked on the timeline
SCRUB_GAP = 0.8  # presses closer together than this count as one run, and the step grows (ScrubStepper)
SCRUB_AUTO = 1.2  # the fast-forward and rewind keys jump to the picked time by themselves this long after the last press
UP_NEXT_SECONDS = 10
CACHE_SECONDS = 600  # versions found for a title are reused for 10 minutes (the versions page and the player share them)

VOD_FAILED = "This version didn't start."
LIVE_FAILED = "This channel isn't playing right now."

# Kodi action ids
LEFT, RIGHT, UP, DOWN, SELECT = 1, 2, 3, 4, 7
BACK = (9, 10, 92, 247)
PAUSE, STOP, NEXT_ITEM, PREV_ITEM, FORWARD, REWIND, PLAYPAUSE, PLAY = 12, 13, 14, 15, 77, 78, 229, 68
MENU_KEYS = (11, 117)  # info, context menu
SCORES_KEY = 117  # on a live channel the menu key opens the scores instead of the controls (0.4.9, mc_scores)

# Control ids in mediacenter-player.xml (kodi/tools/make_windows.py player_window). The controls, left to right
# (owner, 2026-11-26): Play/Pause first, -10 s beside it, no +10 s button (Right still skips 10 s with the controls
# hidden), then Next Episode, Episodes (0.4.9), Audio, Subtitles, Versions.
HUD = 600
B_BACK10, B_PLAYPAUSE, B_NEXT, B_AUDIO, B_SUBS, B_VERSIONS, B_EPISODES = 601, 602, 604, 605, 606, 607, 608
SCRUB, SCRUB_BAR = 610, 611  # the timeline (focus it with Up from the buttons) and the bar that shows the picked time
ERR = 700
E_OTHER, E_RETRY, E_NEXT, E_CLOSE = 701, 702, 703, 704
ASK = 800
A_RESUME, A_START = 801, 802
UPNEXT = 900
U_PLAY, U_CANCEL = 901, 902

HOME_PROPS = ("mc.dock", "mc.full")
FOCUS_TRIES = 20  # Kodi ignores focus on a control that is still hidden: a new layer shows only on the next frame
FOCUS_STEP = 0.05
KODI_PAUSE_WAIT = 0.8  # seconds Kodi gets to pause by itself before the page does (PlayerPage.kodi_paused)
EARLY_KEYS = 0.6  # 0.4.9.6: keys in the player's first moment are presses meant for the Guide that piled up; dropped
# What a player hands on with its picture (PlayerPage.picture), so the full screen opened again from the Guide's mini
# player knows the title, its versions and the next episode.
CARRIED = ("mode", "kind", "tmdb", "season", "episode", "pick", "fresh", "t", "versions", "others", "feeds", "episode_name",
           "channel_id", "channel_name", "alts", "now_title", "eps_cache")


# ---- pure helpers (tested off the box) ---------------------------------------------------------------------------------

class ScrubStepper(object):
    """How far one Left/Right press on the timeline, or one fast-forward/rewind press, moves the picked time: 10 s at
    first, then 30, 60 and 120 s the more presses come in a row. The same rule as Apple TV (tvos/Sources/ScrubStepper.swift)."""

    def __init__(self, now=time.time):
        self.now = now
        self.reset()

    def step(self, forward):
        at = self.now()
        self.streak = self.streak + 1 if at - self.last < SCRUB_GAP else 0
        self.last = at
        size = 10 if self.streak < 2 else 30 if self.streak < 5 else 60 if self.streak < 9 else 120
        return size if forward else -size

    def reset(self):
        self.streak, self.last = 0, -1e9


def clock(seconds):
    t = int(max(0, seconds))
    return "%d:%02d:%02d" % (t // 3600, t // 60 % 60, t % 60) if t >= 3600 else "%02d:%02d" % (t // 60, t % 60)


def stage_text(stages, pct):
    """The step a percentage is at, and every step marked done, now or to come (✓ ● ○ on the screen)."""
    current = 0
    for i, (p, _) in enumerate(stages):
        if pct >= p:
            current = i
    return [(words, "done" if i < current else "now" if i == current else "todo") for i, (_, words) in enumerate(stages)]


MARK = {"done": u"✓", "now": u"●", "todo": u"○"}


def loading_lines(kind):
    lines = ((V.experience().get("loading") or {}).get("live" if kind == "live" else "movie") or {}).get("lines") or []
    return lines or [u"Starting in a moment…"]


def line_seconds():
    try:
        return max(1, int((V.experience().get("loading") or {}).get("lineSeconds") or 2))
    except (TypeError, ValueError):
        return 2


class LineDeck(object):
    """The rotating loading lines in a shuffled order, each shown once before any comes back, and never the same line
    twice in a row (owner, 2026-11-26: on a long load they ran out and repeated)."""

    def __init__(self, lines, shuffle=None):
        import random
        self.lines = list(lines) or [u"Starting in a moment…"]
        self.shuffle = shuffle or random.shuffle
        self.deck, self.last = [], None

    def next(self):
        if not self.deck:
            self.deck = list(self.lines)
            self.shuffle(self.deck)
            if len(self.deck) > 1 and self.deck[0] == self.last:
                self.deck.append(self.deck.pop(0))
        self.last = self.deck.pop(0)
        return self.last


def percent_text(pct, seconds, admin=False):
    """Under the bar: the percent for everyone; the admin also sees the seconds so far (0.4.9.8)."""
    return "%d%% · %ds" % (int(pct), int(seconds)) if admin else "%d%%" % int(pct)


def next_episode(season, episode, episodes_of, seasons):
    """The episode after (season, episode): the next in the season, else the next season's first. episodes_of(n) gives
    that season's episode numbers (aired ones only). Returns (season, episode) or None."""
    eps = sorted(int(n) for n in episodes_of(season) or [])
    later = [n for n in eps if n > int(episode)]
    if later:
        return int(season), later[0]
    for s in sorted(int(x) for x in seasons or []):
        if s > int(season):
            nxt = sorted(int(n) for n in episodes_of(s) or [])
            if nxt:
                return s, nxt[0]
    return None


def number(value):
    """A season or episode number from the server ("2", 2, None) as an int; 0 when it isn't one."""
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def play_target(history, tmdb, seasons):
    """What Play does on a show's page, as on the web (vod.js): the episode left part-way ("Resume S1 E2"), else the one
    after the last one finished ("Play S1 E3"), else the first ("Play S1 E1"). Returns (label, season, episode, resume)."""
    first = (sorted(int(s) for s in seasons or [1]) or [1])[0]
    rows = [h for h in history or [] if str(h.get("seriesId") or "") == "tmdb-%s" % tmdb and h.get("season") is not None]
    if not rows:
        return "Play S%d E1" % first, first, 1, False
    last = max(rows, key=lambda h: (L.when_seconds(h.get("updatedAt")), number(h.get("season")), number(h.get("episode"))))
    s, e = int(last["season"]), int(last["episode"])
    if not last.get("finished") and float(last.get("position") or 0) >= 30:
        return "Resume S%d E%d" % (s, e), s, e, True
    if last.get("finished"):
        return "Play S%d E%d" % (s, e + 1), s, e + 1, False
    return "Play S%d E%d" % (s, e), s, e, False


def split_versions(versions, caps):
    """(versions this box plays, best first; versions it may not play)."""
    ranked, _ = L.rank_versions(versions, caps)
    others = [v for v in versions or [] if L.play_level(v, caps) == "no"]
    return ranked, others


_found = {}


def found_versions(api, kind, tmdb, season=None, episode=None, now=time.time):
    """Every version of a title (mc_play.gather), kept for 10 minutes so the versions page and the player agree."""
    import mc_play
    key = (kind, str(tmdb), str(season or ""), str(episode or ""))
    hit = _found.get(key)
    if hit and now() - hit[0] < CACHE_SECONDS:
        return hit[1], hit[2]
    versions, name = mc_play.gather(api, kind, tmdb, season, episode)
    _found[key] = (now(), versions, name)
    return versions, name


def forget_found():
    _found.clear()


def busy(on):
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)" if on else "Dialog.Close(busydialognocancel)")


def failed_links():
    return MV.FailedLinks(V.PROFILE)


def feed_words(feed):
    """What the admin's checklist calls a link: its quality, size and place (a channel: its feed number), no address."""
    if feed.get("version") is not None:
        return AT.version_words(feed["version"])
    return u"channel %s" % (feed.get("id") or "?")


def check_answer(answer):
    """A link check's answer as (True|False|None, why): link_works gives a pair, live_plays a bare answer."""
    if isinstance(answer, tuple):
        return answer[0], (answer[1] if len(answer) > 1 else "")
    return answer, ""


# ---- Playback: one try after another, with Kodi's own messages kept off the screen ---------------------------------------

def kodi_setting(key):
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Settings.GetSettingValue",
                                                            "params": {"setting": key}})) or "{}")
        return (answer.get("result") or {}).get("value", "?") if isinstance(answer.get("result"), dict) else "?"
    except (ValueError, TypeError, AttributeError):
        return "?"


def describe_picture():
    """One line in kodi.log on how Kodi decodes and draws what is playing (no link, only the formats), so a black
    picture can be told apart from a slow decoder: e.g. "h264 1920x1080, decoder v4l2m2m-h264 (hardware), drm_prime"."""
    def later():
        time.sleep(2)
        info = lambda k: str(xbmc.getInfoLabel(k) or "")
        hw = xbmc.getCondVisibility("Player.Process(videohwdecoder)")
        V.log("picture: %s %sx%s, decoder %s (%s), %s, %s fps" % (
            info("VideoPlayer.VideoCodec") or "?", info("Player.Process(videowidth)") or "?", info("Player.Process(videoheight)") or "?",
            info("Player.Process(videodecoder)") or "?", "hardware" if hw else "software", info("Player.Process(pixformat)") or "?",
            info("Player.Process(videofps)") or "?"))
        V.log("video settings: %s" % ", ".join("%s=%s" % (k.split(".")[-1], kodi_setting(k)) for k in
                                              ("videoplayer.useprimedecoder", "videoplayer.useprimerenderer", "videoplayer.usev4l2m2mdecoder")))
    th = threading.Thread(target=later)
    th.daemon = True
    th.start()


LAST_PLAY = {"by": None}  # the Playback that last asked Kodi to play (every Watcher hears every playback's events)
# 0.4.9.6: asking Kodi to play and stopping the player that is no longer wanted happen one at a time, so an old channel
# stopped off the remote's thread (mc_app.GuidePage.choose) can never stop the new one that started a moment before.
PLAY_LOCK = threading.RLock()
STOPPING = []  # 0.4.9.9: stops still running off the remote's thread (Playback.stop_later), waited for by the next play
STOP_WAIT_MOST = 8.0
SETTLE_MOST = 3.0  # seconds Playback.settle waits at most for Kodi's late words about the link before
SETTLE_QUIET = 0.4  # ... and how long nothing must come before the next link opens


def wait_for_stops(most=STOP_WAIT_MOST):
    """Before a new channel or title opens: the one that was stopped a moment ago (the Guide stops the old channel on
    its own thread) has let go. Two streams at once from one provider account is what providers refuse."""
    end = time.time() + most
    for th in list(STOPPING):
        th.join(max(0.0, end - time.time()))
        if not th.is_alive():
            try:
                STOPPING.remove(th)
            except ValueError:
                pass


def airplay_make_room():
    """The AirPlay speaker (mc_airplay) holds the TV's sound while music plays to it: it is stopped before a video so
    Kodi can play. Never stops playback from starting."""
    if V.ADDON.getSetting("airplay_speaker") != "true":
        return False
    try:
        import mc_airplay
        if mc_airplay.speaker(V.ADDON, log=V.log).make_room():
            V.notify(mc_airplay.SAID["busy"])
            return True
    except Exception as e:
        V.log("AirPlay speaker not checked: %s" % type(e).__name__)
    return False


class Watcher(xbmc.Player):
    def __init__(self, owner):
        super(Watcher, self).__init__()
        self.owner = owner
        self.toggled_at = 0.0  # when Kodi last paused or resumed (PlayerPage.kodi_paused)

    def onPlayBackPaused(self):
        self.toggled_at = time.time()

    def onPlayBackResumed(self):
        self.toggled_at = time.time()

    def onAVStarted(self):
        if self.owner.cancelled and LAST_PLAY.get("by") is self.owner:
            # Back (or Close) came while Kodi was still opening this link: Kodi starts it a moment later all the same,
            # and the sound played on with nothing on screen (owner, 2026-11-26). Stop it now.
            try:
                self.stop()
            except RuntimeError:
                pass
            return
        self.owner.event("started")

    def onPlayBackError(self):
        self.owner.event("error")

    def onPlayBackStopped(self):
        self.owner.event("stopped")

    def onPlayBackEnded(self):
        self.owner.event("ended")


def close_kodi_messages():
    """Kodi's own "failed to play" box and its busy spinner: closed as soon as they appear (the rig showed this keeps
    them off the screen). Returns True when the failure box was there."""
    seen = False
    if xbmc.getCondVisibility("Window.IsActive(okdialog)"):
        xbmc.executebuiltin("Dialog.Close(okdialog,true)")
        seen = True
    if xbmc.getCondVisibility("Window.IsActive(busydialog)"):
        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
    return seen


class Playback(object):
    """Plays a list of feeds in order until one shows a picture. ui gets: stage(pct, words, detail), toast(words),
    started(feed), failed(), ended(), stopped(). Feeds are dicts: url, li, key (for FailedLinks), check (a function
    giving True/False/None, or None to skip the check), entry (what service.py saves, or None), resume."""

    def __init__(self, ui, windowed=True):
        self.ui = ui
        self.windowed = windowed
        self.q = queue.Queue()
        self.player = Watcher(self)
        self.cancelled = False
        self.playing = None  # the feed that is showing
        self.thread = None
        self.remembered = []

    def event(self, name):
        self.q.put(name)

    def drain(self):
        while True:
            try:
                self.q.get_nowait()
            except queue.Empty:
                return

    def start(self, feeds, stages=STAGES):
        if self.cancelled:
            return  # stopped (Back) before its links were known: it must not start afterwards
        self.thread = threading.Thread(target=self.run, args=(list(feeds), stages))
        self.thread.daemon = True
        self.thread.start()

    current = None  # the feed Kodi was last asked to open (hang_up)

    def hang_up(self, feed=None):
        """0.4.9.9: before Kodi is told to stop a link, the relay on this box hangs up on it (mc_relay.DROP). Kodi's stop
        runs on its main thread and waits for the player to let go; a link still opening (or a live feed waiting on its
        next piece) held it for up to a minute (owner's kodi.log, 2026-11-26: "VideoPlayer: waiting for threads to exit"
        from 12:19:23 to 12:20:23), and the screen and the iPhone remote froze with it. Never raises."""
        feed = feed or self.current
        if not feed:
            return 0
        try:
            import mc_relay
            prefix, path = mc_relay.split(feed.get("url"))
            if not prefix:
                return 0
            answer = mc_relay.ask(prefix, mc_relay.DROP, path, timeout=2.0) or {}
            return int(answer.get("dropped") or 0)
        except Exception:
            return 0

    def relay_why(self, feed):
        """What the relay heard from our server for this link (status and the server's reason), or None."""
        try:
            import mc_relay
            prefix, path = mc_relay.split(feed.get("url"))
            return mc_relay.ask(prefix, mc_relay.WHY, path, timeout=2.0) if prefix else None
        except Exception:
            return None

    def settle(self, most=SETTLE_MOST):
        """0.4.9.9: before the next link opens, Kodi's last words about the one before (a late "stopped" or "error")
        are let in and thrown away, so they can't be taken for the next link failing. In the owner's kodi.log every
        other link was marked "did not start" 3 ms after Kodi began opening it, and never really tried."""
        end = time.time() + most
        quiet_since = time.time()
        while time.time() < end:
            try:
                self.q.get(timeout=0.05)
                quiet_since = time.time()
                continue
            except queue.Empty:
                pass
            if self.cancelled:
                return
            if time.time() - quiet_since >= SETTLE_QUIET and not self.player.isPlaying():
                return

    def stop(self):
        """Stop playing and stop trying (Back, Close, leaving the Guide). A link Kodi is still opening is stopped too:
        play() only queues the link, so Watcher.onAVStarted stops it again if it starts after Back."""
        self.cancelled = True
        self.playing = None
        with PLAY_LOCK:
            if LAST_PLAY["by"] not in (None, self):
                return  # another Playback asked Kodi to play after this one: the player is its now
            V.WINDOW.clearProperty(V.PLAYING_KEY)
            self.hang_up()
            try:
                # Always: a link Kodi is still opening isn't "playing" yet, and it would start after Back.
                self.player.stop()
            except RuntimeError:
                pass

    def stop_later(self):
        """stop() on its own thread (0.4.9.6): Kodi's stop waits for the player, and on the remote's thread every press
        made meanwhile piled up and landed at once (owner, 2026-11-26: changing channels in the Guide froze). It stops
        nothing once another Playback has asked Kodi to play (PLAY_LOCK). Returns the thread."""
        self.cancelled = True
        self.playing = None
        th = threading.Thread(target=self.stop)
        th.daemon = True
        th.start()
        STOPPING.append(th)
        return th

    def note(self, key, text, state="now"):
        """A line for the admin's checklist and log (PlayerPage.note); nothing for anyone else (0.4.9.8)."""
        fn = getattr(self.ui, "note", None)
        if fn is not None:
            try:
                fn(key, text, state)
            except Exception:  # the checklist never stops playback
                pass

    def remember(self, feed, why):
        if feed.get("key"):
            failed_links().remember(feed["key"], why)
            self.remembered.append(feed["key"])

    def precheck(self, feeds):
        """Every link's check at once (each takes up to 8 s), so a dead link further down is already known when its
        turn comes and the player goes straight past it. Returns a list of Events, each set once that check is done."""
        done = []
        for feed in feeds:
            ev = threading.Event()
            done.append(ev)
            check = feed.get("check")
            if check is None:
                ev.set()
                continue

            def ask(f=feed, e=ev, c=check):
                try:
                    f["checked"] = c()
                except Exception:
                    f["checked"] = None
                e.set()
            th = threading.Thread(target=ask)
            th.daemon = True
            th.start()
        return done

    def run(self, feeds, stages):
        n = len(feeds)
        wait_for_stops()  # 0.4.9.9: the channel the Guide just left lets go of the provider first
        for i, feed in enumerate(feeds):
            if self.cancelled:
                return
            key, what = "link%d" % (i + 1), u"%s %d of %d (%s)" % ("Feed" if feed.get("version") is None else "Link", i + 1, n, feed_words(feed))
            if feed.get("check") is not None:
                self.ui.stage(stages[1][0], stages[1][1], "%d of %d" % (i + 1, n) if n > 1 else "")
                self.note(key, what + u": checking it answers")
                # 0.4.9.9: one link at a time, just before its turn. All of them at once (0.4.8) opened up to eight
                # requests to the same provider together, and a provider that allows one or two streams per account
                # then refused the link Kodi opened next (the owner's log: 502 on nearly every link).
                done = self.precheck([feed])[0]
                while not done.wait(0.1):
                    if self.cancelled:
                        return
                ok, why = check_answer(feed.get("checked"))
                if ok is False:
                    V.log("link %d of %d does not answer (%s); next" % (i + 1, n, why or "dead"))
                    self.note(key, what + u": doesn't answer (%s), next" % (why or "dead"), "fail")
                    self.remember(feed, why or "dead")
                    continue
            if i:
                self.ui.toast("Trying the next source")
            last = i == n - 1
            wait = START_WAIT if last else NEXT_WAIT
            self.note(key, what + u": opening the stream (up to %ds)" % wait)
            opened = time.time()
            result = self.try_one(feed, stages, wait, stop_on_timeout=not last)
            took = int(time.time() - opened)
            if result == "started":
                self.note(key, what + u": picture after %ds" % took, "done")
            elif result != "cancelled":
                self.note(key, what + u": %s after %ds" % (AT.RESULT_WORDS.get(result, result), took),
                          "now" if result == "timeout" and last else "fail")
            if result == "started":
                if self.watch(feed, more=not last) != "stalled":
                    return
                # It started, then stood still: the next source, from where this one stopped (0.4.9.3). Not written
                # down as failed (0.4.9.5): a source that stalls once on a slow connection plays another time.
                at = feed.get("stalled_at") or 0
                for later in feeds[i + 1:]:
                    if at >= 30 and later.get("entry"):
                        later["resume"] = max(float(later.get("resume") or 0), at - 5)
                lost = getattr(self.ui, "lost_picture", None)
                if lost:
                    lost()
                self.note(key, what + u": %s at %s, next" % (AT.RESULT_WORDS["stalled"], clock(at)), "fail")
                self.ui.toast("This source stalled. Trying the next one")
                continue
            if self.cancelled:
                return
            heard = self.relay_why(feed) if result != "started" else None
            if heard and heard.get("status"):
                said = u"our server answered %s%s" % (heard["status"], (u": " + heard["why"]) if heard.get("why") else "")
                V.log("link %d of %d: %s" % (i + 1, n, said))
                self.note(key + ".why", u"   %s" % said, "fail" if int(heard["status"]) >= 400 and int(heard["status"]) != 504 else "now")
                if int(heard["status"]) == 504 and result == "failed":
                    result = "timeout"  # the relay said "slow": only slow, never written down as failed (0.4.9.5)
            V.log("link %d of %d did not start (%s)" % (i + 1, n, result))
            if result == "timeout":
                self.slow = feed  # only slow: never written down as failed (0.4.9.5)
            else:
                self.remember(feed, {"failed": "couldn't be played", "no picture": "no picture"}.get(result, "temporary"))
        if not self.cancelled:
            self.note("end", u"None of the %d started%s" % (n, ", the last one is still opening" if self.slow is not None else ""), "fail")
            self.ui.failed()
            late = self.late_start()
            if late is not None:
                V.log("the last link started after all; playing it")
                self.watch(late)

    slow = None  # the last link given up on for taking too long, if Kodi may still be opening it

    def late_start(self):
        """After "didn't start": the last link was left opening (try_one, stop_on_timeout=False). If Kodi starts it
        within LATE_WAIT, it is what plays: the message goes and the picture shows. Returns its feed, or None."""
        feed = self.slow
        if feed is None or LAST_PLAY["by"] is not self:
            return None
        end = time.time() + LATE_WAIT
        while time.time() < end and not self.cancelled and LAST_PLAY["by"] is self:
            try:
                e = self.q.get(timeout=0.25)
            except queue.Empty:
                continue
            if e == "started" and not self.cancelled and LAST_PLAY["by"] is self:
                self.playing = feed
                return feed
            if e in ("error", "stopped", "ended"):
                return None
        if LAST_PLAY["by"] is self and not self.cancelled:
            self.stop_quietly()  # nothing came of it: don't let it start later still
        return None

    def try_one(self, feed, stages, wait=START_WAIT, stop_on_timeout=True):
        if self.windowed:
            V.WINDOW.clearProperty(V.PLAYING_KEY)  # the clip mc_picture may play is nothing service.py should save
            MP.prepare(self.player, V.WINDOW, kodi_setting, lambda: MP.clip(V.PROFILE), log=V.log,
                       cancelled=lambda: self.cancelled, listitem=xbmcgui.ListItem())
        airplay_make_room()  # 0.4.9.9: music AirPlayed to the TV lets go of its sound first
        if self.player.isPlaying():
            self.hang_up()
            self.player.stop()
            end = time.time() + 3
            while self.player.isPlaying() and time.time() < end:
                xbmc.sleep(50)
        self.settle()
        self.ui.stage(stages[-3][0], stages[-3][1], "")
        if self.cancelled:
            return "cancelled"
        if feed.get("entry"):
            V.WINDOW.setProperty(V.PLAYING_KEY, json.dumps({"entry": feed["entry"], "resume": feed.get("resume") or 0}))
        else:
            V.WINDOW.clearProperty(V.PLAYING_KEY)
        with PLAY_LOCK:
            if self.cancelled:
                return "cancelled"
            LAST_PLAY["by"] = self
            self.current = feed
            self.player.play(feed["url"], feed["li"], self.windowed)
        began, buffering = time.time(), False
        while time.time() - began < wait:
            if self.cancelled:
                if LAST_PLAY["by"] is self:
                    self.stop_quietly()
                return "cancelled"
            if close_kodi_messages() and not self.player.isPlaying():
                self.settle()  # Kodi's "stopped" for this link comes after its box: not the next link's
                return "failed"
            try:
                e = self.q.get(timeout=0.05)
            except queue.Empty:
                e = None
            if e in ("error", "stopped", "ended") and self.player.isPlaying():
                # Kodi is still opening (or playing) this link: the event is about the one before it (0.4.9.9).
                V.log("an earlier link's \"%s\" came late; ignored" % e)
                e = None
            if e == "started":
                if feed.get("version") is not None and not self.picture_shows():
                    self.stop_quietly()
                    return "no picture"
                self.playing = feed
                return "started"
            if e in ("error", "stopped", "ended"):
                # Stopping before any picture is how Kodi says a link failed (onPlayBackError rarely comes).
                end = time.time() + 1.5
                while time.time() < end:  # its "failed to play" box comes a moment later
                    close_kodi_messages()
                    xbmc.sleep(50)
                return "failed"
            if not buffering and time.time() - began > 2:
                buffering = True
                self.ui.stage(stages[-2][0], stages[-2][1], "")
        if stop_on_timeout:
            self.stop_quietly()  # the next link is tried; Kodi opens one at a time
        return "timeout"

    def picture_shows(self):
        """After the sound starts: whether this link has a picture at all (a file with only a sound track would play
        over black), so the next link is tried instead. The format is not judged here: Kodi on the box decodes what it
        can, in hardware or in software (the owner played these links on his Pi 3 before 0.4.5)."""
        end = time.time() + PICTURE_WAIT
        while time.time() < end and not self.cancelled:
            if xbmc.getCondVisibility("Player.HasVideo") or xbmc.getInfoLabel("VideoPlayer.VideoCodec"):
                return True
            time.sleep(0.1)
        if not self.cancelled:
            V.log("this link has no picture; next")
        return self.cancelled

    def stop_quietly(self):
        """Stop a try without the page hearing about it as the end of playback."""
        self.hang_up()
        try:
            self.player.stop()
        except RuntimeError:
            pass
        end = time.time() + 3
        while self.player.isPlaying() and time.time() < end:
            xbmc.sleep(50)
        self.drain()

    def watch(self, feed, more=False):
        """While it plays. Returns "stalled" when a movie or episode stood still right after it started and there is
        another source to try (more); the page has heard nothing about it then."""
        self.ui.stage(100, "", "")
        self.ui.started(feed)
        describe_picture()
        looked = began = time.time()
        stall = W.StallWatch(seconds=VOD_STALL) if more and feed.get("version") is not None else None
        while not self.cancelled:
            try:
                e = self.q.get(timeout=0.25)
            except queue.Empty:
                close_kodi_messages()
                if time.time() - looked >= 1:  # live TV: a picture standing still too long takes a backup feed (0.4.9)
                    looked = time.time()
                    if self.lost(feed, "stall"):
                        return
                    if stall is not None and time.time() - began < VOD_SETTLE and self.vod_stalled(stall):
                        try:
                            feed["stalled_at"] = float(self.player.getTime() or 0)
                        except RuntimeError:
                            feed["stalled_at"] = 0
                        V.log("this source stood still for %d s right after it started; next" % VOD_STALL)
                        self.playing = None
                        self.stop_quietly()
                        return "stalled"
                continue
            if self.cancelled:
                return
            if e in ("ended", "stopped", "error") and self.lost(feed, "drop"):
                return  # a live channel that dropped mid-stream: its next feed is being tried
            if e == "ended":
                self.playing = None
                return self.ui.ended()
            if e in ("stopped", "error"):
                self.playing = None
                return self.ui.stopped()

    def vod_stalled(self, stall):
        try:
            position = self.player.getTime()
        except RuntimeError:
            position = None
        return stall.update(position, xbmc.getCondVisibility("Player.Paused"))

    def lost(self, feed, why):
        """Asks the player page whether a live channel should go on with a backup feed (mc_watching.PlayerExtras):
        why is "stall" (looked at once a second) or "drop" (Kodi stopped it). The Guide's mini player has no backups."""
        extras = getattr(self.ui, "extras", None)
        if extras is None or self.cancelled:
            return False
        try:
            if why == "stall" and not extras.stalled(self.player):
                return False
            return bool(extras.backup(feed, why))
        except Exception as e:  # never let a check end the playback
            V.log("backup check failed (%s)" % type(e).__name__)
            return False


# ---- feeds for movies, episodes and channels ---------------------------------------------------------------------------

def box_for(t, caps=None, minutes=0):
    """What mc_versions.sort_for_box needs to judge versions for this box: its bitrate limit and the title's length."""
    import mc_play
    caps = caps if caps is not None else mc_play.caps()
    kind = "series" if (t or {}).get("type") == "series" else "movie"
    try:
        minutes = int(minutes or (t or {}).get("runtime") or 0)
    except (TypeError, ValueError):
        minutes = 0
    return {"max_mbps": caps.get("max_mbps") or 0, "minutes": minutes or MV.HEAVY_MINUTES[kind]}


MIMES = {"m3u8": "application/vnd.apple.mpegurl", "mp4": "video/mp4", "m4v": "video/mp4", "mov": "video/quicktime",
         "mkv": "video/x-matroska", "webm": "video/webm", "avi": "video/x-msvideo", "ts": "video/mp2t", "mpd": "application/dash+xml"}


def mime_for(version, url):
    """The type Kodi is told a version's link has (so it never asks the link itself): from the version's container,
    else the link's own ending, else "" (Kodi then reads it from the file as it opens it)."""
    kind = str((version or {}).get("container") or "").lower().lstrip(".")
    if kind not in MIMES:
        path = str(url or "").split("|", 1)[0].split("?", 1)[0].lower()
        kind = path.rsplit(".", 1)[-1] if "." in path.rsplit("/", 1)[-1] else ""
    return MIMES.get(kind, "")


def vod_feeds(api, versions, pick, t, season, episode, episode_name, resume, box=None):
    """The links to try for a movie or episode (mc_versions.feeds), each checked first."""
    failed = failed_links()
    entry = L.history_entry(t, season, episode, episode_name)
    out = []
    for v in MV.feeds(versions, pick, failed.has, box=box):
        url = api.kodi_url(v["url"], cookie=bool(v.get("cookie")))
        li = xbmcgui.ListItem(episode_name or t.get("name", ""), path=url)
        li.setArt({"poster": t.get("poster"), "thumb": t.get("poster"), "fanart": t.get("backdrop")})
        info = {"title": episode_name or t.get("name", ""), "mediatype": "episode" if t.get("type") == "series" else "movie",
                "plot": t.get("overview", "")}
        if t.get("type") == "series":
            info.update(tvshowtitle=t.get("name", ""), season=season, episode=episode)
        V.set_info(li, info)
        mime = mime_for(v, url)
        if mime:
            li.setMimeType(mime)
        # 0.4.9.9: never let Kodi look the link up itself before it plays. It does that on its main thread (the owner's
        # kodi.log: "CCurlFile::Stat" on the screen's thread before each link), so a slow link froze the screen and the
        # iPhone remote while Kodi waited for an answer.
        li.setContentLookup(False)
        out.append({"url": url, "li": li, "key": MV.link_key(v), "version": v, "entry": entry, "resume": resume,
                    "check": (lambda u=url: api.link_works(u))})
    return out


def live_feeds(api, channel_id, name, alts):
    """A channel and its backup feeds (up to five), each checked first, as the web player switches by itself."""
    out = []
    for sid in [str(channel_id)] + [a for a in (alts or []) if str(a).isdigit()][:5]:
        try:
            url = api.live_url(sid)
        except ValueError:
            continue
        li = xbmcgui.ListItem(name or "Live TV", path=url)
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
        V.set_info(li, {"title": name or "Live TV", "mediatype": "video"})
        out.append({"url": url, "li": li, "key": "", "entry": None, "resume": 0, "id": sid,
                    "check": (lambda s=sid: api.live_plays(s))})
    return out


# ---- the player page ---------------------------------------------------------------------------------------------------

class PlayerPage(xbmcgui.WindowXMLDialog):
    """The full-screen player (mediacenter-player.xml). Opened with one of the classmethods below."""

    @classmethod
    def movie(cls, api, kind, tmdb, season=None, episode=None, pick=None, fresh=False, art=None, choose=False, resume=False):
        """art: what the page that opened it already knows ({name, backdrop, ...}), so the loading screen shows the
        title's picture at once instead of after the server answers. choose: Choose a version opens over the loading
        screen once the versions are found (0.4.9.3), and Back there closes the player."""
        w = cls("mediacenter-player.xml", V.HERE, "Default", "1080i")
        w.setup(api, "vod")
        w.kind, w.tmdb, w.season, w.episode, w.pick, w.fresh = kind, str(tmdb), season, episode, pick, fresh
        w.choose = bool(choose) and pick is None
        w.resume_now = bool(resume) and not fresh  # Resume on a Continue Watching card or its hold menu: no question (0.4.9.6)
        w.art = dict(art or {})
        pages.modal(w)
        result = w.result
        del w
        return result

    @classmethod
    def live(cls, api, channel_id, name="", alts=None, now_title="", dock=False, game=None, logo=""):
        """dock: opened from the Guide, so Back hands the channel to its mini player instead of stopping it.
        game: the Sports answer's game this channel is showing, for a loading screen with both teams and their logos.
        logo: the channel's own logo, shown on the loading screen instead of mediaCENTER's."""
        w = cls("mediacenter-player.xml", V.HERE, "Default", "1080i")
        w.setup(api, "live")
        w.channel_id, w.channel_name, w.alts, w.now_title = str(channel_id), name, list(alts or []), now_title
        w.game, w.channel_logo = game, logo or ""
        w.dock_on_back = dock
        pages.modal(w)
        result = w.result
        del w
        return result

    @classmethod
    def attach(cls, api, playback, name="", now_title="", carry=None):
        """Full screen for what the Guide's mini player is showing; Back returns to the Guide with it still playing.
        carry: what the player that first played it knew (picture()), so a movie's controls work again."""
        w = cls("mediacenter-player.xml", V.HERE, "Default", "1080i")
        w.setup(api, (carry or {}).get("mode") or "live")
        for key, value in (carry or {}).items():
            if key in CARRIED:
                setattr(w, key, value)
        w.attached, w.playback = True, playback
        w.channel_name, w.now_title = name, now_title
        pages.modal(w)
        result = w.result
        del w
        return result

    def setup(self, api, mode):
        self.api, self.mode = api, mode
        self.attached = False
        self.dock_on_back = False
        self.kind = None
        self.playback = None
        self.result = "closed"
        self.layer = ""
        self.t = {}
        self.hud_until = 0
        self.scrub_target = None  # the time picked on the timeline, in seconds; None when nothing is being moved
        self.scrub_auto = 0  # counts fast-forward/rewind runs, so only the newest one jumps by itself
        self.stepper = ScrubStepper()
        self.ask_event = threading.Event()
        self.ask_answer = None
        self.upnext_target = None
        self.upnext_cancel = threading.Event()
        self.feeds, self.versions, self.others = [], [], []
        self.ticker = None
        self.closing = False
        self.season = self.episode = None
        self.episode_name = ""
        self.art, self.game, self.channel_logo, self.meta = {}, None, "", None
        self.extras = W.PlayerExtras(self)  # 0.4.9: skip offers, Episodes, Subtitles and Audio, live backups
        self.choose = False  # Choose a version first (PlayerPage.movie)
        self.box = None  # how this box judges versions (box_for)
        self.trace = AT.Trace()  # what the player is really doing; shown only to the admin (0.4.9.8)
        self.admin = False
        self.resume_at = 0  # where this viewing started (seconds), so another version carries on from there

    # -- layers --

    def show_layer(self, name, focus=None):
        self.layer = name
        self.setProperty("layer", name)
        if focus:
            self.focus_on(focus, name)

    def focus_on(self, cid, layer):
        """Put the highlight on a control of the layer just shown. Kodi shows the layer only on its next frame and
        ignores focus on a control that is still hidden, so the highlight stayed on the invisible button (699): the
        controls showed but OK and the arrows did nothing on the box. Tried again for up to a second, until it holds."""
        self.focus_want = cid  # a newer focus_on wins over an older one still retrying
        self.setFocusId(cid)
        if self.getFocusId() == cid:
            return None

        def again():
            for _ in range(FOCUS_TRIES):
                time.sleep(FOCUS_STEP)
                if self.closing or self.layer != layer or getattr(self, "focus_want", cid) != cid:
                    return
                self.setFocusId(cid)
                if self.getFocusId() == cid:
                    return
        th = threading.Thread(target=again)
        th.daemon = True
        th.start()
        return th

    def stage(self, pct, words, detail):
        if pct >= 100:
            self.clearProperty("loading")
            return
        stages = LIVE_STAGES if self.mode == "live" else STAGES
        self.setProperty("loading", "1")
        if self.layer not in ("", "loading"):
            return
        self.show_layer("loading")
        self.setProperty("load.pct", str(int(pct)))
        try:
            self.getControl(510).setPercent(pct)
        except RuntimeError:
            pass
        self.setProperty("load.text", (words + u"…") if words else "")
        self.setProperty("load.detail", (u"%s · %s" % (words, detail)) if detail else "")
        self.setProperty("load.when", percent_text(pct, time.time() - self.began, self.admin))
        for i, (text, state) in enumerate(stage_text(stages, pct), 1):
            self.setProperty("step.%d" % i, u"%s  %s" % (MARK[state], text))
            self.setProperty("step.%d.state" % i, state)
        for i in range(len(stages) + 1, 7):
            self.clearProperty("step.%d" % i)

    def note(self, key, text, state="now"):
        """The admin's checklist and log (mc_admin_trace): written for everyone, drawn only for the admin."""
        self.trace.step(key, text, state)
        if self.admin:
            self.setProperty("adm.check", self.trace.checklist(AT.CORNER[0], AT.CHECK_ROWS))
            self.setProperty("adm.log", self.trace.log_text(*AT.CORNER))
            self.setProperty("adm.check.wide", self.trace.checklist(AT.WIDE[0], AT.WIDE[1] + 1))
            self.setProperty("adm.log.wide", self.trace.log_text(*AT.WIDE))

    def admin_check(self):
        """Off the main thread, before the search starts: whether this account is the admin (0.4.9.8)."""
        try:
            self.admin = AT.is_admin(self.api)
        except Exception:
            self.admin = False
        if self.admin:
            self.setProperty("admin", "1")
        else:
            self.clearProperty("admin")

    def toast(self, words):
        self.setProperty("toast", words)
        stamp = time.time()
        self.toast_at = stamp

        def clear():
            if getattr(self, "toast_at", 0) == stamp:
                self.clearProperty("toast")
        timer = threading.Timer(3.5, clear)
        timer.daemon = True
        timer.start()

    def started(self, feed):
        self.clearProperty("loading")
        self.show_layer("")
        self.setProperty("playing", "1")
        self.show_hud()
        self.extras.started(feed)

    def failed(self):
        self.clearProperty("loading")
        self.clearProperty("playing")
        live = self.mode == "live"
        self.setProperty("err.title", LIVE_FAILED if live else VOD_FAILED)
        self.setProperty("err.reason", "None of its feeds answered. Try again in a few minutes, or pick another channel." if live else
                         "mediaCENTER tried %d source%s for this title and none of them started. Another version may work, "
                         "or try again in a few minutes." % (len(self.feeds), "" if len(self.feeds) == 1 else "s"))
        if not live and self.playback is not None and self.playback.slow is not None:
            self.setProperty("err.reason", self.getProperty("err.reason") + "\n\nThe last one is still opening. If it starts, it plays here.")
        self.setProperty("err.other", "" if live or not self.versions else "1")
        self.show_layer("error", E_OTHER if self.getProperty("err.other") else E_RETRY)

    def ended(self):
        self.clearProperty("playing")
        if self.mode == "vod" and self.kind == "series" and not self.extras.tracker.held:
            # (Cancel on the Next Episode countdown means no switch by itself, as on the web: the episode just ends.)
            nxt = self.find_next()
            if nxt:
                return self.up_next(nxt)
        self.finish("ended")

    def stopped(self):
        self.clearProperty("playing")
        self.finish("stopped")

    def finish(self, why):
        self.result = why
        self.closing = True
        self.close()

    # -- opening --

    def onInit(self):
        if getattr(self, "started_once", False):
            return
        self.started_once = True
        self.began = self.opened_at = time.time()
        for k in HOME_PROPS:
            V.WINDOW.clearProperty(k)
        V.WINDOW.setProperty("mc.full", "1")
        self.setProperty("mode", self.mode)
        # The Homebridge remote (homebridge/homebridge-mediacenter-tv) reads this to switch to its playback buttons.
        self.setProperty("heading", "Player")
        self.lines = LineDeck(loading_lines(self.mode))
        self.setProperty("load.line", self.lines.next())
        if self.attached:
            self.playback.ui = self
            self.setProperty("title", self.channel_name)
            self.setProperty("sub", self.now_title)
            if self.mode == "live":
                self.setProperty("live", "1")
            elif self.kind == "series":
                self.setProperty("series", "1")
            if self.playback.playing is None:  # docked while it was still starting: the loading screen until it shows
                self.setProperty("load.title", self.channel_name)
                self.setProperty("load.sub", self.now_title or ("Live TV" if self.mode == "live" else ""))
                self.show_layer("loading")
                self.stage(LIVE_STAGES[2][0] if self.mode == "live" else STAGES[3][0],
                           LIVE_STAGES[2][1] if self.mode == "live" else STAGES[3][1], "")
            else:
                self.setProperty("playing", "1")
                self.show_layer("")
                self.show_hud()
                self.extras.started(self.playback.playing)
        else:
            self.playback = Playback(self)
            self.dress()
            self.show_layer("loading")
            self.stage(0, (LIVE_STAGES if self.mode == "live" else STAGES)[0][1], "")
            self.worker = threading.Thread(target=self.prepare_live if self.mode == "live" else self.prepare_vod)
            self.worker.daemon = True
            self.worker.start()
        self.ticker = threading.Thread(target=self.tick)
        self.ticker.daemon = True
        self.ticker.start()

    def tick(self):
        """Once a second: the rotating loading line, the time on the loading screen, and hiding the controls."""
        k = 0
        every = line_seconds()
        while not self.closing:
            time.sleep(1)
            k += 1
            if self.getProperty("loading"):
                if k % every == 0:
                    self.setProperty("load.line", self.lines.next())
                self.setProperty("load.when", percent_text(self.getProperty("load.pct") or 0, time.time() - self.began, self.admin))
            if self.layer == "hud" and time.time() > self.hud_until:
                self.hide_hud()
            if self.mode == "live" and self.getProperty("playing"):
                self.paused_shown()  # the iPhone remote pauses through Kodi itself: the page only sees the result
            try:
                self.extras.tick()  # Skip Intro, Skip Credits, the Next Episode countdown
            except Exception as e:  # never stop the ticker
                V.log("offers: %s" % type(e).__name__)

    # -- what the loading screen shows: the title's own picture, or the two teams --

    def dress(self):
        """Before anything is asked of the server: what the page that opened the player already knew. A movie or episode
        shows its backdrop (the same TMDB picture as its title page, so Kodi has it cached) and name; a game both teams
        with their ESPN logos; a channel its own logo. The title's logo and facts follow from /meta/title, off the main
        thread. Nothing here is required: a missing picture leaves the plain loading screen."""
        if self.mode == "live":
            self.setProperty("load.title", self.channel_name)
            self.setProperty("load.sub", self.now_title or "Live TV")
            if self.channel_logo.startswith(("https://", "http://", L.SAMPLE_ART)):
                self.setProperty("load.chlogo", self.channel_logo)
            g = L.game_loading(self.game, self.channel_name) if self.game else None
            if g:
                self.setProperty("load.game", "1")
                self.setProperty("load.gline", g["line"])
                self.setProperty("load.middle", g["middle"])
                for side in ("away", "home"):
                    for key, value in g[side].items():
                        self.setProperty("load.%s.%s" % (side, key), value)
            return
        art = self.art or {}
        if art.get("backdrop"):
            self.setProperty("load.fanart", art["backdrop"])
        if art.get("name"):
            self.setProperty("load.title", art["name"])
        if art.get("logo"):
            self.setProperty("load.logo", art["logo"])
        th = threading.Thread(target=self.dress_vod)
        th.daemon = True
        th.start()

    def dress_vod(self):
        """The title's logo (TMDB, drawn in place of its name, as the web's TitleLoading does) and its facts line."""
        try:
            m = self.api.get("/meta/title", type=self.kind, tmdb=self.tmdb) or {}
        except (ServerError, SignedOut, OSError, ValueError):
            return
        if self.closing or not isinstance(m, dict):
            return
        logo = L.picture(m.get("logo"), "w500")
        if logo and not self.getProperty("load.logo"):
            self.setProperty("load.logo", logo)
        if not self.getProperty("load.fanart"):
            back = L.picture(m.get("backdrop") or m.get("card"), "w1280")
            if back:
                self.setProperty("load.fanart", back)
        self.meta = m
        self.setProperty("load.facts", L.loading_facts(self.t or self.art or {}, m))

    def prepare_live(self):
        self.setProperty("live", "1")
        self.setProperty("title", self.channel_name)
        self.setProperty("sub", self.now_title)
        self.admin_check()
        playback = self.playback
        self.note("title", u"Channel: %s (%s)" % (self.channel_name or "?", self.channel_id), "done")
        self.note("feeds", u"Finding its feeds")
        try:
            self.feeds = live_feeds(self.api, self.channel_id, self.channel_name, self.alts)
        except SignedOut:
            self.note("feeds", u"Signed out", "fail")
            return self.signed_out() if playback.ui is self else playback.ui.failed()
        if playback.cancelled:
            return  # Back while the feeds were looked up
        if not self.feeds:
            self.note("feeds", u"No feed for this channel", "fail")
            return playback.ui.failed()  # docked in the Guide by then: its mini player says so
        self.note("feeds", u"%d feed%s: the channel and %d backup%s" % (len(self.feeds), "" if len(self.feeds) == 1 else "s",
                                                                       len(self.feeds) - 1, "" if len(self.feeds) == 2 else "s"), "done")
        if len(self.feeds) == 1:
            self.feeds[0]["check"] = None  # one feed: the player tries it straight away
        playback.start(self.feeds, LIVE_STAGES)

    def prepare_vod(self):
        import mc_play
        kind, tmdb = self.kind, self.tmdb
        self.admin_check()
        if self.trace.rows:
            self.trace.restart()  # the next episode: a new checklist
        what = u"%s S%s E%s" % ("Episode", self.season, self.episode) if kind == "series" else u"Movie"
        self.note("title", u"%s: asking the server about it" % what)
        try:
            info = self.api.get("/api/roku/title", type=kind, tmdb=tmdb) or {}
            t = L.title_of(dict(info.get("title") or {}, type=kind, tmdb=tmdb)) or {"tmdb": tmdb, "type": kind, "name": "", "poster": ""}
            self.t = t
            if t.get("backdrop"):
                self.setProperty("load.fanart", t["backdrop"])
            if t.get("name"):
                self.setProperty("load.title", t["name"])
            self.setProperty("load.facts", L.loading_facts(t, self.meta))
            self.about_title(t)
            if kind == "series":
                self.episode_name = self.episode_title(self.season, self.episode)
                self.setProperty("load.sub", u"Season %s · Episode %s" % (self.season, self.episode) +
                                 (u" · " + self.episode_name if self.episode_name else ""))
            self.note("title", u"%s: %s" % (what, t.get("name") or tmdb), "done")
            self.stage(STAGES[1][0], STAGES[1][1], "")
            self.note("versions", u"Looking for versions: the server and your add-ons")
            asked = time.time()
            versions, name = found_versions(self.api, kind, tmdb, self.season, self.episode)
            self.note("versions", u"%d version%s found in %ds%s" % (len(versions), "" if len(versions) == 1 else "s", int(time.time() - asked),
                                                                   (": " + AT.where_words(versions)) if versions else ""),
                      "done" if versions else "fail")
        except SignedOut:
            self.note("versions", u"Signed out", "fail")
            return self.signed_out()
        except (ServerError, OSError) as e:
            V.log("play: versions not found (%s)" % type(e).__name__)
            self.note("versions", u"The server didn't answer (%s)" % type(e).__name__, "fail")
            versions, name = [], ""
        if self.closing:
            return
        if not t.get("name"):
            t["name"] = name or "mediaCENTER"
            self.setProperty("load.title", t["name"])
        self.versions, self.others = split_versions(versions, mc_play.caps())
        if not self.versions and self.others:
            # Only versions above what this box is set to look for (4K, AV1): try them anyway, the lightest first,
            # rather than saying no (owner, 2026-11-26: "if it can do 4K, then it should do 4K").
            self.versions = sorted(self.others, key=lambda v: L.RES_ORDER.get(v.get("res") or "", 2))
            self.others = []
            V.log("play: only bigger versions found; trying them")
        V.log("play %s: %d versions, %d play here" % (kind, len(versions), len(self.versions)))
        if versions:
            self.note("box", u"%d play on this box%s" % (len(self.versions), (u", %d need a stronger one" % len(self.others)) if self.others else ""),
                      "done" if self.versions else "fail")
        self.box = box_for(t, minutes=self.episode_minutes())
        self.set_titles()
        if not self.versions:
            self.setProperty("err.title", "No versions for this title yet." if not versions else "This title doesn't play on this box yet.")
            self.setProperty("err.reason", "Try again later: new versions are found all the time." if not versions else
                             "%d version%s need a stronger box than this one." % (len(self.others), "" if len(self.others) == 1 else "s"))
            self.setProperty("err.other", "")
            self.clearProperty("loading")
            return self.show_layer("error", E_CLOSE)
        if self.choose and self.pick is None:
            # Choose a version (the web's link sheet): its first row is the automatic pick; Back closes the player.
            pick = self.choose_version()
            if self.closing:
                return
            if pick is None:
                return self.finish("closed")
            self.pick = pick
        resume = 0 if self.fresh else self.ask_resume(ask=not getattr(self, "resume_now", False))
        if resume is None or self.closing:
            return
        self.resume_at = resume
        self.note("resume", u"Starts at %s" % L.clock_text(resume) if resume else u"Starts from the beginning", "done")
        self.stage(STAGES[2][0], STAGES[2][1], "")
        self.feeds = vod_feeds(self.api, self.versions, self.pick, t, self.season, self.episode, self.episode_name, resume, box=self.box)
        if self.closing:
            return
        self.note_pick()
        self.playback.start(self.feeds, STAGES)

    def note_pick(self):
        """The admin's checklist: what was picked first, how many links stand behind it, and the ones left out."""
        if not self.feeds:
            return
        gone = len([v for v in self.versions if failed_links().has(MV.link_key(v))])
        first = self.feeds[0].get("version")
        self.note("pick", u"%s: %s" % ("Your pick" if self.pick is not None else "Best match", AT.version_words(first)), "done")
        self.note("queue", u"%d link%s to try in order%s" % (len(self.feeds), "" if len(self.feeds) == 1 else "s",
                                                           (u", %d left out: failed here lately" % gone) if gone else ""), "done")

    def episode_minutes(self):
        """An episode's length, from the episode list episode_title read (0 when it isn't known)."""
        if self.kind != "series":
            return 0
        eps = getattr(self, "eps_cache", {}).get(number(self.season)) or []
        e = next((x for x in eps if number(x.get("n")) == number(self.episode)), None) or {}
        return number(e.get("runtime"))

    def choose_version(self):
        """Choose a version over the loading screen. Returns the version, or None for Back."""
        import mc_versions_page as VP
        self.stage(STAGES[2][0], STAGES[2][1], "")
        try:
            return VP.VersionsPage.choose(self.versions, self.others, title=self.t.get("name", ""),
                                          subtitle=self.getProperty("sub") if self.kind == "series" else "", box=self.box)
        except RuntimeError as e:  # never leave the player stuck on the loading screen
            V.log("versions page didn't open (%s); playing the best match" % type(e).__name__)
            return self.versions[0] if self.versions else None

    def lost_picture(self):
        """Playback moved on from a source that stalled after it started: the loading screen again until the next shows."""
        self.clearProperty("playing")
        self.setProperty("loading", "1")
        self.show_layer("loading")

    def about_title(self, t):
        """What the loading screen adds once the server has described the title: its poster and what it's about."""
        self.setProperty("load.poster", t.get("poster") or "")
        self.setProperty("load.plot", t.get("overview") or "")

    def episode_title(self, season, episode):
        try:
            eps = (self.api.get("/api/roku/episodes", tmdb=self.tmdb, season=season) or {}).get("episodes") or []
        except (ServerError, SignedOut, OSError):
            return ""
        self.eps_cache = getattr(self, "eps_cache", {})
        self.eps_cache[int(season)] = eps
        return next((e.get("name", "") for e in eps if int(e.get("n") or 0) == int(episode)), "")

    def set_titles(self):
        t = self.t
        if self.kind == "series":
            self.setProperty("title", t.get("name", ""))
            self.setProperty("sub", u"S%s · E%s%s" % (self.season, self.episode, (u" · " + self.episode_name) if self.episode_name else ""))
            self.setProperty("series", "1")
        else:
            self.setProperty("title", t.get("name", ""))
            self.setProperty("sub", L.title_line(t))
            self.clearProperty("series")

    def ask_resume(self, ask=True):
        """Resume or start over, asked in mediaCENTER's own screen. Returns seconds, or None when Back was pressed.
        ask=False: resume without asking (a Continue Watching card, 0.4.9.6)."""
        try:
            hist = (self.api.get("/api/history", limit=300) or {}).get("items") or []
        except (ServerError, SignedOut, OSError):
            return 0
        item_id = L.history_key(self.kind, self.tmdb, self.season, self.episode)
        row = next((h for h in hist if h.get("itemId") == item_id), None)
        if not row or row.get("finished") or float(row.get("position") or 0) < 30:
            return 0
        pos = float(row["position"])
        if not ask:
            return pos
        self.note("resume", u"Asking: resume at %s or start over" % L.clock_text(pos))
        self.setProperty("ask.resume", "Resume from %s" % L.clock_text(pos))
        self.ask_event.clear()
        self.clearProperty("loading")
        self.show_layer("ask", A_RESUME)
        self.ask_event.wait()
        if self.ask_answer is None:
            return None
        self.show_layer("loading")
        self.setProperty("loading", "1")
        return pos if self.ask_answer == "resume" else 0

    def signed_out(self):
        self.clearProperty("loading")
        self.setProperty("err.title", "Your session ended.")
        self.setProperty("err.reason", "Sign in again from Settings, then play this again.")
        self.setProperty("err.other", "")
        self.show_layer("error", E_CLOSE)

    # -- Up Next --

    def find_next(self):
        try:
            seasons = (self.t or {}).get("seasonList") or []
            if not seasons:
                info = self.api.get("/api/roku/title", type="series", tmdb=self.tmdb) or {}
                seasons = (info.get("title") or {}).get("seasonList") or [self.season]
            cache = getattr(self, "eps_cache", {})

            def numbers(s):
                if int(s) not in cache:
                    cache[int(s)] = (self.api.get("/api/roku/episodes", tmdb=self.tmdb, season=s) or {}).get("episodes") or []
                return [e.get("n") for e in cache[int(s)] if e.get("n")]
            self.eps_cache = cache
            return next_episode(self.season, self.episode, numbers, seasons)
        except (ServerError, SignedOut, OSError, ValueError):
            return None

    def up_next(self, target):
        s, e = target
        name = next((x.get("name", "") for x in getattr(self, "eps_cache", {}).get(int(s), []) if int(x.get("n") or 0) == e), "")
        self.upnext_target = target
        self.setProperty("upnext.title", u"S%d · E%d%s" % (s, e, (u" · " + name) if name else ""))
        self.setProperty("upnext.show", self.t.get("name", ""))
        self.setProperty("upnext.fanart", self.t.get("backdrop") or "")
        self.upnext_cancel.clear()
        self.show_layer("upnext", U_PLAY)

        def count():
            for left in range(UP_NEXT_SECONDS, 0, -1):
                if self.upnext_cancel.is_set() or self.closing:
                    return
                self.setProperty("upnext.count", "UP NEXT · %d" % left)
                time.sleep(1)
            if not self.upnext_cancel.is_set() and not self.closing:
                self.play_next()
        th = threading.Thread(target=count)
        th.daemon = True
        th.start()

    def play_next(self, target=None, choose=False):
        """Next Episode (the button, the remote's next key, Up Next). Finding it asks the server, so a press with no
        Up Next showing looks it up away from Kodi's button thread and the button answers at once. The next episode
        plays its best match, as on the web; choose (an episode picked in the Episodes panel) opens Choose a version."""
        target = target or self.upnext_target
        if not target:
            def find():
                found = self.find_next()
                if self.closing:
                    return
                if not found:
                    return V.notify("This is the last episode.")
                self.play_next(found)
            th = threading.Thread(target=find)
            th.daemon = True
            th.start()
            return th
        self.upnext_cancel.set()
        if self.playback:
            self.playback.stop()
        self.clearProperty("playing")
        self.clearProperty("offer")
        self.season, self.episode = target
        self.pick, self.fresh = None, True
        self.choose = bool(choose)
        self.playback = Playback(self)
        self.began = time.time()
        self.show_layer("loading")
        self.setProperty("loading", "1")
        self.worker = threading.Thread(target=self.prepare_vod)
        self.worker.daemon = True
        self.worker.start()

    # -- the controls --

    def show_hud(self, seconds=HUD_SECONDS):
        self.hud_until = time.time() + seconds
        if self.layer != "hud":
            self.setProperty("pp", "Play" if xbmc.getCondVisibility("Player.Paused") else "Pause")
            self.show_layer("hud", B_PLAYPAUSE)

    def hide_hud(self):
        self.scrub_cancel()
        if self.layer == "hud":
            self.show_layer("")
            self.setFocusId(HUD + 99)  # an invisible button, so OK on a hidden control does nothing

    def seek(self, seconds):
        p = self.playback.player if self.playback else None
        if not p or not p.isPlaying() or self.mode == "live":
            return
        try:
            p.seekTime(max(0, p.getTime() + seconds))
        except RuntimeError:
            pass
        self.show_hud()

    def scrub_by(self, seconds, auto=False):
        """Move the picked time on the timeline by seconds; the picture keeps playing until OK (scrub_jump). auto: the
        fast-forward and rewind keys, which jump by themselves SCRUB_AUTO seconds after the last press. Live TV has no
        timeline, so nothing moves there."""
        p = self.playback.player if self.playback else None
        if not p or self.mode == "live":
            return False
        try:
            if not p.isPlaying():
                return False
            now, length = p.getTime(), p.getTotalTime()
        except RuntimeError:
            return False
        if length <= 0:
            return False  # a stream with no known length: no timeline to move along
        start = now if self.scrub_target is None else self.scrub_target
        target = min(max(0, start + seconds), max(0, length - 1))
        self.scrub_target = target
        delta = int(round(target - now))
        self.setProperty("scrub", "1")
        self.setProperty("scrub.time", clock(target))
        self.setProperty("scrub.left", "-" + clock(length - target))
        self.setProperty("scrub.delta", ("+" if delta >= 0 else u"\u2212") + clock(abs(delta)))
        self.setProperty("scrub.hint", "Jumping there" if auto else "OK to jump, Back to cancel")
        try:
            self.getControl(SCRUB_BAR).setPercent(100.0 * target / length)
        except (RuntimeError, AttributeError):
            pass
        if self.layer != "hud":
            self.show_hud(SCRUB_HUD_SECONDS)
        self.hud_until = time.time() + SCRUB_HUD_SECONDS
        if self.getFocusId() != SCRUB:
            self.focus_on(SCRUB, "hud")
        if auto:
            self.scrub_auto += 1
            run = self.scrub_auto
            th = threading.Thread(target=self.scrub_later, args=(run,))
            th.daemon = True
            th.start()
        return True

    def scrub_later(self, run):
        time.sleep(SCRUB_AUTO)
        if run == self.scrub_auto and not self.closing and self.scrub_target is not None:
            self.scrub_jump()

    def scrub_jump(self):
        """OK on the timeline (or the keys' own pause): play from the picked time."""
        target = self.scrub_target
        self.scrub_cancel()
        p = self.playback.player if self.playback else None
        if target is None or not p:
            return
        try:
            p.seekTime(target)
        except RuntimeError:
            pass
        self.show_hud()

    def scrub_cancel(self):
        if self.scrub_target is None and not self.getProperty("scrub"):
            return
        self.scrub_target = None
        self.scrub_auto += 1  # a waiting automatic jump no longer fires
        self.stepper.reset()
        for key in ("scrub", "scrub.time", "scrub.left", "scrub.delta", "scrub.hint"):
            self.clearProperty(key)

    def toggle_pause(self):
        """The Play/Pause button on the controls (OK on it)."""
        was = xbmc.getCondVisibility("Player.Paused")
        if self.playback:
            self.playback.player.pause()
        xbmc.sleep(150)
        if self.mode == "live" and not was:
            end = time.time() + LP.SETTLE
            while not xbmc.getCondVisibility("Player.Paused") and time.time() < end and not self.closing:
                xbmc.sleep(100)
            if not xbmc.getCondVisibility("Player.Paused"):
                V.log("live pause refused")
                V.notify(LP.REFUSED)
        self.paused_shown()
        self.show_hud()

    def kodi_paused(self, a):
        """The Pause, Play/Pause and Play keys (the remotes, the controller): Kodi pauses on these by itself, after this
        page has seen them, so pausing here too undid it. Only when Kodi did nothing (no pause or resume came within a
        moment) does the page pause; Play only ever resumes (mc_live_pause.toggle). Then the button's label follows.
        0.4.9.6, live TV (owner, 2026-11-26: Play/Pause did nothing on a channel): "Paused" with the time shows while it
        is paused; if Kodi won't pause the channel, the page says so and kodi.log records it."""
        player = self.playback.player if self.playback else None

        def check():
            state = LP.toggle(player, a, KODI_PAUSE_WAIT, lambda: xbmc.getCondVisibility("Player.Paused"),
                              closing=lambda: self.closing)
            if self.closing:
                return
            if state == "refused" and self.mode == "live":
                V.log("live pause refused")
                V.notify(LP.REFUSED)
            self.paused_shown(state)
            self.show_hud()
        th = threading.Thread(target=check)
        th.daemon = True
        th.start()
        return th

    def paused_shown(self, state=None):
        """The button's label and, on live TV, "Paused · 9:41 PM" while paused (mc_live_pause.Hold remembers when)."""
        paused = xbmc.getCondVisibility("Player.Paused") if state in (None, "refused") else state == "paused"
        self.setProperty("pp", "Play" if paused else "Pause")
        hold = self.hold()
        hold.follow("paused" if paused else "playing")
        if paused and self.mode == "live":
            self.setProperty("paused.note", LP.paused_note(hold.paused_at, L.clock_s))
        else:
            self.clearProperty("paused.note")

    def hold(self):
        h = getattr(self, "held", None)
        if h is None:
            h = self.held = LP.Hold()
        return h

    def back_to_live(self, feeds):
        """The channel couldn't hold the pause (it dropped or stood still while paused, or right after Play): the same
        channel again from now, with "Back to live" (mc_watching.PlayerExtras.backup asks)."""
        V.log("live channel couldn't hold the pause; back to live")
        self.hold().reset()
        self.clearProperty("paused.note")
        self.retry_with(feeds, LP.BACK_TO_LIVE)

    def normal_speed(self):
        """Fast-forward and rewind keys: Kodi also changes the play speed on these; the page skips instead, so the
        speed goes back to normal."""
        def check():
            time.sleep(0.3)
            if not self.closing and str(xbmc.getInfoLabel("Player.PlaySpeed") or "1").strip() not in ("1", "1.0", "1.00", ""):
                xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Player.SetSpeed", "params": {"playerid": 1, "speed": 1}}))
        th = threading.Thread(target=check)
        th.daemon = True
        th.start()
        return th

    def choose_stream(self, audio):
        p = self.playback.player if self.playback else None
        if not p or not p.isPlaying():
            return
        try:
            names = p.getAvailableAudioStreams() if audio else p.getAvailableSubtitleStreams()
        except RuntimeError:
            names = []
        names = [n or "Track %d" % (i + 1) for i, n in enumerate(names or [])]
        if audio:
            if not names:
                return V.notify("This version has one sound track.")
            i = xbmcgui.Dialog().select("Audio", names)
            if i >= 0:
                p.setAudioStream(i)
        else:
            if not names:
                return V.notify("This version has no subtitles.")
            i = xbmcgui.Dialog().select("Subtitles", ["Off"] + names)
            if i == 0:
                p.showSubtitles(False)
            elif i > 0:
                p.setSubtitleStream(i - 1)
                p.showSubtitles(True)
        self.show_hud()

    def other_version(self):
        """Choose another version: the versions page, then the player starts again with that one first."""
        if self.mode != "vod" or not self.versions:
            return
        import mc_versions_page as VP
        pick = VP.VersionsPage.choose(self.versions, self.others, title=self.t.get("name", ""),
                                      subtitle=self.getProperty("sub") if self.kind == "series" else "", box=self.box)
        if pick is None:
            return self.show_hud() if self.getProperty("playing") else None
        at = self.carry_on_at()
        if self.playback:
            self.playback.stop()
        self.pick = pick
        self.playback = Playback(self)
        self.began = time.time()
        self.trace.restart()
        self.note("resume", u"Another version, carrying on at %s" % L.clock_text(at) if at else u"Another version, from the beginning", "done")
        self.show_layer("loading")
        self.setProperty("loading", "1")
        self.feeds = vod_feeds(self.api, self.versions, pick, self.t, self.season, self.episode, self.episode_name, at, box=self.box)
        self.note_pick()
        self.playback.start(self.feeds, STAGES)

    def carry_on_at(self):
        """Where another version starts (0.4.9.8, owner: switching a source asked again, or started over): where the
        picture is now, else where this viewing started. Never asked again."""
        at = 0.0
        if self.playback is not None and self.playback.playing is not None:
            try:
                at = float(self.playback.player.getTime() or 0)
            except (RuntimeError, AttributeError, TypeError, ValueError):
                at = 0.0
        if at < 30:
            at = float(self.resume_at or 0)
        return max(0.0, at - 5) if at >= 30 else 0

    def retry(self, skip_first=False):
        """Retry: the same sources again, checked again. Try the next source: the first one goes to the back."""
        if self.playback:
            self.playback.cancelled = True  # a last link still opening from the try before must not take over
        self.playback = Playback(self)
        self.began = time.time()
        self.trace.restart()
        self.show_layer("loading")
        self.setProperty("loading", "1")
        feeds = self.feeds[1:] + self.feeds[:1] if skip_first else self.feeds
        self.playback.start(feeds, LIVE_STAGES if self.mode == "live" else STAGES)

    def retry_with(self, feeds, words):
        """A live channel's backup feeds, after the one showing dropped or stalled (mc_watching.PlayerExtras.backup).
        self.feeds keeps every feed, so a later drop goes on to the one after."""
        old = self.playback
        if old:
            old.stop()
        self.toast(words)
        self.clearProperty("playing")
        self.playback = Playback(self)
        self.began = time.time()
        self.show_layer("loading")
        self.setProperty("loading", "1")
        self.playback.start(feeds, LIVE_STAGES)

    def leave(self):
        """Back with nothing on screen: stop and go back where the player was opened from (from the Guide, what is
        playing carries on in its mini player: handed over through mc_pages)."""
        self.closing = True
        self.upnext_cancel.set()
        self.ask_answer = None
        self.ask_event.set()
        if (self.attached or self.dock_on_back) and self.dockable():
            pages.hand_over(**self.picture())
            self.result = "docked"
        else:
            if self.playback:
                self.playback.stop()
            self.result = "stopped"
        self.close()

    def dockable(self):
        """Back from a Guide channel puts it in the Guide's mini player (owner's choice), also while it is still starting:
        it was stopped then, and a link Kodi had already been given could start a moment later with sound and no
        picture anywhere. Not after it failed (the error screen) or once stopped."""
        pb = self.playback
        if pb is None or pb.cancelled:
            return False
        return pb.playing is not None or self.layer == "loading"

    def goto_close(self):
        """The iPhone remote's TV button (mc_pages.go): what is playing goes to the Guide's mini player; anything still
        loading stops."""
        if self.playback is not None and self.playback.playing is not None and self.layer != "error":
            self.closing = True
            self.upnext_cancel.set()
            self.ask_answer = None
            self.ask_event.set()
            pages.hand_over(**self.picture())
            self.result = "docked"
            return self.close()
        self.leave()

    def picture(self):
        """What the Guide's mini player needs to carry on with this picture, and to bring it back full screen."""
        live = self.mode == "live"
        return {"playback": self.playback, "name": self.getProperty("title") or getattr(self, "channel_name", "") or "",
                "sub": self.getProperty("sub") or getattr(self, "now_title", "") or "", "live": live,
                "channel": getattr(self, "channel_id", None) if live else None,
                "carry": dict((k, getattr(self, k)) for k in CARRIED if hasattr(self, k))}

    def onClick(self, cid):
        if self.extras.on_click(cid):
            return
        if cid == SCRUB:
            return self.scrub_jump() if self.scrub_target is not None else self.toggle_pause()
        if cid == B_BACK10:
            return self.seek(-10)
        if cid == B_PLAYPAUSE:
            return self.toggle_pause()
        if cid == B_NEXT:
            return self.play_next()
        if cid in (B_AUDIO, B_SUBS):
            return self.choose_stream(cid == B_AUDIO)
        if cid in (B_VERSIONS, E_OTHER):
            return self.other_version()
        if cid == E_RETRY:
            return self.retry()
        if cid == E_NEXT:
            return self.retry(skip_first=True)
        if cid == E_CLOSE:
            return self.leave()
        if cid in (A_RESUME, A_START):
            self.ask_answer = "resume" if cid == A_RESUME else "start"
            return self.ask_event.set()
        if cid == U_PLAY:
            return self.play_next()
        if cid == U_CANCEL:
            self.upnext_cancel.set()
            return self.finish("ended")

    def onAction(self, action):
        a = action.getId()
        layer = self.layer
        if a not in BACK and a != STOP and time.time() - getattr(self, "opened_at", 0) < EARLY_KEYS:
            return  # 0.4.9.6: presses meant for the Guide that piled up while the channel was chosen; Back still works
        if self.extras.on_action(a, layer):
            return
        if a in BACK:
            if layer == "hud" and self.scrub_target is not None:
                self.scrub_cancel()  # Back puts the timeline back where playback is; the controls stay
                self.hud_until = time.time() + HUD_SECONDS
                return
            if layer == "hud":
                return self.hide_hud()
            if layer == "upnext":
                self.upnext_cancel.set()
                return self.finish("ended")
            return self.leave()
        if a == STOP:
            return self.leave()
        if layer in ("loading", "error", "ask", "upnext"):
            return
        if a == SCORES_KEY and self.mode == "live":  # 0.4.9: scores while watching, a drawer over the picture (mc_scores)
            import mc_scores
            return mc_scores.open_over(self)
        if layer == "offer" and a in (LEFT, RIGHT, UP, DOWN):
            self.show_layer("")  # the offer stays on screen; the arrows work as with nothing showing
        if a in (PAUSE, PLAYPAUSE, PLAY):
            return self.kodi_paused(a)
        if a in (FORWARD, REWIND):
            # Fast forward and rewind (the TV remote's keys, the iPhone remote's): move along the timeline, faster
            # the more presses in a row, and jump there once the presses stop. Kodi's own fast play is undone.
            self.normal_speed()
            if not self.scrub_by(self.stepper.step(a == FORWARD), auto=True) and self.mode == "live":
                V.notify("Live TV can't be skipped.")
            return
        if a == NEXT_ITEM and self.mode == "vod" and self.kind == "series":
            return self.play_next()
        if layer == "hud":
            self.hud_until = time.time() + HUD_SECONDS
            focus = self.getFocusId()
            if focus == HUD + 99 and a in (LEFT, RIGHT, UP, DOWN, SELECT):
                self.focus_on(B_PLAYPAUSE, "hud")  # the highlight missed the controls: put it on them
            elif focus == SCRUB and a in (LEFT, RIGHT):
                self.scrub_by(self.stepper.step(a == RIGHT))
            elif a == DOWN and self.scrub_target is not None:
                self.scrub_cancel()  # left the timeline without jumping
            return
        if a == LEFT:
            return self.seek(-10)
        if a == RIGHT:
            return self.seek(10)
        if a in (UP, DOWN, SELECT) or a in MENU_KEYS:
            return self.show_hud()

    def close(self):
        self.closing = True
        V.WINDOW.clearProperty("mc.full")
        xbmcgui.WindowXMLDialog.close(self)


# ---- what the other pages call -----------------------------------------------------------------------------------------

def wants_choice(api):
    """Settings > "Choose a source before playing" (the account's chooseSource, as the web's chooseLink): on unless off."""
    import mc_subtitles as S
    return S.prefs(api).get("chooseSource") is not False


def choose_first(api, kind, tmdb, season=None, episode=None):
    """0.4.9.9 (owner, 2026-11-26: the source question should come before the loading screen, not after it): the
    versions are found under Kodi's small busy circle on the page Play was pressed on, then Choose a version opens, and
    only the version chosen gets the loading screen. Returns the chosen version, "back" (Back on Choose a version), or
    None when there is nothing to choose from (the player then searches and says why, as before)."""
    import mc_play
    import mc_versions_page as VP
    busy(True)
    try:
        versions, name = found_versions(api, kind, tmdb, season, episode)
    except SignedOut:
        raise
    except (ServerError, OSError) as e:
        V.log("play: versions not found before the choice (%s)" % type(e).__name__)
        return None
    finally:
        busy(False)
    ranked, others = split_versions(versions, mc_play.caps())
    if not ranked:
        return None
    try:
        pick = VP.VersionsPage.choose(ranked, others, title=name or "", box=box_for({"type": kind}))
    except RuntimeError as e:
        V.log("versions page didn't open (%s); playing the best match" % type(e).__name__)
        return None
    return "back" if pick is None else pick


def play_title(api, kind, tmdb, season=None, episode=None, choose=None, fresh=False, art=None, resume=False):
    """Play a movie or an episode from any page (Home, Continue watching, a title's page, an episode, Search, the
    Guide). choose: True opens Choose a version first (the Choose a version button), False plays the best match at once
    (Up Next), None (the default) does what Settings > "Choose a source before playing" says, on unless turned off, as
    the web's Play does. 0.4.9.9: Choose a version comes first, before the loading screen (choose_first), and the
    loading screen then opens for the version chosen (0.4.9.8 had Play pick by itself, which the owner never asked for).
    art: what the page knows about the title ({name, backdrop, logo}), for the loading screen.
    resume: carry on from the saved place without asking (Continue Watching, 0.4.9.6); fresh: start from the beginning."""
    if choose is None:
        try:
            choose = wants_choice(api)
        except Exception:
            choose = True
    more = {"resume": True} if resume else {}
    if choose:
        try:
            pick = choose_first(api, kind, tmdb, season, episode)
        except SignedOut:
            pick = None  # the player says so
        if pick == "back":
            return "closed"
        if pick is not None:
            return PlayerPage.movie(api, kind, tmdb, season, episode, pick=pick, fresh=fresh, art=art, **more)
    return PlayerPage.movie(api, kind, tmdb, season, episode, fresh=fresh, art=art, choose=bool(choose), **more)


def play_channel(api, channel_id, name="", alts=None, now_title="", dock=False, game=None, logo=""):
    return PlayerPage.live(api, channel_id, name, alts, now_title, dock, game=game, logo=logo)
