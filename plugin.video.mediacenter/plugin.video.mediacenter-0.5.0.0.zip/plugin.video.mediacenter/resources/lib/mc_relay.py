# mediaCENTER for Kodi: a small relay on this box (127.0.0.1) for the links that need the account's sign-in (0.4.8).
#
# Before 0.4.8 a link on our server that needs the session (TorBox versions, live channels through /relay/live) was
# handed to Kodi as "https://server/path|Cookie=...": Kodi writes every link it opens, with what follows the "|", into
# kodi.log, so the sign-in cookie landed in the log each time a video opened or failed (owner, 2026-11-26). Now Kodi gets
# "http://127.0.0.1:PORT/TOKEN/path" instead: this relay adds the cookie itself and passes the answer back as it comes,
# so the log only ever shows the box's own address. The cookie stays inside the add-on (its profile folder and memory).
#
#   - It listens on 127.0.0.1 only (nothing outside the box can reach it) and answers only under a random TOKEN made
#     each time it starts, only GET and HEAD, and only for playback paths on our own server (ALLOWED).
#   - Redirects are not followed: Kodi gets them as they are (TorBox's own file needs no cookie), and a redirect to our
#     own server is pointed back at the relay. HLS playlists have their links to our server pointed at the relay too.
#   - The service (service.py) runs it for as long as Kodi runs and leaves its address in the Home window property
#     PROP; a page that finds no service relay starts one in its own process (Relay.local).
#
# 0.4.9.9 (owner's kodi.log, 2026-11-26: nearly every link "Failed with code 502", and one link that hung froze the whole
# box for a minute):
#   - Every answer that isn't a picture is written to kodi.log with its status, how long it took and the server's own
#     reason ("The FlixNest video server refused this source"), never the link, the token or the cookie (Relay.why).
#   - Our server gets UPSTREAM_TIMEOUT seconds to start answering: a slow link is answered "504 slow" before Kodi's own
#     20-second wait runs out, so Kodi gives up cleanly instead of trying twice more (a minute) with its screen frozen.
#   - The player can ask the relay to hang up on a link it no longer wants (DROP): Kodi's stop waits on the main thread
#     for a link it is still opening, and that froze the screen and the iPhone remote (mc_player.Playback.stop).
#     It can also ask why a link failed (WHY), for the admin's log on the loading screen.

import json
import re
import secrets
import socket
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
except ImportError:  # pragma: no cover
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn

PROP = "mediacenter.relay"
ALLOWED = re.compile(r"^/(relay|live|movie|series|share|jellyfin|aio)/")
PASS_ON = ("Range", "If-Range", "Accept", "Accept-Encoding")  # Kodi's request headers that go on to our server
SEND_BACK = ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "Last-Modified", "ETag", "Cache-Control")
PLAYLIST_MAX = 4 * 1024 * 1024
CHUNK = 64 * 1024
UPSTREAM_TIMEOUT = 18  # below Kodi's own 20 s wait (network.curlclienttimeout), so Kodi hears "slow" before it times out
ERROR_BODY_MAX = 4096
DROP, WHY = "_drop", "_why"  # the relay's own two questions, under its token: hang up on a link, why a link failed
OUTCOMES_KEPT = 40
_URLISH = re.compile(r"(?i)\b(?:https?|rtmp)://\S+|\b[\w.-]+\.(?:m3u8|mkv|mp4|ts)\S*")


def reason_text(body, n=120):
    """The first line of our server's own error message, without anything that looks like a link (for kodi.log)."""
    try:
        text = body.decode("utf-8", "replace") if isinstance(body, bytes) else str(body or "")
    except Exception:
        return ""
    if text.lstrip().startswith(("{", "[")):
        try:
            data = json.loads(text)
            if isinstance(data, dict):
                text = str(data.get("message") or data.get("error") or data.get("reason") or "")
        except ValueError:
            pass
    text = _URLISH.sub("[link]", " ".join(text.split()))
    return text[:n]


def kind_of(path):
    """What kind of link a relay path is, for the log: "live", "movie", "series", "share", ... (never the path)."""
    parts = [p for p in path.split("?", 1)[0].split("/") if p]
    if not parts:
        return "?"
    return "live" if parts[0] == "relay" else parts[0]


def rewrite_uri(uri, base, prefix):
    """A link inside a playlist or a redirect: ours goes through the relay; another site's, or a relative one, stays."""
    u = (uri or "").strip()
    if u.startswith(base + "/"):
        return prefix + u[len(base):]
    if u.startswith("/") and not u.startswith("//"):
        return prefix + u
    return uri


_ATTR = re.compile(r'URI="([^"]*)"')


def rewrite_playlist(text, base, prefix):
    """An HLS playlist with its links to our server pointed at the relay (segment lines and URI="..." attributes)."""
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            out.append(line)
        elif s.startswith("#"):
            out.append(_ATTR.sub(lambda m: 'URI="%s"' % rewrite_uri(m.group(1), base, prefix), line))
        else:
            out.append(rewrite_uri(s, base, prefix))
    return "\n".join(out) + "\n"


def upstream_path(path, token):
    """The path on our server for a relay path, or None when the relay must refuse it (wrong token, not a playback path,
    or anything that tries to climb out)."""
    head = "/%s/" % token
    if not token or not path.startswith(head):
        return None
    rest = "/" + path[len(head):]
    plain = urllib.parse.unquote(rest.split("?", 1)[0])
    if ".." in plain or "//" in plain or "\\" in plain or not ALLOWED.match(plain):
        return None
    return rest


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Relay(object):
    """The relay for one server. cookie() gives the current sign-in cookie ("name=value") or ""."""

    def __init__(self, base, cookie, user_agent="mediaCENTER-Kodi", device="kodi", opener=None, log=None, now=time.time):
        self.base = base.rstrip("/")
        self.cookie = cookie
        self.user_agent = user_agent
        self.device = device
        self.token = secrets.token_hex(12)
        self.server = None
        self.thread = None
        self.log = log or (lambda line: None)
        self.now = now
        self.lock = threading.Lock()
        self.active = {}  # id(handler) -> (relay path with its query, handler): the links Kodi has open right now
        self.outcomes = []  # [relay path, {"status", "why", "seconds"}], newest last (WHY)
        self.opener = opener or urllib.request.build_opener(
            _NoRedirect(), urllib.request.HTTPSHandler(context=ssl.create_default_context()))

    @property
    def prefix(self):
        return "http://127.0.0.1:%d/%s" % (self.server.server_address[1], self.token) if self.server else ""

    def start(self):
        relay = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.0"  # one answer per connection: the end of the body is the end of the connection

            def log_message(self, *args):  # nothing about requests goes to stderr (and so to kodi.log)
                pass

            def do_HEAD(self):
                relay.handle(self, head=True)

            def do_GET(self):
                relay.handle(self, head=False)

        self.server = _Server(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, name="mediacenter-relay")
        self.thread.daemon = True
        self.thread.start()
        return self.prefix

    def stop(self):
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
            self.server = None

    def url(self, path):
        """The relay's link for a path on our server ("/relay/live/..../1.m3u8?x=1")."""
        return self.prefix + (path if path.startswith("/") else "/" + path)

    # -- one request from Kodi --

    def handle(self, h, head):
        own = self.own_question(h)
        if own is not None:
            return own
        path = upstream_path(h.path, self.token)
        if path is None:
            return self._reply(h, 403, b"")
        began = self.now()
        with self.lock:
            self.active[id(h)] = (path, h)
        try:
            return self._handle(h, head, path, began)
        finally:
            with self.lock:
                self.active.pop(id(h), None)

    def own_question(self, h):
        """/TOKEN/_drop?p=PATH and /TOKEN/_why?p=PATH (the player's questions; PATH is the relay path after the token,
        with its query). None for any other request."""
        head = "/%s/" % self.token
        if not self.token or not h.path.startswith(head):
            return None
        rest = h.path[len(head):]
        name, _, query = rest.partition("?")
        if name not in (DROP, WHY):
            return None
        want = urllib.parse.parse_qs(query).get("p", [""])[0]
        if name == DROP:
            return self._reply(h, 200, json.dumps({"dropped": self.drop(want)}).encode("utf-8"), "application/json")
        return self._reply(h, 200, json.dumps(self.why(want) or {}).encode("utf-8"), "application/json")

    def drop(self, path):
        """Hang up on Kodi for every open request of this link (path with its query, as the player has it; "" for
        all). Kodi's reading then ends at once, so its stop doesn't wait for a link that is still opening. Returns how
        many were hung up on."""
        with self.lock:
            hits = [h for p, h in self.active.values() if not path or p == path]
        for h in hits:
            try:
                h.connection.shutdown(socket.SHUT_RDWR)
            except (OSError, AttributeError):
                pass
        if hits:
            self.log("relay: hung up on %d request%s for a %s link the player no longer wants" % (
                len(hits), "" if len(hits) == 1 else "s", kind_of(path) if path else "any"))
        return len(hits)

    def remember(self, path, status, why, began):
        out = {"status": status, "why": why, "seconds": round(max(0.0, self.now() - began), 1)}
        with self.lock:
            self.outcomes = [o for o in self.outcomes if o[0] != path][-(OUTCOMES_KEPT - 1):] + [[path, out]]
        if status >= 400 or status == 0:
            self.log("relay: a %s link answered %s after %.1fs%s" % (kind_of(path), status or "nothing", out["seconds"],
                                                                     (": " + why) if why else ""))
        return out

    def why(self, path):
        """What the last request of this link was answered (status, the server's reason, seconds), or None."""
        with self.lock:
            for p, out in reversed(self.outcomes):
                if p == path:
                    return dict(out)
        return None

    def _handle(self, h, head, path, began):
        cookie = self.cookie() or ""
        if not cookie:
            return self._reply(h, 401, b"")
        headers = {"Cookie": cookie, "User-Agent": self.user_agent, "X-MC-Device": self.device}
        for k in PASS_ON:
            if h.headers.get(k):
                headers[k] = h.headers.get(k)
        req = urllib.request.Request(self.base + path, headers=headers, method="HEAD" if head else "GET")
        try:
            res = self.opener.open(req, timeout=UPSTREAM_TIMEOUT)
        except urllib.error.HTTPError as e:
            res = e  # an error answer (or a redirect, which is not followed) is passed on as it is
        except (socket.timeout, TimeoutError) as e:
            self.remember(path, 504, "our server took longer than %ds to start answering (slow, not failed)" % UPSTREAM_TIMEOUT, began)
            return self._reply(h, 504, b"slow")
        except urllib.error.URLError as e:
            reason = getattr(e, "reason", None)
            if isinstance(reason, (socket.timeout, TimeoutError)):
                self.remember(path, 504, "our server took longer than %ds to start answering (slow, not failed)" % UPSTREAM_TIMEOUT, began)
                return self._reply(h, 504, b"slow")
            self.remember(path, 502, "couldn't reach our server (%s)" % type(reason or e).__name__, began)
            return self._reply(h, 502, b"")
        except (OSError, ValueError) as e:
            self.remember(path, 502, "couldn't reach our server (%s)" % type(e).__name__, began)
            return self._reply(h, 502, b"")
        try:
            self._pass_on(h, res, head, path, began)
        except (OSError, ValueError):
            pass  # Kodi hung up (a seek, Stop): nothing to do
        finally:
            try:
                res.close()
            except Exception:
                pass

    def _pass_on(self, h, res, head, path, began=None):
        status = res.getcode() if hasattr(res, "getcode") else res.code
        rh = res.headers
        began = self.now() if began is None else began
        if status >= 400:
            # Our server's refusal, with its own words: passed on to Kodi as it is, and its reason kept for the log.
            body = b"" if head else res.read(ERROR_BODY_MAX)
            self.remember(path, status, reason_text(body), began)
            return self._reply(h, status, body, rh.get("Content-Type") or "text/plain")
        self.remember(path, status, "", began)
        kind = (rh.get("Content-Type") or "").lower()
        playlist = "mpegurl" in kind or path.split("?", 1)[0].lower().endswith(".m3u8")
        if playlist and not head and 200 <= status < 300:
            body = res.read(PLAYLIST_MAX + 1)
            if len(body) <= PLAYLIST_MAX:
                text = rewrite_playlist(body.decode("utf-8", "replace"), self.base, self.prefix).encode("utf-8")
                return self._reply(h, status, text, rh.get("Content-Type") or "application/vnd.apple.mpegurl")
        h.send_response(status)
        for k in SEND_BACK:
            if rh.get(k):
                h.send_header(k, rh.get(k))
        if rh.get("Location"):
            h.send_header("Location", rewrite_uri(urllib.parse.urljoin(self.base + path, rh.get("Location")), self.base, self.prefix))
        h.end_headers()
        if head:
            return
        while True:
            chunk = res.read(CHUNK)
            if not chunk:
                return
            h.wfile.write(chunk)

    @staticmethod
    def _reply(h, status, body, kind="text/plain"):
        try:
            h.send_response(status)
            h.send_header("Content-Type", kind)
            h.send_header("Content-Length", str(len(body)))
            h.end_headers()
            if body and h.command != "HEAD":
                h.wfile.write(body)
        except (OSError, socket.error):
            pass


# ---- finding the relay from a page -------------------------------------------------------------------------------------

def _kodi_log(line):
    try:
        import xbmc
        xbmc.log("[mediaCENTER] " + line, xbmc.LOGINFO)
    except Exception:
        pass


def ask(prefix, question, path, timeout=2.0):
    """The player's question to the relay at prefix (DROP or WHY) about one link: its relay path with the query, i.e.
    the part of Kodi's link after the token. Returns the answer, or None (no relay, or it didn't answer in time)."""
    if not prefix:
        return None
    url = prefix + "/" + question + "?" + urllib.parse.urlencode({"p": path})
    try:
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(urllib.request.Request(url), timeout=timeout) as res:
            return json.loads(res.read(8192).decode("utf-8") or "{}")
    except (OSError, ValueError):
        return None


def split(url):
    """(relay prefix, relay path with its query) for a link through a relay on this box, else (None, None)."""
    m = re.match(r"^(http://127\.0\.0\.1:\d+/[0-9a-f]{8,64})(/.*)$", str(url or "").split("|", 1)[0])
    return (m.group(1), m.group(2)) if m else (None, None)

_local = {}


def stop_local():
    """An app-owned fallback relay must not keep its Python invocation alive after the app closes."""
    relays = list(_local.values())
    _local.clear()
    for relay in relays:
        relay.stop()


def announce(window, relay):
    """The service leaves the relay's address for the pages (the token is only good on this box, while Kodi runs)."""
    window.setProperty(PROP, json.dumps({"prefix": relay.prefix, "base": relay.base}))


def prefix_for(api, window=None):
    """The relay to use for this account's server: the service's when it runs for the same server, else one in this
    process (kept for as long as the process lives, reading the cookie from api)."""
    if window is not None:
        try:
            data = json.loads(window.getProperty(PROP) or "{}")
        except ValueError:
            data = {}
        if data.get("prefix") and data.get("base") == api.base:
            return data["prefix"]
    hit = _local.get(api.base)
    if hit is None or hit.server is None:
        hit = Relay(api.base, lambda: api.cookie, log=_kodi_log)
        hit.start()
        _local[api.base] = hit
    else:
        hit.cookie = lambda: api.cookie
    return hit.prefix
