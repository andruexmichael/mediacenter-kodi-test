# mediaCENTER for Kodi: the background service. While a mediaCENTER movie or episode plays it saves progress to
# /api/history every 30 seconds and when playback stops, so Continue Watching matches the phone, the Apple TV and the
# web. It also jumps to the resume point chosen in mc_play.resume_point once the video has started, and puts in the
# iPhone remote (service.mediacenter.remote) from the update list when the box doesn't have it yet.

import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("plugin.video.mediacenter")  # named, so it never depends on who started it
sys.path.insert(0, os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")), "resources", "lib"))

from mc_api import Api, Session  # noqa: E402
import mc_launch  # noqa: E402
import mc_sample  # noqa: E402

PLAYING_KEY = "mediacenter.playing"
SAVE_EVERY = 30


def api():
    sample = mc_sample.folder(xbmcvfs.translatePath(ADDON.getAddonInfo("path")))
    if sample:
        return mc_sample.SampleApi(sample)
    a = Api(ADDON.getSetting("server") or None, Session(xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))))
    a.profile = "guest" if ADDON.getSetting("guest_room") == "true" else ""  # Guest Room: its own Continue Watching
    return a


def save(entry, position, duration):
    if not entry or duration <= 0 or position < 0:
        return
    body = dict({k: v for k, v in entry.items() if v is not None}, position=int(min(position, duration)), duration=int(duration))
    try:
        api().call("POST", "/api/history", body=body, timeout=10)
    except Exception as e:  # never let a failed save stop playback
        xbmc.log("[mediaCENTER] progress not saved: %s" % type(e).__name__, xbmc.LOGINFO)


class Player(xbmc.Player):
    def __init__(self):
        super(Player, self).__init__()
        self.reset()

    def reset(self):
        self.entry = None
        self.position = 0.0
        self.duration = 0.0
        self.last_save = 0.0

    def onAVStarted(self):
        raw = xbmcgui.Window(10000).getProperty(PLAYING_KEY)
        xbmcgui.Window(10000).clearProperty(PLAYING_KEY)
        if not raw:
            self.reset()
            return
        try:
            data = json.loads(raw)
        except ValueError:
            return
        self.entry = data.get("entry")
        resume = float(data.get("resume") or 0)
        if resume > 0:
            self.seekTime(resume)
        self.position = resume
        self.last_save = resume

    def finish(self):
        if self.entry:
            save(self.entry, self.position, self.duration)
        self.reset()

    def onPlayBackStopped(self):
        self.finish()

    def onPlayBackEnded(self):
        self.position = self.duration
        self.finish()

    def tick(self):
        if not self.entry or not self.isPlayingVideo():
            return
        try:
            self.position = self.getTime()
            self.duration = self.getTotalTime() or self.duration
        except RuntimeError:
            return
        if abs(self.position - self.last_save) >= SAVE_EVERY:
            self.last_save = self.position
            save(self.entry, self.position, self.duration)


def start_relay():
    """The relay that adds the sign-in to links on our server, so Kodi (and kodi.log) never sees it (mc_relay)."""
    import mc_relay
    a = api()
    if not hasattr(a, "base") or not hasattr(a, "session") or a.session is None:
        return None  # sample-data mode: nothing needs the sign-in
    session = a.session
    try:
        relay = mc_relay.Relay(a.base, lambda: session.load().get("cookie", ""),
                               log=lambda line: xbmc.log("[mediaCENTER] " + line, xbmc.LOGINFO))
        relay.start()
        mc_relay.announce(xbmcgui.Window(10000), relay)
        return relay
    except Exception as e:
        xbmc.log("[mediaCENTER] relay not started: %s" % type(e).__name__, xbmc.LOGINFO)
        return None


def refresh_guide():
    """Every few hours, fetch the channels and the guide again for Kodi's TV guide (once the Guide set it up)."""
    import mc_guide as G
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not G.due(profile):
        return
    try:
        a = api()
        if not a.signed_in:
            return
        n, programmes = G.refresh(a, profile, "plugin://plugin.video.mediacenter/", ADDON.getSetting("guide_channels") == "1")
        xbmc.log("[mediaCENTER] guide refreshed: %d channels, %d programmes" % (n, programmes), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log("[mediaCENTER] guide not refreshed: %s" % type(e).__name__, xbmc.LOGINFO)


def theme_sync():
    """The website's colour theme (0.4.9, mc_theme): the account's choice when it is newer, this box's when it is."""
    import mc_theme as T
    try:
        a = api()
        if a.signed_in:
            T.sync(a, ADDON, window=xbmcgui.Window(10000))
    except Exception as e:  # never stop the service
        xbmc.log("[mediaCENTER] theme not synced: %s" % type(e).__name__, xbmc.LOGINFO)


def game_alerts():
    """Game alerts for My Teams (0.4.9, mc_alerts): starting soon, started, final, as Kodi notes."""
    if ADDON.getSetting("game_alerts") == "false":
        return
    import mc_alerts
    try:
        a = api()
        if a.signed_in:
            mc_alerts.check(a, xbmcvfs.translatePath(ADDON.getAddonInfo("profile")),
                            lambda text: xbmcgui.Dialog().notification("mediaCENTER", text, ADDON.getAddonInfo("icon"), 8000))
    except Exception as e:  # never stop the service
        xbmc.log("[mediaCENTER] game alerts: %s" % type(e).__name__, xbmc.LOGINFO)


def sleep_timer():
    """The power menu's sleep timer (mc_power): a notice a minute before, then playback stops and the TV turns off."""
    import mc_power
    try:
        mc_power.tick(xbmcgui.Window(10000), xbmc.executebuiltin,
                      lambda method, params: json.loads(xbmc.executeJSONRPC(json.dumps(
                          {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))).get("result"),
                      lambda text: xbmcgui.Dialog().notification("mediaCENTER", text))
    except Exception as e:  # never stop the service
        xbmc.log("[mediaCENTER] sleep timer: %s" % type(e).__name__, xbmc.LOGINFO)


def remote_on():
    """A remote that is on the box but switched off in Kodi is switched on (it was left off on the owner's Pi, and the
    folder being there made it look done). Returns True once there's nothing left to do."""
    import mc_remote_link as R
    found = R.switch_on(xbmc.executeJSONRPC)
    if found == "missing":  # copied, but Kodi hasn't looked yet
        xbmc.executebuiltin("UpdateLocalAddons", True)
        found = R.switch_on(xbmc.executeJSONRPC)
    if found in ("off", "missing"):
        xbmc.log("[mediaCENTER] iPhone remote is on the box but not switched on (%s)" % found, xbmc.LOGINFO)
        return False
    return True


def add_remote():
    """Put in the iPhone remote if this box doesn't have it yet (it came after the updater on some boxes), and switch it
    on. Quiet: it tries again later if either can't be done. Returns True once there's nothing left to do."""
    import mc_updates as U
    addons = xbmcvfs.translatePath("special://home/addons")
    if os.path.isdir(os.path.join(addons, U.REMOTE)):
        return remote_on()
    channel = ADDON.getSetting("update_channel") or U.default_channel(U.installed(addons))

    def turn_on():
        U.refresh_local()  # Kodi looks at the new folder, then it is switched on and checked (it starts off)
        U.ensure_enabled(U.NEEDED, U.kodi_rpc, U.refresh_local)
    try:
        added = U.add_needed(channel, addons, after_swap=turn_on)
    except Exception as e:  # never print addresses or messages from the update list
        xbmc.log("[mediaCENTER] iPhone remote not added yet: %s" % type(e).__name__, xbmc.LOGINFO)
        return False
    if added:
        xbmc.log("[mediaCENTER] added: %s" % ", ".join(added), xbmc.LOGINFO)
    return remote_on() if os.path.isdir(os.path.join(addons, U.REMOTE)) else True


def box_idle(player):
    """Nothing playing, nobody has pressed a key for a while, and (off the box) the app is closed: an automatic update
    can go in. On the box mediaCENTER is always open; it restarts into the new version."""
    import mc_updates as U
    return U.automatic_idle(player)


def auto_update(auto, player, now=None):
    """0.4.9: mediaCENTER updates itself (mc_updates.Auto); Settings > Software update can turn it off."""
    import shutil
    import time
    import mc_sample
    import mc_updates as U
    if ADDON.getSetting("auto_update") == "false" or mc_sample.folder(xbmcvfs.translatePath(ADDON.getAddonInfo("path"))):
        auto.plan = None
        return None
    now = time.time() if now is None else now
    addons = xbmcvfs.translatePath("special://home/addons")
    channel = ADDON.getSetting("update_channel") or U.default_channel(U.installed(addons))
    if auto.plan and auto.plan["channel"] != channel:
        auto.plan = None
        auto.next = now  # a queued update must follow the newly chosen list
    if auto.due(now):
        plan = auto.look(lambda: U.check(channel, U.installed(addons)), now)
        if plan:
            xbmc.log("[mediaCENTER] automatic update: %s is ready, waiting for the box to be idle" % plan["version"], xbmc.LOGINFO)
    plan = auto.ready(lambda: box_idle(player), now)
    if plan is None:
        return None
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    os.makedirs(profile, exist_ok=True)
    if (U.installing(xbmcgui.Window(10000)) or os.path.exists(os.path.join(profile, "update-plan.json"))
            or U.auto_state(profile).get("trying")):
        return None  # a manual or automatic installer already owns this plan
    with open(os.path.join(profile, "update-plan.json"), "w") as f:
        json.dump(dict(plan, quiet=True), f)
    worker = os.path.join(profile, "update-worker.py")
    shutil.copyfile(U.__file__, worker)  # the installer runs from a copy: the add-on's own folder is what it replaces
    auto.start(plan, now)
    xbmc.log("[mediaCENTER] automatic update: installing %s" % plan["version"], xbmc.LOGINFO)
    xbmcgui.Dialog().notification("mediaCENTER", "Updating mediaCENTER. It restarts in a moment.", ADDON.getAddonInfo("icon"), 6000)
    xbmc.executebuiltin('RunScript("%s","%s")' % (worker, profile))
    return plan


FORCED_FILE = "forced-on.json"
FORCED_GAP = 6 * 3600  # a restart to bring parts on happens at most this often, so a box can never loop


def parts_on(profile, addons, now=None):
    """0.4.9.6: at every start each mediaCENTER part that Kodi has off (the launcher, the look, the remote) is switched
    on; one Kodi won't switch on is marked on in its add-on table and the box restarts once to bring it in. Returns
    True when it asked for that restart."""
    import time
    import mc_updates as U
    now = time.time() if now is None else now
    forced = U.switch_on_everything([i for i in U.ORDER if i in U.installed(addons)])
    if not forced or not U.whole_box(xbmc.getSkinDir()):
        return False  # Kodi on a computer is never restarted by itself; the parts come on when it next starts
    path = os.path.join(profile, FORCED_FILE)
    try:
        with open(path) as f:
            last = float(json.load(f).get("at") or 0)
    except (OSError, ValueError, AttributeError, TypeError):
        last = None  # never before
    if last is not None and now - last < FORCED_GAP:
        xbmc.log("[mediaCENTER] parts marked on; they come on at the next start", xbmc.LOGINFO)
        return False
    os.makedirs(profile, exist_ok=True)
    with open(path, "w") as f:
        json.dump({"at": now, "parts": forced}, f)
    xbmc.log("[mediaCENTER] restarting so Kodi switches on: %s" % ", ".join(forced), xbmc.LOGINFO)
    xbmc.executebuiltin(U.restart_command())
    return True


def start_auto_update():
    import mc_updates as U
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    addons = xbmcvfs.translatePath("special://home/addons")
    auto = U.Auto(profile)
    try:
        U.tidy(profile, addons, xbmcgui.Window(10000))  # puts right an update a power cut stopped part way
        said = auto.settle(U.installed(addons))
        if said:
            xbmc.log("[mediaCENTER] last automatic update: %s" % said, xbmc.LOGINFO)
    except Exception as e:
        xbmc.log("[mediaCENTER] automatic update state: %s" % type(e).__name__, xbmc.LOGINFO)
    if not U.installing(xbmcgui.Window(10000)):
        try:
            parts_on(profile, addons)
        except Exception as e:  # never stop the service
            xbmc.log("[mediaCENTER] parts not checked: %s" % type(e).__name__, xbmc.LOGINFO)
    return auto


def say_updated():
    """0.4.9.9: after an update, once: "mediaCENTER updated to 0.4.9.9, running on LibreELEC 12.2." The version
    started is remembered either way, so the notice never repeats."""
    import mc_updates as U
    now = ADDON.getAddonInfo("version")
    try:
        last = ADDON.getSetting("last_version")
        if not last and ADDON.getSetting("setup_complete") == "true":
            last = "0.0.0"  # set up under a version older than this notice (0.4.9.8 and before): this start is an update
        text = U.updated_notice(last, now, U.system_name())
        ADDON.setSetting("last_version", now)
    except Exception as e:  # never stop the service
        xbmc.log("[mediaCENTER] update notice: %s" % type(e).__name__, xbmc.LOGINFO)
        return ""
    if text:
        xbmcgui.Dialog().notification("mediaCENTER", text, ADDON.getAddonInfo("icon"), 8000)
    return text


def airplay_ensure():
    """0.4.9.9: a box with the AirPlay speaker on has it running after every start (Docker can start after Kodi, so
    this is tried again until it works). True once there is nothing left to do."""
    if ADDON.getSetting("airplay_speaker") != "true":
        return True
    try:
        import mc_airplay
        return mc_airplay.speaker(ADDON, log=lambda line: xbmc.log("[mediaCENTER] " + line, xbmc.LOGINFO)).ensure()
    except Exception as e:  # never stop the service
        xbmc.log("[mediaCENTER] AirPlay speaker: %s" % type(e).__name__, xbmc.LOGINFO)
        return False


STEP = 0.25  # the service never waits longer than this before looking whether Kodi or the installer wants it gone


def pause(monitor, seconds):
    """Wait about seconds, in short steps, so Kodi's stop (an update's restart) is answered within a second: Kodi kills
    a service that hasn't stopped in 5 seconds, as it did during the 0.4.9 update. True: stop now."""
    for _ in range(max(1, int(round(seconds / STEP)))):
        if monitor.waitForAbort(STEP):
            return True
    return False


def picture_render():
    """0.4.9.4: on a box that draws video on its own layer (the Pi), Kodi's render method follows Settings > Playback and
    Live TV > Picture, "With the menus" (EGL) unless changed, so the Guide's mini player shows the whole picture."""
    import mc_picture as MP

    def rpc(method, params):
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
        if "error" in answer:
            raise RuntimeError("unavailable")
        return answer.get("result")

    def setting(key):
        try:
            answer = rpc("Settings.GetSettingValue", {"setting": key})
        except (RuntimeError, ValueError, TypeError):
            return "?"
        return answer.get("value", "?") if isinstance(answer, dict) else "?"
    try:
        said = MP.apply_render(ADDON.getSetting("picture_render") or "egl", setting,
                               lambda key, value: rpc("Settings.SetSettingValue", {"setting": key, "value": value}),
                               lambda line: xbmc.log("[mediaCENTER] " + line, xbmc.LOGINFO))
        return said
    except Exception as e:  # never stop the service
        xbmc.log("[mediaCENTER] picture setting not applied: %s" % type(e).__name__, xbmc.LOGINFO)
        return "failed"


def main():
    window = xbmcgui.Window(10000)
    monitor = xbmc.Monitor()
    relay = None
    try:
        player = Player()
        try:
            # 0.5.0.2: the two Kodi settings that stop live TV waiting 40 s (mc_kodi_settings.py). Written once; Kodi
            # restarts itself that one time so they take effect at once, before anything plays.
            import mc_kodi_settings
            if mc_kodi_settings.ensure(xbmcvfs.translatePath("special://userdata"), lambda w: xbmc.log("[mediaCENTER] " + w, xbmc.LOGINFO)):
                if not player.isPlaying():
                    xbmc.executebuiltin("RestartApp")
        except Exception as e:
            xbmc.log("[mediaCENTER] Kodi settings for live TV not written (%s)" % type(e).__name__, getattr(xbmc, "LOGWARNING", xbmc.LOGINFO))
        try:
            import mc_theme  # noqa: E402
            mc_theme.apply(mc_theme.chosen(ADDON))  # this box's theme before anything opens
        except Exception as e:
            xbmc.log("[mediaCENTER] theme not applied: %s" % type(e).__name__, xbmc.LOGINFO)
        picture_render()
        relay = start_relay()
        try:  # 0.4.8: the links a Pi played as sound over black were remembered as failed; give them another go, once
            import mc_versions  # noqa: E402
            if mc_versions.FailedLinks(xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))).forget_once("0.4.8"):
                xbmc.log("[mediaCENTER] links remembered as failed were forgotten (0.4.8)", xbmc.LOGINFO)
        except Exception:
            pass
        if ADDON.getSetting("autostart") != "false" and not pause(monitor, 4):
            # A mediaCENTER box opens straight into the app (owner, 2026-11-25: plug and play). On the box, mediaCENTER's
            # start-up picture and look are put in place first (mc_boot); the mediaCENTER look opens the app itself from
            # its Home. Anywhere else (or while the look is being switched to) the service opens it.
            import mc_boot  # noqa: E402
            here = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
            try:
                state = mc_boot.prepare(monitor, here, xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), ADDON.getAddonInfo("version"))
            except Exception as e:  # never keep the app from opening
                xbmc.log("[mediaCENTER] start-up steps skipped: %s" % type(e).__name__, xbmc.LOGINFO)
                state = ""
            if state:
                xbmc.log("[mediaCENTER] mediaCENTER look: %s" % state, xbmc.LOGINFO)
            if state != "switching" and xbmc.getSkinDir() != "skin.mediacenter":
                xbmc.executebuiltin(mc_launch.open_app(here))
        seconds = 0
        remote_here = False
        airplay_ready = False
        auto = start_auto_update()
        while not monitor.abortRequested():
            if pause(monitor, 1):
                break
            player.tick()
            seconds += 1
            if seconds % 600 == 30 and not player.isPlayingVideo():  # look every 10 minutes, never during a film
                refresh_guide()
            if seconds % 600 == 8:  # soon after start, then every 10 minutes: a theme picked on the website shows here
                theme_sync()
            if seconds % 120 == 60:  # a minute after start, then every two minutes
                game_alerts()
            if not remote_here and seconds % 600 == 45 and not player.isPlayingVideo():
                remote_here = add_remote()
            if seconds == 10 and not xbmcgui.Window(10000).getProperty("mediacenter.update.installing"):
                say_updated()  # once the app is up after a start
            if not airplay_ready and seconds % 60 == 25:  # 25 seconds after start, then every minute until it runs
                airplay_ready = airplay_ensure()
            sleep_timer()
            if seconds % 60 == 20:  # once a minute: is an update due, and is the box idle for it
                try:
                    auto_update(auto, player)  # the installer takes over from a copy, then restarts the box
                except Exception as e:  # never stop the service
                    xbmc.log("[mediaCENTER] automatic update: %s" % type(e).__name__, xbmc.LOGINFO)
    finally:
        if relay is not None:
            window.clearProperty("mediacenter.relay")
            relay.stop()


if __name__ == "__main__":
    main()
