# Kodi's advancedsettings.xml entries mediaCENTER needs (0.5.0.2).
#
# Why (owner's kodi.log, 2026-11-27): when a Guide channel closed, Kodi saved its "file state" and marked it watched,
# and on the way looked the channel's link up ("CCurlFile::Stat ... Timeout was reached", twice, 20 s each). That job
# runs on the worker that also loads the next channel's settings, so the next channel waited about 40 s and the app
# looked frozen (changing channels, Back on the Guide, leaving a game). With these, Kodi takes the date added from the
# clock (no lookup) and never counts a play as watched (mediaCENTER keeps watch progress on its own server).
# Kodi reads the file only when it starts, so they apply from the next start.
import os
import re

WANT = {
    ("videolibrary", "dateadded"): "0",
    ("video", "playcountminimumpercent"): "101",
}


def merged(text):
    """advancedsettings.xml text with WANT set, everything else kept. Returns (text, changed)."""
    text = text if text and "<advancedsettings" in text else '<advancedsettings version="1.0">\n</advancedsettings>\n'
    changed = False
    for (section, key), value in WANT.items():
        tag = "<%s>%s</%s>" % (key, value, key)
        inner = re.search(r"<%s>(.*?)</%s>" % (section, section), text, re.S)
        if inner and re.search(r"<%s>\s*%s\s*</%s>" % (key, re.escape(value), key), inner.group(1)):
            continue
        changed = True
        if inner:
            body = re.sub(r"\s*<%s>.*?</%s>" % (key, key), "", inner.group(1), flags=re.S)
            text = text[:inner.start(1)] + body + tag + text[inner.end(1):]
        else:
            text = text.replace("</advancedsettings>", "  <%s>%s</%s>\n</advancedsettings>" % (section, tag, section), 1)
    return text, changed


def ensure(userdata, log=lambda words: None):
    """Write the entries into userdata/advancedsettings.xml when missing. True when the file changed."""
    path = os.path.join(userdata, "advancedsettings.xml")
    try:
        with open(path, encoding="utf-8") as f:
            old = f.read()
    except OSError:
        old = ""
    new, changed = merged(old)
    if changed:
        with open(path, "w", encoding="utf-8") as f:
            f.write(new)
        log("Kodi settings for live TV written (advancedsettings.xml); they apply from the next start")
    return changed
