# mediaCENTER for Kodi: the streaming services on the Movies and TV Shows pages (0.4.9.3, owner, 2026-11-26: "Instead of
# all the genres on the side, switch those to all of the streaming services and put those as the categories"; genres
# are in the Guide). The services, their names and logos are design/services.json's streaming list, copied into
# resources/data/services.json by kodi/tools/make_windows.py. The page answer (/api/browse, src/ba-browse.js) already
# has each service's rows, with ids "top:<service>", "popular:<service>" and "new:<service>", so choosing a service
# shows its rows without asking the server again.

import json
import os

PREFIXES = ("top", "popular", "new")


def load(here):
    """design/services.json's streaming services, in the website's order: [{id, name, aliases, logo}] ([] if missing)."""
    try:
        with open(os.path.join(here, "resources", "data", "services.json"), encoding="utf-8") as f:
            raw = json.load(f).get("streaming") or []
    except (OSError, ValueError, AttributeError):
        return []
    return [s for s in raw if isinstance(s, dict) and s.get("id") and s.get("name")]


def service_of(row_id):
    """The service a page row belongs to ("top:netflix" -> "netflix"), or '' for a row of no service ("new")."""
    prefix, _, sid = str(row_id or "").partition(":")
    return sid if prefix in PREFIXES and sid else ""


def name_from_title(title):
    """A service the box doesn't know yet (added on the server after this build): its name from "Top 10 on X"."""
    text = str(title or "")
    return text.rsplit(" on ", 1)[1].strip() if " on " in text else ""


def group(answer_rows, known):
    """The page's services, in the website's order (services the box doesn't know after them, as the page has them):
    [{id, name, logo, rows: [page row dicts]}]. Only services that have at least one row are listed."""
    by_id = {}
    order = []
    for r in answer_rows or []:
        if not isinstance(r, dict):
            continue
        sid = service_of(r.get("id"))
        if not sid:
            continue
        if sid not in by_id:
            by_id[sid] = []
            order.append(sid)
        by_id[sid].append(r)
    out = []
    names = {s["id"]: s for s in known or []}
    for s in known or []:
        if s["id"] in by_id:
            out.append({"id": s["id"], "name": s["name"], "logo": s.get("logo") or "", "rows": by_id[s["id"]]})
    for sid in order:
        if sid not in names:
            rows = by_id[sid]
            name = next((n for n in (name_from_title(r.get("title")) for r in rows) if n), sid)
            out.append({"id": sid, "name": name, "logo": "", "rows": rows})
    return out
