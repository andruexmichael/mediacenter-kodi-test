# mediaCENTER for Kodi: Play and Pause, shared by the full-screen player (mc_player.PlayerPage.kodi_paused) and the
# Guide's mini player (mc_app.GuidePage). Kept free of Kodi so it can be tested: Kodi's own calls come in as arguments.
#
# Kodi pauses by itself on the Pause, Play/Pause and Play keys, a moment after the page has seen them, so pausing here
# too would undo it. Only when Kodi did nothing (no pause or resume came within `wait` seconds) does this pause. Play
# only ever resumes. Owner, 2026-11-26: live TV would not pause. If Kodi still isn't paused after a pause was asked for,
# the answer is "refused", so the page can say so and kodi.log records it (the cause needs the box's log).

import time

PAUSE, PLAYPAUSE, PLAY = 12, 229, 68
KEYS = (PAUSE, PLAYPAUSE, PLAY)
SETTLE = 1.0  # seconds Kodi gets to report the pause before it counts as refused


def toggle(watcher, key, wait, paused, closing=lambda: False, sleep=time.sleep, clock=time.time, settle=None):
    """watcher: the Playback's xbmc.Player (toggled_at, pause()); paused(): Kodi's Player.Paused. Returns "paused",
    "playing" or "refused" (a pause was wanted and Kodi stayed playing)."""
    was = bool(paused())
    asked = clock()
    end = asked + wait
    kodi_did = False
    while clock() < end and not closing():
        if watcher is not None and getattr(watcher, "toggled_at", 0) >= asked - wait:
            kodi_did = True
            break
        sleep(0.05)
    if not kodi_did and watcher is not None and not closing() and (key != PLAY or paused()):
        watcher.pause()
        sleep(0.15)
    wanted_pause = key != PLAY and not was
    if wanted_pause:
        stop = clock() + (SETTLE if settle is None else settle)
        while not paused() and clock() < stop and not closing():
            sleep(0.1)
        if not paused():
            return "refused"
    return "paused" if paused() else "playing"


# ---- a paused channel, and going back to live (0.4.9.6) -------------------------------------------------------------
#
# The design plan (owner, 2026-11-26): Play/Pause pauses the channel and shows "Paused" with the time; Play carries on.
# If the channel can't hold that long (the stream dropped or stood still while paused, or right after Play), it goes
# back to live and says "Back to live". How long a Pi can hold a paused channel is still to be tried on the box.

GRACE = 30.0  # seconds after Play in which a drop, or a stall (20 s still, mc_watching.STALL_SECONDS), counts as
# "couldn't hold": back to live, not a backup feed
BACK_TO_LIVE = "Back to live"
REFUSED = "This channel can't be paused."


def paused_note(at, clock_text):
    """What the player shows while a channel is paused: "Paused · 9:41 PM" (clock_text turns a time into words)."""
    return "Paused" + (u" · " + clock_text(at) if at else "")


class Hold(object):
    """Whether a live channel is paused, and whether a drop or a stall now means it couldn't hold the pause."""

    def __init__(self, clock=time.time, grace=GRACE):
        self.clock, self.grace = clock, grace
        self.paused_at = None
        self.resumed_at = None

    def paused(self):
        if self.paused_at is None:
            self.paused_at = self.clock()
        return self.paused_at

    def resumed(self):
        if self.paused_at is not None:
            self.resumed_at = self.clock()
        self.paused_at = None

    def follow(self, state):
        """state: what toggle() answered, or Kodi's Player.Paused as "paused" / "playing" (the iPhone remote pauses
        through Kodi, so the page only sees the result)."""
        if state == "paused":
            self.paused()
        elif state == "playing":
            self.resumed()

    def is_paused(self):
        return self.paused_at is not None

    def lost_hold(self):
        """True when a drop or a stall now is the pause running out: paused, or Play only moments ago."""
        if self.paused_at is not None:
            return True
        return self.resumed_at is not None and self.clock() - self.resumed_at <= self.grace

    def reset(self):
        """Back to live (or a new channel): nothing held any more."""
        self.paused_at = None
        self.resumed_at = None
