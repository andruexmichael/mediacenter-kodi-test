# mediaCENTER for Kodi: announcements and the welcome tour (0.4.9). Pure: no Kodi here; mc_more draws them.
#
# Announcements: the admin writes them on the website (src/ba-announcements.js); GET /api/announcements?platform=tv
# lists what shows now. Each one shows once, as the website's card, until "Got it"; the ids closed are the synced setting
# "dismissedAnnouncements" (web-v27/js/announce-state.js), so one closed here stays closed on the website and back.
# The text arrives as plain blocks (src/ba-richtext.js parseBlocks), written here as Kodi label text.
#
# The welcome tour: like the website's quick tour (web-v27/js/views/guided-tour.js), in this box's own words, as cards
# beside the sidebar, the place each card talks about highlighted. Shown once per account on this box after signing
# in; Settings > Account has it again.

import time

DISMISSED = "dismissedAnnouncements"
KEEP = 200
PLATFORM = "tv"
BADGE = {"feature": "NEW", "tip": "TIP", "maintenance": "MAINTENANCE", "account": "ACCOUNT", "important": "IMPORTANT"}
# The screens an announcement's button can open (ba-announcements.js TARGETS) that this app has.
SCREENS = {"home": "home", "guide": "guide", "sports": "sports", "search": "search", "library": "library", "mylist": "library",
           "settings": "settings"}

TOUR_PREF = "piWelcomeTour"
TOUR_VERSION = "pi-v1"


# ---- announcements -------------------------------------------------------------------------------------------------

def dismissed(prefs):
    entry = (prefs or {}).get(DISMISSED)
    value = entry.get("value") if isinstance(entry, dict) else None
    return sorted(set(str(i) for i in value)) if isinstance(value, list) else []


def dismiss_body(prefs, notice_id, now=None):
    """PUT /api/prefs for closing one: the account's list with this id added (a union, as the website keeps it)."""
    ids = sorted(set(dismissed(prefs)) | {str(notice_id)})[-KEEP:]
    return {"prefs": {DISMISSED: {"value": ids, "updatedAt": int((time.time() if now is None else now) * 1000)}}}


def waiting(answer, prefs):
    """The announcements still to show, newest first (the server sends them in that order)."""
    if not isinstance(answer, dict) or not answer.get("ready"):
        return []
    gone = set(dismissed(prefs))
    return [n for n in answer.get("notices") or [] if isinstance(n, dict) and n.get("id") and str(n["id"]) not in gone]


def spans(x):
    out = []
    for sp in x or []:
        if not isinstance(sp, dict):
            continue
        s = str(sp.get("s") or "").replace("[", "(").replace("]", ")")  # Kodi reads [ ] as its own formatting
        if sp.get("b"):
            s = "[B]%s[/B]" % s
        if sp.get("i"):
            s = "[I]%s[/I]" % s
        out.append(s)
    return "".join(out)


def blocks_text(blocks):
    """Headings in bold, paragraphs, bullet and numbered lists; pictures are left out (first_image has them)."""
    lines = []
    for b in blocks or []:
        if not isinstance(b, dict):
            continue
        t = b.get("t")
        if t == "h":
            lines.append("[B]%s[/B]" % spans(b.get("x")))
        elif t == "p":
            lines.append(spans(b.get("x")))
        elif t == "ul":
            lines.extend(u"•  " + spans(i) for i in b.get("i") or [])
        elif t == "ol":
            lines.extend("%d.  %s" % (n, spans(i)) for n, i in enumerate(b.get("i") or [], 1))
    return "\n".join(l for l in lines if l.strip())


def first_image(notice):
    """The announcement's first picture (https only, as the server allows), intro sections first, or ""."""
    sections = notice.get("sections") or []
    ordered = [s for s in sections if s.get("kind") == "intro"] + [s for s in sections if s.get("kind") != "intro"]
    for sec in ordered:
        for b in sec.get("blocks") or []:
            if isinstance(b, dict) and b.get("t") == "img" and str(b.get("s") or "").startswith("https://"):
                return b["s"]
    return ""


def text(notice):
    sections = notice.get("sections") or []
    if sections:
        return "\n\n".join(t for t in (blocks_text(s.get("blocks")) for s in sections) if t)
    return "\n".join(u"•  " + str(p) for p in notice.get("points") or [] if str(p).strip())


def buttons(notice):
    """What this box can do from an announcement: [(kind, label, target)] with kind "screen" or "tutorial". Links to
    web pages are left out (there is no browser here)."""
    out = []
    for b in notice.get("buttons") or []:
        if not isinstance(b, dict) or not b.get("label"):
            continue
        if b.get("type") == "screen" and b.get("target") in SCREENS:
            out.append(("screen", str(b["label"]), SCREENS[b["target"]]))
        elif b.get("type") == "tutorial" and notice.get("tutorial"):
            out.append(("tutorial", str(b["label"]), ""))
    return out[:2]


def card(notice):
    """{"eyebrow", "title", "text", "image", "buttons"} for mc_more.CardPage."""
    return {"eyebrow": BADGE.get(notice.get("kind"), "NEW"), "title": str(notice.get("title") or ""), "text": text(notice),
            "image": first_image(notice), "buttons": buttons(notice)}


def tutorial(notice):
    """The "Show me how" steps: [{"text", "image"}]."""
    return [{"text": str(s.get("text") or ""), "image": str(s.get("image") or "") if str(s.get("image") or "").startswith("https://") else ""}
            for s in notice.get("tutorial") or [] if isinstance(s, dict) and s.get("text")]


# ---- the welcome tour ----------------------------------------------------------------------------------------------

# (title, text, the sidebar place it talks about or "", the Continue button's words). Written for this box (0.4.9.3,
# owner, 2026-11-26: the website's words didn't fit a TV): only what this app has, worked with a TV remote or the
# iPhone remote. Same steps and places as before, so tour_seen and the sidebar highlight are unchanged.
TOUR = [
    ("Welcome to mediaCENTER", u"Your movies, shows, sports and live TV channels, all in one place on this TV.", "", "Continue"),
    ("Take a quick tour", u"The menu on the left has every place in mediaCENTER. We’ll go through them one at a time. Choose "
     u"Exit tour whenever you’re ready to watch.", "", "Show me around"),
    ("Continue Watching", u"Pick up a movie or episode right where you left off. Home also has the Top 10 and picks just for "
     u"you.", "home", "Continue"),
    ("Movies and TV Shows", u"Pick a streaming service to see its Top 10, what’s popular and what’s new. Genres are in the Guide.", "movies", "Continue"),
    ("Guide", u"See what’s on now. The groups at the top, like Favorites, narrow the channels. Choose a channel to watch "
     u"it, and press Back to keep it playing at the top of the Guide.", "guide", "Continue"),
    ("Sports", u"Today’s games, live and later. Choose Edit to pick your teams, and their games show first. Choose a "
     u"game on now to watch it.", "sports", "Continue"),
    ("Search", u"Up from Home. Press OK on the search box and type, on the TV or on your iPhone: movies, shows, channels "
     u"and games.", "search", "Continue"),  # 0.4.9.9: Kodi's keyboard, Search above Home
    ("My List", u"On a movie or show, choose Add to My List to save it for later. You’ll find it in Library.",
     "library", "Continue"),
    ("You know your way around", u"To see this tour again, go to Settings, then Account, then Welcome tour.", "settings",
     "Start watching"),
]


def tour_seen(prefs, local_seen):
    entry = (prefs or {}).get(TOUR_PREF)
    return bool(local_seen) or (isinstance(entry, dict) and entry.get("value") == TOUR_VERSION)


def tour_body(now=None):
    return {"prefs": {TOUR_PREF: {"value": TOUR_VERSION, "updatedAt": int((time.time() if now is None else now) * 1000)}}}


def first_name(name):
    name = str(name or "").strip()
    return name.split()[0] if name and "@" not in name else ""
