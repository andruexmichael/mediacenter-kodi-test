# mediaCENTER for Kodi: the AirPlay speaker (0.4.9.9, owner 2026-11-26). Music from an iPhone, iPad or Mac plays
# through the TV, joins other AirPlay 2 speakers, and can be added to the Home app as a speaker. Settings > Audio >
# AirPlay speaker turns it on and off. (Research: /mnt/project-files/kodi/airplay-home.md.)
#
# How: shairport-sync (AirPlay 2; the official image mikebrady/shairport-sync, pinned below, which has arm/v7 for a
# Pi 3) runs as a container from LibreELEC's Docker add-on, with the box's network and sound devices. Kodi's own
# AirPlay (the old, audio-only kind, which can't group or go in Home) is switched off while it's on: only one may
# answer. The remote's Apple TV look-alike (_companion-link on port 49500) uses none of AirPlay's ports.
#
# The TV's sound: Kodi and the speaker play through the same HDMI output, and only one can hold it at a time.
#   - Kodi lets go of it whenever it isn't playing: "Keep audio device alive" (audiooutput.streamsilence) goes to Off
#     while the speaker is on, and its old value comes back when the speaker is turned off.
#   - The speaker lets go of it when an AirPlay session ends (shairport-sync's default).
#   - mediaCENTER starting a video while AirPlay holds it: the speaker is restarted, which ends the AirPlay session
#     and frees the output, then the video starts (make_room, called by mc_player before Kodi plays).
# Only the Pi can show whether this hand-over works on its HDMI sound; see the test list in the 0.4.9.9 handoff.

import json
import os
import re
import shutil
import subprocess
import time

CONTAINER = "mediacenter-airplay"
IMAGE = "mikebrady/shairport-sync:5.6.3"  # Docker Hub, 2026-11-10: amd64, arm64, arm/v7 (a Pi 3 on LibreELEC is arm/v7)
DOCKER_ADDON = "service.system.docker"
DEFAULT_NAME = "mediaCENTER TV"

ON = "airplay_speaker"          # "true" while the speaker is on
NAME = "airplay_name"           # what iPhones show ("mediaCENTER TV" when empty)
KEPT = "airplay_kept_silence"   # Kodi's "Keep audio device alive" before the speaker turned it off
DEVICE = "airplay_device"       # the sound output the speaker was started with

PULL_TIMEOUT = 900   # the first download on a Pi 3 over Wi-Fi
RUN_TIMEOUT = 120
QUICK = 30
FREE_WAIT = 4.0      # seconds make_room waits for the output once the speaker has been restarted

SAID = {
    "on": "The AirPlay speaker is on. On your iPhone, open Music, tap AirPlay and choose “%s”.",
    "off": "The AirPlay speaker is off.",
    "needs_docker": "The AirPlay speaker needs Docker, from LibreELEC's own add-ons.",
    "no_device": "The AirPlay speaker plays through the TV's HDMI sound. Choose the TV under Audio > Sound output, then try again.",
    "no_download": "The AirPlay speaker couldn't be downloaded. Check the internet connection and try again.",
    "failed": "The AirPlay speaker didn't start. Restart the box and try again.",
    "busy": "AirPlay stopped so this can play.",
}


def shell(args, timeout):
    """(exit code, text) of a command; (-1, "") when it couldn't run or took too long. Nothing it prints is logged."""
    try:
        done = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout, text=True)
    except (OSError, subprocess.SubprocessError, ValueError):
        return -1, ""
    return done.returncode, done.stdout or ""


def docker_binary(addons, which=shutil.which):
    """The docker command: the one in LibreELEC's Docker add-on, else one on the PATH; None when there's neither."""
    path = os.path.join(str(addons), DOCKER_ADDON, "bin", "docker")
    if os.path.isfile(path) and os.access(path, os.X_OK):
        return path
    return which("docker")


def alsa_device(kodi_value):
    """Kodi's sound output (audiooutput.audiodevice) as the ALSA device the speaker plays to, or None when Kodi isn't
    using ALSA (PulseAudio, Bluetooth). "ALSA:hdmi:CARD=vc4hdmi,DEV=0" -> "hdmi:CARD=vc4hdmi,DEV=0". Kodi writes "@"
    for its own way to the card; HDMI then goes through ALSA's hdmi device (it converts the sound for the Pi's HDMI)."""
    value = str(kodi_value or "")
    if not value.startswith("ALSA:"):
        return None
    device = value[5:]
    if not device or device == "default":
        return "default"
    if device.startswith("@"):
        rest = device[1:]
        base = "hdmi" if "hdmi" in rest.lower() else "plughw"
        device = base + rest
    return device if re.fullmatch(r"[A-Za-z0-9_@:=,.\-]+", device) else None


def output_of(device):
    """(card, device number) for /proc/asound, from an ALSA name: "hdmi:CARD=vc4hdmi,DEV=0" -> ("vc4hdmi", 0),
    "hw:1,0" -> ("card1", 0). None when it can't be told (then make_room does nothing)."""
    if not device or ":" not in device:
        return None
    args = device.split(":", 1)[1]
    named = dict(p.split("=", 1) for p in args.split(",") if "=" in p)
    plain = [p for p in args.split(",") if "=" not in p]
    card = named.get("CARD") or (plain[0] if plain else "")
    dev = named.get("DEV") or (plain[1] if len(plain) > 1 else "0")
    if not card or not re.fullmatch(r"[A-Za-z0-9_\-]+", card):
        return None
    try:
        dev = int(dev)
    except ValueError:
        return None
    return ("card%s" % card if card.isdigit() else card), dev


def holder(output, root="/proc/asound"):
    """The process playing on that output now, or None when nothing is (or it can't be read)."""
    if not output:
        return None
    path = os.path.join(root, output[0], "pcm%dp" % output[1], "sub0", "status")
    try:
        with open(path) as f:
            text = f.read()
    except OSError:
        return None
    found = re.search(r"owner_pid\s*:\s*(\d+)", text)
    return int(found.group(1)) if found else None


def clean_name(name):
    """A name iPhones can show: letters, digits, spaces and a little punctuation, at most 40 characters."""
    name = re.sub(r"[^A-Za-z0-9 '._\-]", "", str(name or "")).strip()[:40].strip()
    return name or DEFAULT_NAME


def run_args(docker, name, device):
    """docker run for the speaker. --net host: AirPlay finds it like any speaker on the Wi-Fi, and its clock helper
    (NQPTP) has ports 319 and 320; --device /dev/snd: the TV's sound; --restart: it comes back after every restart."""
    return [docker, "run", "-d", "--name", CONTAINER, "--restart", "unless-stopped", "--net", "host",
            "--device", "/dev/snd", "--cap-add", "SYS_NICE", IMAGE, "-a", clean_name(name), "--", "-d", device]


def kodi_rpc(method, params):
    import xbmc
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    except (RuntimeError, ValueError, TypeError):
        return None
    return None if not isinstance(answer, dict) or "error" in answer else answer.get("result")


class Speaker(object):
    """addon: the app's settings (getSetting/setSetting). rpc(method, params): Kodi's JSON-RPC, the result or None.
    run(args, timeout): (exit code, text). docker: the docker command or None. pid: Kodi's own process."""

    def __init__(self, addon, docker, rpc=kodi_rpc, run=shell, sleep=time.sleep, clock=time.time, pid=None,
                 asound="/proc/asound", log=None):
        self.addon, self.docker, self.rpc, self.sh = addon, docker, rpc, run
        self.sleep, self.clock = sleep, clock
        self.pid = os.getpid() if pid is None else pid
        self.asound = asound
        self.log = log or (lambda line: None)

    # -- what it is --

    def wanted(self):
        return self.addon.getSetting(ON) == "true"

    def name(self):
        return clean_name(self.addon.getSetting(NAME))

    def state(self):
        """"on" (playing or ready), "stopped", "missing" (never set up) or "no_docker"."""
        if not self.docker:
            return "no_docker"
        code, out = self.sh([self.docker, "inspect", "-f", "{{.State.Running}}", CONTAINER], QUICK)
        if code != 0:
            return "missing"
        return "on" if out.strip() == "true" else "stopped"

    def kodi_device(self):
        found = self.rpc("Settings.GetSettingValue", {"setting": "audiooutput.audiodevice"})
        return found.get("value") if isinstance(found, dict) else None

    # -- turning it on and off --

    def turn_on(self):
        """Sets up and starts the speaker. (what happened, what to tell the viewer): "on", "needs_docker",
        "no_device", "no_download" or "failed"."""
        if not self.docker:
            return "needs_docker", SAID["needs_docker"]
        device = alsa_device(self.kodi_device())
        if not device:
            return "no_device", SAID["no_device"]
        self.rpc("Settings.SetSettingValue", {"setting": "services.airplay", "value": False})
        self.let_go()
        said = self.start(device)
        if said != "on":
            return said, SAID[said]
        self.addon.setSetting(ON, "true")
        self.addon.setSetting(DEVICE, device)
        self.log("AirPlay speaker on")
        return "on", SAID["on"] % self.name()

    def turn_off(self):
        if self.docker:
            self.sh([self.docker, "rm", "-f", CONTAINER], QUICK)
        kept = self.addon.getSetting(KEPT)
        if kept not in ("", None):
            try:
                self.rpc("Settings.SetSettingValue", {"setting": "audiooutput.streamsilence", "value": int(kept)})
            except ValueError:
                pass
            self.addon.setSetting(KEPT, "")
        self.addon.setSetting(ON, "false")
        self.log("AirPlay speaker off")
        return "off", SAID["off"]

    def let_go(self):
        """Kodi lets go of the TV's sound when it isn't playing, so the speaker can have it. Its old setting is kept once."""
        found = self.rpc("Settings.GetSettingValue", {"setting": "audiooutput.streamsilence"})
        now = found.get("value") if isinstance(found, dict) else None
        if self.addon.getSetting(KEPT) in ("", None) and now is not None:
            self.addon.setSetting(KEPT, str(now))
        if now != 0:
            self.rpc("Settings.SetSettingValue", {"setting": "audiooutput.streamsilence", "value": 0})

    def start(self, device):
        """A fresh container (so a new name or output takes effect). "on", "no_download" or "failed"."""
        self.sh([self.docker, "rm", "-f", CONTAINER], QUICK)
        if self.sh([self.docker, "image", "inspect", IMAGE], QUICK)[0] != 0:
            if self.sh([self.docker, "pull", IMAGE], PULL_TIMEOUT)[0] != 0:
                self.log("AirPlay speaker: the download didn't work")
                return "no_download"
        if self.sh(run_args(self.docker, self.name(), device), RUN_TIMEOUT)[0] != 0:
            self.log("AirPlay speaker: it didn't start")
            return "failed"
        return "on"

    def ensure(self):
        """At start (the service, until it says True): a speaker that is on is running, with Kodi's current output.
        Docker starts with the box, sometimes after Kodi, so False means "look again later"."""
        if not self.wanted():
            return True
        if not self.docker:
            return False
        device = alsa_device(self.kodi_device())
        if not device:
            return True  # Kodi plays elsewhere now (Bluetooth): leave the speaker as it is
        state = self.state()
        if state == "on" and device == self.addon.getSetting(DEVICE):
            return True
        if state == "stopped" and device == self.addon.getSetting(DEVICE):
            return self.sh([self.docker, "start", CONTAINER], QUICK)[0] == 0
        if state == "no_docker":
            return False
        if self.start(device) != "on":
            return False
        self.addon.setSetting(DEVICE, device)
        return True

    # -- sharing the TV's sound --

    def make_room(self):
        """Before mediaCENTER plays: when the speaker is on and something other than Kodi holds the TV's sound (AirPlay
        playing), the speaker is restarted, which ends the AirPlay session, and this waits a moment for the output to
        be free. True when AirPlay was stopped (the player says so)."""
        if not self.wanted() or not self.docker:
            return False
        output = output_of(self.addon.getSetting(DEVICE) or alsa_device(self.kodi_device()))
        who = holder(output, self.asound)
        if who is None or who == self.pid:
            return False
        self.log("AirPlay is playing; stopping it for mediaCENTER")
        self.sh([self.docker, "restart", "-t", "1", CONTAINER], QUICK)
        end = self.clock() + FREE_WAIT
        while self.clock() < end:
            if holder(output, self.asound) in (None, self.pid):
                break
            self.sleep(0.2)
        return True


def speaker(addon, addons=None, log=None):
    """The box's speaker, with the real docker command and Kodi."""
    if addons is None:
        import xbmcvfs
        addons = xbmcvfs.translatePath("special://home/addons")
    return Speaker(addon, docker_binary(addons), log=log)
