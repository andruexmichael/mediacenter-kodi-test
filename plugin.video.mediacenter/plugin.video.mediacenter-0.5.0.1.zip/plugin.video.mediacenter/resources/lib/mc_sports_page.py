# mediaCENTER for Kodi: the Sports page and a game's page (0.4.9), the website's Sports (web-v27/js/views/sports.js and
# game-detail.js) drawn for a TV. Windows: mediacenter-sports.xml and mediacenter-game.xml (kodi/tools/sports_windows.py).
#
# Sports: "Sports" and "6 live now · 86 later today"; My Teams along the top (each team's next game, then Edit); the
# league chips; the games as team-colour cards, two across, in the website's order (live with close games first, then
# by start time, then finals); beside them the highlighted game with Watch now, its other channels and Game stats.
# OK on a card plays the best channel for it (the loading screen shows both teams); a final, or a game no channel in
# the lineup shows, opens its page instead. The data and every decision are in mc_sports (no Kodi there).

import threading
import time

import xbmc
import xbmcgui

import mc_logic as L
import mc_sports as S
import mc_views as V
import mc_pages as pages
from mc_api import SignedOut, ServerError
from mc_menu import Rail

BACK = (9, 10, 92, 247)
MOVES = (1, 2, 3, 4, 5, 6)
TEAMS, CHIPS, CARDS = 60, 70, 50
WATCH, CHANNELS, STATS = 80, 81, 82
REFRESH = 60  # seconds between score updates while the page is open and a game is live


def accent():
    import mc_theme as T
    return T.color("accent", V.WINDOW)


def wording():
    return (V.experience().get("sports") or {})


def load(api):
    """The games for the Sports page, the Guide's Sports group, the scores over the player and the alerts:
    /api/sports/active joined with /api/roku/sports. My Teams from the account (/api/prefs), else the Roku answer's."""
    active = roku = None
    try:
        active = V.cached("sports-active", 30, lambda: api.get("/api/sports/active"))
    except (ServerError, OSError, ValueError):
        active = None
    try:
        roku = V.sports_answer(api)
    except (ServerError, OSError, ValueError):
        roku = None
    if active is None and roku is None:
        raise ServerError("sports")
    mine = my_teams(api)
    if mine is None:
        mine = list((roku or {}).get("myTeams") or [])
    return S.join(active, roku, mine), mine


def my_teams(api):
    try:
        prefs = (api.get("/api/prefs") or {}).get("prefs") or {}
    except (ServerError, OSError, ValueError):
        return None
    value = (prefs.get("myTeams") or {}).get("value") if isinstance(prefs.get("myTeams"), dict) else None
    return [str(k) for k in value] if isinstance(value, list) else None


def save_teams(api, mine):
    api.call("PUT", "/api/prefs", body={"prefs": {"myTeams": {"value": list(mine), "updatedAt": int(time.time() * 1000)}}})
    V.drop_cache("sports")  # the Roku answer marks "mine" games; ask again


def for_loading(game):
    """The game as the player's loading screen reads it (mc_logic.game_loading): the league's name, small logos."""
    g = dict(game, league=game.get("leagueLabel") or game.get("league") or "")
    g["teams"] = [dict(t, logo=S.small_logo(t.get("logo"), 200) or t.get("logo") or "") for t in game.get("teams") or []]
    return g


def play(api, game, channel=None):
    """Play a game's channel (the best one unless another is given). False when the lineup has none."""
    chans = game.get("channels") or []
    ch = channel or (chans[0] if chans else None)
    if not ch:
        return False
    import mc_player as P
    P.play_channel(api, ch["id"], S.channel_name(ch.get("name")), [a for a in L.alt_ids(ch).split(",") if a],
                   game.get("title") or S.title(game), game=for_loading(game))
    return True


def open_game(api, game, win=None):
    """OK on a game anywhere in Sports: play it when it is on (or soon) and a channel has it; otherwise its page."""
    if game.get("state") != "post" and play(api, game):
        if win is not None:
            from mc_app import refocus
            refocus(win, win.getFocusId() or CARDS)
        return
    GamePage.open(api, game)


# ---- what the cards hold ----------------------------------------------------------------------------------------------

def card(game, section="", now=None):
    away, home = S.sides(game)
    li = xbmcgui.ListItem(game.get("title") or S.title(game), S.status(game, now))
    props = {"id": str(game.get("id")), "section": section, "tag": S.tag(game, now), "status": S.status(game, now),
             "where": S.where(game), "league": game.get("leagueLabel") or "", "ball": S.ball(game),
             "live": "1" if game.get("state") == "in" else "", "close": "1" if S.close_game(game) else "",
             "mine": "1" if game.get("mine") else "", "channel": "1" if game.get("channels") else "",
             "more": "1" if len(game.get("channels") or []) > 1 else "",
             "c1": S.zone_color(away) if away else "FF3A3A44", "c2": S.zone_color(home) if home else "FF3A3A44"}
    for side, t in (("away", away), ("home", home)):
        t = t or {}
        props.update({side + ".name": t.get("name") or "", side + ".abbr": (t.get("abbr") or "")[:4],
                      side + ".score": str(t.get("score") or "") if game.get("state") != "pre" else "",
                      side + ".logo": S.small_logo(t.get("logo"), 96)})
    li.setProperties(props)
    return li


def team_chip(key, games, now=None):
    t = S.team_of(games, key)
    g = S.next_game(games, key)
    li = xbmcgui.ListItem(t["name"], S.chip_text(g, now))
    li.setProperties({"kind": "team", "key": key, "logo": S.small_logo(t.get("logo"), 96), "game": str(g.get("id")) if g else "",
                      "live": "1" if g and g.get("state") == "in" else "", "abbr": key.split("|")[-1][:4]})
    return li


# ---- the page ---------------------------------------------------------------------------------------------------------

class SportsPage(Rail, xbmcgui.WindowXMLDialog):
    ready = False
    goto_name = "sports"
    rail_key, rail_home = "sports", 50  # the menu on the left (mc_menu, 0.4.9.6): Left from the chips or the cards

    @classmethod
    def open(cls, api):
        w = cls("mediacenter-sports.xml", V.HERE, "Default", "1080i")
        w.api = api
        pages.modal(w)
        w.closing = True
        del w

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started, self.closing = True, False
        self.rail_setup("sports")
        self.filter, self.games, self.mine, self.order = "all", [], [], []
        self.setProperty("heading", "Sports")
        self.reload(first=True)
        self.ready = True
        t = threading.Thread(target=self.keep_up)
        t.daemon = True
        t.start()

    def reload(self, first=False):
        try:
            self.games, self.mine = load(self.api)
            self.clearProperty("empty")
        except SignedOut:
            self.games = []
            self.setProperty("empty", "Your session ended. Sign in again from Settings.")
        except (ServerError, OSError):
            self.games = []
            self.setProperty("empty", "Couldn't load the games right now. Try again in a moment.")
        self.setProperty("counts", S.counts(self.games) if self.games else "")
        self.draw_teams()
        self.draw_chips()
        self.draw_games()
        if first:
            self.setFocusId(CARDS if self.order else (TEAMS if self.mine else CHIPS))

    def draw_teams(self):
        control = self.getControl(TEAMS)
        control.reset()
        items = [team_chip(k, self.games) for k in self.mine]
        edit = xbmcgui.ListItem("Edit", "Pick your teams")
        edit.setProperty("kind", "edit")
        control.addItems(items + [edit])
        self.setProperty("teams.note", "" if self.mine else "Pick your teams with Edit. Their games show here first.")

    def draw_chips(self):
        self.chips = S.chips(self.games)
        if self.filter not in [k for k, _ in self.chips]:
            self.filter = "all"
        control = self.getControl(CHIPS)
        control.reset()
        for k, name in self.chips:
            li = xbmcgui.ListItem(name)
            li.setProperties({"key": k, "active": "1" if k == self.filter else ""})
            control.addItem(li)

    def draw_games(self):
        control = self.getControl(CARDS)
        control.reset()
        self.order = []
        now = time.time()
        for title, count, games in S.sections(self.games, self.filter, self.mine, now=now):
            for g in games:
                control.addItem(card(g, "%s%s%d" % (title, S.DOT, count), now))
                self.order.append(g)
        if not self.order and self.games:
            mine = self.filter == "mine"
            self.setProperty("empty", ("No games for your teams today. " + ("Pick your teams with Edit above." if not self.mine else "Check back closer to game time."))
                             if mine else "No games right now. Check back closer to game time.")
        elif self.games:
            self.clearProperty("empty")
        self.show_game()

    def focused(self):
        i = self.getControl(CARDS).getSelectedPosition()
        return self.order[i] if 0 <= i < len(self.order) else None

    def show_game(self):
        """The panel beside the cards: the highlighted game, and its channels (the first is Watch now)."""
        g = self.focused()
        chans = (g or {}).get("channels") or []
        listing = self.getControl(CHANNELS)
        listing.reset()
        for ch in chans[1:6]:
            li = xbmcgui.ListItem(S.channel_name(ch.get("name")), str(ch.get("num") or ""))
            li.setProperty("why", L.why_line(ch.get("why")) if ch.get("why") else "")
            listing.addItem(li)
        if g is None:
            for k in ("game.title", "game.status", "game.where", "game.league", "game.note", "game.watch"):
                self.clearProperty(k)
            return
        self.setProperty("game.title", g.get("title") or "")
        self.setProperty("game.status", S.status(g))
        self.setProperty("game.league", g.get("leagueLabel") or "")
        self.setProperty("game.where", S.where(g))
        self.setProperty("game.watch", "1" if chans and g.get("state") != "post" else "")
        self.setProperty("game.note", "" if chans or g.get("state") == "post" else S.no_channel_message(g, wording()))

    # -- the scores keep up while the page is open --

    def keep_up(self):
        monitor = xbmc.Monitor()
        while not self.closing and not monitor.waitForAbort(REFRESH):
            if self.closing:
                return
            if any(g.get("state") == "in" for g in self.games) and not xbmc.getCondVisibility("Player.HasVideo"):
                self.update_scores()

    def update_scores(self):
        """New scores into the cards already shown, so the highlight stays where it is."""
        V.drop_cache("sports-active")
        try:
            games, _ = load(self.api)
        except (ServerError, SignedOut, OSError):
            return
        by = dict((str(g.get("id")), g) for g in games)
        control = self.getControl(CARDS)
        for i, old in enumerate(list(self.order)):
            g = by.get(str(old.get("id")))
            if g is None or i >= control.size():
                continue
            fresh = card(g, control.getListItem(i).getProperty("section"))
            li = control.getListItem(i)
            for key in ("tag", "status", "where", "ball", "live", "close", "away.score", "home.score"):
                li.setProperty(key, fresh.getProperty(key))
            li.setLabel2(fresh.getLabel2())
            self.order[i] = g
        self.games = games
        self.setProperty("counts", S.counts(games))
        self.show_game()

    # -- input --

    def onClick(self, control_id):
        if self.rail_click(control_id):
            return
        if control_id == CARDS or control_id == WATCH:
            g = self.focused()
            if g is not None:
                return open_game(self.api, g, self)
        if control_id == CHANNELS:
            g = self.focused()
            i = self.getControl(CHANNELS).getSelectedPosition()
            chans = (g or {}).get("channels") or []
            if g is not None and 0 <= i + 1 < len(chans):
                play(self.api, g, chans[i + 1])
                from mc_app import refocus
                return refocus(self, CHANNELS)
        if control_id == STATS:
            g = self.focused()
            if g is not None:
                return GamePage.open(self.api, g)
        if control_id == CHIPS:
            i = self.getControl(CHIPS).getSelectedPosition()
            if 0 <= i < len(self.chips):
                self.filter = self.chips[i][0]
                self.draw_chips()
                self.getControl(CHIPS).selectItem(i)
                self.draw_games()
                if self.order:
                    self.setFocusId(CARDS)
            return
        if control_id == TEAMS:
            li = self.getControl(TEAMS).getSelectedItem()
            if li is None:
                return
            if li.getProperty("kind") == "edit":
                if pick_teams(self.api, self.mine) is not None:
                    self.reload()
                return
            g = next((x for x in self.games if str(x.get("id")) == li.getProperty("game")), None)
            if g is None:
                return V.notify("No game for the %s today." % li.getLabel())
            return open_game(self.api, g, self)

    def onAction(self, action):
        a = action.getId()
        if self.rail_action(a):
            return
        if a in BACK:
            self.closing = True
            return self.close()
        if a in MOVES and self.ready and self.getFocusId() == CARDS:
            self.show_game()


def pick_teams(api, mine):
    """Edit (the website's My Teams editor): a league, then its teams with the picked ones ticked. Saved to the
    account at once, so the website and the Apple apps have them too. Returns the new list, or None if unchanged."""
    dialog = xbmcgui.Dialog()
    i = dialog.select("My Teams: pick a league", S.TEAM_LEAGUES)
    if i is None or i < 0:
        return None
    league = S.TEAM_LEAGUES[i]
    try:
        teams = [t for t in (api.get("/api/sports/teams", league=league) or {}).get("teams") or [] if isinstance(t, dict) and t.get("key")]
    except (ServerError, SignedOut, OSError, ValueError):
        teams = []
    if not teams:
        V.notify("Couldn't load the %s teams right now." % league)
        return None
    keys = [str(t["key"]) for t in teams]
    picked = dialog.multiselect("My Teams: %s" % league, [t.get("full") or t.get("name") or t["key"] for t in teams],
                                preselect=[n for n, k in enumerate(keys) if k in mine])
    if picked is None:
        return None
    others = [k for k in mine if not k.startswith(league + "|")]
    new = sorted(set(others + [keys[n] for n in picked]))
    if new == sorted(mine):
        return None
    try:
        save_teams(api, new)
    except (ServerError, SignedOut, OSError):
        V.notify("Couldn't save My Teams right now.")
        return None
    V.notify("My Teams saved")
    return new


# ---- a game's page (/api/sports/game) ---------------------------------------------------------------------------------

TABS = 100  # 101..104
ROWS_LIST, WATCH_GAME = 50, 110
GAME_REFRESH = 30
FIELD = {"left": 260, "width": 1400}  # the flat field's playing area on screen (between the goal lines)


class GamePage(xbmcgui.WindowXMLDialog):
    @classmethod
    def open(cls, api, game, over=False):
        """over: opened over the picture (scores while watching), so the page shows while the video plays."""
        w = cls("mediacenter-game.xml", V.HERE, "Default", "1080i")
        w.api, w.game, w.over = api, game, over
        pages.modal(w)
        w.closing = True
        del w

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started, self.closing = True, False
        self.tab, self.detail = "overview", None
        if getattr(self, "over", False):
            self.setProperty("over", "1")
        g = self.game
        away, home = S.sides(g)
        self.setProperty("title", g.get("title") or S.title(g))
        self.setProperty("league", g.get("leagueLabel") or "")
        for side, t in (("away", away), ("home", home)):
            t = t or {}
            self.setProperty(side + ".name", t.get("name") or "")
            self.setProperty(side + ".abbr", (t.get("abbr") or "")[:4])
            self.setProperty(side + ".logo", S.small_logo(t.get("logo"), 200))
            self.setProperty(side + ".color", S.zone_color(t) if t else "FF3A3A44")
        for n, (key, name) in enumerate(S.GAME_TABS, 1):
            self.setProperty("tab.%d" % n, name)
        self.setProperty("watch", "1" if g.get("channels") and g.get("state") != "post" else "")
        self.fetch()
        self.setFocusId(101)
        t = threading.Thread(target=self.keep_up)
        t.daemon = True
        t.start()

    def fetch(self):
        g = self.game
        try:
            self.detail = self.api.get("/api/sports/game", league=g.get("league"), id=str(g.get("id"))) or {}
        except (ServerError, SignedOut, OSError, ValueError):
            self.detail = None
        self.draw()

    def draw(self):
        d = self.detail or {}
        g = self.game
        teams = d.get("teams") or []
        state = d.get("state") or g.get("state")
        away, home = S.sides(dict(g, teams=teams)) if len(teams) >= 2 else S.sides(g)
        for side, t in (("away", away), ("home", home)):
            t = t or {}
            self.setProperty(side + ".score", str(t.get("score") or "") if state != "pre" else "")
            self.setProperty(side + ".record", t.get("record") or "")
        self.setProperty("status", S.status(dict(g, state=state, detail=d.get("detail") or g.get("detail"))))
        for n, (key, _) in enumerate(S.GAME_TABS, 1):
            self.setProperty("tab.%d.bg" % n, accent() if key == self.tab else "24FFFFFF")
        control = self.getControl(ROWS_LIST)
        control.reset()
        rows = S.game_rows(d, self.tab) if self.detail else []
        for label, a, b, kind in rows:
            li = xbmcgui.ListItem(label)
            li.setProperties({"a": a, "b": b, "kind": kind})
            control.addItem(li)
        w = wording()
        if self.detail is None:
            self.setProperty("empty", w.get("detailsUnavailable") or "Game details aren't available right now.")
        elif not rows:
            self.setProperty("empty", w.get("noDetails") or "ESPN has no details for this game yet.")
        else:
            self.clearProperty("empty")
        self.draw_field(S.field_marks(d))

    def draw_field(self, marks):
        if not marks:
            for k in ("field", "field.down", "field.last"):
                self.clearProperty(k)
            return
        self.setProperty("field", "1")
        self.setProperty("field.down", S.DOT.join(p for p in [marks["possession"], marks["down"]] if p))
        self.setProperty("field.last", marks["last"])
        f = FIELD
        try:
            self.getControl(120).setPosition(int(f["left"] + marks["ball"] / 100.0 * f["width"]) - 14, 14)
            self.getControl(121).setPosition(int(f["left"] + marks["first"] / 100.0 * f["width"]) - 2, 0)
        except (RuntimeError, TypeError):
            pass

    def keep_up(self):
        monitor = xbmc.Monitor()
        while not self.closing and not monitor.waitForAbort(GAME_REFRESH):
            if self.closing:
                return
            if (self.detail or {}).get("state", self.game.get("state")) == "in" and not xbmc.getCondVisibility("Player.HasVideo"):
                self.fetch()

    def onClick(self, control_id):
        if 101 <= control_id <= 100 + len(S.GAME_TABS):
            self.tab = S.GAME_TABS[control_id - 101][0]
            return self.draw()
        if control_id == WATCH_GAME:
            if play(self.api, self.game):
                from mc_app import refocus
                return refocus(self, WATCH_GAME)
            return V.notify(S.no_channel_message(self.game, wording()))

    def onAction(self, action):
        if action.getId() in BACK:
            self.closing = True
            self.close()
