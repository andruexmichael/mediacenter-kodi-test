# mediaCENTER for Kodi 0.4.9.3: a show's episodes as the website draws them on a TV-sized screen, and an episode's own
# page.
#
# The episode row on a show's page (mc_app.TitlePage, list 402) scrolls sideways like the website's episode cards
# (web-v27/js/views/vod.js, Card in a row-scroll): the episode's still (the show's backdrop when it has none), "N. name"
# and "S1 E2 · 45 min · Mar 3, 2024" under it, a tag on the picture (Not out yet, Airs Mar 3, Watched, Up next) and how
# far it was watched. Descriptions are cut short there, so a press and hold (or the menu or Info button) opens the
# episode in full. 0.4.9.9: that is 0.4.9.6's hold sheet (mc_hold.episode_sheet, the design plan), which now ends with
# Choose a version as 0.4.9.3's own episode page did; that page and its window are not brought back.
#
# Kodi turns a held OK into its context menu on most remotes; the iPhone remote built into mediaCENTER
# (service.mediacenter.remote) sends Kodi's context menu when OK is held.

import datetime
import re

import xbmcgui

import mc_logic as L
import mc_views as V

ROW_STILL = "w300"



def number(x):
    try:
        return int(x)
    except (TypeError, ValueError):
        return 0


def watched(history, tmdb, season):
    """{episode: (finished, position, duration)} for one season of a show, from /api/history rows."""
    out = {}
    for h in history or []:
        if not isinstance(h, dict) or str(h.get("seriesId") or "") != "tmdb-%s" % tmdb or number(h.get("season")) != number(season):
            continue
        try:
            out[number(h.get("episode"))] = (bool(h.get("finished")), float(h.get("position") or 0), float(h.get("duration") or 0))
        except (TypeError, ValueError):
            continue
    return out


def episode_facts(e, season, today=None):
    """What one episode from /meta/episodes (or /api/roku/episodes) shows: its number, name, the facts line, whether it
    is out yet and the tag for a later one."""
    today = today or datetime.date.today().isoformat()
    num = number(e.get("n") or e.get("episode"))
    air = str(e.get("air") or "")[:10]
    later = bool(air) and air > today
    facts = ["S%d E%d" % (season, num)]
    if e.get("runtime"):
        facts.append("%s min" % e["runtime"])
    if air:
        facts.append(("Airs " if later else "") + L.date_text(air))
    return {"n": num, "name": e.get("name") or "Episode %d" % num, "air": air, "later": later, "facts": L.DOT.join(facts),
            "runtime": e.get("runtime") or "", "overview": e.get("overview") or "", "still": e.get("still") or ""}


def episode_items(eps, season, backdrop="", history=(), tmdb="", target=None, today=None):
    """The row's ListItems: label "N. name", label2 the facts line, the still (the show's backdrop when the episode has
    none), a tag (Not out yet / Airs Mar 3 / Watched / Up next), how far it was watched, and the rest for the page.
    target: (season, episode) that the show's Play button starts."""
    seen = watched(history, tmdb, season)
    out = []
    for e in eps or []:
        if not isinstance(e, dict):
            continue
        f = episode_facts(e, season, today)
        done, position, duration = seen.get(f["n"], (False, 0.0, 0.0))
        part = not done and position >= 30 and duration > position
        if f["later"]:
            tag = ("Airs " + L.date_text(f["air"]).split(",")[0]) if f["air"] else "Not out yet"
        elif done:
            tag = "Watched"
        elif target and tuple(target) == (season, f["n"]):
            tag = "Resume" if part else "Up next"
        else:
            tag = ""
        li = xbmcgui.ListItem("%d. %s" % (f["n"], f["name"]), f["facts"])
        still = L.picture(f["still"], ROW_STILL) if f["still"] else ""
        li.setArt({"thumb": still or L.picture(backdrop, "w780")})
        V.set_info(li, {"title": f["name"], "mediatype": "episode", "season": season, "episode": f["n"]},
                   (position, duration) if part else None)
        li.setProperties({"episode": str(f["n"]), "plot": f["overview"][:220], "overview": f["overview"], "name": f["name"],
                          "air": f["air"], "runtime": str(f["runtime"]), "still": f["still"], "later": "1" if f["later"] else "",
                          "tag": tag, "progress": str(int(100 * position / duration)) if part else ""})
        out.append(li)
    return out
