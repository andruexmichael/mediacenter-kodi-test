# mediaCENTER for Kodi: subtitles drawn by the player page itself (0.4.9.3).
#
# Why this exists (the owner, 2026-11-26: "it doesn't look like subtitles are working", Pi 3, Kodi 21.3):
#   - Kodi draws every subtitle (a track in the version, or a file it was given) in its "overlay" step,
#     CRenderManager::Render(..., gui=true) -> m_overlays.Render.
#   - With hardware decoding drawn "Direct to plane" (the Pi), only Kodi's own full-screen video window takes that step
#     (CGUIWindowFullScreen::Render calls Render(true, 255), gui=true). A video control in a page of our own does not:
#     CGUIVideoControl::Render only clears a hole in the menus when the video is on its own layer
#     (IsRenderingVideoLayer), and its RenderEx calls Render(false, 255, false), the picture without the overlay.
#     (Kodi 21.3-Omega, xbmc/guilib/GUIVideoControl.cpp and VideoRenderers/RenderManager.cpp.)
#   - mediaCENTER plays in its own player page (windowed, since 0.4.5), so on the Pi Kodi turned subtitles on and
#     drew nothing. On boxes that draw video with the menus (EGL, Windows, a Mac) the video control does draw them.
#
# What this does: on a box that draws video on its own layer (mc_picture.own_layer), the player page reads the SRT or
# WebVTT file itself and shows the line due now in labels of its own (mediacenter-player.xml, Window.Property(subs.N)),
# a few times a second, over the picture like the rest of the page. Subtitles found online are such files; tracks
# inside the version can't be read from Python, so on those boxes the same language is found online instead.
#
# Kept free of Kodi so it can be tested: the page (setProperty / clearProperty), the time and the clock come in.

import bisect
import re
import threading
import time

try:
    from html import unescape
except ImportError:  # pragma: no cover
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape

LINES = 3  # labels in the player page, filled from the bottom (subs.1 is the lowest)
STEP = 0.1  # seconds between looks at the time
# Characters a line holds before it is wrapped, for each size (JetBrains Mono, a fixed-width font, 1760 wide; the
# sizes are kodi/tools/watching_windows.py SUB_FONTS).
WRAP = {"small": 80, "medium": 70, "large": 58, "xl": 44}
COLORS = {"yellow": "FFFFFF00"}
WHITE = "FFFFFFFF"

TIME = re.compile(r"(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[,.](\d{1,3})")
ARROW = re.compile(r"^\s*(\S+)\s*-->\s*(\S+)")


def seconds(stamp):
    """"00:01:02,500", "01:02.500" or "1:02:03.5" -> 62.5 seconds; None when it isn't a time."""
    m = TIME.match(str(stamp or "").strip())
    if not m:
        return None
    h, mi, s, ms = m.groups()
    return int(h or 0) * 3600 + int(mi) * 60 + int(s) + int((ms + "00")[:3]) / 1000.0


def decode(raw):
    if isinstance(raw, str):
        text = raw
    else:
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
    return text.replace("﻿", "").replace("\r\n", "\n").replace("\r", "\n")


def clean(line):
    """One line of a cue as Kodi label text: <i> and <b> become [I] and [B], other tags and {\\an8}-style codes go."""
    line = re.sub(r"\{\\[^}]*\}", "", line)
    line = re.sub(r"(?i)<\s*(/?)\s*i\s*>", lambda m: "[/I]" if m.group(1) else "[I]", line)
    line = re.sub(r"(?i)<\s*(/?)\s*b\s*>", lambda m: "[/B]" if m.group(1) else "[B]", line)
    line = re.sub(r"<[^>]*>", "", line)
    line = unescape(line).replace("\\N", " ").replace("\\n", " ")
    return re.sub(r"\s+", " ", line).strip()


def parse(raw):
    """SRT or WebVTT text -> [(start, end, [lines])], sorted by start. Cues with no words or no times are left out."""
    cues = []
    for block in re.split(r"\n\s*\n", decode(raw)):
        rows = [r for r in block.split("\n") if r.strip()]
        for i, row in enumerate(rows):
            m = ARROW.match(row)
            if not m:
                continue
            start, end = seconds(m.group(1)), seconds(m.group(2))
            words = [clean(r) for r in rows[i + 1:]]
            words = [w for w in words if w]
            if start is not None and end is not None and end > start and words:
                cues.append((start, end, words))
            break
    cues.sort(key=lambda c: c[0])
    return cues


def wrap(line, width):
    """A long line split at spaces so each piece fits `width` characters (formatting tags don't count)."""
    out, cur, n = [], [], 0
    for word in line.split(" "):
        size = len(re.sub(r"\[/?[IB]\]", "", word))
        if cur and n + 1 + size > width:
            out.append(" ".join(cur))
            cur, n = [], 0
        cur.append(word)
        n += size + (1 if n else 0)
    if cur:
        out.append(" ".join(cur))
    return out


def balance(lines):
    """Each line closes the [I] and [B] it opened and opens again what the line before left open, so Kodi shows each
    label the same way the cue meant (an italic sentence over two lines stays italic on both)."""
    out, open_tags = [], []
    for line in lines:
        text = "".join("[%s]" % t for t in open_tags) + line
        for m in re.finditer(r"\[(/?)([IB])\]", line):
            tag = m.group(2)
            if m.group(1):
                if tag in open_tags:
                    open_tags.remove(tag)
            elif tag not in open_tags:
                open_tags.append(tag)
        out.append(text + "".join("[/%s]" % t for t in reversed(open_tags)))
    return out


class Cues(object):
    def __init__(self, cues):
        self.cues = list(cues)
        self.starts = [c[0] for c in self.cues]
        self.longest = max([c[1] - c[0] for c in self.cues] or [0])

    def __len__(self):
        return len(self.cues)

    def at(self, t):
        """The lines due at `t` seconds (two cues that overlap are both shown, the earlier one on top)."""
        i = bisect.bisect_right(self.starts, t)
        lines = []
        j = i - 1
        while j >= 0 and self.cues[j][0] >= t - self.longest:
            start, end, words = self.cues[j]
            if start <= t < end:
                lines[0:0] = words
            j -= 1
        return lines


def layout(lines, size):
    """The cue's lines as the page's labels: wrapped for the size, at most LINES, the last ones kept (the bottom)."""
    width = WRAP.get(size, WRAP["medium"])
    out = []
    for line in balance(lines):
        out.extend(balance(wrap(line, width)) if len(re.sub(r"\[/?[IB]\]", "", line)) > width else [line])
    return out[-LINES:]


class Drawer(object):
    """Shows `cues` on `page` while `alive()`; `position()` is the player's time in seconds (None when it can't say).
    One drawer per subtitle file; stop() takes the words off."""

    def __init__(self, page, cues, position, alive=lambda: True, size="medium", style="shadow", sleep=time.sleep,
                 delay=0.0):
        self.page = page
        self.cues = cues if isinstance(cues, Cues) else Cues(cues)
        self.position = position
        self.alive = alive
        self.sleep = sleep
        self.delay = delay
        self.stopped = threading.Event()
        self.shown = None
        self.thread = None
        self.restyle(size, style)

    def restyle(self, size, style):
        self.size = size if size in WRAP else "medium"
        self.style = style or "shadow"
        self.page.setProperty("subs.size", self.size)
        self.page.setProperty("subs.style", self.style)
        self.page.setProperty("subs.color", COLORS.get(self.style, WHITE))
        self.shown = None  # drawn again in the new size on the next look

    def show(self, lines):
        rows = layout(lines, self.size)
        if rows == self.shown:
            return False
        self.shown = rows
        for k in range(1, LINES + 1):
            text = rows[-k] if k <= len(rows) else ""
            if text:
                self.page.setProperty("subs.%d" % k, text)
            else:
                self.page.clearProperty("subs.%d" % k)
        if rows:
            self.page.setProperty("subs.n", str(len(rows)))
        else:
            self.page.clearProperty("subs.n")
        return True

    def step(self):
        t = self.position()
        if t is None:
            return self.show([])
        return self.show(self.cues.at(t - self.delay))

    def run(self):
        while not self.stopped.is_set() and self.alive():
            try:
                self.step()
            except Exception:  # a player that went away mid-look: try again on the next look
                pass
            self.sleep(STEP)
        self.clear()

    def start(self):
        th = threading.Thread(target=self.run)
        th.daemon = True
        self.thread = th
        th.start()
        return th

    def stop(self):
        self.stopped.set()
        self.clear()

    def clear(self):
        self.shown = None
        for k in range(1, LINES + 1):
            self.page.clearProperty("subs.%d" % k)
        self.page.clearProperty("subs.n")


def load(path):
    """The cues in a downloaded subtitle file, or an empty list when it can't be read."""
    try:
        with open(path, "rb") as f:
            return Cues(parse(f.read()))
    except (OSError, IOError, ValueError):
        return Cues([])
