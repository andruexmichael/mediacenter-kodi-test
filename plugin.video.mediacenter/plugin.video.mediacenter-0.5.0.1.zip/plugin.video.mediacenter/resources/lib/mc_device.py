# mediaCENTER for Kodi: Settings, first-run setup, software updates and phone sign-in, as one full-screen page in
# mediaCENTER's own look (mediacenter-device.xml, written by kodi/tools/device_window.py). Rows down the left, what the
# highlighted row does on the right. Nothing here shows Kodi's own menus: Network and Remotes talk to the box's
# connection manager (mc_network), Audio to the player, Updates to the update list (mc_updates), Account to the phone
# sign-in (mc_pairing), the iPhone remote to the remote built into the box (mc_remote_link).

import datetime
import json
import os
import shutil
import threading
import time

import xbmc
import xbmcgui
import xbmcvfs

import mc_network as N
import mc_pairing as P
import mc_remote_link as R
import mc_theme as T
import mc_updates as U
import mc_views as V
import mc_pages as pages
from mc_api import ServerError

LIST = 50
BACK = (9, 10, 92, 247)
MOVES = (1, 2, 3, 4, 5, 6)
MIN_WAIT = 5  # seconds between asks while a phone sign-in waits (the server turns faster asks away)
REMOTE_LOOKS = 330  # looks, a second apart, while an iPhone pairing code is open (the code works for five minutes)
REMOTE_PATIENCE = 10  # looks before saying the remote didn't answer with a code
REMOTE_STARTING = 45  # the same, when the remote has only just been switched on and a slow box is still loading it
REMOTE_GRACE = 3  # looks after the code closes before saying it ran out (it also closes when an iPhone pairs)
WELCOME_SECTIONS = ("setup", "signin", "account", "network")  # signed out, these show the iPhone remote's code at the bottom


def spawn(work):
    """Work that waits on the network runs beside the page (tests run it in place)."""
    threading.Thread(target=work, daemon=True).start()


def pause(stop, seconds):
    """Waits between a phone sign-in's asks; True once the page has stopped waiting (tests don't wait)."""
    return stop.wait(seconds)


def watch(work):
    """The signed-out iPhone remote's code is watched beside the page for as long as the page shows (tests start it
    themselves)."""
    threading.Thread(target=work, daemon=True).start()


def welcome_pause(stop, seconds):
    return stop.wait(seconds)


def welcome_watch(show, alive):
    """Start mc_remote_link.Welcome for a signed-out screen; returns the Event that stops it. show(code, how)."""
    stop = threading.Event()
    watcher = R.Welcome(V.WINDOW, xbmcvfs.translatePath(R.CODE_FILE), show, lambda e, s: welcome_pause(e, s),
                        alive=alive, wake=lambda: R.switch_on(xbmc.executeJSONRPC))
    watch(lambda: watcher.run(stop))
    return stop


def rpc(method, params=None):
    answer = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}})))
    if "error" in answer:
        raise RuntimeError("unavailable")
    return answer.get("result")


def plain(value):
    """Text from elsewhere (a network's name, a device's name) shown as text, never as Kodi formatting."""
    return str(value).replace("[", "(").replace("]", ")")


def on_device():
    """The box itself (the mediaCENTER skin): no way out to Kodi. On Kodi on a computer, the app can still be closed."""
    return xbmc.getSkinDir() == "skin.mediacenter"


def online():
    address = xbmc.getIPAddress() or ""
    return bool(address) and not address.startswith(("127.", "0.", "169.254."))


# Playback and Live TV: each row steps through its choices (the add-on's own settings, never Kodi's settings screen).
PLAYBACK_CHOICES = {
    "max_res": ("max_res", [("1", "1080p"), ("0", "720p"), ("2", "4K")]),
    "hevc": ("hevc", [("auto", "Automatic"), ("true", "Yes"), ("false", "No")]),
    "guide_mini": ("guide_mini", [("true", "On"), ("false", "Off")]),
    "guide_channels": ("guide_channels", [("0", "Locals and Cable"), ("1", "Every channel")]),
    "opening_sound": ("opening_sound", [("true", "On"), ("false", "Off")]),
    "picture_render": ("picture_render", [("egl", "With the menus"), ("plane", "On its own layer")]),
}


def update_failed(error):
    """Why Check for updates didn't work, in words that say what to do (never the address or the error itself)."""
    text = str(error)
    if "changing" in text:  # the list and its checksum disagree: GitHub serves a new list for a few minutes after it's sent
        return "The update list was just changed. Try again in five minutes."
    if isinstance(error, ValueError):
        return "The update list couldn't be read. Try again later, or switch Updates from."
    return "Couldn't reach the update list. Check the connection and try again."


# design/experience.json settings.labels (kodi/tests/test_more.py checks they match); "off" is the Roku's words.
GUEST = {"label": "Guest Room",
         "about": "For someone else watching on this device. What they watch goes in the Guest Room's own Continue Watching, "
                  "kept apart from yours. Turn it off to go back to yours.",
         "on": "Guest Room is on on this device", "off": "Back to your own Continue Watching"}


CHOOSE_SOURCE = ("Choose a source before playing",  # design/experience.json settings.labels.chooseSource
                 "On: Play opens Choose a version, with the best match first.\nOff: Play starts the best match at once, and the next "
                 "source if one stalls; Choose a version stays on every title's page. Shared with the website and the apps.")


def render_follow():
    """Kodi's render method after the Picture setting (mc_picture.apply_render); never stops anything."""
    import mc_picture as MP
    try:
        return MP.apply_render(V.ADDON.getSetting("picture_render") or "egl", kodi_setting,
                               lambda key, value: rpc("Settings.SetSettingValue", {"setting": key, "value": value}), V.log)
    except Exception as e:  # a box without the setting, or Kodi saying no
        V.log("picture setting not applied: %s" % type(e).__name__)
        return "failed"


def kodi_setting(key):
    try:
        answer = rpc("Settings.GetSettingValue", {"setting": key})
    except (RuntimeError, ValueError, TypeError):
        return "?"
    return answer.get("value", "?") if isinstance(answer, dict) else "?"


def choice_now(action):
    """What a Playback or Live TV row is set to now, in words."""
    key, values = PLAYBACK_CHOICES[action]
    v = V.ADDON.getSetting(key) or values[0][0]
    return dict(values).get(v, values[0][1])


def playback_rows(api=None):
    """Playback and sources (0.4.9.3: Settings in groups): the picture, HEVC, the Picture setting (0.4.9.x) and links
    that failed on this box. 0.5.0.0: "Choose a source before playing" is back at the top (signed in), and Choose a
    version stays on every title's page."""
    rows = []
    if api is not None:  # 0.5.0.0: back, the owner never asked for Play to pick by itself
        import mc_subtitles as S
        rows.append((CHOOSE_SOURCE[0], "Off" if S.prefs(api).get("chooseSource") is False else "On", CHOOSE_SOURCE[1], "choose_source"))
    return rows + [("Best picture", choice_now("max_res"), "The best picture mediaCENTER looks for. A Raspberry Pi 3 plays up to 1080p.\n\nChoose to change it.", "max_res"),
            ("HEVC (H.265) versions", choice_now("hevc"), "Automatic leaves HEVC versions for last on a Raspberry Pi, which can't play them smoothly.\n\nChoose to change it.", "hevc"),
            ("Picture", choice_now("picture_render"), "With the menus: the picture goes where mediaCENTER puts it, so the Guide's mini "
             "player shows the whole channel.\nOn its own layer: Kodi's own way on a Raspberry Pi. Try it if films don't play "
             "smoothly.\n\nChanges from the next video.", "picture_render"),
            ("Try every link again", "", "mediaCENTER remembers links that didn't play on this box and leaves them out for a while. This forgets them.", "forget_links"),
            ("Back", "", "Back to Settings.", "back")]


def livetv_rows():
    """Live TV and Guide: the Guide's mini player and which channels it lists."""
    return [("Mini player in the Guide", choice_now("guide_mini"), "On: a channel chosen in the Guide plays in a small picture at the top; choose it again for full screen.\nOff: channels open full screen.", "guide_mini"),
            ("Channels in the Guide", choice_now("guide_channels"), "Every channel is slower on a Raspberry Pi.\n\nChoose to change it.", "guide_channels"),
            ("Back", "", "Back to Settings.", "back")]


# Settings' groups, in order (0.4.9.3, owner, 2026-11-26: "better organization for the settings"). Each opens its own
# list; Back returns to the group it came from. The stored settings are the same as before, so nothing resets.
SETTINGS_ORDER = ["account", "playback", "livetv", "appearance", "remotes", "box", "updates", "about"]
BOX = ["network", "audio", "power"]  # This box: what the box itself does


class DevicePage(xbmcgui.WindowXML):
    """section: settings (the default), setup (first run), account (sign in or out), signin (the phone sign-in), updates.
    The result says what changed: "signed_in", "signed_out", "exit" (Exit mediaCENTER, off the box only), "update"."""

    @classmethod
    def open(cls, api, section=None, first_run=False):
        w = cls("mediacenter-device.xml", V.HERE, "Default", "1080i")
        w.api, w.first_run = api, first_run
        w.start_section = section or ("setup" if first_run else "settings")
        w.goto_blocks = first_run or w.start_section in ("setup", "signin")  # the TV button waits for these to finish
        pages.modal(w)
        result = w.result
        del w
        return result

    # -- life --

    def onInit(self):
        if getattr(self, "ready", False):
            return
        self.ready = True
        self.result = ""
        self.rows, self.section, self.busy, self.plan = [], "", False, None
        self.closing = threading.Event()
        self.pairing = None  # the code being waited on: {"deviceCode", ...}
        self.remote_watch = None  # while an iPhone pairing code shows: the Event that stops watching it
        self.welcome = None  # while a signed-out screen shows the iPhone remote's code (0.4.9.3): the Event that stops it
        self.profile = xbmcvfs.translatePath(V.ADDON.getAddonInfo("profile"))
        self.addons = xbmcvfs.translatePath("special://home/addons")
        self.show(self.start_section)

    def close(self):
        self.closing.set()
        self.stop_pairing()
        self.stop_remote()
        self.stop_welcome()
        xbmcgui.WindowXML.close(self)

    def stop_pairing(self):
        if self.pairing:
            self.pairing["stop"].set()
            self.pairing = None
            P.forget(self.profile)
        for k in ("qr", "code", "address"):
            self.clearProperty(k)

    # -- drawing --

    def display(self, heading, rows, subheading="", status="", focus=0):
        """rows: (label, value, detail, action). value shows under the label; detail on the right."""
        if self.closing.is_set():
            return
        self.rows = rows
        self.setProperty("heading", heading)
        self.setProperty("subheading", subheading)
        self.setProperty("status", status)
        control = self.getControl(LIST)
        control.reset()
        control.addItems([xbmcgui.ListItem(r[0], r[1]) for r in rows])
        if rows:
            control.selectItem(min(focus, len(rows) - 1))
            self.setProperty("detail", rows[min(focus, len(rows) - 1)][2])
        self.setFocusId(LIST)

    def status(self, text):
        if not self.closing.is_set():
            self.setProperty("status", text)

    def version(self):
        return V.ADDON.getAddonInfo("version") or ""

    def update_waiting(self):
        """A newer mediaCENTER that's installed but not running yet (Kodi updated it while the app was open), or ''."""
        return U.waiting(V.RUNNING or self.version(), U.installed(self.addons))

    def channel(self):
        return V.ADDON.getSetting("update_channel") or U.default_channel(U.installed(self.addons))

    def show(self, section, focus=0):
        if section not in ("account", "signin"):
            self.stop_pairing()
        if section != "iphone":
            self.stop_remote()
        if section in WELCOME_SECTIONS and not self.api.signed_in:
            self.start_welcome()
        else:
            self.stop_welcome()
        self.section = section
        self.setProperty("step", "")
        signed = self.api.signed_in
        who = plain(self.api.username) if signed else ""
        if section == "settings":
            version = V.RUNNING or self.version()
            rows = [("Account", ("Signed in as %s" % who + (u" \u00b7 Guest Room" if V.guest_room() else "")) if signed else "Not signed in",
                     ("Signed in as %s on this TV.\n\nGuest Room, your picks, the welcome tour, and signing out." % who) if signed else
                     "Sign in with your phone: scan a code on this TV and approve it. Or type your username and password.", "account"),
                    ("Playback and sources", "Picture, HEVC, links",
                     "The best picture to look for, HEVC versions, and links that didn't play on this box.", "playback"),
                    ("Live TV and Guide", "Mini player, channels", "The Guide's mini player and which channels the Guide lists.", "livetv"),
                    ("Appearance", T.find(T.chosen(V.ADDON))["name"],
                     "The colour theme, the same ones as the website, and the sound at the opening. Your theme follows your account to the website.", "appearance"),
                    ("Remote and pairing", "iPhone remote, Bluetooth", "Use your iPhone's own remote and keyboard with this box, or pair a Bluetooth game controller or remote.", "remotes"),
                    ("This box", "Network, audio, restart", "Wi-Fi and Ethernet, the volume and where the sound goes, and restarting or turning off this box.", "box"),
                    ("Software update", "Restart to update" if self.update_waiting() else "mediaCENTER %s" % version, "Check for a new version, read what changed, and install it.", "updates"),
                    ("About", "mediaCENTER %s" % version, "The version on this box, and the open-source notices.", "about")]
            if not on_device():
                rows.append(("Exit mediaCENTER", "", "Close mediaCENTER.", "exit"))
            return self.display("Settings", rows, focus=focus)
        if section == "box":
            return self.display("This box", [
                ("Network", "Wi-Fi and Ethernet", "Join a Wi-Fi network. A network cable connects by itself.", "network"),
                ("Audio", "Volume and output", "Volume, mute and where the sound goes (TV or receiver).", "audio"),
                ("Restart", "Restart or turn off", "Restart mediaCENTER, restart this box, or turn it off before unplugging it.", "power"),
                ("Back", "", "Back to Settings.", "back")], focus=focus)
        if section == "about":
            version = V.RUNNING or self.version()
            return self.display("About", [
                ("Version", "mediaCENTER %s" % version, "This box runs mediaCENTER %s.\n\nNew versions are in Settings, Software update." % version, "none"),
                ("Legal", "Open-source notices", "The software mediaCENTER on this box is built on, and its licences.", "legal"),
                ("Back", "", "Back to Settings.", "back")], focus=focus)
        if section == "setup":
            done = {k: V.ADDON.getSetting("setup_" + k) == "true" for k in ("network", "remote")}
            done["network"] = done["network"] or online()  # already connected: nothing to set up (owner, 2026-11-25)
            rows = [("Network", "Done" if done["network"] else "Step 1", "Join Wi-Fi, or plug in a network cable and choose Continue.", "setup_network"),
                    ("Remotes and controllers", "Done" if done["remote"] else "Step 2 (you can skip this)",
                     "Pair your iPhone's own remote and keyboard, or a Bluetooth controller. The remote that came with your TV already works.", "setup_remote"),
                    ("Sign in", ("Signed in as %s" % who) if signed else "Step 3", "Sign in with your phone, or with the TV keyboard.", "setup_account"),
                    ("Finish", "Start watching", "You can change all of this later in Settings.", "finish")]
            nxt = 0 if not done["network"] else 1 if not done["remote"] else 2 if not signed else 3
            self.display("Welcome to mediaCENTER", rows, "Let's get this box ready.", focus=nxt if not focus else focus)
            return self.setProperty("step", "Setup")
        if section == "signin":
            return self.begin_pairing()
        if section == "account":
            if signed:
                return self.display("Account", [
                    (GUEST["label"], "On" if V.guest_room() else "Off", GUEST["about"], "guest_room"),
                    ("Picked for you", "Change my picks", "Three quick questions: what you like, what to skip, movies or shows. "
                     "Home makes collections from them, only for you. Your answers follow your account to the website.", "picks"),
                    ("Welcome tour", "Take the tour again", "A quick walk through the places in mediaCENTER.", "tour"),
                    ("Sign out", "", "Signed in as %s.\n\nSign out on this TV only. Your other devices stay signed in." % who, "signout"),
                    ("Back", "", "Back to Settings.", "back")], focus=focus)
            return self.begin_pairing()
        if section == "network":
            address = xbmc.getIPAddress() or ""
            return self.display("Network", [("Find Wi-Fi networks", "", "Look for Wi-Fi networks near this box." + ("\n\nThis box's address: %s" % address if address else ""), "scanwifi"),
                                            ("Continue" if self.first_run else "Back", "", "A network cable connects by itself; no setup needed." if self.first_run else "Back to This box.",
                                             "network_done" if self.first_run else "back")])
        if section == "remotes":
            kodi_has = self.remote_addon()
            return self.display("Remote and pairing", [
                ("iPhone remote", R.summary(V.WINDOW, kodi_has), R.explain(V.WINDOW, kodi_has), "iphone"),
                ("Bluetooth controllers", "", "Pair a Bluetooth game controller or remote. Keep the remote you have now nearby while pairing.", "bluetooth"),
                ("Continue" if self.first_run else "Back", "", "Skip this step." if self.first_run else "Back to Settings.", "remote_done" if self.first_run else "back")],
                focus=focus)
        if section == "iphone":
            on = R.state(V.WINDOW) not in ("off", "")
            kodi_has = self.remote_addon()
            return self.display("iPhone remote", [
                ("Pair an iPhone", R.summary(V.WINDOW, kodi_has), R.explain(V.WINDOW, kodi_has), "iphone_pair"),
                ("Turn off the iPhone remote" if on else "Turn on the iPhone remote", "",
                 "Turns off the iPhone remote on this box. Paired iPhones stay paired for when you turn it on again." if on else
                 "Turns the iPhone remote on again.", "iphone_toggle"),
                ("Back", "", "Back to Remote and pairing.", "back")], focus=focus)
        if section == "bluetooth":
            return self.display("Remote and pairing", [
                ("Find Bluetooth devices", "", "Put the controller in pairing mode (see its instructions), then choose this.\n\nControllers that ask for a PIN can't be paired here yet.", "scanbt"),
                ("Continue" if self.first_run else "Back", "", "Skip this step." if self.first_run else "Back to Remote and pairing.", "remote_done" if self.first_run else "back")])
        if section == "audio":
            try:
                props = rpc("Application.GetProperties", {"properties": ["volume", "muted"]})
            except (RuntimeError, ValueError):
                props = None
            props = props if isinstance(props, dict) else {}
            vol = props.get("volume")
            return self.display("Audio", [
                ("Volume up", "%s%%" % vol if vol is not None else "", "Turns up mediaCENTER on this box. The TV's own volume is separate.", "volup"),
                ("Volume down", "", "Turns down mediaCENTER on this box.", "voldown"),
                ("Unmute" if props.get("muted") else "Mute", "Muted" if props.get("muted") else "", "Mutes or unmutes mediaCENTER on this box.", "mute"),
                ("Sound output", "", "Where the sound goes: through the TV (HDMI) or the headphone socket.", "outputs"),
                ("Let mediaCENTER control the volume", "", "Turns off sending surround sound straight to a receiver, so the volume keys work for everything.", "pcm"),
                ] + self.airplay_rows() + [
                ("Back", "", "Back to This box.", "back")], focus=focus)
        if section == "updates":
            channel = self.channel()
            checked = V.ADDON.getSetting("update_checked") or "Not yet"
            rows = [("Check for updates", "Last checked: %s" % checked, "mediaCENTER %s is installed.\n\nChecks the %s update list for a newer version." % (
                        V.RUNNING or self.version(), "test" if channel == "test" else "mediaCENTER"), "check"),
                    ("Updates from", "Test builds" if channel == "test" else "mediaCENTER", "Test builds come first and may have problems. Switch back any time.", "channel"),
                    ("Update automatically", "Off" if V.ADDON.getSetting("auto_update") == "false" else "On",
                     "mediaCENTER looks for updates a few times a day and installs them by itself while nothing is playing and "
                     "nobody is using the box, then restarts. If an update can't finish, the version you have stays.", "auto_update")]
            if self.plan and self.plan.get("available") and self.plan["channel"] == channel:
                rows.insert(0, ("Install %s" % plain(self.plan["version"]), "Available now",
                                "What's new:\n%s\n\nKeep the box plugged in while it installs. Your account and settings are kept, and if anything goes wrong the version you have now stays." % plain(self.plan["notes"]),
                                "install"))
            ready = self.update_waiting()
            if ready:
                rows.insert(0, ("Restart now", "Update ready", "mediaCENTER %s is installed and ready.\n\nRestart mediaCENTER to start using it. "
                                "Your account and settings are kept." % plain(ready), "restart_update"))
            rows.append(("Back", "", "Back to Settings.", "back"))
            return self.display("Software update", rows, focus=focus,
                                status="A new update is ready. Choose Restart now to finish." if ready else "")
        if section == "playback":
            return self.display("Playback and sources", playback_rows(self.api), focus=focus)
        if section == "livetv":
            return self.display("Live TV and Guide", livetv_rows(), focus=focus)
        if section == "appearance":
            now = T.chosen(V.ADDON)
            rows = [(t["name"], "On" if t["id"] == now else "", "%s: the accent and the glow behind every page. The website "
                     "shows the same theme when you sign in there." % t["name"], "theme:" + t["id"]) for t in T.THEMES]
            rows.append(("Sound at the opening", choice_now("opening_sound"), "The short sound when mediaCENTER opens, as on the Apple TV.", "opening_sound"))
            rows.append(("Back", "", "Back to Settings.", "back"))
            return self.display("Appearance", rows, focus=focus)
        if section == "power":
            return self.display("Restart", [("Restart mediaCENTER", "", "Starts mediaCENTER again. Your account and settings are kept.", "restart"),
                                            ("Restart this box", "", "Restarts the whole box. It comes back to mediaCENTER.", "reboot"),
                                            ("Turn off", "", "Turns the box off safely, so it can be unplugged.", "poweroff"),
                                            ("Back", "", "Back to This box.", "back")])

    def parent(self):
        if self.section in ("iphone", "bluetooth"):
            return "remotes"
        if self.first_run:
            return "setup"
        if self.section in BOX:
            return "box"
        return "settings"

    # -- the iPhone remote's pairing code --

    def remote_addon(self):
        """How Kodi has the remote add-on, asked only when the remote itself says nothing."""
        return "" if R.state(V.WINDOW) else R.addon_state(xbmc.executeJSONRPC)

    def wake_remote(self):
        """Before asking a silent remote for anything: switch it on in Kodi. Returns what to say if that can't be done."""
        found = R.switch_on(xbmc.executeJSONRPC)
        return {"missing": R.MISSING, "off": R.STUCK}.get(found, "")

    def stop_remote(self):
        if self.remote_watch:
            self.remote_watch.set()
            self.remote_watch = None
        for k in ("remotecode", "remotecode.until"):
            self.clearProperty(k)

    def start_welcome(self):
        """Signed out (first run, or the sign-in page): the iPhone remote's code shows at the bottom right away, and
        again whenever an iPhone asks to pair, with no trip to Settings (owner, 2026-11-26)."""
        if self.welcome:
            return
        holder = []

        def show(code, how):
            if holder and self.welcome is holder[0] and not self.closing.is_set():
                self.setProperty("welcome.code", code)
                self.setProperty("welcome.how", how)
        self.welcome = welcome_watch(show, lambda: not self.api.signed_in and not self.closing.is_set())
        holder.append(self.welcome)

    def stop_welcome(self):
        if self.welcome:
            self.welcome.set()
            self.welcome = None
        for k in ("welcome.code", "welcome.how"):
            self.clearProperty(k)

    def pair_iphone(self):
        """Ask the remote for a pairing code, show it while it works, and say when the iPhone has paired."""
        self.stop_remote()
        stop = threading.Event()
        self.remote_watch = stop
        patience = REMOTE_PATIENCE
        if not R.state(V.WINDOW):
            problem = self.wake_remote()
            if problem:
                return self.status(problem)
            patience = REMOTE_STARTING
        before = R.paired(V.WINDOW)
        path = xbmcvfs.translatePath(R.CODE_FILE)
        R.ask(V.WINDOW, "pair")
        self.status("Getting a code…")

        def end():
            if self.remote_watch is stop:  # a newer code may already be showing; leave that one alone
                self.stop_remote()
            return True

        def watch():
            shown, waited, gone = None, 0, 0
            for _ in range(REMOTE_LOOKS):
                if pause(stop, 1) or stop.is_set() or self.closing.is_set():
                    return
                if R.paired(V.WINDOW) > before:
                    end()
                    if self.first_run:
                        V.ADDON.setSetting("setup_remote", "true")
                    self.show("setup" if self.first_run else "iphone")
                    return self.status("Paired. Your iPhone can now control this box.")
                code = R.read_code(path)
                if code:
                    if code != shown:
                        shown = code
                        self.setProperty("remotecode", R.spaced(code[0]))
                        self.setProperty("remotecode.until", R.until_text(code[1]))
                        self.status("Waiting for your iPhone…")
                    continue
                if shown:
                    gone += 1  # the code closes when the iPhone pairs; give the count a moment to say so
                    if gone < REMOTE_GRACE:
                        continue
                    end()
                    return self.status("That code ran out. Choose Pair an iPhone for a new one.")
                waited += 1
                now = R.state(V.WINDOW)
                if waited >= patience or now in ("broken", "missing"):
                    end()
                    if now == "in use":
                        return self.status("The old remote is still running. See the steps on the right.")
                    if now in ("broken", "missing"):
                        return self.status("The iPhone remote couldn't start. Restart the box and try again.")
                    return self.status("The iPhone remote didn't answer. Try again in a moment.")
            end()
        spawn(watch)

    # -- background work --

    def run(self, work, done, waiting="Working…", failed=None):
        if self.busy:
            return
        self.busy = True
        self.status(waiting)

        def go():
            try:
                result = work()
            except Exception as e:
                self.busy = False
                if not self.closing.is_set():
                    self.status((failed and failed(e)) or (str(e) if isinstance(e, RuntimeError) and str(e) != "unavailable" else
                                                           "That didn't work. Check the connection and try again."))
                return
            self.busy = False
            if not self.closing.is_set():
                self.status("")
                done(result)
        spawn(go)

    # -- phone sign-in --

    def begin_pairing(self):
        self.stop_pairing()
        self.display("Sign in", [("Sign in with your phone", "", "Getting a code…", "newcode"),
                                 ("Use the TV keyboard", "", "Type your mediaCENTER username and password with the remote instead.", "keyboard"),
                                 ("Back", "", "Back without signing in.", "back")], "Scan the code with your phone's camera.")
        stop = threading.Event()
        self.pairing = {"stop": stop}

        def work():
            return P.start(self.api, self.profile)

        def failed(e):
            if isinstance(e, ServerError) and e.status == 503:
                return "Phone sign-in isn't ready yet. Choose Use the TV keyboard."
            if isinstance(e, ServerError) and e.status == 429:
                return "Too many new codes. Wait a few minutes, or choose Use the TV keyboard."
            if isinstance(e, (ServerError, P.SignedOut, ValueError)):
                # mediaCENTER answered, but without a code: phone sign-in isn't switched on there yet
                V.log("phone sign-in unavailable (%s)" % (getattr(e, "status", "") or type(e).__name__))
                return "Phone sign-in isn't ready yet. Choose Use the TV keyboard."
            return "Couldn't reach mediaCENTER. Check the box's internet connection, or choose Use the TV keyboard."
        self.run(work, lambda data: self.pairing_ready(data, stop), "Getting a code…", failed)

    def pairing_ready(self, data, stop):
        if stop.is_set() or self.closing.is_set():
            return P.forget(self.profile)
        self.pairing.update(data)
        detail = ("1. Point your phone's camera at the code.\n2. Sign in to mediaCENTER on your phone.\n3. Approve this TV.\n\n"
                  "No camera? On your phone, open the address under the code and type the code.")
        rows = [("Get a new code", "", detail, "newcode")] + self.rows[1:]
        self.display("Sign in", rows, "Scan the code with your phone's camera.", "Waiting for your phone. The code works for 10 minutes.")
        self.setProperty("qr", data["image"])
        self.setProperty("code", data["userCode"])
        self.setProperty("address", data["address"])

        def wait():
            deadline = time.monotonic() + min(600, int(data.get("expiresIn") or 600))
            interval = max(MIN_WAIT, int(data.get("interval") or MIN_WAIT))
            while not pause(stop, interval) and time.monotonic() < deadline:
                try:
                    result = P.poll(self.api, data["deviceCode"])
                except P.SignedOut:
                    return self.status("This TV couldn't be signed in. Choose Get a new code, or Use the TV keyboard.")
                except Exception:
                    self.status("Lost the connection. Still trying…")
                    continue
                if stop.is_set():
                    return
                if result == "approved":
                    P.forget(self.profile)
                    self.result = "signed_in"
                    V.notify("Signed in as %s" % self.api.username)
                    if self.first_run:
                        self.pairing = None
                        return self.show("setup", focus=3)
                    return self.close()
                if result == "expired":
                    break
            if not stop.is_set():
                self.status("That code ran out. Choose Get a new code.")
        spawn(wait)

    # -- input --

    def onFocus(self, control_id):
        self.follow()

    def follow(self):
        if self.rows:
            i = self.getControl(LIST).getSelectedPosition()
            if 0 <= i < len(self.rows):
                self.setProperty("detail", self.rows[i][2])

    def onAction(self, action):
        a = action.getId()
        if a in BACK:
            if self.section == "setup":
                return  # first run: setup ends with Finish
            if self.section == "settings" or (self.section == self.start_section and self.start_section != "setup"):
                return self.close()
            return self.show(self.parent(), focus=self.parent_focus())
        if a in MOVES:
            self.follow()

    def onClick(self, control_id):
        if control_id != LIST or not self.rows:
            return
        i = self.getControl(LIST).getSelectedPosition()
        if not 0 <= i < len(self.rows):
            return
        try:
            self.act(self.rows[i][3], i)
        except RuntimeError:
            self.status("That isn't available on this box.")

    def act(self, action, index=0):
        if isinstance(action, tuple):
            return self.act_on(*action)
        if self.busy and action not in ("back", "keyboard"):
            return
        if isinstance(action, str) and action.startswith("theme:"):
            T.choose(self.api, V.ADDON, action[6:], V.WINDOW)  # every page changes colour at once
            return self.show("appearance", focus=index)
        if action == "appearance":
            return self.show("appearance")
        if action in ("account", "network", "bluetooth", "audio", "updates", "power", "remotes", "iphone", "livetv", "box", "about"):
            return self.show(action)
        if action == "none":
            return
        if action == "iphone_pair":
            return self.pair_iphone()
        if action == "iphone_toggle":
            on = R.state(V.WINDOW) not in ("off", "")
            if not on and not R.state(V.WINDOW):
                problem = self.wake_remote()
                if problem:
                    return self.status(problem)
            R.ask(V.WINDOW, "off" if on else "on")
            V.WINDOW.setProperty(R.STATUS, "off" if on else "starting")  # the service says the rest in a moment
            self.show("iphone", focus=index)
            return self.status("The iPhone remote is off." if on else "Turning on the iPhone remote…")
        if action == "guest_room":
            on = not V.guest_room()
            V.ADDON.setSetting("guest_room", "true" if on else "false")
            self.api.profile = "guest" if on else ""
            self.result = self.result or "account"  # Home is drawn again: its Continue Watching is the other list now
            self.show("account", focus=index)
            return V.notify(GUEST["on"] if on else GUEST["off"])
        if action == "picks":
            import mc_more
            if mc_more.run_survey(self.api):
                self.result = self.result or "account"
            return
        if action == "tour":
            import mc_more
            return mc_more.run_tour(self.api, self.api.username)
        if action == "playback":
            return self.show("playback")
        if action in PLAYBACK_CHOICES:
            key, values = PLAYBACK_CHOICES[action]
            now = V.ADDON.getSetting(key) or values[0][0]
            ids = [v for v, _ in values]
            V.ADDON.setSetting(key, ids[(ids.index(now) + 1) % len(ids)] if now in ids else ids[0])
            if key == "picture_render":
                render_follow()
            return self.show(self.section, focus=index)  # Playback and sources, Live TV and Guide, or Appearance
        if action == "choose_source":  # 0.4.9.3: the account's chooseSource, as the website's Settings toggle
            import mc_subtitles as S
            on = S.prefs(self.api).get("chooseSource") is not False
            saved = S.remember(self.api, "chooseSource", not on)
            self.show(self.section, focus=index)
            return self.status("" if saved else "Couldn't save this right now. Try again in a moment.")
        if action == "forget_links":
            import mc_versions as MV
            MV.FailedLinks(V.PROFILE).forget_all()
            self.show("playback", focus=index)
            return self.status("Every link will be tried again.")
        if action == "back":
            if self.section == self.start_section and self.start_section not in ("settings", "setup"):
                return self.close()
            if self.start_section == "signin":
                return self.close()
            return self.show(self.parent(), focus=self.parent_focus())
        if action == "setup_network":
            return self.show("network")
        if action == "setup_remote":
            return self.show("remotes")
        if action == "setup_account":
            return self.show("account") if not self.api.signed_in else None
        if action == "network_done":
            V.ADDON.setSetting("setup_network", "true")
            return self.show("setup")
        if action == "remote_done":
            V.ADDON.setSetting("setup_remote", "true")
            return self.show("setup")
        if action == "finish":
            V.ADDON.setSetting("setup_complete", "true")
            return self.close()
        if action == "legal":
            from mc_app import legal
            return legal()
        if action == "exit":
            self.result = "exit"
            return self.close()
        if action == "signout":
            if xbmcgui.Dialog().yesno("mediaCENTER", "Sign out of mediaCENTER on this TV?", nolabel="Stay", yeslabel="Sign out"):
                self.api.sign_out()
                self.result = "signed_out"
                return self.close()
            return
        if action == "newcode":
            return self.begin_pairing()
        if action == "keyboard":
            self.stop_pairing()
            if V.sign_in_flow(self.api):
                self.result = "signed_in"
                return self.show("setup", focus=3) if self.first_run else self.close()
            return self.begin_pairing()
        if action in ("restart", "reboot", "poweroff"):
            question = {"restart": "Restart mediaCENTER?", "reboot": "Restart this box?", "poweroff": "Turn off this box?"}[action]
            if xbmcgui.Dialog().yesno("mediaCENTER", question, nolabel="Cancel", yeslabel="Restart" if action != "poweroff" else "Turn off"):
                xbmc.executebuiltin({"restart": "RestartApp", "reboot": "Reboot", "poweroff": "Powerdown"}[action])
            return
        if action in ("volup", "voldown", "mute", "pcm"):
            if action == "mute":
                rpc("Application.SetMute", {"mute": "toggle"})
            elif action == "pcm":
                rpc("Settings.SetSettingValue", {"setting": "audiooutput.passthrough", "value": False})
                self.status("mediaCENTER now controls the volume.")
            else:
                rpc("Application.SetVolume", {"volume": "increment" if action == "volup" else "decrement"})
            return self.show("audio", focus=index)
        if action == "airplay":
            return self.airplay_switch(index)
        if action == "outputs":
            found = rpc("Settings.GetSettings", {"filter": {"section": "system", "category": "audio"}})
            found = found if isinstance(found, dict) else {}
            setting = next((s for s in found.get("settings", []) if s.get("id") == "audiooutput.audiodevice"), {})
            current = setting.get("value")
            rows = [(plain(o.get("label", "")), "In use" if o.get("value") == current else "", "Send the sound here.", ("output", o.get("value")))
                    for o in setting.get("options", [])]
            return self.display("Sound output", rows + [("Back", "", "Back to Audio.", "back_audio")], status="" if rows else "This box didn't list any other outputs.")
        if action == "back_audio":
            return self.show("audio")
        if action == "scanwifi":
            return self.run(self.wifi_scan, self.wifi_found, "Looking for Wi-Fi networks…")
        if action == "scanbt":
            return self.run(self.bt_scan, self.bt_found, "Looking for Bluetooth devices for 10 seconds…")
        if action == "channel":
            # A list to pick from, not a switch: one press of OK used to flip it (the owner's Pi had "stable" saved
            # while it installs test builds, and the stable list then refused it).
            now = self.channel()
            choices = [("stable", "mediaCENTER"), ("test", "Test builds")]
            i = xbmcgui.Dialog().select("Updates from", [("%s (now)" % label) if key == now else label for key, label in choices],
                                        preselect=[k for k, _ in choices].index(now))
            if i is None or i < 0 or choices[i][0] == now:
                return
            V.ADDON.setSetting("update_channel", choices[i][0])
            self.plan = None
            return self.show("updates", focus=index)
        if action == "auto_update":
            V.ADDON.setSetting("auto_update", "true" if V.ADDON.getSetting("auto_update") == "false" else "false")
            return self.show("updates", focus=index)
        if action == "check":
            self.plan = None
            if self.update_waiting():  # already installed (Kodi got there first): it only needs a restart, no download
                return self.show("updates")

            def checked(plan):
                self.plan = plan
                V.ADDON.setSetting("update_checked", datetime.datetime.now().strftime("%b %d, %I:%M %p").replace(" 0", " "))
                self.show("updates")
                self.status("Version %s is ready to install." % plain(plan["version"]) if plan["available"] else "mediaCENTER is up to date.")
            def failed(e):
                U.log("check failed (%s)" % type(e).__name__)
                if self.update_waiting():  # Kodi finished installing the update while this looked
                    self.show("updates")
                    return "A new update is ready. Choose Restart now to finish."
                return update_failed(e)
            return self.run(lambda: self.updates().check(self.channel(), U.installed(self.addons)), checked, "Checking for updates…",
                            failed)
        if action == "restart_update":
            if V.SAMPLE:
                return self.status("Sample data: nothing is restarted.")
            # the box restarts into mediaCENTER with every new part loaded; on a computer only mediaCENTER starts again
            if on_device():
                xbmc.executebuiltin(U.restart_command())
                return
            self.result = "update"
            self.close()
            xbmc.executebuiltin("RunScript(script.mediacenter)")
            return
        if action == "install" and self.plan:
            if not xbmcgui.Dialog().yesno("mediaCENTER", "Install mediaCENTER %s now? It takes a minute or two, then mediaCENTER restarts." % plain(self.plan["version"]),
                                          nolabel="Not now", yeslabel="Install"):
                return
            return self.install()

    def parent_focus(self):
        if self.section in ("iphone", "bluetooth"):
            return 0 if self.section == "iphone" else 1
        if self.first_run:
            return {"network": 0, "remotes": 1, "account": 2}.get(self.section, 0)
        if self.section in BOX:
            return BOX.index(self.section)
        return SETTINGS_ORDER.index(self.section) if self.section in SETTINGS_ORDER else 0

    def act_on(self, kind, value):
        if kind == "wifi":
            password = ""
            if value["secure"]:
                password = xbmcgui.Dialog().input("Wi-Fi password for %s" % plain(value["name"]), option=xbmcgui.ALPHANUM_HIDE_INPUT)
                if not password:
                    return

            def joined(_):
                if self.first_run:
                    V.ADDON.setSetting("setup_network", "true")
                    self.show("setup")
                self.status("Connected to %s." % plain(value["name"]))
            return self.run(lambda: self.network().wifi_connect(value["id"], password), joined, "Joining %s…" % plain(value["name"]))
        if kind == "bt":
            def paired(_):
                if self.first_run:
                    V.ADDON.setSetting("setup_remote", "true")
                    self.show("setup")
                self.status("%s is connected." % plain(value["name"]))
            return self.run(lambda: self.network().bluetooth_connect(value["id"]), paired, "Pairing %s…" % plain(value["name"]))
        if kind == "output":
            rpc("Settings.SetSettingValue", {"setting": "audiooutput.audiodevice", "value": value})
            return self.act("outputs")

    # -- the AirPlay speaker (0.4.9.9, mc_airplay) --

    def airplay(self):
        import mc_airplay as A
        return A.speaker(V.ADDON, self.addons, log=V.log)

    def airplay_rows(self):
        """Settings > Audio: the AirPlay speaker, on the box only (it runs beside Kodi on LibreELEC)."""
        if not on_device():
            return []
        import mc_airplay as A
        on = V.ADDON.getSetting(A.ON) == "true"
        return [("AirPlay speaker", "On" if on else "Off",
                 "Play music from an iPhone, iPad or Mac on this TV, as \u201c%s\u201d. It joins your other AirPlay speakers, and "
                 "you can add it to the Home app as a speaker.\n\nStarting a video in mediaCENTER stops the music." % A.clean_name(V.ADDON.getSetting(A.NAME)),
                 "airplay")]

    def airplay_switch(self, index):
        import mc_airplay as A
        if V.SAMPLE:
            return self.status("Sample data: the AirPlay speaker isn't set up.")
        sp = self.airplay()
        if V.ADDON.getSetting(A.ON) == "true":
            def off_done(said):
                self.show("audio", focus=index)
                self.status(said[1])
            return self.run(sp.turn_off, off_done, "Turning off the AirPlay speaker\u2026")
        if not sp.docker:
            if xbmcgui.Dialog().yesno("mediaCENTER", A.SAID["needs_docker"] + " Install it now? Then choose AirPlay speaker again.",
                                      nolabel="Not now", yeslabel="Install"):
                xbmc.executebuiltin("InstallAddon(%s)" % A.DOCKER_ADDON)
            return

        def on_done(said):
            self.show("audio", focus=index)
            self.status(said[1])
        return self.run(sp.turn_on, on_done, "Setting up the AirPlay speaker\u2026 The first time takes a few minutes.")

    # -- helpers the test box swaps for sample answers --

    def network(self):
        if V.SAMPLE:
            import mc_sample
            return mc_sample.SampleNetwork
        return N

    def updates(self):
        if V.SAMPLE:
            import mc_sample
            return mc_sample.SampleUpdates
        return U

    def wifi_scan(self):
        return self.network().wifi_scan()

    def wifi_found(self, found):
        rows = [(plain(n["name"]), "Locked" if n["secure"] else "Open", "Join this network." + (" You'll type its password next." if n["secure"] else ""), ("wifi", n))
                for n in found]
        back = ("Back", "", "Back.", "back")
        self.display("Choose Wi-Fi", rows + [back], status="" if rows else "No Wi-Fi networks found. Try again, or plug in a network cable.")
        self.section = "network"

    def bt_scan(self):
        return self.network().bluetooth_scan()

    def bt_found(self, found):
        rows = [(plain(n["name"]), "", "Pair and connect this device.", ("bt", n)) for n in found]
        self.display("Choose a device", rows + [("Back", "", "Back.", "back")],
                     status="" if rows else "Nothing found. Put the controller in pairing mode and try again.")
        self.section = "bluetooth"

    def install(self):
        """The installer runs from a copy outside the add-on (the add-on's own folder is what it replaces), with this page
        left open under its progress box: closing windows while that box is up is what stuck the app (0.4.9.3). It
        checks every package before swapping, puts the old version back on any error, and restarts the box."""
        if V.SAMPLE:
            return self.status("Sample data: nothing is installed.")
        if U.installing(V.WINDOW):
            return self.status("An update is already being installed.")
        os.makedirs(self.profile, exist_ok=True)
        with open(os.path.join(self.profile, "update-plan.json"), "w") as f:
            json.dump(self.plan, f)
        worker = os.path.join(self.profile, "update-worker.py")
        shutil.copyfile(U.__file__, worker)
        xbmc.executebuiltin('RunScript("%s","%s")' % (worker, self.profile))
