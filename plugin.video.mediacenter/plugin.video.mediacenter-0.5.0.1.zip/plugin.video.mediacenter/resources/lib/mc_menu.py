# mediaCENTER for Kodi: the menu on the left (0.4.9.6, design plan section 8.1, items 1 and 2), shared by every page that
# has it (Home and Library, Movies, TV Shows, Search, Sports, the Guide).
#
# Folded, it is a thin column of icons over the left edge of the picture (kodi/tools/make_windows.py rail()), so the
# artwork fills the screen. Left from the left edge of a page moves the highlight onto it, and then it opens with the
# names (the windows draw it open while 9000 or 9001 has the highlight). Moving up and down only highlights; OK goes
# there; Right or Back folds it and puts the highlight back where it was. The page you are on is the white pill with a
# black icon and name; the highlight is a white ring, drawn apart from that pill.
#
# 9000 holds Search, Home, Movies, TV Shows, Guide, Sports, Library (design/experience.json "pi"; 0.4.9.9: Search above
# Home, so Up from Home reaches it, owner 2026-11-26); 9001 holds Settings
# alone at the bottom. A page other than Home goes elsewhere through mc_pages.go(..., inside=True): the pages above Home
# close and Home opens the one chosen (App.arrive_at). Kept free of Kodi windows below the Rail class so it can be tested.

import os

import mc_views as V

NAV, BOTTOM = 9000, 9001
RIGHT = 2
BACK = (9, 10, 92, 247)  # parent dir, previous menu, back, back (remote)
OPEN = "menu"  # window property: drawn open while set (the welcome tour shows the names beside its cards)
SCREENS = {"Home": "home", "Movies": "movies", "TV Shows": "shows", "Guide": "guide", "Sports": "sports", "Search": "search",
           "Library": "library", "Settings": "settings"}
DEFAULT = ["Search", "Home", "Movies", "TV Shows", "Guide", "Sports", "Library", "Settings"]


def items(experience=None):
    """The whole menu in design/experience.json's order ("pi" menu, written to resources/data/experience.json as
    "app"), Settings last. Names this app has no screen for, and Apps (never on the Pi), are left out."""
    exp = V.experience() if experience is None else experience
    names = (exp.get("app") or {}).get("menu") or DEFAULT
    out = [(SCREENS[n], n) for n in names if n in SCREENS and n not in V.NOT_ON_THE_PI and n != "Settings"]
    out.append(("settings", "Settings"))
    return out


def split(menu):
    """(the places in 9000, the one at the bottom in 9001): Settings sits alone at the bottom."""
    return [m for m in menu if m[0] != "settings"], [m for m in menu if m[0] == "settings"]


def icon(key):
    path = os.path.join(V.HERE, "resources", "skins", "Default", "media", "icon_%s.png" % key)
    return path if os.path.isfile(path) else ""


def key_at(menu, control_id, position):
    """The place under the highlight: control 9000 at position, or Settings in 9001."""
    top, bottom = split(menu)
    if control_id == BOTTOM:
        return bottom[0][0] if bottom else None
    if control_id == NAV and 0 <= position < len(top):
        return top[position][0]
    return None


class Rail(object):
    """What a page with the menu mixes in. The page sets rail_key (the place it is: "movies", "guide", ...) and
    rail_home (where the highlight goes if it has never been anywhere else); it calls rail_setup() from onInit,
    rail_focus() from onFocus (if it has its own), rail_action() first thing in onAction and rail_click() first thing
    in onClick. On Home the App does its own going (App.arrive_at); other pages go through mc_pages."""
    rail_key = "home"
    rail_home = None
    rail_from = None
    MENU = None  # set below, once

    def rail_setup(self, active=None):
        import xbmcgui
        menu = self.MENU or items()
        top, bottom = split(menu)
        for cid, places in ((NAV, top), (BOTTOM, bottom)):
            control = self.getControl(cid)
            control.reset()
            out = []
            for key, name in places:
                li = xbmcgui.ListItem(name)
                li.setProperty("icon", icon(key))
                li.setProperty("key", key)
                out.append(li)
            control.addItems(out)
        self.rail_mark(active or self.rail_key)

    def rail_mark(self, key):
        """The white pill goes on the place you are on."""
        self.rail_key = key
        for cid in (NAV, BOTTOM):
            control = self.getControl(cid)
            for i in range(control.size()):
                li = control.getListItem(i)
                li.setProperty("active", "1" if li.getProperty("key") == key else "")

    def rail_open(self, show_names=False):
        """Put the highlight on the menu, on the page you are on (Settings if you are there)."""
        menu = self.MENU or items()
        top, _ = split(menu)
        keys = [k for k, _ in top]
        if self.rail_key in keys:
            self.getControl(NAV).selectItem(keys.index(self.rail_key))
        if show_names:
            self.setProperty(OPEN, "1")
        self.setFocusId(BOTTOM if self.rail_key == "settings" else NAV)

    def rail_is_open(self):
        return self.getFocusId() in (NAV, BOTTOM)

    def rail_fold(self):
        """Back where the highlight was before the menu (or the page's first place)."""
        self.clearProperty(OPEN)
        back = self.rail_from or self.rail_home
        if back is not None:
            self.setFocusId(back)
        return True

    def rail_focus(self, control_id):
        """Remember the last place on the page, so folding the menu goes back there."""
        if control_id and control_id not in (NAV, BOTTOM):
            self.rail_from = control_id

    def onFocus(self, control_id):
        self.rail_focus(control_id)

    def rail_action(self, a):
        """True if the menu took the key: Right or Back fold it while it has the highlight."""
        if not self.rail_is_open():
            return False
        if a == RIGHT or a in BACK:
            return self.rail_fold()
        return False

    def rail_click(self, control_id):
        """True if OK was on the menu. The page you are on just folds it; another page goes there."""
        if control_id not in (NAV, BOTTOM):
            return False
        key = key_at(self.MENU or items(), control_id, self.getControl(NAV).getSelectedPosition())
        if key is None:
            return True
        if key == self.rail_key:
            return self.rail_fold()
        self.rail_go(key)
        return True

    def rail_leaving(self):
        """Before going to another page (the Guide stops its mini player and keeps the place)."""

    def rail_go(self, key):
        import mc_pages as pages
        self.rail_leaving()
        self.clearProperty(OPEN)
        done = pages.go(key, inside=True)
        V.log("menu: go to %s: %s" % (key, done))
        if done in ("ignored", "there"):
            self.rail_fold()
        return done


Rail.MENU = items()
