# mediaCENTER for Kodi 0.4.9: the website's smaller pages on the box.
#   - CardPage (mediacenter-card.xml): one card over the page, for the taste survey, the welcome tour and announcements.
#   - GridPage (mediacenter-grid.xml): a page of posters, for See more at the end of Home's New rows (the website's
#     #/new/movie and #/new/series) and for one Picked for you collection (#/picks/<genre>).
#   - Picked for you on Home: the survey's first collections as rows, or a card that starts the survey.
#   - Search before typing: the website's Movies / TV Shows choice, genre chips, a count and a poster grid.
#   - The welcome tour once per account, then announcements, when Home first opens.
# The rules are in mc_taste.py and mc_notices.py (pure, tested on their own); this file draws them.

import json
import threading
import time

import xbmcgui

import mc_logic as L
import mc_notices as N
import mc_pages as pages
import mc_taste as T
import mc_views as V
from mc_api import SignedOut, ServerError

ERRORS = (ServerError, SignedOut, OSError, ValueError)
BACK = (9, 10, 92, 247)
MOVES = (1, 2, 3, 4, 5, 6)
KINDS = ("more", "pick", "survey", "showmore")  # the cards this file opens (mc_app.open_item hands them here)
PICK_ROWS = 2  # Picked for you rows on Home
PER_PICK = 12


def app():
    import mc_app  # here, not at the top: mc_app imports this file
    return mc_app


# ---- the account's settings ------------------------------------------------------------------------------------------

_PREFS = {"at": 0, "for": None, "prefs": {}}


def prefs(api, fresh=False):
    """/api/prefs's "prefs", reused for 20 seconds (Home, the tour and announcements all ask as Home opens)."""
    if not fresh and _PREFS["for"] is api and time.time() - _PREFS["at"] < 20:
        return _PREFS["prefs"]
    try:
        got = (api.get("/api/prefs") or {}).get("prefs") or {}
    except ERRORS:
        got = {}
    _PREFS.update(at=time.time(), prefs=got)
    _PREFS["for"] = api
    return got


def save(api, body):
    try:
        api.call("PUT", "/api/prefs", body=body)
    except ERRORS:
        return False
    _PREFS["at"] = 0  # read again next time
    return True


# ---- one card over the page ------------------------------------------------------------------------------------------

class CardPage(xbmcgui.WindowXMLDialog):
    """Draws flow.card() and hands the presses back: flow.toggle(key) for a chip, flow.press(91 | 92 | 93) and
    flow.back() for buttons and Back, which say "close" when the card goes. The flow's result is the card's."""
    CHIPS, BUTTONS = 80, (91, 92, 93)

    @classmethod
    def run(cls, flow, side=False):
        w = cls("mediacenter-card.xml", V.HERE, "Default", "1080i")
        w.flow, w.side = flow, side
        pages.modal(w)
        result = getattr(flow, "result", None)
        del w
        return result

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started = True
        if self.side:
            self.setProperty("side", "1")
        self.draw()

    def draw(self, focus=True):
        c = self.flow.card()
        for k in ("eyebrow", "title", "text", "image"):
            self.setProperty(k, c.get(k) or "")
        chips = c.get("chips") or []
        self.setProperty("mode", "chips" if chips else "image" if c.get("image") else "plain")
        n, of = c.get("dots") or (0, 0)
        self.setProperty("dots", str(of if of > 1 else 0))
        self.setProperty("dot", str(n))
        labels = c.get("buttons") or {}
        for i, bid in enumerate(self.BUTTONS, 1):
            if labels.get(bid):
                self.setProperty("button.%d" % i, labels[bid])
            else:
                self.clearProperty("button.%d" % i)
        control = self.getControl(self.CHIPS)
        if focus:
            control.reset()
            items = []
            for key, label, on in chips:
                li = xbmcgui.ListItem(label)
                li.setProperties({"key": key, "on": "1" if on else ""})
                items.append(li)
            control.addItems(items)
            self.setFocusId(self.CHIPS if chips else 92 if labels.get(92) else 91)
        else:
            for i, (key, label, on) in enumerate(chips):
                if i < control.size():
                    control.getListItem(i).setProperty("on", "1" if on else "")

    def onClick(self, control_id):
        if control_id == self.CHIPS:
            li = self.getControl(self.CHIPS).getSelectedItem()
            if li is not None:
                self.flow.toggle(li.getProperty("key"))
                self.draw(focus=False)
            return
        if control_id in self.BUTTONS:
            return self.after(self.flow.press(control_id))

    def onAction(self, action):
        if action.getId() in BACK:
            return self.after(self.flow.back())

    def after(self, said):
        if said == "close":
            return self.close()
        if said != "stay":
            self.draw()


# ---- the taste survey (web-v27/js/views/picks.js TasteSurvey) ----------------------------------------------------------

class SurveyFlow(object):
    def __init__(self, start=None):
        self.s, self.result = T.Survey(start), None

    def card(self):
        title, text = T.STEPS[self.s.step]
        back, nxt, ok = self.s.buttons()
        return {"eyebrow": "PICKED FOR YOU", "title": title, "text": text, "chips": self.s.chips(), "dots": (self.s.step + 1, len(T.STEPS)),
                "buttons": {91: back, 92: nxt if ok else ""}}

    def toggle(self, key):
        self.s.toggle(key)  # the card is drawn again: Next shows once a genre is liked

    def press(self, bid):
        if bid == 91:
            return self.back()
        if bid == 92:
            if self.s.next():
                self.result = self.s.result()
                return "close"
        return "draw"

    def back(self):
        return "draw" if self.s.back() else "close"


def run_survey(api, start=None):
    """The survey; when it is finished it is saved with the account ("tasteSurvey", as the website's). Returns it or None."""
    if start is None:
        start = T.from_prefs(prefs(api))
    flow = SurveyFlow(start)
    result = CardPage.run(flow)
    if not result:
        return None
    if save(api, T.body(result)):
        V.notify("Your picks are ready")
    else:
        V.notify("Couldn't save your picks right now.")
    return result


# ---- the welcome tour (web-v27/js/views/guided-tour.js) --------------------------------------------------------------

class TourFlow(object):
    def __init__(self, name="", highlight=None):
        self.i, self.name, self.highlight, self.result = 0, name, highlight, None
        self.show_place()

    def show_place(self):
        if self.highlight:
            try:
                self.highlight(N.TOUR[self.i][2] or "home")
            except Exception:  # the sidebar is only a help here
                pass

    def card(self):
        title, text, _, nxt = N.TOUR[self.i]
        if self.i == 0 and self.name:
            title += ", " + self.name
        last = self.i == len(N.TOUR) - 1
        return {"eyebrow": "mediaCENTER  /  QUICK TOUR", "title": title, "text": text, "dots": (self.i + 1, len(N.TOUR)),
                "buttons": {91: "Back" if self.i else "", 92: nxt, 93: "" if last else "Exit tour"}}

    def toggle(self, key):
        pass

    def press(self, bid):
        if bid == 92:
            if self.i == len(N.TOUR) - 1:
                self.result = "done"
                return "close"
            self.i += 1
        elif bid == 91 and self.i:
            self.i -= 1
        elif bid == 93:
            self.result = "exit"
            return "close"
        self.show_place()
        return "draw"

    def back(self):
        if self.i == 0:
            self.result = "exit"
            return "close"
        return self.press(91)


def tour_seen_here(username):
    return username in [u for u in (V.ADDON.getSetting("tour_seen") or "").split(",") if u]


def remember_tour(api):
    who = api.username or ""
    seen = [u for u in (V.ADDON.getSetting("tour_seen") or "").split(",") if u]
    if who and who not in seen:
        V.ADDON.setSetting("tour_seen", ",".join(seen + [who])[-2000:])
    save(api, N.tour_body())


def run_tour(api, name="", highlight=None):
    """The tour, from Home or Settings. Leaving it early or finishing it both count as seen, as on the website."""
    result = CardPage.run(TourFlow(N.first_name(name), highlight), side=highlight is not None)  # the sidebar shows on Home
    remember_tour(api)
    if result is not None:
        V.notify("Take the tour again in Settings, Account.")
    return result


# ---- announcements (the website's What's new cards) ------------------------------------------------------------------

class NoticeFlow(object):
    def __init__(self, notices, api):
        self.notices, self.api, self.i, self.steps, self.step, self.result = list(notices), api, 0, None, 0, None

    def current(self):
        return self.notices[self.i]

    def card(self):
        n = self.current()
        if self.steps is not None:
            s = self.steps[self.step]
            last = self.step == len(self.steps) - 1
            return {"eyebrow": "SHOW ME HOW", "title": n.get("title") or "", "text": s["text"], "image": s["image"],
                    "dots": (self.step + 1, len(self.steps)), "buttons": {91: "Back", 92: "Done" if last else "Next"}}
        c = N.card(n)
        extra = c["buttons"][0] if c["buttons"] else None
        return {"eyebrow": c["eyebrow"] + ("   %d of %d" % (self.i + 1, len(self.notices)) if len(self.notices) > 1 else ""),
                "title": c["title"], "text": c["text"], "image": c["image"],
                "buttons": {91: "Later", 92: "Got it", 93: extra[1] if extra else ""}}

    def toggle(self, key):
        pass

    def dismiss(self):
        n = self.current()
        save(self.api, N.dismiss_body(prefs(self.api, fresh=True), n["id"]))
        self.notices.pop(self.i)
        if not self.notices:
            return "close"
        self.i = min(self.i, len(self.notices) - 1)
        return "draw"

    def press(self, bid):
        if self.steps is not None:
            if bid == 91:
                return self.back()
            if self.step < len(self.steps) - 1:
                self.step += 1
                return "draw"
            self.steps = None
            return "draw"
        if bid == 91:
            return "close"
        if bid == 92:
            return self.dismiss()
        extra = N.card(self.current())["buttons"]
        if bid == 93 and extra:
            kind, _, target = extra[0]
            if kind == "tutorial":
                self.steps, self.step = N.tutorial(self.current()), 0
                return "draw" if self.steps else self.dismiss()
            self.result = {"screen": target}
            self.dismiss()
            return "close"
        return "stay"

    def back(self):
        if self.steps is not None:
            if self.step == 0:
                self.steps = None
            else:
                self.step -= 1
            return "draw"
        return "close"


def run_notices(api):
    """What's new: each announcement not closed yet, one card at a time. Returns {"screen": key} when its button
    asked for a page, else None."""
    try:
        answer = api.get("/api/announcements", platform=N.PLATFORM) or {}
    except ERRORS:
        return None
    todo = N.waiting(answer, prefs(api))
    if not todo:
        return None
    return CardPage.run(NoticeFlow(todo, api))


def welcome(win):
    """Home has opened for a signed-in account: the tour the first time, else what's new. Once per app open."""
    api = win.api
    if getattr(win, "welcomed", False) or not api.signed_in or pages.GOTO.get("to"):
        return None
    win.welcomed = True
    p = prefs(api)
    if not N.tour_seen(p, tour_seen_here(api.username)):
        # Each card marks the place it talks about in the menu beside it (the open place's pill). The highlight itself
        # stays on the card: Kodi gives the keys to the card, and focus moved under it would only confuse.
        # 0.4.9.6: the menu stays open with its names beside the cards, so the pill shows each place by name.
        win.setProperty("menu", "1")
        try:
            run_tour(api, win.getProperty("account"), win.mark)
        finally:
            win.clearProperty("menu")
        win.mark(getattr(win, "screen", "home") or "home")
        return None
    return run_notices(api)


# ---- Picked for you on Home ------------------------------------------------------------------------------------------

def genre_titles(api, kind, genre):
    """TMDB's genre row (/meta/row, as taste.js tmdbRow), kept six hours on the box like the Home answer."""
    try:
        answer = V.cached("row-%s-genre%s" % (kind, genre), 6 * 3600, lambda: api.get("/meta/row", type=kind, row="genre:%s" % genre))
    except ERRORS:
        return []
    return L.titles_of((answer or {}).get("items"))


def pick_titles(api, pick, limit=PER_PICK):
    return T.mix([genre_titles(api, kind, genre) for kind, genre in pick["rows"]], limit)


def special_card(kind, label, label2, eyebrow="", plot="", **props):
    li = xbmcgui.ListItem(label, label2)
    li.setProperties(dict({"kind": kind, "eyebrow": eyebrow, "plot": plot, "meta": label2}, **props))
    return li


def home_picks(api):
    """Home's Picked for you rows: each of the first collections with its titles and a "See all" card; before the
    survey, one card that starts it."""
    survey = T.from_prefs(prefs(api))
    if not survey:
        return [("Picked for you", [special_card("survey", "Tell us what you like", "Make my picks", "PICKED FOR YOU",
                                                 "Answer three quick questions and we'll make collections just for you.")])]
    rows = []
    for p in T.picks(survey)[:PICK_ROWS]:
        cards = [app().title_card(t) for t in pick_titles(api, p)]
        if not cards:
            continue
        for li in cards:
            li.setProperty("tag", "PICKED FOR YOU")
        cards.append(special_card("pick", "See all", p["genre"], "PICKED FOR YOU", "%s. Titles from every service." % p["blurb"], pick=p["id"]))
        rows.append((p["title"], cards))
    return rows


def see_more(kind):
    """The card at the end of Home's New Movies and New TV Shows rows (the website's "See more")."""
    name = "New Movies" if kind == "movie" else "New TV Shows"
    return special_card("more", "See more", name, name.upper(), NEW_SUB[kind], type=kind)


NEW_SUB = {"movie": "Out lately and ready to watch: streaming, or to rent or buy", "series": "Out lately and streaming now"}


def open_card(api, li):
    """A card from this file was chosen. True when the picks changed (Home draws its rows again)."""
    kind = li.getProperty("kind")
    if kind == "more":
        GridPage.open(api, NewSource(li.getProperty("type") or "movie"))
        return False
    if kind == "pick":
        return GridPage.open(api, PicksSource(api, li.getProperty("pick")))
    if kind == "survey":
        return bool(run_survey(api))
    return False


# ---- a page of posters -----------------------------------------------------------------------------------------------

class NewSource(object):
    """Everything that came out lately and can be watched now, most popular first, 50 at a time (views/new-list.js)."""

    def __init__(self, kind):
        self.kind = kind
        self.page, self.pages, self.seen = 0, 1, set()
        self.heading = "New Movies" if kind == "movie" else "New TV Shows"
        self.eyebrow, self.sub, self.button, self.chips = "", NEW_SUB[kind], "", []

    def first(self, api):
        self.page, self.seen = 0, set()
        return self.more(api)

    def more(self, api):
        """The next 50: (titles, more to come). Titles have no posters yet (posters() fills them in)."""
        if self.page >= self.pages:
            return [], False
        answer = api.get("/api/services/home-new", kind=self.kind, page=self.page + 1) or {}
        self.page += 1
        self.pages = int(answer.get("pages") or 1)
        out = []
        for t in L.titles_of(answer.get("titles"), 50):
            key = t["type"] + t["tmdb"]
            if key not in self.seen:
                self.seen.add(key)
                out.append(t)
        return out, self.page < self.pages


class PicksSource(object):
    """One Picked for you collection (views/picks.js Picks): its titles from every service, the other collections as
    chips, and Change my picks."""

    def __init__(self, api, pick_id):
        self.survey = T.from_prefs(prefs(api))
        self.list = T.picks(self.survey)
        self.choose(pick_id)
        self.eyebrow, self.button = "PICKED FOR YOU", "Change my picks"

    def choose(self, pick_id):
        self.pick = next((p for p in self.list if p["id"] == pick_id), self.list[0] if self.list else None)
        self.heading = self.pick["title"] if self.pick else "No picks yet"
        self.sub = ("%s. Titles from every service." % self.pick["blurb"]) if self.pick else "Answer a few questions and we'll make collections just for you."
        self.chips = [(p["id"], p["genre"], p is self.pick) for p in self.list] if len(self.list) > 1 else []

    def first(self, api):
        return (pick_titles(api, self.pick, 40) if self.pick else []), False

    def more(self, api):
        return [], False


class GridPage(xbmcgui.WindowXMLDialog):
    GRID, CHIPS, BUTTON = 78, 77, 81

    @classmethod
    def open(cls, api, source):
        """Returns True when the picks were changed here. The page is let go here, after it closed, as every other page
        is: 0.4.9 returned it to the caller while a poster lookup still held it, so it could be destroyed from that
        lookup's thread, which crashes Kodi (owner, 2026-11-26: See more on TV Shows crashed)."""
        w = cls("mediacenter-grid.xml", V.HERE, "Default", "1080i")
        w.api, w.source, w.changed = api, source, False
        pages.modal(w)
        changed = bool(w.changed)
        del w
        return changed

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started = True
        self.fill()

    def head(self):
        s = self.source
        for k in ("eyebrow", "heading", "sub", "button"):
            self.setProperty(k, getattr(s, k) or "")
        chips = self.getControl(self.CHIPS)
        chips.reset()
        items = []
        for key, label, on in s.chips:
            li = xbmcgui.ListItem(label)
            li.setProperties({"key": key, "on": "1" if on else ""})
            items.append(li)
        chips.addItems(items)

    def fill(self):
        self.head()
        grid = self.getControl(self.GRID)
        grid.reset()
        self.clearProperty("empty")
        app().busy(True)
        try:
            titles, more = self.source.first(self.api)
            titles = with_posters(self.api, titles)
        except ERRORS:
            titles, more = None, False
        finally:
            app().busy(False)
        if titles is None:
            self.setProperty("empty", "Couldn't load this page. Try again in a moment.")
        elif not titles:
            self.setProperty("empty", "Nothing here right now. Try again in a little while.")
        self.add(titles or [], more)
        self.setFocusId(self.GRID if titles else (self.CHIPS if self.source.chips else 85))

    def add(self, titles, more):
        grid = self.getControl(self.GRID)
        if grid.size() and grid.getListItem(grid.size() - 1).getProperty("kind") == "showmore":
            grid.getListItem(grid.size() - 1).setProperties({"kind": "spent"})  # replaced by what it loaded
            spent = grid.size() - 1
        else:
            spent = None
        cards = [app().title_card(t) for t in titles]
        if more:
            cards.append(special_card("showmore", "Show more", "", "", "The next 50."))
        items = [grid.getListItem(i) for i in range(grid.size()) if i != spent]
        keep = grid.getSelectedPosition()
        grid.reset()
        grid.addItems(items + cards)
        if spent is not None:
            grid.selectItem(min(keep, grid.size() - 1))
        app().show_details(self, (items + cards)[0] if (items + cards) else None)

    def onClick(self, control_id):
        if control_id == self.GRID:
            li = self.getControl(self.GRID).getSelectedItem()
            if li is None:
                return
            if li.getProperty("kind") == "showmore":
                app().busy(True)
                try:
                    titles, more = self.source.more(self.api)
                    titles = with_posters(self.api, titles)
                except ERRORS:
                    titles, more = [], True
                finally:
                    app().busy(False)
                return self.add(titles, more)
            if li.getProperty("kind") == "title":
                return app().open_item(self.api, li, win=self)
            return
        if control_id == self.CHIPS and isinstance(self.source, PicksSource):
            li = self.getControl(self.CHIPS).getSelectedItem()
            if li is not None:
                self.source.choose(li.getProperty("key"))
                self.fill()
                self.setFocusId(self.CHIPS)
            return
        if control_id == self.BUTTON and isinstance(self.source, PicksSource):
            done = run_survey(self.api, self.source.survey)
            if done:
                self.changed = True
                current = self.source.pick["id"] if self.source.pick else ""
                self.source = PicksSource(self.api, current if current in done["liked"] else done["liked"][0])
                self.fill()

    def onAction(self, action):
        a = action.getId()
        if a in BACK:
            return self.close()
        if a in MOVES and self.getFocusId() == self.GRID:
            app().show_details(self, self.getControl(self.GRID).getSelectedItem())


def with_posters(api, titles, size=6, workers=3):
    """Pictures for titles that came without one (/meta/batch, six at a time, as /api/browse fills its rows), looked up
    before the page draws them. The lookups run side by side but only fetch: nothing on screen is touched from another
    thread, and nothing is left running once the page shows."""
    missing = [t for t in titles or [] if not t.get("poster")]
    parts = [missing[i:i + size] for i in range(0, len(missing), size)]
    answers = [None] * len(parts)

    def fetch(n):
        q = json.dumps([{"type": t["type"], "tmdb": t["tmdb"]} for t in parts[n]], separators=(",", ":"))
        try:
            answers[n] = api.get("/meta/batch", q=q)
        except ERRORS:
            answers[n] = None
    for start in range(0, len(parts), workers):
        threads = [threading.Thread(target=fetch, args=(n,)) for n in range(start, min(start + workers, len(parts)))]
        for t in threads:
            t.daemon = True
            t.start()
        for t in threads:
            t.join(25)
    for part, got in zip(parts, answers):
        for t, a in zip(part, got if isinstance(got, list) else []):
            if isinstance(a, dict) and str(a.get("poster") or "").startswith("https://"):
                t["poster"] = L.picture(a["poster"], "w342")
                t["backdrop"] = t.get("backdrop") or L.picture(a.get("backdrop") or "", "w1280")
    return titles


# ---- Search before typing (web-v27/js/views/search.js Browse) ---------------------------------------------------------

class SearchBrowse(object):
    """What Search shows before anything is typed: Movies or TV Shows, the genres ("All" first), how many, and their
    posters, from /api/browse (the Movies and TV Shows pages' own answer). Mixed into mc_app.SearchPage."""
    KIND, GENRES, POSTERS = 76, 77, 78
    AREA = (76, 77, 78)
    PROMPT = "What are we watching today?"

    def browse(self, kind=None, genre=0):
        if kind:
            self.b_kind = kind
        kind = getattr(self, "b_kind", "movie")
        self.setProperty("browse", "1")
        self.setProperty("status", "")
        kinds = self.getControl(self.KIND)
        if not kinds.size():
            kinds.addItems([xbmcgui.ListItem("Movies"), xbmcgui.ListItem("TV Shows")])
        for i, k in enumerate(("movie", "series")):
            kinds.getListItem(i).setProperty("on", "1" if k == kind else "")
        cache = self.__dict__.setdefault("b_cache", {})
        if kind not in cache:
            try:
                answer = self.api.get("/api/browse", kind=kind) or {}
            except ERRORS:
                answer = None
            cache[kind] = answer
        answer = cache[kind]
        genres = [g for g in (answer or {}).get("genres") or [] if isinstance(g, dict) and g.get("id")]
        self.b_genres = genres
        chips = self.getControl(self.GENRES)
        chips.reset()
        items = [xbmcgui.ListItem("All")] + [xbmcgui.ListItem(g.get("name", "")) for g in genres]
        for i, li in enumerate(items):
            li.setProperty("on", "1" if i == genre else "")
        chips.addItems(items)
        if genre:
            try:
                titles = L.titles_of((self.api.get("/api/browse", kind=kind, genre=str(genres[genre - 1]["id"])) or {}).get("items"), 60)
            except ERRORS:
                titles = None
        elif answer is None:
            titles = None
        else:
            titles = all_titles(answer)
        grid = self.getControl(self.POSTERS)
        grid.reset()
        if titles is None:
            self.setProperty("count", "")
            self.setProperty("status", "Couldn't load this right now. Try again in a moment.")
            return
        grid.addItems([app().title_card(t) for t in titles])
        word = "movie" if kind == "movie" else "show"
        self.setProperty("count", "%d %s%s" % (len(titles), word, "" if len(titles) == 1 else "s"))
        app().show_details(self, grid.getListItem(0) if titles else None)

    def browse_off(self):
        self.clearProperty("browse")
        self.clearProperty("count")

    def browse_click(self, control_id):
        """True when the click was the browse area's."""
        if control_id == self.KIND:
            i = self.getControl(self.KIND).getSelectedPosition()
            self.browse("series" if i == 1 else "movie")
            return True
        if control_id == self.GENRES:
            self.browse(genre=self.getControl(self.GENRES).getSelectedPosition())
            return True
        if control_id == self.POSTERS:
            li = self.getControl(self.POSTERS).getSelectedItem()
            if li is not None:
                app().open_item(self.api, li, win=self)
            return True
        return False


def all_titles(answer, limit=120):
    """Every title of /api/browse's rows once, in row order (the website lists the whole library before typing)."""
    out, seen = [], set()
    for r in (answer or {}).get("rows") or []:
        for t in L.titles_of((r or {}).get("items")):
            key = t["type"] + t["tmdb"]
            if key not in seen:
                seen.add(key)
                out.append(t)
    return out[:limit]
