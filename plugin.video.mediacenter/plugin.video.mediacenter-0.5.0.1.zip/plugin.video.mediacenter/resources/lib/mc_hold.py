# mediaCENTER for Kodi: the hold menus (0.4.9.6; the design plan's "Hold menus", PI 3 App Design pages 6-7, items 13
# to 16). Holding OK on a card, or the menu key, opens a sheet over the dimmed page (mediacenter-hold.xml, written by
# kodi/tools/hold_windows.py): the bigger picture with its progress line, the full names, the facts, the whole
# description, then what can be done.
#
# How a hold reaches the app: Kodi's own keymaps turn a held OK into the menu key (ContextMenu, action 117): a keyboard's
# held Enter (<return mod="longpress">), a game controller's held A (<a holdtime="500">), and the menu key itself (a
# TV remote's Menu or Title key, a keyboard's C or Menu key, a controller's X). Nothing here waits on a timer, so a plain
# OK is never slower. Remotes that send no hold and have no menu key (the iPhone's Control Center remote) can't open it.
#
#   Continue Watching (Home, Library's In Progress): Resume, Start from the beginning, Go to show / Movie details,
#     Remove from Continue Watching (no "are you sure"; the account's history, so every device).
#   An episode on a show's page: the still, the full name, runtime and air date, the whole description, then Play
#     episode, or Resume and Start from the beginning (the website's episode sheet, web-v27/js/views/episode-sheet.js).
#
# 0.4.9.9 (owner, 2026-11-26: "why is there no press and hold? it doesn't pull up the full titles or descriptions"):
#   - Every card has one now (card_hold): a movie or show anywhere (Home's rows and Top 10, Movies, TV Shows, Search,
#     My List) shows its full name, its facts and the whole description, then Play or Go to show, Details, and Add to
#     or Remove from My List; a channel or a game shows its full name and what's on, then Watch. A programme in the
#     Guide shows its full name, time and description, then Watch and the Favorites choice (guide_sheet).
#   - Play/Pause on a highlighted card opens it too (HOLD_KEYS), because the iPhone's remote never sends a held button:
#     the iPhone sends Play/Pause as Kodi's PlayPause while nothing plays (service.mediacenter.remote's tvcontrol), the
#     box's own remotes send Play, Pause or PlayPause. While something plays, Play/Pause still pauses it.

import datetime

import xbmc
import xbmcgui

import mc_logic as L
import mc_views as V
import mc_pages as pages
from mc_api import ServerError, SignedOut

ACTIONS, PICTURE = 50, 60
PAUSE, PLAY, PLAYPAUSE = 12, 68, 229
HOLD_KEYS = (11, 117, PAUSE, PLAY, PLAYPAUSE)  # info, the menu key (a held OK), and Play/Pause on a highlighted card
NO_DESCRIPTION = "No description yet."
BACK = (9, 10, 92, 247)
FOOT = "Back closes."
NO_PLOT = "No description for this episode yet."  # the website's words
MONTHS_LONG = ("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November",
               "December")


# ---- the words (tested off the box) -----------------------------------------------------------------------------------

def long_date(iso):
    """ "2011-04-17" -> "April 17, 2011", as the website's episode sheet; anything else -> ""."""
    try:
        d = datetime.date(*(int(p) for p in str(iso or "")[:10].split("-")))
    except (TypeError, ValueError):
        return ""
    return "%s %d, %d" % (MONTHS_LONG[d.month - 1], d.day, d.year)


def minutes_left(seconds):
    """ "58 min left" under an hour (the design's words), "1h 20m left" over it (the website's cards)."""
    m = int(max(0, seconds) // 60)
    return "%d min left" % max(1, m) if m < 60 else L.time_left(seconds)


def episode_code(season, episode, name=""):
    """ "S1 · E3 · Lord Snow" """
    return L.DOT.join(p for p in ["S%s" % season, "E%s" % episode, name] if p)


def runtime_text(minutes):
    try:
        m = int(minutes or 0)
    except (TypeError, ValueError):
        return ""
    return "%d min" % m if m > 0 else ""


def find_episode(api, tmdb, season, episode):
    """One episode's details (/meta/episodes, else /api/roku/episodes), or {}."""
    for path in ("/meta/episodes", "/api/roku/episodes"):
        try:
            eps = (api.get(path, tmdb=tmdb, season=season) or {}).get("episodes") or []
        except (ServerError, SignedOut, OSError, ValueError):
            eps = []
        for e in eps:
            if isinstance(e, dict) and str(e.get("n")) == str(episode):
                return e
    return {}


def history_row(api, item_id):
    """The account's history row for one movie or episode, or None (it can't be read: None too)."""
    try:
        rows = (api.get("/api/history", limit=300) or {}).get("items") or []
    except (ServerError, SignedOut, OSError):
        return None
    return next((h for h in rows if isinstance(h, dict) and h.get("itemId") == item_id), None)


def part_way(row):
    """Seconds to resume from, or 0 (finished, not started, or under 30 seconds: the players' rule)."""
    if not row or row.get("finished"):
        return 0
    pos = float(row.get("position") or 0)
    return pos if pos >= 30 else 0


def continue_sheet(api, li):
    """What the Continue Watching hold shows for a card (mc_app.continue_card). The details the card doesn't carry (the
    description, runtime, air date, a bigger picture) are asked for here; the sheet still opens without them."""
    series = li.getProperty("type") == "series"
    tmdb = li.getProperty("tmdb")
    pos, dur = float(li.getProperty("position") or 0), float(li.getProperty("duration") or 0)
    left = minutes_left(dur - pos) if dur > pos else ""
    picture = li.getArt("landscape") or li.getArt("thumb") or li.getArt("poster")
    if series:
        season, episode = li.getProperty("season") or "1", li.getProperty("episode") or "1"
        e = find_episode(api, tmdb, season, episode)
        name = e.get("name") or li.getProperty("episodeName")
        facts = [runtime_text(e.get("runtime")), str(e.get("air") or e.get("air_date") or "")[:10], left]
        sheet = {"eyebrow": li.getLabel().upper(), "title": episode_code(season, episode, name), "plot": e.get("overview") or "",
                 "picture": L.picture(e.get("still"), "w780") if e.get("still") else picture}
        go = {"key": "show", "label": u"≡  Show details", "label2": "seasons and episodes"}
    else:
        try:
            t = L.title_of(dict((api.get("/api/roku/title", type="movie", tmdb=tmdb) or {}).get("title") or {}, type="movie", tmdb=tmdb)) or {}
        except (ServerError, SignedOut, OSError, ValueError):
            t = {}
        runtime = t.get("runtime") or 0
        facts = [t.get("year", ""), ("%dh %dm" % divmod(runtime, 60) if runtime >= 60 else runtime_text(runtime)), left]
        sheet = {"eyebrow": "CONTINUE WATCHING", "title": li.getLabel(), "plot": t.get("overview", ""),
                 "picture": t.get("backdrop") or picture}
        go = {"key": "details", "label": u"≡  Movie details"}
    # In the owner's words and order (2026-11-26): Show details, Resume episode, Start from beginning, Delete from history.
    sheet.update(facts=L.DOT.join(p for p in facts if p), progress=(pos, dur) if pos and dur else None, actions=[
        go,
        {"key": "resume", "label": u"▶  Resume episode" if series else u"▶  Resume", "label2": ("from %s" % L.clock_text(pos)) if pos else ""},
        {"key": "start", "label": u"↩  Start from beginning"},
        {"key": "remove", "label": u"✕  Delete from history", "danger": True},
    ])
    return sheet


def episode_sheet(show, season, e, row=None, today=None):
    """What holding an episode on a show's page shows. e: the episode as /meta/episodes gives it; row: its history row."""
    n = e.get("n")
    air = str(e.get("air") or e.get("air_date") or "")[:10]
    later = bool(air) and air > (today or datetime.date.today().isoformat())
    facts = [runtime_text(e.get("runtime")), long_date(air)] + (["Not out yet"] if later else [])
    pos = part_way(row)
    dur = float((row or {}).get("duration") or 0)
    if later:
        actions = [{"key": "later", "label": "Not out yet", "off": True}]
    elif pos:
        actions = [{"key": "resume", "label": u"▶  Resume", "label2": "from %s" % L.clock_text(pos)},
                   {"key": "start", "label": u"↩  Start from the beginning"}]
    else:
        actions = [{"key": "play", "label": u"▶  Play episode"}]
    if not later:  # 0.4.9.3's episode page had it (brought back in 0.4.9.9): pick the version before it plays
        actions.append({"key": "choose", "label": "Choose a version"})
    return {"eyebrow": (show or "").upper(), "title": episode_code(season, n, e.get("name") or "Episode %s" % n),
            "facts": L.DOT.join(p for p in facts if p), "plot": e.get("overview") or NO_PLOT,
            "picture": L.picture(e.get("still"), "w780") if e.get("still") else "", "actions": actions,
            "progress": (pos, dur) if pos and dur > pos else None}


def title_sheet(t, li=None, pinned=False):
    """What holding a movie or show card shows. t: the title as /api/roku/title gives it (mc_logic.title_of), or {} when
    it couldn't be asked; li: the card, for what the card already knows."""
    li_get = (lambda k: li.getProperty(k)) if li is not None else (lambda k: "")
    series = (t.get("type") or li_get("type")) == "series"
    name = t.get("name") or (li.getLabel() if li is not None else "")
    import mc_home
    kind = "TV Show" if series else "Movie"
    facts = li_get("meta")  # "2024 · Movie", what the card knows
    if t:
        parts = [p for p in mc_home.featured_facts(t).split(L.DOT) if p]  # "2025 · PG-13 · 2h 4m · IMDb 7.4 · Drama"
        at = 1 if parts and parts[0][:4].isdigit() else 0
        facts = L.DOT.join(parts[:at] + [kind] + parts[at:])
    picture = t.get("backdrop") or (li.getArt("fanart") if li is not None else "") or (li.getArt("poster") if li is not None else "")
    actions = [{"key": "show", "label": u"≡  Go to show", "label2": "seasons and episodes"} if series else
               {"key": "play", "label": u"▶  Play"},
               {"key": "details", "label": u"≡  %s details" % ("Show" if series else "Movie")}]
    if series:
        actions = actions[:1]
    actions.append({"key": "unpin", "label": u"✓  Remove from My List"} if pinned else {"key": "pin", "label": u"+  Add to My List"})
    return {"eyebrow": li_get("tag") or kind.upper(), "title": name, "facts": facts or "",
            "plot": t.get("overview") or li_get("plot") or NO_DESCRIPTION, "picture": picture, "actions": actions}


def other_sheet(li):
    """A channel or a game card: its full name, the line under it and what's on, then Watch."""
    eyebrow = li.getProperty("eyebrow") or ("CHANNEL" if li.getProperty("kind") == "channel" else "GAME")
    return {"eyebrow": eyebrow.upper(), "title": li.getLabel(), "facts": li.getProperty("meta") or li.getLabel2(),
            "plot": li.getProperty("plot") or li.getLabel2() or NO_DESCRIPTION, "picture": li.getArt("fanart") or li.getArt("thumb"),
            "actions": [{"key": "open", "label": u"▶  Watch"}]}


def guide_sheet(ch, prog, live, favorite):
    """Holding a programme in the Guide: the channel over the programme's full name, its time, the whole description,
    then Watch and Favorites. prog: None when the channel has no guide information."""
    name = " ".join(x for x in [str(ch.get("num") or ""), ch.get("name", "")] if x)
    if prog is None:
        title, facts, plot = ch.get("name", ""), name, "No guide information for this channel yet."
    else:
        title = prog.get("title") or ch.get("name", "")
        facts = L.DOT.join(x for x in ["LIVE" if live else "", L.clock_s(prog["start"]) + u" – " + L.clock_s(prog["stop"])] if x)
        plot = "No description available." if L.is_filler(prog) or not prog.get("desc") else prog["desc"]
    actions = [{"key": "watch", "label": u"▶  Watch %s" % (ch.get("name") or "")}]
    if not ch.get("game"):
        actions.append({"key": "favorite", "label": u"★  Remove from Favorites" if favorite else u"☆  Add to Favorites"})
    return {"eyebrow": name.upper(), "title": title, "facts": facts, "plot": plot, "picture": "", "actions": actions}


def busy(on):
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)" if on else "Dialog.Close(busydialognocancel)")


# ---- the sheet --------------------------------------------------------------------------------------------------------

class HoldPage(xbmcgui.WindowXMLDialog):
    """Opened with ask(sheet); returns the chosen action's key, or None (Back)."""

    @classmethod
    def ask(cls, sheet):
        w = cls("mediacenter-hold.xml", V.HERE, "Default", "1080i")
        w.sheet, w.picked = sheet, None
        pages.modal(w)
        picked = w.picked
        del w
        return picked

    def onInit(self):
        s = self.sheet
        for k in ("eyebrow", "title", "facts", "plot"):
            self.setProperty(k, s.get(k) or "")
        self.setProperty("foot", FOOT)
        if s.get("progress"):
            self.setProperty("progress", "1")
        else:
            self.clearProperty("progress")
        picture = self.getControl(PICTURE)
        picture.reset()
        picture.addItem(self.picture_item(s))
        actions = self.getControl(ACTIONS)
        actions.reset()
        for a in s.get("actions") or []:
            row = xbmcgui.ListItem(a.get("label", ""), a.get("label2", ""))
            row.setProperties({"danger": "1" if a.get("danger") else "", "off": "1" if a.get("off") else ""})
            actions.addItem(row)
        actions.selectItem(0)
        self.setFocusId(ACTIONS)

    @staticmethod
    def picture_item(s):
        """The bigger picture, with the progress line under it read from ListItem.PercentPlayed (a new item: the card's own
        stays as it is on its row)."""
        li = xbmcgui.ListItem(s.get("title") or "")
        if s.get("picture"):
            li.setArt({"thumb": s["picture"]})
        if s.get("progress"):
            V.set_info(li, {"title": s.get("title") or "", "mediatype": "video"}, s["progress"])
        return li

    def onClick(self, cid):
        if cid != ACTIONS:
            return
        actions = self.sheet.get("actions") or []
        pos = self.getControl(ACTIONS).getSelectedPosition()
        if 0 <= pos < len(actions) and not actions[pos].get("off"):
            self.picked = actions[pos]["key"]
            self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()


# ---- what each choice does ----------------------------------------------------------------------------------------------

def continue_hold(api, li, ask=None):
    """Hold (or the menu key) on a Continue Watching card. Returns "removed" when it left Continue Watching, "played"
    or "opened" when something played or a page opened (so Continue Watching is asked for again), else None."""
    import mc_player as P
    ask = ask or HoldPage.ask
    busy(True)
    try:
        sheet = continue_sheet(api, li)
    finally:
        busy(False)
    key = ask(sheet)
    series = li.getProperty("type") == "series"
    tmdb = li.getProperty("tmdb")
    season = int(li.getProperty("season") or 1) if series else None
    episode = int(li.getProperty("episode") or 1) if series else None
    art = {"name": li.getLabel(), "backdrop": li.getArt("fanart") or li.getArt("landscape")}
    if key in ("resume", "start"):
        P.play_title(api, "series" if series else "movie", tmdb, season, episode, art=art,
                     resume=key == "resume", fresh=key == "start")
        return "played"
    if key in ("show", "details"):
        import mc_app
        mc_app.TitlePage.open(api, "series" if series else "movie", tmdb)
        return "opened"
    if key == "remove":
        import mc_watching
        try:
            mc_watching.remove(api, li.getProperty("itemId"), rows=[])
        except SignedOut:
            V.notify("Your session ended. Sign in again from Settings.")
            return None
        except (ServerError, OSError):
            V.notify("Could not remove saved progress. Please try again.")
            return None
        V.notify("Removed from Continue Watching")
        return "removed"
    return None


def wants_hold(action_id, playing=None):
    """Whether a key on a highlighted card opens its hold sheet: the menu key or Info always; Play, Pause or Play/Pause
    only while nothing plays (then they pause what plays, as before)."""
    if action_id in (11, 117):
        return True
    if action_id not in (PAUSE, PLAY, PLAYPAUSE):
        return False
    if playing is None:
        playing = xbmc.getCondVisibility("Player.HasMedia")
    return not playing


def card_hold(api, li, ask=None):
    """Hold (the menu key, or Play/Pause) on any card but Continue Watching's (continue_hold) and an episode's.
    Returns "played", "opened", "pinned", "unpinned" or None; "open" for a channel or game card, which the page opens
    as OK would."""
    import mc_player as P
    ask = ask or HoldPage.ask
    kind = li.getProperty("kind")
    if kind in ("channel", "game"):
        return "open" if ask(other_sheet(li)) == "open" else None
    if kind != "title" or not li.getProperty("tmdb"):
        return None
    series = li.getProperty("type") == "series"
    tmdb = li.getProperty("tmdb")
    kind_name = "series" if series else "movie"
    busy(True)
    try:
        try:
            raw = (api.get("/api/roku/title", type=kind_name, tmdb=tmdb) or {}).get("title") or {}
            t = L.title_of(dict(raw, type=kind_name, tmdb=tmdb)) if isinstance(raw, dict) else None
        except (ServerError, SignedOut, OSError, ValueError):
            t = None
        t = t or {}
        try:
            pins = V.my_list(api)
        except (ServerError, SignedOut, OSError, ValueError):
            pins = None
        mine = L.title_of({"type": kind_name, "tmdb": tmdb, "name": t.get("name") or li.getLabel(), "year": t.get("year") or li.getLabel2(),
                           "poster": t.get("poster") or li.getArt("poster"), "backdrop": t.get("backdrop") or li.getArt("fanart")})
        pinned = bool(pins and mine and L.is_pinned(pins, mine))
        sheet = title_sheet(t, li, pinned)
        if pins is None:
            sheet["actions"] = [a for a in sheet["actions"] if a["key"] not in ("pin", "unpin")]
    finally:
        busy(False)
    key = ask(sheet)
    if key == "play":
        P.play_title(api, "movie", tmdb, art={"name": li.getLabel(), "backdrop": li.getArt("fanart")})
        return "played"
    if key in ("show", "details"):
        import mc_app
        mc_app.TitlePage.open(api, kind_name, tmdb)
        return "opened"
    if key in ("pin", "unpin") and mine:
        import time
        try:
            new_pins, now_pinned = L.toggle_pin(V.my_list(api), mine)
            api.call("PUT", "/api/prefs", body={"prefs": {"myList": {"value": new_pins, "updatedAt": int(time.time() * 1000)}}})
        except SignedOut:
            V.notify("Your session ended. Sign in again from Settings.")
            return None
        except (ServerError, OSError, ValueError):
            V.notify("Could not change My List. Please try again.")
            return None
        V.notify(("Added to My List: %s" if now_pinned else "Removed from My List: %s") % mine["name"])
        return "pinned" if now_pinned else "unpinned"
    return None


def take_out(control):
    """A removed card leaves its row at once; the highlight moves to the next card (the last card: the one before).
    Returns how many cards are left."""
    pos = control.getSelectedPosition()
    control.removeItem(pos)
    left = control.size()
    if left:
        control.selectItem(min(pos, left - 1))
    return left
