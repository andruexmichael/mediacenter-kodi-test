# mediaCENTER for Kodi: talking to the mediaCENTER server.
#
# The add-on uses the same server routes as the Roku app (src/ba-roku.js, /api/roku/*: one small answer per screen,
# the server does the matching) plus the routes every app shares (/access/*, /api/history, /api/prefs, /meta/*,
# /api/share, player_api.php). The session is the account's own sign-in cookie, kept in this add-on's private
# profile folder; it is never logged or shown. Passwords are sent once to /access/authenticate and never stored.

import json
import os
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request

DEFAULT_BASE = "https://watch.littlebirdtampa.com"
DEVICE = "kodi"
USER_AGENT = "mediaCENTER-Kodi/0.1"
COOKIE_NAME = "__Host-ba_tester"


class SignedOut(Exception):
    """The server says there is no session (401/403): the person must sign in again."""

    def __init__(self, code=""):
        super().__init__(code or "signed_out")
        self.code = code


class ServerError(Exception):
    def __init__(self, status, code=""):
        super().__init__("HTTP %s %s" % (status, code))
        self.status = status
        self.code = code


def clean_base(address):
    """Only an https origin (no path, query or credentials) is accepted; anything else falls back to the default."""
    try:
        u = urllib.parse.urlsplit((address or "").strip())
    except ValueError:
        return DEFAULT_BASE
    if u.scheme != "https" or not u.hostname or u.username or u.password or u.query or u.fragment or u.path not in ("", "/"):
        return DEFAULT_BASE
    return "https://" + u.netloc


def cookie_from_headers(set_cookies):
    """The session cookie ("name=value") from the Set-Cookie headers of a sign-in answer; "" when there is none."""
    for header in set_cookies or []:
        first = str(header).split(";", 1)[0].strip()
        if first.startswith(COOKIE_NAME + "="):
            value = first[len(COOKIE_NAME) + 1:]
            return first if value else ""
    return ""


class Session(object):
    """Where the sign-in cookie lives: a small JSON file in the add-on's profile folder (owner-only permissions)."""

    def __init__(self, folder):
        self.path = os.path.join(folder, "session.json")
        self.folder = folder

    def load(self):
        try:
            with open(self.path, "r") as f:
                data = json.load(f)
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    def save(self, data):
        if not os.path.isdir(self.folder):
            os.makedirs(self.folder)
        tmp = self.path + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(data, f)
        os.replace(tmp, self.path)

    def clear(self):
        try:
            os.remove(self.path)
        except OSError:
            pass


class Api(object):
    def __init__(self, base=DEFAULT_BASE, session=None, opener=None, timeout=25):
        self.base = clean_base(base)
        self.session = session
        self.timeout = timeout
        self._opener = opener or urllib.request.build_opener(urllib.request.HTTPSHandler(context=ssl.create_default_context()))
        self._custom_opener = opener is not None  # tests pass a fake opener; the link check uses it too
        state = session.load() if session else {}
        self.cookie = state.get("cookie", "")
        self.username = state.get("username", "")
        self.profile = ""  # "guest" while the Guest Room is on: the server keeps that history and those picks apart

    # ---- plumbing -------------------------------------------------------------------------------------------------

    @property
    def signed_in(self):
        return bool(self.cookie)

    def headers(self, with_body=False, method="GET"):
        h = {"Accept": "application/json", "User-Agent": USER_AGENT, "X-MC-Device": DEVICE}
        if self.cookie:
            h["Cookie"] = self.cookie
        if self.profile == "guest":
            h["X-MC-Profile"] = "guest"  # as the Roku sends it (roku/components/lib/Api.brs)
        if method not in ("GET", "HEAD"):
            h["Origin"] = self.base  # the server only takes changes from its own origin
        if with_body:
            h["Content-Type"] = "application/json"
        return h

    def url(self, path, query=None):
        if not path.startswith("/"):
            path = "/" + path
        out = self.base + path
        if query:
            out += ("&" if "?" in out else "?") + urllib.parse.urlencode(query)
        return out

    def raw(self, method, path, query=None, body=None, timeout=None):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        req = urllib.request.Request(self.url(path, query), data=data, method=method,
                                     headers=self.headers(with_body=data is not None, method=method))
        try:
            res = self._opener.open(req, timeout=timeout or self.timeout)
            self.heard(res.headers)
            return res.getcode(), res.read(), res.headers
        except urllib.error.HTTPError as e:
            self.heard(e.headers)
            return e.code, e.read(), e.headers

    server_time = None  # (the server's HTTP Date, this box's time when it came): the app's clock (mc_home.now)

    def heard(self, headers):
        date = headers.get("Date") if headers is not None else None
        if date:
            Api.server_time = (date, time.time())

    def call(self, method, path, query=None, body=None, timeout=None):
        status, text, _ = self.raw(method, path, query, body, timeout)
        parsed = None
        if text:
            try:
                parsed = json.loads(text.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                parsed = None
        code = parsed.get("error", "") if isinstance(parsed, dict) else ""
        if status in (401, 403):
            if code == "email_verification_required":
                raise ServerError(status, code)
            raise SignedOut(code)
        if not 200 <= status < 300:
            raise ServerError(status, code)
        return parsed

    def get(self, path, **query):
        return self.call("GET", path, {k: v for k, v in query.items() if v is not None and v != ""} or None)

    # ---- account --------------------------------------------------------------------------------------------------

    def sign_in(self, username, password):
        """POST /access/authenticate; keeps only the session cookie. Returns "" or a short error message."""
        self.cookie = ""
        status, text, headers = self.raw("POST", "/access/authenticate",
                                         body={"username": username, "password": password, "remember": True})
        if status == 429:
            return "Too many attempts. Try again in 15 minutes."
        if status == 401:
            return "Username or password not accepted."
        if status >= 500 or status == 404 or status < 0:
            return "Sign-in is unavailable right now. Please try again in a moment."
        if status != 200:
            return "Sign-in failed (HTTP %d)." % status
        cookie = cookie_from_headers(headers.get_all("Set-Cookie") if headers else [])
        if not cookie:
            return "The session could not be established."
        self.cookie = cookie
        self.username = username.strip().lower()
        if self.session:
            self.session.save({"cookie": self.cookie, "username": self.username})
        return ""

    def check(self):
        """The account behind the session (GET /access/session); None when signed out."""
        try:
            info = self.call("GET", "/access/session")
        except SignedOut:
            self.forget()
            return None
        if isinstance(info, dict) and info.get("username"):
            return info
        return None

    def sign_out(self):
        try:
            self.call("POST", "/access/logout", body={})
        except Exception:
            pass
        self.forget()

    def forget(self):
        self.cookie = ""
        self.username = ""
        if self.session:
            self.session.clear()

    # ---- playback links -------------------------------------------------------------------------------------------

    def kodi_url(self, path_or_url, cookie=False):
        """A URL Kodi's player can open. Paths on this server get the base. `cookie` (a link that needs the session):
        the link goes through this box's own relay (mc_relay), which adds the session itself, so Kodi, and kodi.log,
        never see the cookie. Only ever for this server: another site's link is returned as it is."""
        u = path_or_url
        ours = u.startswith("/")
        if ours:
            u = self.base + u
        elif urllib.parse.urlsplit(u).netloc == urllib.parse.urlsplit(self.base).netloc:
            ours = True
        if cookie and ours and self.cookie:
            import mc_relay
            try:
                import xbmcgui
                window = xbmcgui.Window(10000)
            except ImportError:
                window = None
            path = u[len(self.base):] or "/"
            u = mc_relay.prefix_for(self, window) + path
        return u

    def link_works(self, link, timeout=8):
        """Whether a version's link answers right now, asked before the player opens it so a dead one can give way to
        the next (the web player's link check, web-v27/js/playvod.js). Returns (True|False|None, reason): None when it
        couldn't be told in time, which the player then simply tries. Only the first two bytes are asked for. Headers
        after "|" go only to the link's own host: a redirect to another site drops the Cookie. A link through this box's
        relay (kodi_url) is asked through the relay, which adds the session itself."""
        url, _, extra = str(link or "").partition("|")
        if not url.startswith(("https://", "http://")):
            return None, ""
        h = {"User-Agent": USER_AGENT, "Range": "bytes=0-1"}
        for k, v in urllib.parse.parse_qsl(extra):
            h[k] = v
        req = urllib.request.Request(url, headers=h)
        try:
            res = self._probe_opener().open(req, timeout=timeout)
            status, head = res.getcode(), res.read(16)
        except urllib.error.HTTPError as e:
            status, head = e.code, b""
        except (OSError, ValueError):
            return None, ""
        if status in (200, 206):
            if url.split("?", 1)[0].lower().endswith(".m3u8") and head.lstrip()[:7] != b"#EXTM3U":
                return False, "not a playlist"
            return True, ""
        if status in (404, 410):
            return False, "not found"
        if status in (401, 403):
            return False, "refused"
        if status == 416:  # the server can't send part of the file; it still answers, so let the player try it
            return True, ""
        # Any other answer (a 500 or 502 on the way, a 429): it may be passing, so the player still tries the link. A
        # link that really is down fails in Kodi within seconds, so this costs little (owner, 2026-11-26: the links
        # are good; don't pass them over).
        return None, "HTTP %d" % status

    def _probe_opener(self):
        if getattr(self, "_probe", None) is None:
            class KeepCookieHome(urllib.request.HTTPRedirectHandler):
                def redirect_request(self, req, fp, code, msg, headers, newurl):
                    new = super().redirect_request(req, fp, code, msg, headers, newurl)
                    if new is not None and urllib.parse.urlsplit(newurl).netloc != urllib.parse.urlsplit(req.full_url).netloc:
                        for k in [k for k in new.headers if k.lower() in ("cookie", "x-mc-device")]:
                            del new.headers[k]
                    return new
            handlers = [KeepCookieHome()]
            if not getattr(self, "_custom_opener", False):
                handlers.append(urllib.request.HTTPSHandler(context=ssl.create_default_context()))
            self._probe = self._opener if getattr(self, "_custom_opener", False) else urllib.request.build_opener(*handlers)
        return self._probe

    def live_path(self, stream_id):
        sid = str(stream_id)
        if not sid.isdigit():
            raise ValueError("bad channel")
        return "/relay/live/STAGING_TESTER/STAGING_PROXY/%s.m3u8" % sid

    def live_url(self, stream_id):
        """A link to one live channel: the relay with the session, as the web app, the Roku, the iPhone and the Mac play
        live TV (web-v27/js/xtream.js playUrl, roku/components/screens/PlayerScreen.brs). The signed /share/live link
        used before goes straight from the server to the provider, which the other apps keep for outside players (VLC)
        only; a game's channel failed there in Kodi on 2026-11-25 while it played in the web player."""
        path = self.live_path(stream_id)
        if not self.cookie:
            raise SignedOut()
        return self.kodi_url(path, cookie=True)

    def live_plays(self, stream_id):
        """Whether a channel's relay answers with a playlist right now: True, False, or None when it couldn't be told
        (no answer in time). Asked before the player opens it, so a dead feed can give way to a backup feed, as the web
        player does on its own (web-v27/js/player.js, settings.backupFeeds, on by default)."""
        try:
            status, text, _ = self.raw("GET", self.live_path(stream_id), timeout=8)
        except (OSError, ValueError):
            return None
        if status in (401, 403):
            raise SignedOut()
        return status == 200 and (text or b"").lstrip()[:7] == b"#EXTM3U"

    # ---- Stremio add-ons (the account's own; asked directly, as the Roku does, never with our session) ------------

    def addon_streams(self, base, kind, stream_id, timeout=30):
        cut = base.lower().find("/manifest.json")
        if cut < 0 or not base.lower().startswith("https://"):
            return []
        url = base[:cut] + "/stream/%s/%s.json" % (kind, urllib.parse.quote(stream_id, safe="")) + base[cut + len("/manifest.json"):]
        req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": USER_AGENT})
        try:
            res = self._opener.open(req, timeout=timeout)
            data = json.loads(res.read().decode("utf-8"))
        except Exception:
            return []
        streams = data.get("streams") if isinstance(data, dict) else None
        return streams if isinstance(streams, list) else []
