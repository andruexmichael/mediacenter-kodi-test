# mediaCENTER for Kodi: the versions of a movie or episode in plain words, as the web app's "Choose a version" shows them.
#
# A line-for-line port of web-v27/js/version-info.js and the labels in web-v27/js/sources.js (the Roku has the same port in
# roku/components/lib/Versions.brs), so the Pi's list says and orders exactly what the web's does: how good it looks
# ("Full HD"), how big it is, whether it starts right away, and what its audio language is, with how sure we are. The one
# difference is what can play: the web asks the browser, the Pi asks mc_logic.play_level (its own decoders).
#
# Links that failed on this box are remembered for a while (web-v27/js/failed-links.js): only a short code for the link,
# the kind of failure and an expiry time are kept, never the address.

import hashlib
import json
import os
import re
import time

DOT = u" · "
QUALITY = {"2160p": "4K", "1080p": "Full HD", "720p": "HD", "480p": "SD"}


def quality_name(res):
    return QUALITY.get(res or "", "")


def _text(s):
    return "%s %s" % (s.get("name") or "", s.get("detail") or "")


SERVICES = "TB|RD|AD|PM|DL|OC|ED|PP"


def ready_state(s):
    """True: cached, starts right away; False: it has to be fetched first; None: the name does not say."""
    t = _text(s)
    if re.search(r"\[(%s)\s*(download|⏳)\]" % SERVICES, t, re.I) or re.search(u"not cached|uncached|not ready|❌", t, re.I):
        return False
    if re.search(r"\[(%s)\s*\+\]" % SERVICES, t, re.I) or re.search(u"⚡|\\bcached\\b|\\bready\\b", t, re.I):
        return True
    return None


NAMES = {"en": "English", "es": "Spanish", "fr": "French", "pt": "Portuguese", "de": "German", "it": "Italian"}


def language_name(code):
    return NAMES.get(str(code or "").lower()[:2], "English")


FLAGS = [(u"\U0001F1EC\U0001F1E7", "English"), (u"\U0001F1FA\U0001F1F8", "English"), (u"\U0001F1E6\U0001F1FA", "English"),
         (u"\U0001F1E8\U0001F1E6", "English"), (u"\U0001F1EA\U0001F1F8", "Spanish"), (u"\U0001F1F2\U0001F1FD", "Spanish"),
         (u"\U0001F1E6\U0001F1F7", "Spanish"), (u"\U0001F1EB\U0001F1F7", "French"), (u"\U0001F1E9\U0001F1EA", "German"),
         (u"\U0001F1EE\U0001F1F9", "Italian"), (u"\U0001F1F5\U0001F1F9", "Portuguese"), (u"\U0001F1E7\U0001F1F7", "Portuguese"),
         (u"\U0001F1F7\U0001F1FA", "Russian"), (u"\U0001F1FA\U0001F1E6", "Ukrainian"), (u"\U0001F1EF\U0001F1F5", "Japanese"),
         (u"\U0001F1F0\U0001F1F7", "Korean"), (u"\U0001F1E8\U0001F1F3", "Chinese"), (u"\U0001F1F9\U0001F1FC", "Chinese"),
         (u"\U0001F1ED\U0001F1F0", "Chinese"), (u"\U0001F1EE\U0001F1F3", "Hindi"), (u"\U0001F1F5\U0001F1F1", "Polish"),
         (u"\U0001F1F3\U0001F1F1", "Dutch"), (u"\U0001F1F9\U0001F1F7", "Turkish"), (u"\U0001F1F8\U0001F1E6", "Arabic"),
         (u"\U0001F1EA\U0001F1EC", "Arabic"), (u"\U0001F1F8\U0001F1EA", "Swedish"), (u"\U0001F1F3\U0001F1F4", "Norwegian"),
         (u"\U0001F1E9\U0001F1F0", "Danish"), (u"\U0001F1EB\U0001F1EE", "Finnish"), (u"\U0001F1EC\U0001F1F7", "Greek"),
         (u"\U0001F1E8\U0001F1FF", "Czech"), (u"\U0001F1ED\U0001F1FA", "Hungarian"), (u"\U0001F1F7\U0001F1F4", "Romanian"),
         (u"\U0001F1F9\U0001F1ED", "Thai"), (u"\U0001F1EE\U0001F1F1", "Hebrew"), (u"\U0001F1FB\U0001F1F3", "Vietnamese"),
         (u"\U0001F1EE\U0001F1E9", "Indonesian")]
WORDS = [("English", "english"), ("Spanish", "spanish|castellano|latino"), ("French", "french|truefrench|vostfr"),
         ("German", "german|deutsch"), ("Italian", "italian"), ("Portuguese", "portuguese"), ("Russian", "russian"),
         ("Ukrainian", "ukrainian"), ("Japanese", "japanese"), ("Korean", "korean"), ("Chinese", "chinese|mandarin|cantonese"),
         ("Hindi", "hindi"), ("Polish", "polish"), ("Dutch", "dutch"), ("Turkish", "turkish"), ("Arabic", "arabic"),
         ("Swedish", "swedish"), ("Norwegian", "norwegian"), ("Danish", "danish"), ("Finnish", "finnish"), ("Greek", "greek"),
         ("Czech", "czech"), ("Hungarian", "hungarian"), ("Romanian", "romanian"), ("Thai", "thai"), ("Hebrew", "hebrew"),
         ("Vietnamese", "vietnamese"), ("Indonesian", "indonesian")]
TAGS = {"English": ["ENG"], "Spanish": ["SPA", "LATINO", "CASTELLANO"], "French": ["FRE", "FRA", "TRUEFRENCH", "VOSTFR"],
        "German": ["GER", "DEU", "GERMAN"], "Italian": ["ITA"], "Portuguese": ["POR", "PTBR"], "Russian": ["RUS"],
        "Japanese": ["JPN", "JAP"], "Korean": ["KOR"], "Chinese": ["CHI", "ZHO", "CHS", "CHT"], "Hindi": ["HIN"],
        "Polish": ["POL"], "Dutch": ["DUT", "NLD"], "Turkish": ["TUR"], "Arabic": ["ARA"]}


def source_languages(s):
    """The languages a source says it has (sources.js sourceLanguages): flags, names after the speech mark, release tags."""
    text = u"%s\n%s" % (s.get("name") or "", s.get("detail") or "")
    out = []
    for flag, name in FLAGS:
        if flag in text and name not in out:
            out.append(name)
    spoken = " ".join(l for l in re.split(r"\r?\n", text) if u"\U0001F5E3" in l or re.match(r"^(languages|audio:)", l, re.I))
    tokens = set(t for t in re.split(r"[^\w]+|[\d_]+", text, flags=re.U) if t)
    for name, words in WORDS:
        if name in out:
            continue
        if re.search(r"\b(%s)\b" % words, spoken, re.I) or any(t in tokens for t in TAGS.get(name, [])):
            out.append(name)
    if not out and re.search(r"multi|dual[ -]audio", text, re.I):
        out.append("Multiple languages")
    return out


SUBS = re.compile(r"\b(e?subs?|multi[ ._-]?subs?|(eng(lish)?|spa(nish)?|fre(nch)?)[ ._-]?sub(s|titles?)?|hardsubs?|softsubs?)\b", re.I)
DUB = re.compile(r"\b(dub(bed)?|(eng(lish)?)[ ._-]?dub)\b", re.I)
DUAL = re.compile(r"\b(dual[ ._-]?audio|multi[ ._-]?audio|multi)\b", re.I)


def audio_mark(s, wanted="en"):
    """What the audio of a version is: {kind: confirmed|listed|subs|other|unknown, text}."""
    w = language_name(wanted)
    if any(str(l).lower().startswith(w.lower()[:3]) for l in s.get("audioLanguages") or []):
        return {"kind": "confirmed", "text": "%s audio" % w}
    text = _text(s)
    langs = source_languages(s)
    has_w = w in langs
    has_sub = bool(SUBS.search(text))
    if DUB.search(text):
        return {"kind": "listed", "text": "%s dub listed, not checked" % w}
    if DUAL.search(text):
        return {"kind": "listed", "text": "Dual audio listed, not checked"}
    if has_w and not has_sub:
        return {"kind": "listed", "text": "%s listed, not checked" % w}
    if has_sub:
        if has_w or re.search(r"\beng", text, re.I):
            return {"kind": "subs", "text": "Original audio, %s subtitles" % w}
        return {"kind": "subs", "text": "Original audio, subtitles"}
    other = next((l for l in langs if l != w), None)
    if other:
        return {"kind": "other", "text": "%s audio listed" % other}
    return {"kind": "unknown", "text": ""}


def sensible_size(b):
    """About 300 MB to 15 GB: a 400 GB "version" is a season pack and a few megabytes a sample."""
    return not b or 3e8 <= b <= 15e9


def size_bytes(s):
    size = s.get("size") or 0
    if isinstance(size, (int, float)) and size > 0:
        return int(size)
    m = re.search(r"(\d+(?:\.\d+)?)\s*(GB|MB|TB)\b", "%s %s" % (s.get("detail") or "", s.get("name") or ""), re.I)
    return int(round(float(m.group(1)) * {"MB": 1e6, "GB": 1e9, "TB": 1e12}[m.group(2).upper()])) if m else 0


def size_text(b):
    """ "12.90 GB", "700 MB" (sources.js sizeText)."""
    if not b:
        return ""
    return "%.2f GB" % (b / 1e9) if b >= 1e9 else "%d MB" % round(b / 1e6)


def version_info(s, wanted="en"):
    return {"quality": quality_name(s.get("res")), "size": size_bytes(s), "ready": ready_state(s), "mark": audio_mark(s, wanted)}


LANG_RANK = {"confirmed": 0, "listed": 1, "unknown": 2, "subs": 3, "other": 4}


def _ready_rank(r):
    return 0 if r is True else 1 if r is None else 2


def sort_versions(rows):
    """Best first (sortVersions): starts right away, a sensible size, the viewer's language, then the order given."""
    return [r for _, r in sorted(enumerate(rows), key=lambda x: (_ready_rank(x[1]["info"]["ready"]), 0 if sensible_size(x[1]["info"]["size"]) else 1,
                                                                  LANG_RANK.get(x[1]["info"]["mark"]["kind"], 2), x[0]))]


# ---- what this box plays well (0.4.9.3) ----------------------------------------------------------------------------
#
# The web asks the browser what it can play; the Pi has to judge for itself. On a Raspberry Pi 3 (owner, 2026-11-26: the
# automatic pick "seemed playable" and then stalled) that means H.264 in hardware at a bitrate its network and decoder keep
# up with: HEVC and 10-bit H.264 decode in software and stutter, and a remux or a 30 GB film streams at 40 Mbps or more.
# So the order for this box puts first what starts (not a link that has to be fetched first), then what plays well here,
# then the web's order (cached, a sensible size, the viewer's language). The list says the same as the web's; only the
# order of what this box plays is its own.

HEAVY_MINUTES = {"movie": 110, "series": 45}  # a title's length when the server doesn't give one
HI10 = re.compile(r"\b(10[ ._-]?bit|hi10p?)\b", re.I)
REMUX = re.compile(r"\b(remux|bdremux|bd[ ._-]?disk|iso)\b", re.I)


def mbps(size, minutes):
    """About how many megabits a second a file of `size` bytes plays at over `minutes`; 0 when either is unknown."""
    if not size or not minutes:
        return 0.0
    return size * 8.0 / (minutes * 60.0) / 1e6


def fit_rank(v, info=None, box=None):
    """0: plays well here; 1: plays well but heavy for this box; 2: may stutter here; 3: may stutter and heavy.
    box: {"max_mbps": the most this box streams smoothly (0: no limit), "minutes": how long the title is}."""
    box = box or {}
    info = info or version_info(v)
    text = _text(v)
    maybe = v.get("level") == "maybe" or (box.get("max_mbps") and (v.get("video") or "") == "h264" and bool(HI10.search(text)))
    limit = box.get("max_mbps") or 0
    heavy = False
    if limit:
        rate = mbps(info.get("size"), box.get("minutes") or 0)
        heavy = bool(REMUX.search(text)) or rate > limit
    return (2 if maybe else 0) + (1 if heavy else 0)


def sort_for_box(rows, box=None):
    """The web's order (sort_versions) with this box's judgement in front of it: links that have to be fetched first go
    last, and among the rest what plays well here comes before what may stutter or is too heavy."""
    return [r for _, r in sorted(enumerate(rows), key=lambda x: (
        1 if x[1]["info"]["ready"] is False else 0, fit_rank(x[1]["version"], x[1]["info"], box),
        _ready_rank(x[1]["info"]["ready"]), 0 if sensible_size(x[1]["info"]["size"]) else 1,
        LANG_RANK.get(x[1]["info"]["mark"]["kind"], 2), x[0]))]


def sort_other_versions(rows):
    """The ones this box may not play (sortVlcVersions): best picture first, then language, ready, a streamable size."""
    q = {"4K": 0, "Full HD": 1, "HD": 2, "SD": 3}

    def size(b):
        return 1 if not b else 3 if b < 3e8 or b > 100e9 else 2 if b > 30e9 else 0
    return [r for _, r in sorted(enumerate(rows), key=lambda x: (q.get(x[1]["info"]["quality"], 4), LANG_RANK.get(x[1]["info"]["mark"]["kind"], 2),
                                                                  _ready_rank(x[1]["info"]["ready"]), size(x[1]["info"]["size"]), x[0]))]


def source_badges(s):
    """ "4K · DV · HEVC · DD+ · 5.1 · English" (sources.js sourceBadges)."""
    text = u"%s\n%s" % (s.get("name") or "", s.get("detail") or "")
    out = []
    res = "4K" if s.get("res") == "2160p" else (s.get("res") or "")
    if res:
        out.append(res)
    if re.search(r"\b(DV|dolby ?vision|DoVi)\b", text, re.I):
        out.append("DV")
    elif re.search(r"\bHDR10\+", text, re.I):
        out.append("HDR10+")
    elif re.search(r"\bHDR", text, re.I):
        out.append("HDR")
    video = s.get("video") or ""
    if video:
        out.append("H.264" if video == "h264" else video.upper())
    a = s.get("audio") or []
    if re.search(r"atmos", text, re.I):
        out.append("Atmos")
    else:
        for codec, name in (("truehd", "TrueHD"), ("eac3", "DD+"), ("dts", "DTS"), ("ac3", "DD"), ("aac", "AAC")):
            if codec in a:
                out.append(name)
                break
    ch = re.search(r"\b([257]\.[01])\b(?!\s*[GMT]B)", text, re.I)  # not the "2.1" of "2.1 GB"
    if ch:
        out.append(ch.group(1))
    langs = source_languages(s)
    if langs:
        out.append(DOT.join(langs[:3]) + (" +%d" % (len(langs) - 3) if len(langs) > 3 else ""))
    return DOT.join(out)


def facts_line(info):
    """ "Full HD · 2.10 GB" (linksheet.js factsLine)."""
    return DOT.join(p for p in [info["quality"], size_text(info["size"])] if p) or "Version"


READY_TEXT = {True: "Starts right away", False: "May take a minute", None: ""}
READY_SHORT = {True: "Instant", False: "A minute", None: ""}
PLACES = {"torbox": "TorBox", "jellyfin": "Jellyfin", "regular": "FlixNest", "addon": "TorBox", "velocity": "Velocity"}


def link_key(v):
    """A short code for a link (provider and a digest of its address), so a failure can be remembered without the address."""
    return "%s:%s" % (v.get("provider") or "", hashlib.sha1((v.get("url") or "").encode("utf-8")).hexdigest()[:12])


def rows_for(ranked, wanted="en", failed=lambda key: False, hidden_versions=(), box=None):
    """The picker's rows, as the web's link sheet builds them: [{version, info, key, place, failed, hidden}].
    Returns (rows that play here, best first; rows left out because they failed here lately; rows this box may not play).
    The first row (BEST MATCH) is the one the automatic pick plays first (sort_for_box)."""
    rows, gone = [], []
    for v in ranked:
        r = {"version": v, "info": version_info(v, wanted), "key": link_key(v), "place": PLACES.get(v.get("provider"), v.get("provider") or ""), "hidden": False}
        (gone if failed(r["key"]) else rows).append(r)
    if not rows:  # everything failed lately: show them all again
        rows, gone = gone, []
    others = [{"version": v, "info": version_info(v, wanted), "key": link_key(v), "place": PLACES.get(v.get("provider"), v.get("provider") or ""), "hidden": True}
              for v in hidden_versions]
    return sort_for_box(rows, box), sort_for_box(gone, box), sort_other_versions(others)


def feeds(ranked, pick=None, failed=lambda key: False, limit=8, box=None):
    """The links to try, in order (playvod.js feedsFor): the version picked in the list first, then the best others behind it
    as fallbacks (the player moves on when one fails or stalls). Links that failed here lately are left out unless picked.
    The order is the picker's (sort_for_box), so the automatic pick plays its BEST MATCH first."""
    pick_key = link_key(pick) if pick else None
    order = sort_for_box([{"version": v, "info": version_info(v), "key": link_key(v)} for v in ranked], box)
    fresh = [r for r in order if not failed(r["key"]) or r["key"] == pick_key]
    chosen = [r["version"] for r in (fresh or order)][:limit]
    if pick:
        chosen = [pick] + [v for v in chosen if link_key(v) != pick_key][:limit - 1]
    return chosen


# ---- links that failed on this box (failed-links.js) -----------------------------------------------------------------

DAY = 86400


def classify(message):
    m = str(message or "").lower()
    if re.search(r"only \d+ seconds|sample or a damaged", m):
        return "sample", 30 * DAY
    if re.search(r"not found|no longer|expired|refused|unsupported|couldn't be played|dead", m):
        return "dead", 7 * DAY
    return "temporary", DAY


class FailedLinks(object):
    """A small file in the add-on's profile: {key: {reason, until}}. 400 entries at most."""
    MAX = 400

    def __init__(self, folder, now=time.time):
        self.path = os.path.join(folder, "failed-links.json")
        self.now = now

    def read(self):
        try:
            with open(self.path) as f:
                data = json.load(f)
        except (OSError, ValueError):
            return {}
        t = self.now()
        return {k: v for k, v in data.items() if isinstance(v, dict) and v.get("until", 0) > t} if isinstance(data, dict) else {}

    def remember(self, key, message=""):
        if not key:
            return None
        reason, ttl = classify(message)
        data = self.read()
        data[key] = {"reason": reason, "until": self.now() + ttl}
        keep = dict(sorted(data.items(), key=lambda kv: -kv[1]["until"])[:self.MAX])
        try:
            folder = os.path.dirname(self.path)
            if not os.path.isdir(folder):
                os.makedirs(folder)
            with open(self.path, "w") as f:
                json.dump(keep, f)
        except OSError:
            pass
        return reason

    def has(self, key):
        return bool(key) and key in self.read()

    def forget_all(self):
        try:
            os.remove(self.path)
        except OSError:
            pass

    def forget_once(self, tag):
        """Forget every remembered failure once for tag (0.4.8: links that played sound over black on a Raspberry Pi
        were remembered as failed though nothing was wrong with them). Returns True when it forgot them now."""
        mark = os.path.join(os.path.dirname(self.path), "failed-links-forgotten-" + tag)
        if os.path.exists(mark):
            return False
        self.forget_all()
        try:
            folder = os.path.dirname(mark)
            if not os.path.isdir(folder):
                os.makedirs(folder)
            open(mark, "w").close()
        except OSError:
            pass
        return True
