"""Trusted update feed, bounded downloads and staged, rollback-capable installation.

The worker is copied to the profile before RunScript so replacing the add-on cannot remove its running code.
Account/profile data is never part of an update. No shell commands or remote installer scripts are run.
"""
import hashlib
import inspect
import json
import os
from pathlib import Path
import re
import shutil
import ssl
import stat
import tempfile
import time
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

FEEDS = {
    'stable': 'https://watch.littlebirdtampa.com/kodi/',
    'test': 'https://raw.githubusercontent.com/andruexmichael/mediacenter-kodi-test/main/'
}
APP = 'plugin.video.mediacenter'
REMOTE = 'service.mediacenter.remote'
ALLOWED = (APP, 'script.mediacenter', 'skin.mediacenter', 'repository.mediacenter', 'repository.mediacenter.test', REMOTE)
NEEDED = (REMOTE,)  # parts the app needs: added by an update when they're not here yet (the app requires them)
# The order parts are put in place: what an add-on imports goes in before it (the remote and the launcher, then the
# app, then the skin, which imports the app), so no part is ever newer than something it asks for (0.4.9.2).
ORDER = (REMOTE, 'script.mediacenter', APP, 'skin.mediacenter', 'repository.mediacenter', 'repository.mediacenter.test')
LIMIT = 60 * 1024 * 1024
CHUNK = 64 * 1024  # downloads are read this much at a time, so the progress bar moves (0.4.9.3)
# Certificate lists to try when Python's own can't be found (LibreELEC keeps its list in /etc/ssl).
CA_FILES = ('/etc/ssl/cacert.pem', '/etc/ssl/certs/ca-certificates.crt', '/etc/pki/tls/certs/ca-bundle.crt')


def version(value):
    """1.2.3, or 1.2.3.4 for a quick fix between two releases (0.4.7.1 comes after 0.4.7 and before 0.4.8)."""
    if not re.fullmatch(r'\d{1,4}(\.\d{1,4}){2,3}', value or ''):
        raise ValueError('Invalid version')
    parts = tuple(map(int, value.split('.')))
    return parts + (0,) * (4 - len(parts))


def log(text):
    try:
        import xbmc
        xbmc.log('mediaCENTER update: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def agent():
    """The name downloads go out under: "mediaCENTER-Kodi/0.4.9". The stable list (the website) refuses Python's own
    "Python-urllib" with HTTP 403 (owner's Pi, 2026-11-26) and answers when the app names itself."""
    ver = ''
    try:
        ver = ET.parse(str(Path(__file__).resolve().parents[2] / 'addon.xml')).getroot().get('version') or ''
    except (OSError, ET.ParseError, IndexError):
        pass
    if not ver:  # the installer runs from a copy in the profile folder: ask Kodi
        try:
            import xbmcaddon
            ver = xbmcaddon.Addon(APP).getAddonInfo('version') or ''
        except Exception:
            ver = ''
    return 'mediaCENTER-Kodi/%s' % ver if re.fullmatch(r'[\d.]{1,20}', ver) else 'mediaCENTER-Kodi'


def expected_size(value, limit):
    """The size a download says it will be (Content-Length, Kodi's file size), or None when it doesn't say or says
    more than the limit allows (the limit still stops the download)."""
    try:
        size = int(value)
    except (TypeError, ValueError):
        return None
    return size if 0 < size <= limit else None


def read_bounded(read, limit, report, total=None):
    """Read up to limit + 1 bytes in CHUNKs, telling report(bytes so far, total or None) after each."""
    data = bytearray()
    while len(data) <= limit:
        chunk = read(min(CHUNK, limit + 1 - len(data)))
        if not chunk:
            break
        data += chunk
        report(len(data), total)
    return bytes(data)


def fetch_python(url, limit, context=None, report=None):
    request = urllib.request.Request(url, headers={'User-Agent': agent(), 'Accept': '*/*'})
    with urllib.request.urlopen(request, timeout=30, context=context) as response:
        if not any(response.geturl().startswith(base) for base in FEEDS.values()):
            raise ValueError('Untrusted redirect')
        if report is None:
            return response.read(limit + 1)
        headers = getattr(response, 'headers', None)
        total = expected_size(headers.get('Content-Length') if hasattr(headers, 'get') else None, limit)
        return read_bounded(response.read, limit, report, total)


def fetch_kodi(url, limit, report=None):
    """Kodi's own downloader, the one that installs add-ons: it works on boxes where Python can't check certificates."""
    import xbmcvfs
    f = xbmcvfs.File(url)
    try:
        if report is None:
            data = bytes(f.readBytes(limit + 1))
        else:
            try:
                total = expected_size(f.size(), limit)
            except Exception:
                total = None
            data = read_bounded(lambda n: bytes(f.readBytes(n)), limit, report, total)
    finally:
        f.close()
    if not data:
        raise OSError('Nothing downloaded')
    return data


def takes_report(fetch):
    """Whether a downloader can say how far it has got (download() can; a test's stand-in may not)."""
    try:
        return 'report' in inspect.signature(fetch).parameters
    except (TypeError, ValueError):
        return False


def download(url, limit=LIMIT, kodi=fetch_kodi, report=None):
    """Python's downloader first, then with the box's own certificate list, then Kodi's downloader. Only the update
    addresses are ever asked for, and the size limit, the checksum and the package checks hold whichever one answers.
    report(bytes so far, expected size or None), when given, is told as the download goes (each try starts again)."""
    if not any(url.startswith(base) for base in FEEDS.values()):
        raise ValueError('Untrusted update address')
    extra = {'report': report} if report is not None else {}
    try:
        data = fetch_python(url, limit, **extra)
    except ValueError:
        raise
    except Exception as first:
        data = None
        log('Python download failed (%s), trying the box\'s certificates' % type(first).__name__)
        for ca in CA_FILES:
            if not os.path.isfile(ca):
                continue
            try:
                data = fetch_python(url, limit, ssl.create_default_context(cafile=ca), **extra)
                break
            except ValueError:
                raise
            except Exception:
                pass
        if data is None:
            try:
                data = kodi(url, limit, **extra) if extra and takes_report(kodi) else kodi(url, limit)
            except ImportError:
                raise first
            except ValueError:
                raise
            except Exception as e:
                log('Kodi download failed too (%s)' % type(e).__name__)
                raise first
    if len(data) > limit:
        raise ValueError('Update too large')
    return data


def waiting(running, have):
    """The newer version that's installed but not running yet (mediaCENTER only needs a restart), or ''."""
    on_disk = have.get(APP) if isinstance(have, dict) else have
    try:
        return on_disk if running and on_disk and version(on_disk) > version(running) else ''
    except ValueError:
        return ''


def ordered(packages):
    """The packages in ORDER: dependencies first."""
    return sorted(packages, key=lambda p: ORDER.index(p['id']) if p['id'] in ORDER else len(ORDER))


def installed(addons):
    """{add-on id: version} of our add-ons in Kodi's add-on folder."""
    out = {}
    for ident in ALLOWED:
        manifest = Path(addons) / ident / 'addon.xml'
        try:
            ver = ET.parse(str(manifest)).getroot().get('version')
            version(ver)
            out[ident] = ver
        except (OSError, ET.ParseError, ValueError):
            pass
    return out


def default_channel(have):
    """The update list this box was set up from: Test when the test repository is installed, otherwise Stable."""
    return 'test' if 'repository.mediacenter.test' in have and 'repository.mediacenter' not in have else 'stable'


def check(channel, have, fetch=download):
    """What the update list offers: {channel, version, available, notes, packages}. Add-ons that are installed here and
    newer in the list are in packages (the skin only goes where the skin is, so a Kodi 20 box never gets it), and so are
    the parts the app needs that aren't here yet (the iPhone remote, the first time)."""
    if isinstance(have, str):
        have = {APP: have}
    base = FEEDS[channel]
    xml = fetch(base + 'addons.xml', 1024 * 1024)
    checksum = fetch(base + 'addons.xml.md5', 128).decode().strip()
    if hashlib.md5(xml).hexdigest() != checksum:
        raise ValueError('Update list is changing; try again')
    root = ET.fromstring(xml)
    if root.tag != 'addons':
        raise ValueError('Invalid update list')
    listed = {}
    for addon in root:
        ident = addon.get('id')
        if ident not in ALLOWED:
            continue
        if ident in listed:
            raise ValueError('Duplicate add-on')
        ver = addon.get('version')
        version(ver)
        listed[ident] = ver
    if APP not in listed or 'script.mediacenter' not in listed:
        raise ValueError('Incomplete update')
    packages = ordered([{'id': ident, 'version': ver} for ident, ver in listed.items()
                        if (ident in have and version(ver) > version(have[ident])) or (ident in NEEDED and ident not in have)])
    notes = root.find("./addon[@id='%s']/extension/news" % APP)
    return {'channel': channel, 'version': listed[APP], 'available': bool(packages),
            'notes': (notes.text or '').strip() if notes is not None and (notes.text or '').strip()
            else 'Improvements to mediaCENTER. Your account and settings are kept.',
            'packages': packages}


def extract(data, folder, ident, ver):
    import io
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        entries = archive.infolist()
        if sum(e.file_size for e in entries) > 150 * 1024 * 1024 or len(entries) > 6000:
            raise ValueError('Expanded update too large')
        for e in entries:
            parts = e.filename.split('/')
            if parts[0] != ident or '..' in parts or '\\' in e.filename or any(p.startswith('.') for p in parts if p):
                raise ValueError('Unsafe update path')
            mode = e.external_attr >> 16
            if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)):
                raise ValueError('Unsafe update entry')
            if '/resources/data/sample/' in e.filename or e.filename.endswith('/session.json'):
                raise ValueError('Unexpected account or sample data')
        archive.extractall(folder)
    manifest = ET.parse(Path(folder) / ident / 'addon.xml').getroot()
    if manifest.get('id') != ident or manifest.get('version') != ver:
        raise ValueError('Package does not match update list')


# ---- the progress bar (0.4.9.3, owner: "a real progress bar for the updater") ----------------------------------------
# Downloading takes the bar to DOWNLOADED per cent, part by part (each part's share moves as its bytes arrive, against
# the size the download says it is, never beyond the limit); putting the parts in place takes it to INSTALLED; checking
# every part is switched on takes it to 100. Each line says which part and what is happening.

NAMES = {REMOTE: 'the iPhone remote', 'script.mediacenter': 'the launcher', APP: 'mediaCENTER',
         'skin.mediacenter': "the box's look", 'repository.mediacenter': 'the update list',
         'repository.mediacenter.test': 'the test update list'}
DOWNLOADED, INSTALLED = 80, 95
KEEP_ON = 'Keep the box plugged in.'


def part_name(ident):
    return NAMES.get(ident, 'mediaCENTER')


def megabytes(size):
    return '%.1f MB' % (size / 1048576.0)


class Progress(object):
    """Turns the installer's steps into show(per cent, text) for a progress dialog, only when something changes."""

    def __init__(self, show, parts):
        self.show, self.parts, self.last = show, max(1, parts), None

    def say(self, percent, text):
        shown = (max(0, min(100, int(percent))), text)
        if shown != self.last:
            self.last = shown
            self.show(*shown)

    def of(self, index):
        return ' (%d of %d)' % (index + 1, self.parts) if self.parts > 1 else ''

    def downloading(self, index, ident, done=0, total=None):
        share = min(1.0, float(done) / total) if total else 0.0
        how_far = '%d%%' % int(share * 100) if total else (megabytes(done) if done else '')
        self.say(DOWNLOADED * (index + share) / self.parts,
                 ('Downloading %s… %s' % (part_name(ident), how_far)).rstrip() + self.of(index) + '\n' + KEEP_ON)

    def closing(self):
        self.say(DOWNLOADED, 'Closing mediaCENTER before installing…\n' + KEEP_ON)

    def installing(self, index, ident):
        self.say(DOWNLOADED + (INSTALLED - DOWNLOADED) * index / self.parts,
                 'Installing %s…%s\n%s' % (part_name(ident), self.of(index), KEEP_ON))

    def checking(self):
        self.say(INSTALLED, 'Checking every part is switched on…\n' + KEEP_ON)

    def done(self):
        self.say(100, 'Update installed. mediaCENTER is restarting…')


def install(plan, addons, fetch=download, progress=lambda percent, text: None, before_swap=lambda: None,
            after_swap=lambda: None):
    """Download and validate everything first; preserve original folders until all replacements succeed.
    progress(per cent, text) is told how far it has got (Progress)."""
    channel = plan['channel']
    base = FEEDS[channel]
    addons = Path(addons)
    if not plan['packages'] or len(plan['packages']) > len(ALLOWED) or len({p['id'] for p in plan['packages']}) != len(plan['packages']):
        raise ValueError('Invalid package list')
    packages = ordered(plan['packages'])
    bar = Progress(progress, len(packages))
    reports = takes_report(fetch)
    staged = Path(tempfile.mkdtemp(prefix='.mediacenter-update-', dir=str(addons)))
    changed = []
    try:
        new, backup = staged / 'new', staged / 'backup'
        new.mkdir(); backup.mkdir()
        for index, package in enumerate(packages):
            ident, ver = package['id'], package['version']
            if ident not in ALLOWED:
                raise ValueError('Unexpected add-on')
            version(ver)
            current = addons / ident / 'addon.xml'
            if current.exists() and version(ET.parse(str(current)).getroot().get('version')) >= version(ver):
                raise ValueError('Refusing to downgrade or reinstall an installed component')
            bar.downloading(index, ident)
            url = base + ident + '/' + ident + '-' + ver + '.zip'
            if reports:
                data = fetch(url, LIMIT, report=lambda done, total, i=index, p=ident: bar.downloading(i, p, done, total))
            else:
                data = fetch(url)
            bar.downloading(index, ident, 1, 1)
            extract(data, new, ident, ver)
        bar.closing()
        before_swap()
        for index, package in enumerate(packages):  # dependencies first (ORDER)
            ident = package['id']
            bar.installing(index, ident)
            target, saved = addons / ident, backup / ident
            existed = target.exists()
            if existed:
                os.replace(target, saved)
            changed.append((ident, existed))
            os.replace(new / ident, target)
        bar.checking()
        after_swap()
        bar.done()
    except Exception:
        for ident, existed in reversed(changed):
            target = addons / ident
            if target.exists():
                shutil.rmtree(target)
            if existed:
                os.replace(staged / 'backup' / ident, target)
        raise
    finally:
        shutil.rmtree(staged, ignore_errors=True)


def add_needed(channel, addons, fetch=download, after_swap=lambda: None):
    """Add the parts the app needs that aren't here yet (the iPhone remote on a box that updated from 0.4.6, whose
    updater didn't know it), quietly and without touching the parts that are here. Returns the ids added."""
    plan = check(channel, installed(addons), fetch)
    plan['packages'] = [p for p in plan['packages'] if p['id'] in NEEDED and not (Path(addons) / p['id']).exists()]
    if not plan['packages']:
        return []
    install(plan, addons, fetch, after_swap=after_swap)
    return [p['id'] for p in plan['packages']]


# ---- keeping the parts switched on (0.4.9.2) --------------------------------------------------------------------------
# On the owner's Pi the 0.4.9 update left the app switched off: Kodi's add-on table had enabled=0 with disabledReason=1.
# In Kodi 21 that reason is USER, which only an explicit switch-off writes (Addons.SetAddonEnabled false, Kodi's own
# menu); a part Kodi finds newly copied gets reason 0, and Kodi only checks xbmc.* and kodi.* imports (never optional
# ones) when it decides a part is incompatible. So the switch-off came from the installer of that time, which turned the
# app off while it swapped files and turned it on again after. Kodi's Addons.SetAddonEnabled answers OK even when the
# switch-on did not take (CAddonMgr::EnableAddon ignores what EnableSingle says), so nothing noticed.
# From 0.4.9.2 the installer never switches the app off, and
# after every install each mediaCENTER part is asked about and switched on again if Kodi has it off.


def kodi_rpc(method, params):
    """Kodi's JSON-RPC from inside Kodi (xbmc.executeJSONRPC), not the web server, which may be off."""
    import xbmc
    reply = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})))
    if not isinstance(reply, dict) or 'error' in reply:
        raise RuntimeError('Kodi said no')
    return reply.get('result')


def enabled_state(rpc, ident):
    """'on', 'off' (installed and switched off), 'missing' (Kodi doesn't know it) or '' (Kodi won't say)."""
    try:
        result = rpc('Addons.GetAddonDetails', {'addonid': ident, 'properties': ['enabled']})
    except RuntimeError:
        return 'missing'
    except (ValueError, TypeError):
        return ''
    addon = result.get('addon') if isinstance(result, dict) else None
    if not isinstance(addon, dict) or 'enabled' not in addon:
        return ''
    return 'on' if addon.get('enabled') else 'off'


def refresh_local():
    import xbmc
    xbmc.executebuiltin('UpdateLocalAddons', True)


def ensure_enabled(idents, rpc=kodi_rpc, refresh=refresh_local, tries=3):
    """Switch on every part in idents that Kodi has installed but off, then ask Kodi to look again and check. Parts
    Kodi doesn't know are left alone. Returns the ids still off (empty when all is well)."""
    off = [i for i in idents if enabled_state(rpc, i) == 'off']
    for _ in range(tries):
        if not off:
            return []
        for ident in off:
            log('%s was switched off; switching it on' % ident)
            try:
                rpc('Addons.SetAddonEnabled', {'addonid': ident, 'enabled': True})
            except (RuntimeError, ValueError, TypeError):
                pass
        refresh()
        off = [i for i in off if enabled_state(rpc, i) == 'off']
    if off:
        log('still switched off: %s' % ', '.join(off))
    return off


# ---- updating by itself (0.4.9, owner: "the Pi app must update itself from now on") --------------------------------
# The service looks at the chosen update list soon after start and every few hours. When something newer is listed it
# waits until the box is idle (nothing playing, nobody pressing keys), then hands the plan to the same installer the
# Install button uses (worker(), from a copy in the profile folder), quietly. Every check above still holds, and the
# old version stays if anything fails. A version that failed, or that never came up after its restart, is written
# down and never tried again; a newer one is. Kodi's own add-on updates are not relied on (on the owner's Pi the app
# has an entry in Kodi's update_rules and the remote has no origin repository).

AUTO_FILE = 'auto-update.json'


def _key(package):
    return '%s@%s' % (package['id'], package['version'])


def auto_state(profile):
    try:
        with open(os.path.join(str(profile), AUTO_FILE)) as f:
            state = json.load(f)
        return state if isinstance(state, dict) else {}
    except (OSError, ValueError):
        return {}


def save_auto_state(profile, state):
    os.makedirs(str(profile), exist_ok=True)
    path = os.path.join(str(profile), AUTO_FILE)
    with open(path + '.new', 'w') as f:
        json.dump(state, f)
    os.replace(path + '.new', path)


def remember_failed(profile, packages):
    """Write down packages that could not be installed, so they are never tried again by themselves."""
    state = auto_state(profile)
    failed = [k for k in state.get('failed') or [] if isinstance(k, str)]
    for p in packages:
        if _key(p) not in failed:
            failed.append(_key(p))
    state['failed'] = failed[-50:]
    state.pop('trying', None)
    save_auto_state(profile, state)


class Auto(object):
    """When to look and when to install. now: time.time(); the service checks once a minute."""
    FIRST = 180          # seconds after start before the first look
    EVERY = 6 * 3600     # then a few times a day
    IDLE = 15 * 60       # nobody has pressed a key for this long

    def __init__(self, profile, now=None):
        self.profile = str(profile)
        self.plan = None
        self.next = (time.time() if now is None else now) + self.FIRST

    def settle(self, have):
        """At start: an install that was started last time either came up (all its parts are here at their versions)
        or it did not, and is written down as failed."""
        state = auto_state(self.profile)
        trying = state.get('trying')
        if not isinstance(trying, list):
            return None
        missed = []
        for p in trying:
            try:
                here = have.get(p['id'])
                if not here or version(here) < version(p['version']):
                    missed.append(p)
            except (KeyError, TypeError, ValueError, AttributeError):
                pass
        if missed:
            remember_failed(self.profile, trying)
            log('automatic update did not come up; it will not be tried again')
            return 'failed'
        state.pop('trying', None)
        save_auto_state(self.profile, state)
        return 'done'

    def failed(self):
        return set(auto_state(self.profile).get('failed') or [])

    def due(self, now):
        return now >= self.next

    def look(self, check, now):
        """check(): mc_updates.check for the chosen list. Keeps the plan when there is something new not failed before."""
        self.next = now + self.EVERY
        self.plan = None
        try:
            plan = check()
        except Exception as e:  # never addresses or messages in the log
            log('automatic check failed (%s)' % type(e).__name__)
            return None
        if auto_state(self.profile).get('trying') or not plan.get('available'):
            return None
        bad = self.failed()
        if any(_key(p) in bad for p in plan['packages']):
            log('automatic update skips a version that failed before')
            return None
        self.plan = plan
        return plan

    def ready(self, idle):
        if self.plan is None:
            return None
        if any(_key(p) in self.failed() for p in self.plan['packages']):
            self.plan = None
            return None
        return self.plan if idle() else None

    def start(self, plan):
        """Just before the installer runs: written down, so a box that never comes back with it does not loop."""
        state = auto_state(self.profile)
        state['trying'] = [{'id': p['id'], 'version': p['version']} for p in plan['packages']]
        save_auto_state(self.profile, state)
        self.plan = None


class UpdateDeferred(Exception):
    """The box was used again while an automatic update was downloading."""


def automatic_idle(player):
    import xbmc
    import xbmcgui
    return (not player.isPlaying() and xbmc.getGlobalIdleTime() >= Auto.IDLE and
            (xbmc.getSkinDir() == 'skin.mediacenter' or
             not xbmcgui.Window(10000).getProperty('mediacenter.app.open')))


# ---- installing and restarting (0.4.9.4) ---------------------------------------------------------------------------
# Nothing is asked to close. Up to 0.4.9.3 the installer first waited for the app to close, and on the owner's Pi (and
# in Kodi 21 on a computer) it never did: the app's window could not be returned to while the progress box was up
# ("Activate of window '13000' refused because there are active modal dialogs"), so the wait ran out after 90 seconds,
# the update "could not finish" and the app stayed marked as open, so it couldn't be opened again either. Now the new
# files are put in place while the old ones run (they are already loaded) and the box restarts straight afterwards.

INSTALLING = 'mediacenter.update.installing'  # a Home property; a restart of Kodi clears it
RESTART_WAIT = 90  # a restart that hasn't begun after this long is said out loud
TRIES = 3  # an automatic update that can't be installed is tried this many times before it is left alone
STAGING = '.mediacenter-update-'


def installing(window):
    return bool(window.getProperty(INSTALLING))


def system_name(path='/etc/os-release'):
    try:
        with open(path, encoding='utf-8') as f:
            return f.read()
    except (OSError, UnicodeError):
        return ''


def whole_box(skin, system=None):
    """True on a mediaCENTER box: LibreELEC (or CoreELEC) runs nothing but Kodi, and the mediaCENTER look is a box too."""
    system = system_name() if system is None else system
    return 'LibreELEC' in system or 'CoreELEC' in system or skin == 'skin.mediacenter'


def restart_command(system=None):
    """On LibreELEC the whole box restarts (always supported there, and it leaves nothing old running); elsewhere Kodi."""
    system = system_name() if system is None else system
    return 'Reboot' if 'LibreELEC' in system or 'CoreELEC' in system else 'RestartApp'


def reason(error):
    """What went wrong, for kodi.log: the kind and the message, never an address."""
    text = re.sub(r'[a-z]+://\S+', '<address>', str(error))[:160]
    return '%s: %s' % (type(error).__name__, text) if text else type(error).__name__


def note_failure(profile, packages):
    """An automatic install that didn't work (a dropped connection, a list still being published): try again at the next
    look, and leave a version alone only after TRIES goes."""
    state = auto_state(profile)
    tries = state.get('tries') if isinstance(state.get('tries'), dict) else {}
    for p in packages:
        tries[_key(p)] = int(tries.get(_key(p)) or 0) + 1
    state['tries'] = tries
    state.pop('trying', None)
    save_auto_state(profile, state)
    worn = [p for p in packages if tries[_key(p)] >= TRIES]
    if worn:
        remember_failed(profile, worn)


def tidy(profile, addons, window):
    """At start: clear what an install cut off by a power cut left behind. A plan file that stayed would stop every
    later automatic update. Nothing is touched while an installer is running."""
    if installing(window):
        return
    try:
        os.remove(os.path.join(str(profile), 'update-plan.json'))
    except OSError:
        pass
    try:
        for name in os.listdir(str(addons)):
            if name.startswith(STAGING):
                shutil.rmtree(os.path.join(str(addons), name), ignore_errors=True)
    except OSError:
        pass


def worker(profile):
    import xbmc
    import xbmcgui
    import xbmcvfs
    profile = Path(profile)
    with open(profile / 'update-plan.json') as f:
        plan = json.load(f)
    window = xbmcgui.Window(10000)
    if installing(window):
        return  # another installer is already at work
    window.setProperty(INSTALLING, '1')
    quiet = bool(plan.get('quiet'))  # started by the service (automatic update): no dialogs, the box is idle

    class Quiet(object):
        def create(self, *a): pass
        def update(self, *a): pass
        def close(self): pass
    dialog = Quiet() if quiet else xbmcgui.DialogProgress()
    dialog.create('mediaCENTER update', 'Preparing update…')
    addons_folder = xbmcvfs.translatePath('special://home/addons')
    step = ['downloading']
    def before():
        if quiet:
            import xbmcaddon
            addon = xbmcaddon.Addon(APP)
            channel = addon.getSetting('update_channel') or default_channel(
                installed(xbmcvfs.translatePath('special://home/addons')))
            if (addon.getSetting('auto_update') == 'false' or channel != plan['channel'] or
                    not automatic_idle(xbmc.Player())):
                raise UpdateDeferred()
        step[0] = 'putting the new files in place'
    def after():
        # Kodi looks at the new files, then every mediaCENTER part here is checked and switched on if Kodi has it off
        # (a newly copied part, like the remote the first time, starts off).
        step[0] = 'switching the parts on'
        refresh_local()
        ensure_enabled([i for i in ORDER if i in installed(addons_folder)], kodi_rpc, refresh_local)
    try:
        install(plan, addons_folder,
                progress=lambda *shown: dialog.update(*shown), before_swap=before, after_swap=after)
        dialog.close()
        (profile / 'update-plan.json').unlink(missing_ok=True)
        log('installed %s; restarting' % plan.get('version', ''))
        if whole_box(xbmc.getSkinDir()):
            xbmc.executebuiltin(restart_command())  # the box comes back into mediaCENTER with every new part loaded
            # INSTALLING stays set until Kodi stops, so nothing starts on half-old code meanwhile
            if not xbmc.Monitor().waitForAbort(RESTART_WAIT):
                log('the restart did not start')
                window.clearProperty(INSTALLING)
                xbmcgui.Dialog().ok('mediaCENTER', 'The update is installed. Turn the box off and on again to finish.')
        else:
            window.clearProperty(INSTALLING)
            if not quiet:
                xbmcgui.Dialog().ok('mediaCENTER', 'The update is installed. Restart Kodi to finish.')
    except UpdateDeferred:
        state = auto_state(profile)
        state.pop('trying', None)
        save_auto_state(profile, state)
        dialog.close()
        window.clearProperty(INSTALLING)
        log('automatic update deferred; the box or update settings changed')
    except Exception as error:
        log('update stopped while %s (%s)' % (step[0], reason(error)))
        try:
            # Whatever happened, no mediaCENTER part is left switched off (the old folders are back by now).
            ensure_enabled([i for i in ORDER if i in installed(addons_folder)], kodi_rpc, refresh_local)
        except Exception:
            pass
        dialog.close()
        window.clearProperty(INSTALLING)
        if quiet:
            try:
                note_failure(profile, plan.get('packages') or [])
            except Exception:
                pass
            log('automatic update could not finish; the previous version was kept')
        else:
            xbmcgui.Dialog().ok('mediaCENTER', 'The update could not finish. Your previous version and account have been kept. Try again later.')
    finally:
        (profile / 'update-plan.json').unlink(missing_ok=True)


if __name__ == '__main__':
    import sys
    worker(sys.argv[1])
