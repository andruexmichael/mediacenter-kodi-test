# mediaCENTER for Kodi 0.4.9.3: Home in the website's look (web-v27/js/views/home-tv.js, the website's Home on a
# computer and a TV). What this file adds to mc_app's Home:
#   - The Featured poster: the top of Home shows one featured title at a time and turns to the next every 8 seconds,
#     as the website's does; Play and "•••" act on the title shown. It no longer follows the highlighted card (owner,
#     2026-11-26: a "Featured" title over every row and a Featured row were confusing): each card names itself under
#     its picture, as the website's cards do, and there is no Featured row.
#   - The cards' shapes, one per row (Window.Property(row.N.shape), drawn by kodi/tools/make_windows.py home_row):
#     "" posters, "wide" Continue Watching (the picture across, the bar inside, the name and what's left under it),
#     "top" Top 10 today (the big number at the poster's lower left), "game" My Teams (Sports' team-colour cards).
#   - The season's row: the films design/experience.json names for the month (pi.seasonal: Holiday Movies in November
#     and December), looked up by name and year through /meta/batch, the lookup the website's cards use.
#   - The app's clock (the pill's date and time, the greeting, the season's month): the server's time and the time zone
#     the server sees the connection in, not the box's own clock, which a Pi may not have set (see now()).
# Nothing here is needed for Home to work: a lookup that fails leaves its pictures or its row out.

import datetime
import email.utils
import json
import re
import threading
import time

import xbmc
import xbmcgui

import mc_logic as L
import mc_views as V
from mc_api import Api, SignedOut, ServerError

ERRORS = (ServerError, SignedOut, OSError, ValueError)
TURN = 8  # seconds between featured titles (home-tv.js TURN_MS)
FEATURED = 8  # titles the featured poster turns through (home-tv.js useFeatured)
SEASONAL_TTL = 12 * 3600  # a season's lookup is kept half a day
PART = 6  # /meta/batch asks six at a time, as everywhere else
NO_DIALOG = 9999  # Kodi's answer when no dialog (another mediaCENTER page) is open
IN_BACKGROUND = True  # pictures land after Home shows; tests switch it off to see them land
SHAPES = ("", "wide", "top", "game")


def later(job):
    if not IN_BACKGROUND:
        return job()
    t = threading.Thread(target=job)
    t.daemon = True
    t.start()
    return t


def batch(api, queries):
    """/meta/batch for any number of lookups, six to a call and the calls side by side (Home waits for the slowest,
    not their sum). The answers in the queries' order; None where a call failed."""
    parts = [queries[i:i + PART] for i in range(0, len(queries), PART)]
    answers = [None] * len(parts)

    def ask(n):
        try:
            got = api.get("/meta/batch", q=json.dumps(parts[n], separators=(",", ":")))
            answers[n] = got if isinstance(got, list) else []
        except ERRORS:
            answers[n] = []

    threads = [threading.Thread(target=ask, args=(n,)) for n in range(len(parts))]
    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(20)
    out = []
    for part, got in zip(parts, answers):
        got = got or []
        out.extend(got[i] if i < len(got) else None for i in range(len(part)))
    return out


# ---- the app's clock ---------------------------------------------------------------------------------------------------
# A Pi keeps no time with the power off: LibreELEC sets the clock from the internet after it starts, and its time zone
# stays at UTC unless someone sets it. Until then Kodi's own date and time are wrong (and the pill's date showed nothing
# in 0.4.9.2, a Kodi label that read the comma in "ddd, mmm d" as two dates). So Home uses the app's clock: the server's
# time (the HTTP Date on every answer, mc_api.Api.server_time) when the box's clock is more than five minutes off, and
# the time zone the server places the connection in (/api/roku/home "clock") when the box's zone was never set (reads
# UTC). Nothing here changes the box's settings.

WRONG = 300  # seconds: a box clock this far from the server's is wrong
_ZONE = {"offset": None, "name": ""}  # minutes from UTC where the connection is, from the server


def set_zone(answer):
    c = answer.get("clock") if isinstance(answer, dict) else None
    if isinstance(c, dict) and isinstance(c.get("offset"), int) and not isinstance(c.get("offset"), bool) \
            and -840 <= c["offset"] <= 840:
        _ZONE.update(offset=c["offset"], name=str(c.get("zone") or ""))


def skew(heard=None):
    """Seconds to add to the box's clock: 0 while it agrees with the server's (within WRONG)."""
    heard = Api.server_time if heard is None else heard
    if not heard:
        return 0.0
    try:
        server = email.utils.parsedate_to_datetime(heard[0]).timestamp()
    except (TypeError, ValueError, IndexError, OverflowError):
        return 0.0
    off = server - heard[1]
    return off if abs(off) > WRONG else 0.0


def now(box=None):
    """The date and time where the person is, by the app's clock."""
    t = (time.time() if box is None else box) + skew()
    mine = datetime.datetime.fromtimestamp(t)
    if _ZONE["offset"] is None:
        return mine
    utc = datetime.datetime.fromtimestamp(t, datetime.timezone.utc).replace(tzinfo=None)
    if mine == utc:  # the box reads UTC: its zone was never set, so the connection's zone
        return utc + datetime.timedelta(minutes=_ZONE["offset"])
    return mine  # someone set the box's zone: theirs wins


def twenty_four():
    try:
        return "%H" in xbmc.getRegion("time")
    except Exception:
        return False


def show_clock(win):
    win.setProperty("clock", L.clock_line(now(), twenty_four()))


# ---- the season's row --------------------------------------------------------------------------------------------------

def look_up(api, wanted):
    """The season's films by name and year; an answer that isn't the film asked for is left out."""
    answers = batch(api, [{"type": "movie", "title": w["title"], "year": w["year"]} for w in wanted])
    out, seen = [], set()
    for w, a in zip(wanted, answers):
        if not L.same_film(w, a):
            continue
        t = dict(a, type="movie")
        if not t.get("title"):
            t["title"] = w["title"]
        card = L.title_of(t)
        if card and card["poster"] and card["tmdb"] not in seen:
            seen.add(card["tmdb"])
            out.append(t)
    return out


def seasonal(api, today=None):
    """(title, [title]) for Home's seasonal row: Holiday Movies in November and December, Halloween Movies in October,
    a genre row (Family Picks) the rest of the year."""
    s = L.seasonal_row(today or now().date(), (V.experience().get("app") or {}).get("seasonal"))
    if s["titles"]:
        name = "seasonal-" + re.sub(r"[^a-z]", "", s["title"].lower())
        found = V.cached(name, SEASONAL_TTL, lambda: look_up(api, s["titles"]))
        if not found:
            V.drop_cache(name)  # a lookup that failed is asked again next time, not kept for half a day
        return s["title"], L.titles_of(found)
    try:
        items = (api.get("/meta/row", type="movie", row=s["row"]) or {}).get("items")
    except ServerError:
        items = []
    return s["title"], L.titles_of(items)


# ---- Continue Watching's wide pictures -------------------------------------------------------------------------------

_WIDE = {}  # "type:tmdb" -> the title's wide picture, kept while the app is open


def _key(li):
    return "%s:%s" % (li.getProperty("type"), li.getProperty("tmdb"))


def wide_pictures(api, cards):
    """The wide picture on each Continue Watching card: the title's backdrop (the history keeps a poster or an
    episode's picture, which is the wrong shape). Cards keep what they have until it lands."""
    need = []
    for li in cards:
        url = _WIDE.get(_key(li))
        if url:
            li.setArt({"landscape": url})
        elif _key(li) not in _WIDE:
            need.append(li)
    if not need:
        return

    def work():
        answers = batch(api, [{"type": li.getProperty("type"), "tmdb": li.getProperty("tmdb")} for li in need])
        for li, a in zip(need, answers):
            if not isinstance(a, dict):
                continue  # failed: asked again next time
            url = L.picture(a.get("backdrop") or a.get("card") or "", "w780")
            _WIDE[_key(li)] = url
            if url:
                li.setArt({"landscape": url})
    later(work)


# ---- the featured poster ---------------------------------------------------------------------------------------------

class Featured(object):
    """The titles at the top of Home, one at a time (home-tv.js Hero): FEATURED, the title's logo (or its name),
    "2022 · Series", Play and "•••", the dots."""

    def __init__(self, titles):
        self.titles = list(titles)[:FEATURED]  # the server sends those with a picture (/api/roku/home)
        self.at = 0
        self.logos = {}

    def current(self):
        return self.titles[self.at % len(self.titles)] if self.titles else None

    def step(self, by=1):
        if self.titles:
            self.at = (self.at + by) % len(self.titles)

    def show(self, win):
        """Put the current title on the page; Play and "•••" act on it (win.hero_item)."""
        import mc_app
        t = self.current()
        if t is None:
            return win.hero(None)
        win.hero_item = mc_app.title_card(t)
        win.setProperty("hero.eyebrow", "FEATURED")
        win.setProperty("hero.title", t["name"])
        win.setProperty("hero.meta", L.featured_line(t))
        win.clearProperty("hero.plot")
        win.setProperty("hero.fanart", t["backdrop"])
        logo = self.logos.get(t["tmdb"], "")
        if logo:
            win.setProperty("hero.logo", logo)
        else:
            win.clearProperty("hero.logo")
        win.setProperty("hero.dots", L.dots(len(self.titles), self.at))

    def fetch_logos(self, api, win):
        """The titles' logos (the website shows the logo in place of the name), asked once, after Home shows."""
        titles = list(self.titles)
        if not titles:
            return

        def work():
            for t, a in zip(titles, batch(api, [{"type": t["type"], "tmdb": t["tmdb"]} for t in titles])):
                logo = L.picture((a or {}).get("logo") or "", "w500") if isinstance(a, dict) else ""
                if logo:
                    self.logos[t["tmdb"]] = logo
            if win.featured is self and win.screen == "home":
                self.show(win)
        later(work)


class Turner(object):
    """Turns the featured poster every TURN seconds while Home is on screen, as the website's, and keeps the pill's
    clock current. It waits while the
    highlight is on Play or "•••" (so Play starts the title the person was looking at), while another page or the
    player is in front, and stops when Home closes."""

    def __init__(self, win):
        self.win = win
        self.stopped = None

    def start(self):
        if self.stopped is not None and not self.stopped.is_set():
            return
        stopped = self.stopped = threading.Event()
        t = threading.Thread(target=self.run, args=(stopped,))
        t.daemon = True
        t.start()

    def stop(self):
        if self.stopped is not None:
            self.stopped.set()

    def run(self, stopped):
        monitor = xbmc.Monitor()
        while not stopped.is_set():
            if monitor.waitForAbort(TURN) or stopped.is_set():
                return
            try:
                if self.win.screen == "home":
                    show_clock(self.win)
            except Exception as e:
                V.log("clock skipped: %s" % type(e).__name__)
            try:
                if may_turn(self.win):
                    self.win.featured.step()
                    self.win.featured.show(self.win)
            except Exception as e:  # never take the app down for a picture
                V.log("featured turn skipped: %s" % type(e).__name__)


def may_turn(win):
    import mc_app
    featured = getattr(win, "featured", None)
    if win.screen != "home" or featured is None or len(featured.titles) < 2:
        return False
    if win.getFocusId() in (mc_app.PLAY, mc_app.INFO):
        return False
    dialog = getattr(xbmcgui, "getCurrentWindowDialogId", None)
    if dialog is not None and dialog() != NO_DIALOG:
        return False
    return not xbmc.getCondVisibility("Player.HasVideo")
