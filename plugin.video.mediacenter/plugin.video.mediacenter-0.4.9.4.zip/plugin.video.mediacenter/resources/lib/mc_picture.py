# mediaCENTER for Kodi: where the picture goes on a box that draws video on its own layer (0.4.9.2).
#
# Why this exists (the black picture with sound on the owner's Pi 3, Kodi 21.3, 0.4.5 to 0.4.9.1):
#   - The box decodes in hardware and draws "Direct to plane" (kodi.log: decoder ff-h264_v4l2m2m-drm_prime, hardware,
#     useprimerenderer=0). The picture then sits on its own layer under the menus, at a place Kodi works out ONCE, when
#     the video opens (CRendererDRMPRIME::Configure -> ManageRenderArea, from CGraphicContext::GetViewWindow()).
#   - Kodi works it out again only in its own full-screen video window (CGUIWindowFullScreen::Render, gui=true ->
#     CRendererDRMPRIME::Update). mediaCENTER plays in its own player page (windowed, since 0.4.5), so that never runs.
#   - The view window is set only by a shown video control that draws while a video is already open
#     (CGUIVideoControl::Render -> SetViewWindow), and it starts empty when Kodi starts (CRect: 0,0,0,0). So the first
#     video after Kodi starts opens with an empty place: CBaseRenderer::CalcDestRect "if view window is empty, set empty
#     destination", the layer gets no size (Kodi may log "CDRMAtomic::DrmAtomicCommit - test commit failed" for it)
#     and the sound plays over black for the whole video. Kodi's own player never meets this: in full screen the view window is
#     the whole screen (GetViewWindow, m_bFullScreenVideo).
#   - Kodi starts again after every update, so the owner met it on nearly every try.
#
# What this does: before a video opens in the player page, make sure Kodi already holds the full-screen place. If
# something is playing, the player page's own video control (shown, full screen) has just set it. If nothing is, a
# three-second black clip (mc_primer_clip.py, written to the add-on's data folder; no sound) plays for about half a second under the loading
# screen, so the player page's video control draws once with a video open; then the real link opens in the right place.
# Done once per Kodi run (a Home window property, which Kodi clears when it starts), and again after the Guide's mini
# player has drawn (its small video control moves the place: mc_app.GuidePage.adopt clears PLACED).
# Only on boxes that draw on their own layer (the Pi with "Direct to plane"); elsewhere nothing changes.
#
# Kept free of Kodi so it can be tested: the player, the Home window, the clock and the settings reader come in.

import base64
import os
import time

PLACED = "mc.picture.placed"  # Window(Home): "full" once Kodi holds the full-screen place for the picture this run
PRIMER_NAME = "picture-primer.mp4"
SETTLE = 0.5  # seconds a shown video control gets to draw once with a video open (~30 frames at 60 Hz)
OPEN_WAIT = 6.0  # seconds the clip gets to open
STOP_WAIT = 3.0


def own_layer(setting):
    """Whether Kodi draws hardware-decoded video on its own layer here: the DRM PRIME decoder with the render method
    "Direct to plane" (videoplayer.useprimerenderer 0; 1 is EGL, drawn with the menus, which needs none of this).
    setting(key) gives Kodi's value, or "?" where the setting doesn't exist (not a DRM box)."""
    renderer = setting("videoplayer.useprimerenderer")
    decoder = setting("videoplayer.useprimedecoder")
    if isinstance(renderer, bool) or str(renderer) != "0":
        return False
    return decoder is True or str(decoder).lower() == "true"


def clip(folder):
    """The clip's path in the add-on's data folder (folder), written there from mc_primer_clip the first time."""
    path = os.path.join(folder, PRIMER_NAME)
    if not os.path.exists(path):
        from mc_primer_clip import PRIMER_MP4
        if not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + ".part"
        with open(tmp, "wb") as f:
            f.write(base64.b64decode("".join(PRIMER_MP4)))
        os.replace(tmp, path)
    return path


def prepare(player, home, setting, primer, log=lambda line: None, cancelled=lambda: False, has_video=None,
            sleep=time.sleep, now=time.time, listitem=None):
    """Before the player page opens a video: make sure the picture will be placed full screen. Returns what was done:
    "placed" (already this run), "not needed" (not drawn on its own layer), "playing" (a video was open, so the shown
    player control has just set the place), "primed" (the clip did it), "missing" or "failed" (go on anyway)."""
    if home.getProperty(PLACED) == "full":
        return "placed"
    if not own_layer(setting):
        return "not needed"
    if player.isPlayingVideo():
        sleep(SETTLE)
        home.setProperty(PLACED, "full")
        log("picture place: full screen, from the video already playing")
        return "playing"
    try:
        primer = primer() if callable(primer) else primer
    except (OSError, ValueError):
        primer = None
    if not primer or not os.path.exists(primer):
        log("picture place: couldn't write the clip")
        return "missing"
    has_video = has_video or player.isPlayingVideo
    if listitem is not None:
        player.play(primer, listitem, True)
    else:
        player.play(primer, windowed=True)
    end, opened = now() + OPEN_WAIT, False
    while now() < end and not cancelled():
        if has_video():
            opened = True
            break
        sleep(0.05)
    if opened:
        sleep(SETTLE)
    try:
        player.stop()
    except RuntimeError:
        pass
    end = now() + STOP_WAIT
    while player.isPlaying() and now() < end:
        sleep(0.05)
    if not opened:
        log("picture place: the clip didn't open; the video may show black (Settings > Player > Videos > "
            "Render method: EGL avoids it)")
        return "failed"
    home.setProperty(PLACED, "full")
    log("picture place: full screen, set with the clip (video drawn on its own layer)")
    return "primed"


# ---- drawing the picture with the menus (0.4.9.4, owner: "Try EGL render") ----------------------------------------
# On its own layer the picture's place is fixed when a video opens, so a channel that opened full screen kept that
# place when it docked into the Guide's mini player: a low, cropped piece of the full picture showed in the small window.
# Drawn with the menus (Kodi's render method "EGL", videoplayer.useprimerenderer 1) the picture goes wherever the
# shown video control is, every frame: the mini player, full screen, and no empty first place (the primer clip above is
# then not needed: own_layer() is False). Settings > Playback and Live TV, "Picture", switches back if a Pi 3 plays
# less smoothly this way. Only boxes with this Kodi setting are touched (DRM boxes: the Pi); others are left alone.

RENDER, DECODER = "videoplayer.useprimerenderer", "videoplayer.useprimedecoder"
MODES = {"egl": 1, "plane": 0}


def apply_render(mode, setting, set_setting, log=lambda line: None):
    """Make Kodi's render method follow the "picture_render" setting ("egl", the default, or "plane"). Returns
    "not here" (no such setting, or no DRM PRIME decoder), "already", or the mode it switched to."""
    current = setting(RENDER)
    if current == "?" or isinstance(current, bool) or not str(current).lstrip("-").isdigit():
        return "not here"
    decoder = setting(DECODER)
    if not (decoder is True or str(decoder).lower() == "true"):
        return "not here"
    want = MODES.get(mode, MODES["egl"])
    if int(current) == want:
        return "already"
    set_setting(RENDER, want)
    log("picture: drawn %s from the next video (render method %s)" % ("with the menus" if want else "on its own layer",
                                                                        "EGL" if want else "Direct to plane"))
    return "egl" if want else "plane"


def moved(home):
    """A smaller video control (the Guide's mini player) drew with a video open: the next video needs the place again."""
    home.clearProperty(PLACED)
