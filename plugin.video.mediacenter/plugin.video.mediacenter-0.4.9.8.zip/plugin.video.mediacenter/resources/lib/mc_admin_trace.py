# mediaCENTER for Kodi: what the player is really doing, for the admin only (0.4.9.8).
#
# Owner, 2026-11-26: the loading screen's step list ("Buffering the first scenes", "Picking the best source") crowds the
# screen and isn't what the app actually does. Everyone now sees only the picture, the logo, the poster and the bar with
# its percent; the admin (the account's role is "admin", from /access/session) also sees, in the corners:
#   - a checklist of the real steps of the source search: the title, how many versions were found and where, how many
#     this box plays, the ones left out, the pick, the resume point, each link's check and how Kodi took it;
#   - a short live log of the same, newest last, with the seconds since the player opened, readable in a photo.
# Never a link, a file name, a code or anything signed: versions are told apart by quality, size and where they come from.
# Kept free of Kodi so it can be tested.

import time

MARKS = {"done": u"✓", "now": u"●", "todo": u"○", "fail": u"✗", "skip": u"–"}
LOG_LINES = 9
MAX_TEXT = 70


def short(text, n=MAX_TEXT):
    text = " ".join(str(text or "").split())
    return text if len(text) <= n else text[:n - 1] + u"…"


def is_admin(api):
    """Whether the signed-in account is the admin. The role comes with /access/session (Api.check); asked once per Api."""
    role = getattr(api, "role", None)
    if role is None:
        try:
            api.check()
        except Exception:
            pass
        role = getattr(api, "role", None)
    return role == "admin"


class Trace(object):
    """The admin's checklist (named rows, in the order they were first written) and live log."""

    def __init__(self, now=time.time):
        self.now = now
        self.began = now()
        self.rows = []  # [key, state, text]
        self.lines = []

    def restart(self):
        """A new try (another version, Retry, the next episode): the checklist starts over, the log carries on."""
        self.began = self.now()
        self.rows = []
        self.log(u"— starting again —")

    def step(self, key, text, state="now", log=True):
        text = short(text)
        for row in self.rows:
            if row[0] == key:
                if row[1:] == [state, text]:
                    return
                row[1], row[2] = state, text
                break
        else:
            self.rows.append([key, state, text])
        if log:
            self.log(text if state != "fail" else u"✗ " + text)

    def log(self, text):
        self.lines.append(u"%5.1fs  %s" % (max(0.0, self.now() - self.began), short(text, 64)))
        del self.lines[:-LOG_LINES]

    def checklist(self):
        return u"[CR]".join(u"%s  %s" % (MARKS.get(state, u"·"), text) for _, state, text in self.rows)

    def log_text(self):
        return u"[CR]".join(self.lines)


# ---- words for the checklist ---------------------------------------------------------------------------------------

def version_words(v, places=None):
    """ "1080p · 2.10 GB · TorBox" for a version, never its link or file name."""
    from mc_versions import size_text, PLACES
    places = places or PLACES
    v = v or {}
    size = v.get("size") or 0
    try:
        size = float(size)
    except (TypeError, ValueError):
        size = 0
    parts = [str(v.get("res") or "?"), str(v.get("video") or "").upper(), size_text(size),
             places.get(v.get("provider"), v.get("provider") or "")]
    return u" · ".join(p for p in parts if p)


def where_words(versions, places=None):
    """ "TorBox 9, Jellyfin 5" (how many versions each place gave)."""
    from mc_versions import PLACES
    places = places or PLACES
    counts = {}
    order = []
    for v in versions or []:
        name = places.get((v or {}).get("provider"), (v or {}).get("provider") or "other")
        if name not in counts:
            order.append(name)
            counts[name] = 0
        counts[name] += 1
    return u", ".join(u"%s %d" % (name, counts[name]) for name in order)


RESULT_WORDS = {"started": "picture showed", "no picture": "sound but no picture", "failed": "the player couldn't open it",
                "timeout": "too slow to start", "cancelled": "stopped", "stalled": "started, then stood still"}
