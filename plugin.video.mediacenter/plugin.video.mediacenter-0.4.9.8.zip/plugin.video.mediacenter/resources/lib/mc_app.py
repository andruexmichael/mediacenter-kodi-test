# mediaCENTER for Kodi: the app itself, full screen in mediaCENTER's own look (resources/skins/Default/1080i,
# written by kodi/tools/make_windows.py). It works like the web app: a sidebar (design/experience.json "pi": Home, Movies,
# TV Shows, Guide, Sports, Search, Library, Settings), a hero picture that follows the highlighted title, and poster rows.
# Movies and TV Shows are pages like the Roku's (genres down the left, rows from /api/browse); Search is a page with
# letters on screen and results as you type. Everything plays in mediaCENTER's own player (mc_player, 0.4.5) on top of
# the page it was started from, so Back after a film returns to that page as it was.

import datetime
import threading
import os
import time
import urllib.parse

import xbmc
import xbmcgui

import mc_home
import mc_logic as L
import mc_menu
from mc_menu import Rail
import mc_picture as MP
import mc_more as more
import mc_theme as T
import mc_views as V
import mc_pages as pages
import mc_live_pause as LP
from mc_api import SignedOut, ServerError

PLUGIN = "plugin://plugin.video.mediacenter/"
NAV, PLAY, INFO, BUTTONS, ROWS = 9000, 201, 202, 200, 1000
NAV_BOTTOM = mc_menu.BOTTOM  # Settings, alone at the bottom of the menu (0.4.9.6)
ROW_IDS = list(range(501, 511))  # ten rows (0.4.9: Picked for you)
BACK = (9, 10, 92, 247)  # parent dir, previous menu, back, back (remote)
REMOTE_0 = 58  # the 0 key: the last channel in the Guide
MOVES = (1, 2, 3, 4, 5, 6)  # left, right, up, down, page up, page down
LEFT, RIGHT = 1, 2
MENU_KEYS = (11, 117)  # info, context menu
CONTINUE = "Continue Watching"
SCREENS = {"Home": "home", "Movies": "movies", "TV Shows": "shows", "Guide": "guide", "Sports": "sports", "Search": "search",
           "Library": "library", "Settings": "settings"}


def colors():
    """The token colours (resources/data/colors.json, written by kodi/tools/make_windows.py from design/tokens.json)."""
    import json
    import os
    try:
        with open(os.path.join(V.HERE, "resources", "data", "colors.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


COLORS = colors()
SURFACE, RAISED, CREAM, CARD = (COLORS.get(k, d) for k, d in (
    ("surface", "FF17171A"), ("raised", "FF232327"), ("cream", "FFF5F5F7"), ("card", "12FFFFFF")))


def accent():
    """The chosen theme's accent (0.4.9, mc_theme), for the colours Python writes into the Guide."""
    return T.color("accent", V.WINDOW)


def menu():
    """The menu on the left, in the order design/experience.json gives ("pi" menu), Settings last (mc_menu)."""
    return mc_menu.items()


MENU = menu()


def link(**params):
    return PLUGIN + "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})


def play(**params):
    xbmc.executebuiltin("PlayMedia(%s)" % link(**params))


def refocus(win, control_id, tries=30):
    """Put the highlight back after the player closes. The page shows again only once the picture has gone, and Kodi
    ignores focus on a hidden control, so this waits for that (up to 3 seconds)."""
    for _ in range(tries):
        if not xbmc.getCondVisibility("Player.HasVideo"):
            win.setFocusId(control_id)
            if win.getFocusId() == control_id:
                return True
        xbmc.sleep(100)
    win.setFocusId(control_id)
    return False


def busy(on):
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)" if on else "Dialog.Close(busydialognocancel)")


# ---- what the cards hold ---------------------------------------------------------------------------------------------

def title_card(t):
    li = xbmcgui.ListItem(t["name"], t.get("year", ""))
    li.setArt({"poster": t.get("poster"), "fanart": t.get("backdrop")})
    li.setProperties({"kind": "title", "type": t["type"], "tmdb": t["tmdb"], "plot": t.get("overview", ""),
                      "meta": L.DOT.join(p for p in [t.get("year", ""), "Movie" if t["type"] == "movie" else "TV Show"] if p),
                      "sub": L.featured_line(t)})  # under the poster on Home, as the website's cards (0.4.9.3)
    return li


def continue_card(h):
    li = xbmcgui.ListItem(h["name"], "S%d E%d" % (h["season"], h["episode"]) if h["type"] == "series" else L.clock_text(h["duration"] - h["position"]) + " left")
    li.setArt({"poster": h["image"], "thumb": h["image"]})
    V.set_info(li, {"title": h["name"], "mediatype": "movie"}, (h["position"], h["duration"]))
    li.setProperties({"kind": "continue", "itemId": h.get("itemId", ""), "type": h["type"], "tmdb": h["tmdb"], "season": str(h.get("season") or ""),
                      "episode": str(h.get("episode") or ""), "progress": str(int(h["progress"] * 100)),
                      "position": str(h["position"]), "duration": str(h["duration"]), "episodeName": h.get("episodeName") or "",  # the hold menu (mc_hold)
                      "eyebrow": "S%d E%d" % (h["season"], h["episode"]) if h["type"] == "series" else "",
                      "meta": ("S%d E%d · " % (h["season"], h["episode"]) if h["type"] == "series" else "") + "%s left" % L.clock_text(h["duration"] - h["position"]),
                      # 0.4.9.3: a wide card on Home, the name and this line under it (the website's ResumeTile)
                      "shape": "wide", "sub": L.DOT.join(p for p in ["S%d · E%d" % (h["season"], h["episode"]), h.get("episodeName", "")] if p)
                      if h["type"] == "series" else L.time_left(h["duration"] - h["position"])})
    return li


def team_card(g):
    """A My Teams card on Home (0.4.9.3): the Sports page's team-colour card with both logos and the score."""
    import mc_sports_page
    li = mc_sports_page.card(g, "home")
    li.setProperties({"kind": "game", "shape": "game", "plot": L.matchup(g), "meta": L.DOT.join(p for p in [g.get("league", ""), L.when(g)] if p)})
    return li


def game_card(g):
    head = L.score_line(g) or L.matchup(g)
    li = xbmcgui.ListItem(head, L.when(g))
    chans = g.get("channels") or []
    li.setProperties({"kind": "game", "id": str(g.get("id")), "eyebrow": ("LIVE · " if g.get("state") == "in" else "") + (g.get("league") or ""),
                      "plot": "\n".join(p for p in [L.matchup(g), L.when(g), ("Watch on " + chans[0]["name"]) if chans else "No channel is showing this game yet"] if p),
                      "meta": L.DOT.join(p for p in [g.get("league", ""), L.when(g)] if p)})
    return li


def channel_card(ch):
    li = xbmcgui.ListItem(ch.get("name", ""), L.now_title(ch))
    li.setProperties({"kind": "channel", "id": str(ch.get("id")), "eyebrow": "CHANNEL %s" % ch["num"] if ch.get("num") else "CHANNEL",
                      "plot": L.channel_plot(ch), "meta": "Live TV"})
    return li


# ---- Home and the other row pages ------------------------------------------------------------------------------------

class App(Rail, xbmcgui.WindowXML):
    rail_home = ROW_IDS[0]

    def __init__(self, *args, **kwargs):
        super(App, self).__init__(*args, **kwargs)
        self.api = V.api()
        self.screen = "home"
        self.rows = {}
        self.hero_item = None
        self.started = False
        import mc_watching
        self.fresh = mc_watching.Freshness()  # when Continue Watching was last asked for (0.4.9)
        self.featured = None  # the featured poster at the top of Home (mc_home, 0.4.9.3)
        self.turner = mc_home.Turner(self)
        self.games = {}  # Home's Games row: id -> game (0.4.9.6)
        self.arrived = (None, 0.0)  # the control the highlight last moved to, and when (onFocus)

    def close(self):
        self.turner.stop()
        super(App, self).close()

    def onInit(self):
        if self.started:
            return
        self.started = True
        try:
            import mc_opening
            mc_opening.Opening.show()  # the Apple TV's opening: posters from last time, the mark, the name
        except Exception as e:  # never keep the app from opening
            V.log("opening skipped: %s" % type(e).__name__)
        from mc_device import DevicePage, on_device
        if on_device() and V.ADDON.getSetting("setup_complete") != "true":
            DevicePage.open(self.api, first_run=True)  # first run on the box: network, remote, sign in
        self.rail_setup("home")  # the menu on the left (mc_menu, 0.4.9.6)
        info = None
        try:
            info = self.api.check()
        except (ServerError, OSError):
            pass
        if info:
            self.setProperty("account", info.get("displayName") or info.get("username") or "")
        if self.api.signed_in:
            self.show("home")
        else:
            self.welcome()
        self.follow()
        self.greet()

    # -- the TV button (mc_pages) --

    def follow(self):
        """From here on, the launcher's asks (the iPhone remote's TV button) take the app to that page."""
        pages.OPENERS["guide"] = lambda: GuidePage.open(self.api)
        for key in pages.INSIDE:  # the menu on the other pages (mc_menu.Rail.rail_go)
            if key != "guide":
                pages.OPENERS[key] = (lambda k: lambda: self.arrive_at(k))(key)
        pages.OPENERS[pages.MENU] = self.tv_menu  # the TV button's one press (0.4.9.7: Watching and the menu joined)
        monitor = xbmc.Monitor()
        self.follow_stop = threading.Event()
        t = threading.Thread(target=pages.follow, args=(V.WINDOW, self.goto,
                                                        lambda: not self.follow_stop.is_set() and bool(V.WINDOW.getProperty(RUNNING)),
                                                        monitor.waitForAbort, self.shutdown))
        t.daemon = True
        self.follower = t
        t.start()

    def stop_following(self):
        stop = getattr(self, "follow_stop", None)
        if stop is not None:
            stop.set()
        thread = getattr(self, "follower", None)
        if thread is not None and thread is not threading.current_thread():
            thread.join(1)

    def shutdown(self):
        close_kodi_dialogs()
        pages.close_all()
        self.close()

    def goto(self, page):
        if page == pages.MENU:  # 0.4.9.6: the TV button's one press (two quick presses are the Guide)
            done = pages.show_menu(allowed=self.api.signed_in, fallback=lambda: self.goto("guide"))
            return V.log("tv button, menu: %s" % done)
        done = pages.go(page, allowed=self.api.signed_in, close_dialogs=close_kodi_dialogs)
        V.log("go to %s: %s" % (page, done))

    def tv_menu(self):
        """The TV button's one press (the design plan 8.9; mc_pages.show_menu runs this on its own thread): the menu on
        the left opens with names over the page that is showing, which stays open, and what plays carries on behind it.
        A page with the menu of its own (Home, Movies, TV Shows, Search, Sports, the Guide) opens it, and a second press
        folds it; any other page (the player, a title's page, Featured, Settings) gets the menu over it (MenuPage),
        which a second press or Back closes."""
        with pages.LOCK:
            top = pages.STACK[-1] if pages.STACK else self
        if isinstance(top, Rail):
            if top.rail_is_open():
                return top.rail_fold()
            return top.rail_open(show_names=True)
        return MenuPage.open(self.api, at=self.place_under())

    def place_under(self):
        """The place the pages showing belong to: the nearest open page with the menu, else Home's own screen."""
        with pages.LOCK:
            opened = list(pages.STACK)
        for page in reversed(opened):
            if isinstance(page, Rail):
                return page.rail_key
        return self.screen if self.screen in dict(MENU) else "home"

    def arrive_at(self, key):
        """A place picked in the menu of another page, once the pages above Home have closed (mc_pages.arrive)."""
        if key == "home":
            if self.screen != "home":
                return self.show("home")
            return self.rail_fold()
        if key == "library":
            return self.library_menu()
        return self.show(key)

    # -- signed out --

    def welcome(self):
        """Signed out: the app opens and says so. The keyboard comes up only when the person picks Sign in. The iPhone
        remote's code shows under the welcome right away, and whenever an iPhone asks to pair (0.4.9.3)."""
        self.setProperty("greeting", "")
        self.setProperty("hero.title", "Welcome to mediaCENTER")
        self.setProperty("hero.plot", WELCOME_PLOT)
        self.welcome_remote()
        self.getControl(PLAY).setLabel("Sign in")
        self.getControl(INFO).setVisible(False)
        self.mark("home")
        self.setFocusId(PLAY)

    def welcome_remote(self):
        """While Home is signed out: the iPhone remote's how-to and code under the welcome line (mc_remote_link.Welcome)."""
        if getattr(self, "welcome_stop", None) is not None and not self.welcome_stop.is_set():
            return
        from mc_device import welcome_watch

        def show(code, how):
            if not self.api.signed_in:
                self.setProperty("hero.plot", WELCOME_PLOT + ("\n" + how + (" " + code + "." if code else "") if how else ""))
        self.welcome_stop = welcome_watch(show, lambda: not self.api.signed_in and bool(V.WINDOW.getProperty(RUNNING)))

    def sign_in(self):
        """Sign in: the phone sign-in page (a QR code and a short code), with the TV keyboard one row down."""
        try:
            from mc_device import DevicePage
            DevicePage.open(self.api, section="signin")
            if not self.api.signed_in:
                return
            info = self.api.check()
        except (ServerError, OSError):
            return xbmcgui.Dialog().ok("mediaCENTER", "Can't reach mediaCENTER right now. Check the internet connection and try again.")
        self.setProperty("account", (info or {}).get("displayName") or (info or {}).get("username") or "")
        self.getControl(PLAY).setLabel("Play")
        self.getControl(INFO).setVisible(True)
        self.show("home")
        self.greet()

    def greet(self):
        """0.4.9: the welcome tour the first time an account opens Home on this box, else the website's announcements
        (mc_more). An announcement's button may ask for a page."""
        try:
            asked = more.welcome(self)
        except Exception as e:  # never keep Home from working
            V.log("welcome skipped: %s" % type(e).__name__)
            return
        if asked and asked.get("screen") in SCREENS.values():
            self.show(asked["screen"])

    # -- screens --

    def mark(self, screen):
        """The white pill on the page you are on (mc_menu.Rail.rail_mark)."""
        self.rail_mark(screen)

    def show(self, screen):
        if screen == "guide":
            return GuidePage.open(self.api)
        if screen == "sports":
            import mc_sports_page
            return mc_sports_page.SportsPage.open(self.api)
        if screen in ("movies", "shows"):
            return BrowsePage.open(self.api, "movie" if screen == "movies" else "series")
        if screen == "search":
            return SearchPage.open(self.api)
        if screen == "settings":
            return self.settings()
        rows = []
        if screen != "home":
            self.featured = None  # the featured poster is Home's alone
        try:
            busy(True)
            if screen == "home":
                rows = self.home_rows()
            elif screen == "library":
                rows = self.library_rows()
        except SignedOut:
            busy(False)
            self.api.forget()
            xbmcgui.Dialog().ok("mediaCENTER", "Your session ended. Sign in again.")
            return self.close()
        except (ServerError, OSError):
            rows = []
            self.setProperty("empty", "Can't reach mediaCENTER right now. Check the internet connection and try again.")
        finally:
            busy(False)
        self.screen = screen
        self.mark(screen)
        self.fill(rows)
        if screen == "home" and self.featured is not None:
            self.featured.fetch_logos(self.api, self)
            self.turner.start()
        else:
            self.turner.stop()
        if screen == "home":
            who = self.getProperty("account")
            mc_home.show_clock(self)
            # 0.4.9.6: typed one letter at a time with the blinking cursor after it, as the website's
            mc_home.type_greeting(self, L.greeting(mc_home.now().hour) + (", " + who if who else "") +
                                  (u" \u00b7 Guest Room" if self.api.profile == "guest" else ""))  # as the Roku says it
        else:
            mc_home.stop_greeting(self, {"library": "Library"}.get(screen, ""))

    def fill(self, rows):
        rows = [r for r in rows if r[1]][:len(ROW_IDS)]
        self.rows = {}
        for i, lid in enumerate(ROW_IDS):
            control = self.getControl(lid)
            control.reset()
            if i < len(rows):
                title, items = rows[i][0], rows[i][1]
                sub = rows[i][2] if len(rows[i]) > 2 else ""  # a line beside the title (Games, 0.4.9.6)
                if sub:
                    self.setProperty("row.%d.sub" % (i + 1), sub)
                else:
                    self.clearProperty("row.%d.sub" % (i + 1))
                # The row's card shape (mc_home.SHAPES), from its first card; set before the cards go in.
                shape = items[0].getProperty("shape")
                if shape in mc_home.SHAPES and shape:
                    self.setProperty("row.%d.shape" % (i + 1), shape)
                else:
                    self.clearProperty("row.%d.shape" % (i + 1))
                control.addItems(items)
                self.setProperty("row.%d.title" % (i + 1), title)
                self.rows[lid] = title
            else:
                self.clearProperty("row.%d.title" % (i + 1))
                self.clearProperty("row.%d.shape" % (i + 1))
                self.clearProperty("row.%d.sub" % (i + 1))
        on_home = self.featured is not None and self.featured.titles
        if rows:
            self.clearProperty("empty")
            if on_home:
                self.featured.show(self)  # Home's top is the featured poster, not the first card (0.4.9.3)
            else:
                self.hero(rows[0][1][0], rows[0][0])
            self.setFocusId(ROW_IDS[0])
        elif on_home:
            self.featured.show(self)
            self.setFocusId(PLAY)
        else:
            self.hero(None)
            if not self.getProperty("empty"):
                self.setProperty("empty", "Nothing here yet.")
            self.setFocusId(NAV)

    def hero(self, li, row_title=None):
        self.clearProperty("hero.logo")
        self.clearProperty("hero.dots")
        if li is None:
            for k in ("hero.title", "hero.plot", "hero.meta", "hero.fanart", "hero.eyebrow"):
                self.clearProperty(k)
            self.hero_item = None
            return
        self.hero_item = li
        # The website's hero says FEATURED over its title; here the hero follows the highlight, so it names the row
        # (a Picked for you collection says PICKED FOR YOU over its funny name).
        self.setProperty("hero.eyebrow", li.getProperty("tag") or (row_title or "Featured").upper())
        self.setProperty("hero.title", li.getLabel())
        self.setProperty("hero.plot", li.getProperty("plot"))
        self.setProperty("hero.meta", li.getProperty("meta"))
        fanart = li.getArt("fanart")
        if fanart:
            self.setProperty("hero.fanart", fanart)

    def home_rows(self):
        """Home in the plan's order (owner, Nov 26; kodi/handoff/0.4.9.5-step1-handover.md 8.4): the featured poster above
        the rows (no Featured row), then Continue Watching as wide cards (in the Apps row's old place; when it's empty
        the next row moves up), Top 10 today with its numbers and bigger posters, Games (your teams first, then today's
        games; it replaces My Teams), the season's row (Holiday Movies now), New Movies, New TV Shows, Picked for you,
        and My List last. Apps stays off Home. The games are asked beside the other rows."""
        games = mc_home.ask_games(self.api)
        answer = V.home_answer(self.api) or {}
        mc_home.set_zone(answer)
        found = {r.get("id"): r for r in answer.get("rows", []) if isinstance(r, dict)}
        self.featured = mc_home.Featured(L.titles_of(answer.get("hero"), mc_home.FEATURED))
        resume = self.continue_cards()
        rows = [(CONTINUE, resume)]
        if "top" in found:
            top = [title_card(t) for t in L.titles_of(found["top"].get("items"), 10)]
            for n, li in enumerate(top, 1):
                li.setProperties({"shape": "top", "rank": str(n)})
            rows.append((found["top"].get("title") or "Top 10 today", top))
        title, cards, self.games = mc_home.games_row(games, found.get("teams"))
        rows.append((title, cards, mc_home.GAMES_SUB))
        try:
            seasonal_title, seasonal = mc_home.seasonal(self.api)
        except (ServerError, OSError, ValueError):
            seasonal_title, seasonal = "", []
        rows.append((seasonal_title, [title_card(t) for t in seasonal]))
        for key in ("movies", "shows"):
            if key in found:
                cards = [title_card(t) for t in L.titles_of(found[key].get("items"))]
                rows.append((found[key].get("title"), cards + [more.see_more("movie" if key == "movies" else "series")] if cards else []))
        rows.extend(more.home_picks(self.api))  # 0.4.9: Picked for you
        rows.append(("My List", [title_card(t) for t in L.titles_of(V.my_list(self.api))]))
        try:
            import mc_opening
            mc_opening.remember([li.getArt("poster") for r in rows for li in r[1]])
        except Exception:
            pass
        return rows

    def continue_cards(self):
        """Continue Watching from the account's history (GET /api/history), shared with every other device."""
        history = (self.api.get("/api/history", limit=40, perShow=1) or {}).get("items")
        self.fresh.asked()
        cards = [continue_card(h) for h in L.continue_items(history)]
        mc_home.wide_pictures(self.api, cards)
        return cards

    def refresh_continue(self, force=True):
        """Continue Watching asked for again (0.4.9, as the web's history.js): after something played or a card was
        removed (force), or once a minute while Home is moved around, so a film watched on the phone shows up here.
        Only that row changes; when it appears or empties, Home is drawn again."""
        if self.screen != "home" or not self.api.signed_in or not (force or self.fresh.due()):
            return False
        try:
            cards = self.continue_cards()
        except (ServerError, SignedOut, OSError):
            return False
        lid = next((k for k, title in self.rows.items() if title == CONTINUE), None)
        if lid is None and not cards:
            return False
        if lid is None or not cards:
            focus = self.getFocusId()
            self.show("home")
            if focus == NAV:
                self.setFocusId(NAV)
            return True
        control = self.getControl(lid)
        keep = control.getSelectedPosition()
        control.reset()
        control.addItems(cards)
        control.selectItem(min(max(0, keep), len(cards) - 1))
        return True

    def later(self, job):
        th = threading.Thread(target=job)
        th.daemon = True
        th.start()
        return th

    def library_rows(self):
        def first(kind, row_id):
            try:
                return L.titles_of((self.api.get("/meta/row", type=kind, row=row_id) or {}).get("items"))
            except ServerError:
                return []
        try:
            in_progress = self.continue_cards()  # the design's In Progress, with the Continue Watching hold (0.4.9.6)
        except (ServerError, OSError):
            in_progress = []
        return [("In Progress", in_progress),
                ("My List", [title_card(t) for t in L.titles_of(V.my_list(self.api))]),
                ("Movies · New", [title_card(t) for t in first("movie", "new")]),
                ("TV Shows · New Series", [title_card(t) for t in first("series", "new")]),
                ("Movies · Action", [title_card(t) for t in first("movie", "genre:28")]),
                ("Movies · Comedy", [title_card(t) for t in first("movie", "genre:35")]),
                ("TV Shows · Netflix", [title_card(t) for t in first("series", "network:213")]),
                ("TV Shows · HBO", [title_card(t) for t in first("series", "network:49")]),
                ("Movies · Family", [title_card(t) for t in first("movie", "genre:10751")])]

    def settings(self):
        """Settings: mediaCENTER's own page (mc_device). Home is drawn again only when the account changed."""
        from mc_device import DevicePage
        result = DevicePage.open(self.api)
        if result in ("exit", "update"):
            return self.close()
        if result == "signed_out" or not self.api.signed_in:
            self.setProperty("account", "")
            self.featured = None
            self.turner.stop()
            self.fill([])  # the last account's rows go too
            self.clearProperty("empty")
            return self.welcome()
        if result == "signed_in":
            try:
                info = self.api.check() or {}
            except (ServerError, OSError):
                info = {}
            self.setProperty("account", info.get("displayName") or self.api.username)
            self.getControl(PLAY).setLabel("Play")
            self.getControl(INFO).setVisible(True)
            self.show("home")
            self.welcomed = False  # another account: its own tour and announcements
            return self.greet()
        if result == "account":  # Guest Room or the picks changed (0.4.9)
            self.show("home")

    # -- input --

    def onClick(self, control_id):
        key = mc_menu.key_at(MENU, control_id, self.getControl(NAV).getSelectedPosition()) if control_id in (NAV, NAV_BOTTOM) else None
        if not self.api.signed_in:
            if key == "settings":
                return self.settings()
            if control_id in (NAV, NAV_BOTTOM, PLAY):
                return self.sign_in()
            return
        if control_id in (NAV, NAV_BOTTOM):
            if key is None or (key == self.screen and key != "library"):
                return self.rail_fold()  # the page you are on: the menu folds away
            self.rail_fold()  # the page opens over Home; Back from it comes back to where Home was
            if key == "library":
                return self.library_menu()
            return self.show(key)
        if control_id in (PLAY, INFO) and self.screen == "home" and self.featured is not None and self.featured.current():
            return self.featured_click(control_id)
        if control_id in (PLAY, INFO) and self.hero_item is not None:
            return self.open_item(self.hero_item, play_now=control_id == PLAY)
        if control_id in ROW_IDS:
            li = self.getControl(control_id).getSelectedItem()
            if li is not None:
                self.open_item(li)

    def featured_click(self, control_id):
        """Featured (0.4.9.6, the plan 8.2 and 8.3): OK on Play plays (a show: the episode left part-way, else the next
        one); OK on "•••" opens the title full screen (mc_home.FeaturedPage). Back from there returns here."""
        t = self.featured.current()
        if control_id == INFO:
            mc_home.FeaturedPage.open(self.api, self.featured)
            self.fresh.touch()
            return self.refresh_continue()
        if t["type"] == "series":
            import mc_player as P
            _, season, episode = mc_home.play_label(self.api, t)
            P.play_title(self.api, "series", t["tmdb"], season, episode, art={"name": t["name"], "backdrop": t.get("backdrop", "")})
            refocus(self, PLAY)
            self.fresh.touch()
            return self.refresh_continue()
        return self.open_item(self.hero_item, play_now=True)

    def step_featured(self, a):
        """Left on Play and Right on "•••" turn the featured poster (the plan, item 6); the dots show which. Left on
        Play with nothing to turn to goes to the menu, as before."""
        focus = self.getFocusId()
        moved_here, when = self.arrived
        if moved_here == focus and time.time() - when < 0.3:
            return False  # this press brought the highlight here from the other button
        by = -1 if a == LEFT else 1
        if (by < 0 and focus != PLAY) or (by > 0 and focus != INFO):
            return False
        if self.screen != "home" or self.featured is None or len(self.featured.titles) < 2:
            if by < 0:
                self.rail_open()  # the menu on the left (0.4.9.6, mc_menu): its highlight on the page you are on
            return True
        self.featured.step(by)
        self.featured.show(self)
        return True

    def onFocus(self, control_id):
        self.arrived = (control_id, time.time())
        self.rail_focus(control_id)  # folding the menu goes back here (mc_menu.Rail)

    def hold_continue(self, lid, li):
        """Held OK or the menu key on a Continue Watching card, on Home or in Library's In Progress (0.4.9.6, mc_hold):
        the sheet. A removed card leaves its row at once and the highlight moves to the next one; when the row empties,
        the page is drawn again (on Home, Top 10 moves up)."""
        import mc_hold
        done = mc_hold.continue_hold(self.api, li)
        if done == "removed":
            self.fresh.asked()  # the row is right as it stands; no need to ask the server again now
            if not mc_hold.take_out(self.getControl(lid)):
                self.show(self.screen)
            return done
        if done in ("played", "opened"):
            if done == "played":
                refocus(self, lid)
            self.fresh.touch()
            self.refresh_continue()
        return done

    def library_menu(self):
        choice = xbmcgui.Dialog().select("Library", ["Everything", "Movies", "TV Shows", "My List", "Live TV", "Watch history"])
        if choice == 0:
            self.show("library")
        elif choice == 1:
            BrowsePage.open(self.api, "movie")
        elif choice == 2:
            BrowsePage.open(self.api, "series")
        elif choice == 3:
            self.show("library")
        elif choice == 4:
            GuidePage.open(self.api)
        elif choice == 5:
            self.watch_history()

    def watch_history(self):
        import mc_watching
        if mc_watching.HistoryPage.open(self.api):
            self.refresh_continue()

    def open_item(self, li, play_now=False):
        game = self.games.get(li.getProperty("id")) if li.getProperty("kind") == "game" and self.screen == "home" else None
        if game is not None:
            # Home's Games row (0.4.9.6): live or later plays its channel with both teams on the loading screen; a
            # final, or a game no channel shows, opens its page with the stats.
            import mc_sports_page
            return mc_sports_page.open_game(self.api, game, win=self)
        result = open_item(self.api, li, play_now, win=self)
        if li.getProperty("kind") in more.KINDS and result is True:
            self.show("home")  # new picks: Home's rows follow
            return result
        self.fresh.touch()
        self.refresh_continue()  # back from a title page or the player: what was watched moves to the front
        return result

    def onAction(self, action):
        a = action.getId()
        if a == mc_menu.RIGHT and self.rail_is_open():
            return self.rail_fold()
        if a in BACK:
            focus = self.getFocusId()
            if focus in ROW_IDS or focus in (PLAY, INFO, BUTTONS, ROWS):
                return self.rail_open()  # Back on Home opens the menu (0.4.9.6: on the page you are on)
            if self.screen != "home":
                return self.show("home")
            from mc_device import on_device
            if on_device():
                # On the box, Home is where Back ends: there is nothing behind mediaCENTER. Restart and Turn off are in
                # Settings. Back on the open menu folds it (0.4.9.6).
                return self.rail_fold() if self.rail_is_open() else self.rail_open()
            if xbmcgui.Dialog().yesno("mediaCENTER", "Exit mediaCENTER?", nolabel="Stay", yeslabel="Exit"):
                self.close()
            return
        if a in MENU_KEYS and self.api.signed_in:
            focus = self.getFocusId()
            li = self.getControl(focus).getSelectedItem() if focus in ROW_IDS else None
            if li is not None and li.getProperty("kind") == "continue":
                return self.hold_continue(focus, li)
        if a in (LEFT, RIGHT) and self.getFocusId() in (PLAY, INFO) and self.api.signed_in:
            self.step_featured(a)
        if a in MOVES:
            focus = self.getFocusId()
            if focus in ROW_IDS and self.screen != "home":  # Home keeps its featured poster (0.4.9.3)
                li = self.getControl(focus).getSelectedItem()
                if li is not None:
                    self.hero(li, self.rows.get(focus))
            if self.screen == "home" and self.fresh.due():
                self.fresh.asked()  # asked once, not on every key press while the answer is on its way
                self.later(self.refresh_continue)


def open_item(api, li, play_now=False, win=None):
    """Selecting a card anywhere: a title opens its page (Play on a movie plays), the rest play. win: the page it was
    chosen on, which gets its highlight back after playing."""
    focus = win.getFocusId() if win is not None else None
    result = _open_item(api, li, play_now)
    if win is not None and focus and (li.getProperty("kind") != "title" or play_now):
        refocus(win, focus)
    return result


def _open_item(api, li, play_now=False):
    import mc_player as P
    kind = li.getProperty("kind")
    if kind in more.KINDS:
        return more.open_card(api, li)  # See more, Picked for you, the survey (0.4.9)
    if kind == "title":
        if play_now and li.getProperty("type") == "movie":
            return P.play_title(api, "movie", li.getProperty("tmdb"), art={"name": li.getLabel(), "backdrop": li.getArt("fanart")})
        return TitlePage.open(api, li.getProperty("type"), li.getProperty("tmdb"))
    if kind == "continue":  # a plain OK resumes straight away, no question (the design's hold menus, 0.4.9.6)
        if li.getProperty("type") == "series":
            return P.play_title(api, "series", li.getProperty("tmdb"), int(li.getProperty("season") or 1), int(li.getProperty("episode") or 1),
                                resume=True)
        return P.play_title(api, "movie", li.getProperty("tmdb"), resume=True)
    if kind == "game":
        return watch_game(api, li.getProperty("id"))
    if kind == "channel":
        return P.play_channel(api, li.getProperty("id"), li.getLabel(), now_title=li.getLabel2())


def put_rows(win, rows):
    """Fill a page's poster rows (501..508) from [(title, [ListItem])]; returns how many rows have posters."""
    rows = [r for r in rows if r[1]][:len(ROW_IDS)]
    for i, lid in enumerate(ROW_IDS):
        control = win.getControl(lid)
        control.reset()
        if i < len(rows):
            control.addItems(rows[i][1])
            if rows[i][0]:
                win.setProperty("row.%d.title" % (i + 1), rows[i][0])
            else:
                win.clearProperty("row.%d.title" % (i + 1))
        else:
            win.clearProperty("row.%d.title" % (i + 1))
    show_details(win, rows[0][1][0] if rows else None)
    return len(rows)


def show_details(win, li):
    """The highlighted poster's name and details along the bottom of the Movies, TV Shows and Search pages."""
    win.setProperty("focus.title", li.getLabel() if li is not None else "")
    win.setProperty("focus.meta", (li.getProperty("meta") or li.getLabel2()) if li is not None else "")


class MenuPage(Rail, xbmcgui.WindowXMLDialog):
    """The menu on the left by itself (mediacenter-menu.xml), drawn open with names over a page that has no menu of its
    own, such as the player (the TV button's one press, 0.4.9.7; the design plan 8.9). What plays carries on behind
    it. Up and Down only highlight; OK goes there (anything still playing stops, and the app saves the place, as Back
    does; the Guide takes the picture into its mini player as two presses do); Back, Right or the TV button again close
    it and leave the page as it was."""
    goto_name = pages.MENU

    @classmethod
    def open(cls, api, at="home"):
        w = cls("mediacenter-menu.xml", V.HERE, "Default", "1080i")
        w.api, w.rail_key = api, at
        pages.modal(w)
        del w

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started = True
        self.rail_setup(self.rail_key)
        self.rail_open(show_names=True)

    def rail_fold(self):
        self.clearProperty(mc_menu.OPEN)
        self.close()
        return True

    def onAction(self, action):
        a = action.getId()
        if a == mc_menu.RIGHT or a in BACK:
            return self.rail_fold()

    def onClick(self, control_id):
        key = mc_menu.key_at(self.MENU or mc_menu.items(), control_id, self.getControl(NAV).getSelectedPosition()) \
            if control_id in (NAV, NAV_BOTTOM) else None
        if key is not None:
            self.rail_go(key)

    def rail_leaving(self, key=None):
        """Before going elsewhere: a player stops (the Guide's mini player keeps the picture only for the Guide)."""
        if key == "guide":
            return
        with pages.LOCK:
            opened = list(pages.STACK)
        for page in reversed(opened):
            try:
                if callable(getattr(page, "stop_mini", None)):
                    page.stop_mini()
                elif getattr(page, "playback", None) is not None and callable(getattr(page, "leave", None)):
                    page.attached = page.dock_on_back = False  # stop, not into the Guide's mini player
                    page.leave()
            except RuntimeError:
                pass

    def rail_go(self, key):
        """Always goes, also to the place under it: the pages above that place close (mc_pages.go, inside=True)."""
        self.rail_leaving(key)
        self.clearProperty(mc_menu.OPEN)
        done = pages.go(key, inside=True)
        if key != "guide":
            picture = pages.take_handoff()  # a player that handed its picture over after all: it stops too
            if picture:
                try:
                    picture["playback"].stop()
                except (RuntimeError, AttributeError):
                    pass
        V.log("tv button menu: go to %s: %s" % (key, done))
        if done in ("ignored", "there"):
            self.close()
        return done


class RowsPage(Rail, xbmcgui.WindowXMLDialog):
    """What the Movies, TV Shows and Search pages share: poster rows on the right, Back to the left side, then out, and
    the menu on the left (mc_menu, 0.4.9.6)."""
    SIDE = 60

    @property
    def rail_home(self):
        return self.SIDE

    def onClick(self, control_id):
        if self.rail_click(control_id):
            return
        if control_id in ROW_IDS:
            li = self.getControl(control_id).getSelectedItem()
            if li is not None:
                open_item(self.api, li, win=self)

    def onAction(self, action):
        a = action.getId()
        if self.rail_action(a):
            return
        focus = self.getFocusId()
        if a in BACK:
            if focus in ROW_IDS or focus == ROWS or focus in WORD_KEYS or focus in more.SearchBrowse.AREA:
                return self.setFocusId(self.SIDE)
            return self.close()
        if a in MOVES and (focus in ROW_IDS or focus == more.SearchBrowse.POSTERS):
            show_details(self, self.getControl(focus).getSelectedItem())


# ---- Movies and TV Shows (as on the Roku: genres down the left, rows from /api/browse) --------------------------------

def browse_rows(answer):
    return [(r.get("title") or "", [title_card(t) for t in L.titles_of(r.get("items"))]) for r in (answer or {}).get("rows") or [] if isinstance(r, dict)]


def genre_rows(name, items, per_row=7):
    """A genre's titles as rows that fill the screen, the genre's name on the first."""
    cards = [title_card(t) for t in L.titles_of(items, per_row * len(ROW_IDS))]
    return [(name if i == 0 else "", cards[i:i + per_row]) for i in range(0, len(cards), per_row)]


def service_groups(answer):
    """The streaming services on a Movies or TV Shows page, in the page's order: [(id, name, [(title, [card])])], from
    /api/browse's rows "top:<service>", "popular:<service>" and "new:<service>" ("Top 10 on Netflix", ...)."""
    out, where = [], {}
    for r in (answer or {}).get("rows") or []:
        if not isinstance(r, dict):
            continue
        rid, title = str(r.get("id") or ""), str(r.get("title") or "")
        if ":" not in rid or " on " not in title:
            continue
        sid = rid.split(":", 1)[1]
        cards = [title_card(t) for t in L.titles_of(r.get("items"))]
        if not sid or not cards:
            continue
        if sid not in where:
            where[sid] = len(out)
            out.append((sid, title.rsplit(" on ", 1)[1], []))
        out[where[sid]][2].append((title, cards))
    return out


class BrowsePage(RowsPage):
    """Movies or TV Shows: "All", then each streaming service down the left (owner, 2026-11-26: "Services only", not
    genres); a service shows its Top 10, Popular and New rows."""
    SIDE = 60

    @classmethod
    def open(cls, api, kind):
        w = cls("mediacenter-browse.xml", V.HERE, "Default", "1080i")
        w.api, w.kind = api, kind
        w.goto_name = "movies" if kind == "movie" else "shows"
        pages.modal(w)
        del w

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started = True
        self.rail_setup("movies" if self.kind == "movie" else "shows")
        self.setProperty("heading", "Movies" if self.kind == "movie" else "TV Shows")
        self.page_rows, self.services = [], []
        busy(True)
        try:
            answer = self.api.get("/api/browse", kind=self.kind) or {}
            self.page_rows = browse_rows(answer)
            self.services = service_groups(answer)
        except SignedOut:
            self.setProperty("empty", "Your session ended. Sign in again from Settings.")
        except (ServerError, OSError):
            self.setProperty("empty", "Couldn't load this page. Try again in a moment.")
        finally:
            busy(False)
        try:
            import mc_opening
            mc_opening.remember([li.getArt("poster") for _, items in self.page_rows for li in items])
        except Exception:
            pass
        chips = self.getControl(60)
        chips.reset()
        chips.addItems([xbmcgui.ListItem("All")] + [xbmcgui.ListItem(name) for _, name, _ in self.services])
        self.draw(self.page_rows, 0, "")

    def draw(self, rows, chip, sub):
        chips = self.getControl(60)
        for i in range(chips.size()):
            chips.getListItem(i).setProperty("active", "1" if i == chip else "")
        self.setProperty("sub", sub)
        if put_rows(self, rows):
            self.clearProperty("empty")
            self.setFocusId(ROW_IDS[0])
        else:
            if not self.getProperty("empty"):
                self.setProperty("empty", "Nothing here right now.")
            self.setFocusId(60)

    def onClick(self, control_id):
        if control_id != 60:
            return RowsPage.onClick(self, control_id)
        i = self.getControl(60).getSelectedPosition()
        if i == 0:
            self.clearProperty("empty")
            return self.draw(self.page_rows, 0, "")
        if i - 1 >= len(self.services):
            return
        _, name, rows = self.services[i - 1]
        self.clearProperty("empty")
        self.draw(rows, i, name)


# ---- Search (its own page: letters on screen, results as you type) ---------------------------------------------------

KEYS = [chr(c) for c in range(ord("a"), ord("z") + 1)] + [str(d) for d in range(10)]
WORD_KEYS = {71: "Space", 72: "Delete", 73: "Clear"}  # the buttons under the letters
HINT = "Movies, shows, channels, programmes"  # what the search pill says before typing (the website's words)
VOICE = "Info or Menu: the keyboard again."  # under the letters (the keyboard, speak())


class SearchPage(RowsPage, more.SearchBrowse):
    SIDE = 70
    goto_name = "search"
    WAIT = 0.6  # seconds after the last letter before searching, as on the Roku; 0 searches at once (tests)
    # Kodi's own full-screen keyboard opens with the page (owner, 2026-11-26). The iPhone remote's keyboard fills it in
    # one go (tvcontrol.Typist sends the text instead of walking the letters) and the phone's dictation (Siri) types into
    # it. Back from it leaves the page with the browse area and the letters; Info or Menu brings the keyboard back.
    KEYBOARD_FIRST = True

    @classmethod
    def open(cls, api):
        w = cls("mediacenter-search.xml", V.HERE, "Default", "1080i")
        w.api = api
        pages.modal(w)
        del w

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started = True
        self.query, self.ticket, self.lock = "", 0, threading.Lock()
        self.rail_setup("search")
        self.setProperty("heading", "Search")
        self.setProperty("query", "")
        keys = self.getControl(70)
        keys.reset()
        keys.addItems([xbmcgui.ListItem(k) for k in KEYS])
        self.before_typing()
        self.setFocusId(70)
        if self.KEYBOARD_FIRST and not pages.GOTO.get("to"):
            self.speak()  # 0.4.9.4: the big keyboard first (owner: the letters were glitchy to type into from the phone)

    def before_typing(self):
        """Nothing typed yet: the website's "What are we watching today?" with Movies or TV Shows, the genres and their
        posters (mc_more.SearchBrowse)."""
        put_rows(self, [])
        self.browse()

    def press(self, key):
        if key == "Space":
            self.query = (self.query + " ") if self.query and not self.query.endswith(" ") else self.query
        elif key == "Delete":
            self.query = self.query[:-1]
        elif key == "Clear":
            self.query = ""
        else:
            self.query = (self.query + key)[:60]
        self.setProperty("query", self.query)
        if self.query.strip():
            self.browse_off()
        self.ticket += 1
        if self.WAIT:
            timer = threading.Timer(self.WAIT, self.search, args=(self.ticket,))
            timer.daemon = True
            timer.start()
        else:
            self.search(self.ticket)

    def search(self, ticket):
        """Runs for the newest letters only; an answer that comes back after more typing is dropped."""
        if ticket != self.ticket:
            return
        q = self.query.strip()
        if not q:
            return self.before_typing()
        if len(q) < 2:
            self.setProperty("status", "Keep typing…")
            return
        self.setProperty("status", "Searching…")
        try:
            answer = self.api.get("/api/roku/search", q=q) or {}
        except SignedOut:
            answer, status = None, "Your session ended. Sign in again from Settings."
        except (ServerError, OSError):
            answer, status = None, "Can't reach mediaCENTER right now. Check the internet connection and try again."
        with self.lock:
            if ticket != self.ticket:
                return
            if answer is None:
                put_rows(self, [])
                return self.setProperty("status", status)
            rows = [("Movies and Shows", [title_card(t) for t in L.titles_of(answer.get("titles"))]),
                    ("Live TV", [channel_card(c) for c in answer.get("channels") or []]),
                    ("Teams and games", [game_card(g) for g in answer.get("games") or []])]
            found = put_rows(self, rows)
            self.setProperty("status", "" if found else u"Nothing found for “%s”." % q)

    def onAction(self, action):
        if action.getId() in MENU_KEYS and not self.rail_is_open():
            return self.speak()
        return RowsPage.onAction(self, action)

    def speak(self):
        """Voice search (0.4.9): Kodi's own keyboard opens, which the iPhone remote's keyboard fills in one go, so the
        phone's microphone key (dictation) searches by voice; a keyboard or the controller works there too. The words
        then search as if typed with the letters."""
        kb = xbmc.Keyboard(self.query, "Search: say it or type it on your phone")
        kb.doModal()
        if not kb.isConfirmed():
            return None
        words = " ".join(str(kb.getText() or "").split())[:60]
        self.query = words
        self.setProperty("query", words)
        if words:
            self.browse_off()  # as typing does: the results show instead of the browse area
        self.ticket += 1
        self.search(self.ticket)
        return words

    def onClick(self, control_id):
        if self.rail_click(control_id):
            return
        if control_id == 70:
            i = self.getControl(70).getSelectedPosition()
            if 0 <= i < len(KEYS):
                self.press(KEYS[i])
            return
        if control_id in WORD_KEYS:
            return self.press(WORD_KEYS[control_id])
        if self.browse_click(control_id):
            return
        return RowsPage.onClick(self, control_id)


def watch_game(api, game_id):
    """A game: the channel most likely showing it first, then every other channel that may carry it."""
    answer = V.sports_answer(api) or {}
    game = next((g for g in answer.get("games", []) if str(g.get("id")) == str(game_id)), None)
    chans = (game or {}).get("channels") or []
    if not chans:
        return xbmcgui.Dialog().ok("mediaCENTER", "No channel is showing this game yet.")
    labels = [("Watch on " if i == 0 else "") + c.get("name", "") + ("  [COLOR grey]%s[/COLOR]" % L.why_line(c.get("why")) if c.get("why") else "")
              for i, c in enumerate(chans)]
    i = xbmcgui.Dialog().select(L.matchup(game) or "Watch", labels)
    if i >= 0:
        import mc_player as P
        P.play_channel(api, chans[i]["id"], chans[i].get("name", ""), [a for a in L.alt_ids(chans[i]).split(",") if a], L.matchup(game),
                       game=game)


# ---- a title's page --------------------------------------------------------------------------------------------------

class TitlePage(xbmcgui.WindowXMLDialog):
    @classmethod
    def open(cls, api, kind, tmdb):
        w = cls("mediacenter-title.xml", V.HERE, "Default", "1080i")
        w.api, w.kind, w.tmdb = api, kind, tmdb
        pages.modal(w)
        del w

    def onInit(self):
        # The buttons have their words before anything is asked of the server (0.4.9.3: a crash further down left Play
        # blank, and both it and Choose a version did nothing).
        self.t, self.season = {}, 1
        self.target = ("Play", 1, 1, False) if self.kind == "series" else ("Play", None, None, False)
        self.setProperty("play", "Play")
        self.setProperty("listlabel", "Add to My List")
        busy(True)
        try:
            answer = self.api.get("/api/roku/title", type=self.kind, tmdb=self.tmdb) or {}
            t = L.title_of(dict(answer.get("title") or {}, type=self.kind, tmdb=self.tmdb)) or {"name": "", "type": self.kind, "tmdb": self.tmdb}
            try:
                m = self.api.get("/meta/title", type=self.kind, tmdb=self.tmdb) or {}
                t["certification"] = str(m.get("certification") or "")
                t["rating"] = str(m.get("imdbRating") or t.get("rating") or "")
            except ServerError:
                pass
            self.t = t
            self.pins = V.my_list(self.api)
            similar = L.titles_of((self.api.get("/meta/similar", type=self.kind, tmdb=self.tmdb) or {}).get("items"))
        except (ServerError, SignedOut, OSError):
            busy(False)
            xbmcgui.Dialog().ok("mediaCENTER", "Couldn't load this title right now.")
            return self.close()
        busy(False)
        parts = [L.title_line(t)]
        if t.get("rating"):
            parts.append("IMDb %s" % t["rating"])
        if t.get("certification"):
            parts.append(t["certification"])
        self.setProperty("title", t.get("name", ""))
        self.setProperty("meta", L.DOT.join(p for p in parts if p))
        self.setProperty("plot", t.get("overview", ""))
        self.setProperty("poster", t.get("poster", ""))
        self.setProperty("fanart", t.get("backdrop", ""))
        self.update_list_label()
        if self.kind == "series":
            self.setProperty("series", "1")
            self.seasons = [int(n) for n in t.get("seasonList") or []] or [1]
            seasons = self.getControl(401)
            seasons.addItems([xbmcgui.ListItem("Season %d" % n) for n in self.seasons])
            self.update_play_label()
            self.load_season(self.target[1] if self.target[1] in self.seasons else self.seasons[0])
        else:
            self.update_play_label()
            self.getControl(501).addItems([title_card(x) for x in similar])
        self.setFocusId(301)

    def update_play_label(self):
        """Play on a show: the episode left part-way, else the next one, else the first (owner, 2026-11-25: "Play S1 E1"
        always played the first). On a movie left part-way it says Resume."""
        import mc_player as P
        # Play always works, even when the history can't be read (0.4.9.2: a crash here left no target, so Play did
        # nothing: "'TitlePage' object has no attribute 'target'").
        first = (sorted(P.number(s) for s in getattr(self, "seasons", None) or [1]) or [1])[0] or 1
        self.target = ("Play S%d E1" % first, first, 1, False) if self.kind == "series" else ("Play", None, None, False)
        self.setProperty("play", self.target[0])
        try:
            hist = (self.api.get("/api/history", limit=300) or {}).get("items") or []
        except (ServerError, SignedOut, OSError):
            hist = []
        try:
            if self.kind == "series":
                self.target = P.play_target(hist, self.tmdb, getattr(self, "seasons", [1]))
            else:
                row = next((h for h in hist if h.get("itemId") == L.history_key("movie", self.tmdb)), None)
                part = bool(row) and not row.get("finished") and float(row.get("position") or 0) >= 30
                self.target = ("Resume" if part else "Play", None, None, part)
        except (TypeError, ValueError, KeyError, AttributeError) as e:
            V.log("play label: history not understood (%s); Play starts at the beginning" % type(e).__name__)
        self.setProperty("play", self.target[0])

    def update_list_label(self):
        self.setProperty("listlabel", "Remove from My List" if L.is_pinned(self.pins, self.t) else "Add to My List")

    def load_season(self, n):
        """A season's episodes with their pictures (/meta/episodes, as the web's episode cards; /api/roku/episodes when
        that has nothing): "N. name", then "S1 E1 · 45 min · Mar 3, 2024" or when it airs, and the description."""
        self.season = n
        eps = []
        try:
            eps = (self.api.get("/meta/episodes", tmdb=self.tmdb, season=n) or {}).get("episodes") or []
        except (ServerError, SignedOut, OSError):
            eps = []
        if not eps:
            try:
                eps = (self.api.get("/api/roku/episodes", tmdb=self.tmdb, season=n) or {}).get("episodes") or []
            except (ServerError, SignedOut, OSError):
                eps = []
        control = self.getControl(402)
        control.reset()
        today = datetime.date.today().isoformat()
        self.eps = {}  # number -> the episode as the server gave it, for the hold menu's full details (0.4.9.6)
        for e in eps:
            num = int(e.get("n") or 0)
            self.eps[num] = e
            air = str(e.get("air") or "")[:10]
            later = bool(air) and air > today
            facts = ["S%d E%d" % (n, num)]
            if e.get("runtime"):
                facts.append("%s min" % e["runtime"])
            if air:
                facts.append(("Airs " if later else "") + L.date_text(air))
            li = xbmcgui.ListItem("%d. %s" % (num, e.get("name") or "Episode %d" % num), L.DOT.join(facts))
            li.setArt({"thumb": L.picture(e.get("still"), "w300") if e.get("still") else ""})
            li.setProperties({"episode": str(num), "plot": (e.get("overview") or "")[:220], "later": "1" if later else "",
                              "tag": "Not out yet" if later else ""})
            control.addItem(li)

    def play_and_return(self, season=None, episode=None, choose=None, resume=False, fresh=False):
        """Play on top of this page; when it ends the page is still here, with its labels brought up to date.
        choose: True opens Choose a version first; None (Play, an episode) follows Settings > Choose a source before
        playing (mc_player.play_title)."""
        import mc_player as P
        focus = self.getFocusId()
        P.play_title(self.api, self.kind, self.tmdb, season, episode, choose=choose, resume=resume, fresh=fresh,
                     art={"name": (self.t or {}).get("name", ""), "backdrop": (self.t or {}).get("backdrop", "")})
        self.update_play_label()
        refocus(self, focus or 301)

    def onClick(self, control_id):
        if control_id in (301, 302):
            if self.kind == "series":
                target = getattr(self, "target", None) or ("", 1, 1, False)
                return self.play_and_return(target[1] or 1, target[2] or 1, choose=True if control_id == 302 else None)
            return self.play_and_return(choose=True if control_id == 302 else None)
        if control_id == 303:
            self.pins, pinned = L.toggle_pin(self.pins, self.t)
            try:
                self.api.call("PUT", "/api/prefs", body={"prefs": {"myList": {"value": self.pins, "updatedAt": int(time.time() * 1000)}}})
                V.notify(("Added to My List" if pinned else "Removed from My List"))
            except (ServerError, SignedOut, OSError):
                V.notify("Couldn't change My List right now.")
            return self.update_list_label()
        if control_id == 401:
            label = self.getControl(401).getSelectedItem().getLabel()
            return self.load_season(int(label.split()[-1]))
        if control_id == 402:
            li = self.getControl(402).getSelectedItem()
            if li is None:
                return
            if li.getProperty("later"):
                return V.notify("This episode isn't out yet.")
            return self.play_and_return(self.season, int(li.getProperty("episode")))
        if control_id == 501:
            li = self.getControl(501).getSelectedItem()
            self.close()
            return TitlePage.open(self.api, li.getProperty("type"), li.getProperty("tmdb"))

    def hold_episode(self, ask=None):
        """Held OK or the menu key on an episode (0.4.9.6, mc_hold): the still large, the full name, runtime and air date,
        the whole description, then Play episode, or Resume and Start from the beginning."""
        import mc_hold
        li = self.getControl(402).getSelectedItem()
        if li is None:
            return None
        num = int(li.getProperty("episode") or 0)
        e = dict((getattr(self, "eps", None) or {}).get(num) or {"n": num, "name": li.getLabel().split(". ", 1)[-1]})
        e.setdefault("n", num)
        row = mc_hold.history_row(self.api, L.history_key("series", self.tmdb, self.season, num))
        key = (ask or mc_hold.HoldPage.ask)(mc_hold.episode_sheet((self.t or {}).get("name", ""), self.season, e, row))
        if key in ("play", "resume", "start"):
            self.play_and_return(self.season, num, resume=key == "resume", fresh=key == "start")
        return key

    def onAction(self, action):
        a = action.getId()
        if a in BACK:
            self.close()
        elif a in MENU_KEYS and self.getFocusId() == 402:
            self.hold_episode()



# ---- Guide (the web app's guide: channels down, two and a half hours across) -----------------------------------------

class GuidePage(Rail, xbmcgui.WindowXMLDialog):
    """web-v27/js/views/guide.js as the Roku draws it (roku/components/screens/GuideScreen.brs), in mediaCENTER's own
    window instead of Kodi's TV guide: the channel groups as pills (Local first, All, Favorites, Recent, then the
    provider's groups), the half-hour ruler with a line at now, six channel rows with logos, and what the highlighted
    programme is about at the top. Up and Down move between channels, Left and Right from show to show (the hours move
    at the edge). OK on a show on now plays the channel; on a later one it says when it starts. The context menu key
    adds or removes a favorite (shared with the other apps through /api/prefs, as favoriteChannels).
    0.4.9 (mc_guide_tools): a Sports group after Favorites (every game from the Sports page as a row, its best channel
    to play); favourites pinned to the top of the other groups; Last channel (button 720, or the 0 key); Jump to (721,
    the website's list of times); Groups (722) to hide Live TV categories, shared with the website as hiddenCategories.
    With the mini player on (the default), OK on a channel plays it full screen and Back from there keeps it playing
    in the mini player at the top; OK on the mini player goes full screen again. The TV button on the iPhone remote
    brings what is playing elsewhere (a movie, an episode, a channel) into the mini player the same way (mc_pages)."""
    GRID, PILLS, MINI = 300, 800, 710
    LAST, JUMP, GROUPS = 720, 721, 722
    goto_name = "guide"
    rail_key, rail_home = "guide", 300  # the menu on the left (mc_menu, 0.4.9.6): Left from the first pill or the earliest hour
    G = {"left": 96, "chw": 380, "ruler": 392, "rows": 6, "cells": 8, "pills": 30}
    G["width"] = 1920 - 48 - G["left"] - G["chw"]
    PPM = G["width"] / (L.GUIDE_SPAN / 60.0)
    ready = False  # Kodi can report focus before onInit has loaded anything

    @classmethod
    def open(cls, api):
        w = cls("mediacenter-guide.xml", V.HERE, "Default", "1080i")
        w.api = api
        pages.modal(w)
        del w

    def onInit(self):
        self.adopt()  # first, so the page shows over the picture handed to it rather than hiding behind it
        self.rail_setup("guide")
        self.now = time.time()
        self.start = L.window_start(self.now)
        self.cursor = self.now
        self.row, self.top = 0, 0
        self.placed = {}
        self.channels, self.list, self.guide, self.categories = [], [], {}, []
        self.favorites, self.recent, self.hidden = [], [], set()
        self.lineup, self.sports = [], None
        busy(True)
        try:
            self.load()
        except SignedOut:
            self.setProperty("empty", "Your session ended. Sign in again.")
        except (ServerError, OSError, ValueError):
            self.setProperty("empty", "Couldn't load the TV guide. Try again in a moment.")
        finally:
            busy(False)
        self.draw_pills()
        saved = self.saved_pill()
        ids = [p["id"] for p in self.pills]
        self.pill = saved if saved in ids else (ids[0] if ids else "all")
        if ids and self.pill not in (ids[0], "sports") and not L.channels_for(self.channels, self.pill, self.favorites, self.recent):
            self.pill = ids[0]  # nothing in the group last chosen (an empty Recent): start on the first group
        self.show_last()
        self.ready = True
        self.filter()
        self.setFocusId(self.GRID if self.list else (801 if self.pills else self.GRID))

    def draw_pills(self):
        import mc_guide_tools as GT
        self.pills = GT.with_sports(L.category_pills([c for c in self.categories if c["id"] not in self.hidden])) if self.channels else []
        for n in range(1, self.G["pills"] + 1):
            if n <= len(self.pills):
                self.setProperty("pill.%d" % n, self.pills[n - 1]["name"])
            else:
                self.clearProperty("pill.%d" % n)

    @staticmethod
    def saved_pill(value=None):
        """The pill last chosen, kept on this box (guide_cat on the web and the Roku)."""
        import os
        path = os.path.join(V.PROFILE, "guide-pill.txt")
        try:
            if value is None:
                with open(path, encoding="utf-8") as f:
                    return f.read().strip()
            if not os.path.isdir(V.PROFILE):
                os.makedirs(V.PROFILE)
            with open(path, "w", encoding="utf-8") as f:
                f.write(value)
        except OSError:
            return ""
        return value

    def load(self):
        streams = self.api.get("/player_api.php", action="get_live_streams", **V.XTREAM) or []
        cats = self.api.get("/player_api.php", action="get_live_categories", **V.XTREAM) or []
        self.categories = [{"id": str(c.get("category_id")), "name": str(c.get("category_name") or "")} for c in cats if isinstance(c, dict)]
        self.channels = L.fold_lineup(streams)
        prefs = {}
        try:
            prefs = (self.api.get("/api/prefs") or {}).get("prefs") or {}
        except (ServerError, OSError):
            pass
        value = lambda key: (prefs.get(key) or {}).get("value") if isinstance(prefs.get(key), dict) else None
        self.favorites = [str(i) for i in value("favoriteChannels") or []]
        self.recent = [str(i) for i in value("recentChannels") or []]
        self.hidden = set(str(i) for i in value("hiddenCategories") or [])
        self.lineup = self.channels
        self.channels = [c for c in self.lineup if c["category"] not in self.hidden]
        small = {}
        try:
            small = L.guide_table(self.api.get("/api/roku/guide"))
        except (ServerError, OSError):
            pass
        import os
        import mc_guide
        self.guide = L.merge_guides(small, mc_guide.read_guide(os.path.join(V.PROFILE, "guide", "guide.xml"), self.now))

    # -- what is shown --

    def filter(self):
        import mc_guide_tools as GT
        if self.pill == "sports":
            self.list = self.sports_rows()
        else:
            self.list = GT.pinned(L.channels_for(self.channels, self.pill, self.favorites, self.recent), self.pill, self.favorites)
        self.row, self.top = 0, 0
        for n, p in enumerate(self.pills, 1):
            self.setProperty("pill.%d.bg" % n, accent() if p["id"] == self.pill else CARD)
        self.setProperty("count", "%d channel%s" % (len(self.list), "" if len(self.list) == 1 else "s") if self.channels else "")
        if self.channels and not self.list:
            self.setProperty("empty", {"fav": "No favorites yet. Press the menu key on a channel to add it to Favorites.",
                                       "recent": "Nothing watched yet.", "sports": "No games right now. Check back closer to game time."
                                       }.get(self.pill, "No channels. Try another group."))
        elif self.channels:
            self.clearProperty("empty")
        self.redraw()

    def progs(self, ch):
        if "programmes" in ch:  # a game in the Sports group
            return ch["programmes"]
        return self.guide.get(ch.get("epgId") or "", [])

    def sports_rows(self):
        """The Sports group: the Sports page's games as rows (mc_sports.guide_rows), loaded the first time it is chosen."""
        if self.sports is None:
            import mc_sports
            import mc_sports_page as SP
            try:
                self.sports = mc_sports.guide_rows(SP.load(self.api)[0])
            except (ServerError, SignedOut, OSError, ValueError):
                self.sports = []
        return self.sports

    def put(self, cid, x, y, w):
        """Move a control only when its place changes (each call to Kodi costs time on a Pi)."""
        if self.placed.get(cid) != (x, y, w):
            self.placed[cid] = (x, y, w)
            control = self.getControl(cid)
            control.setPosition(int(x), int(y))
            control.setWidth(max(1, int(w)))

    def redraw(self):
        g = self.G
        self.now = time.time()
        if self.start + L.GUIDE_SPAN < self.now:
            self.start = L.window_start(self.now)
        self.setProperty("day", L.day_text(max(self.cursor, self.start)))
        for i in range(6):
            t = self.start + i * L.HALF_HOUR
            if i < 5:
                self.setProperty("ruler.%d" % i, L.clock_s(t))
                self.put(3000 + i, g["left"] + g["chw"] + (t - self.start) / 60.0 * self.PPM + 8, g["ruler"], 200)
            else:
                self.clearProperty("ruler.%d" % i)
        away = self.start != L.window_start(self.now)
        self.setProperty("nowpill", accent() if away else RAISED)
        self.setProperty("nowtext", "Now")
        if self.list and self.start <= self.now < self.start + L.GUIDE_SPAN:
            self.setProperty("nowline", "1")
            self.put(3020, g["left"] + g["chw"] + (self.now - self.start) / 60.0 * self.PPM, g["ruler"], 3)
        else:
            self.clearProperty("nowline")
        if self.row < self.top:
            self.top = self.row
        if self.row >= self.top + g["rows"]:
            self.top = self.row - g["rows"] + 1
        on_grid = self.getFocusId() == self.GRID
        for r in range(g["rows"]):
            i = self.top + r
            self.draw_row(r, self.list[i] if i < len(self.list) else None, on_grid and i == self.row)
        self.draw_info()
        self.dock_tag()

    def draw_row(self, r, ch, current):
        g, p = self.G, "g.%d" % r
        if ch is None:
            for key in ("name", "num", "logo", "badge", "on", "fav"):
                self.clearProperty("%s.%s" % (p, key))
            for c in range(g["cells"]):
                self.clear_cell(r, c)
            return
        self.setProperty(p + ".name", ch.get("name", ""))
        self.setProperty(p + ".num", str(ch.get("num") or ""))
        self.setProperty(p + ".logo", L.picture(ch.get("logo"), "w185"))
        self.setProperty(p + ".badge", L.badge_text(ch.get("name", "")))
        self.setProperty(p + ".chbg", "29FFFFFF" if current else SURFACE)
        self.setProperty(p + ".on", "1" if current else "")
        self.setProperty(p + ".fav", "1" if str(ch["id"]) in self.favorites else "")
        cells = []
        for prog in self.progs(ch):
            box = L.place(prog, self.start, self.PPM)
            if box:
                cells.append((prog, box))
        if not cells:
            cells = [(None, (0, g["width"] - 6))]
        for c in range(g["cells"]):
            if c >= len(cells):
                self.clear_cell(r, c)
                continue
            prog, (x, w) = cells[c]
            self.draw_cell(r, c, prog, x, w, current)

    def clear_cell(self, r, c):
        p = "g.%d.%d" % (r, c)
        for key in ("t", "s", "on", "bar"):
            self.clearProperty("%s.%s" % (p, key))

    def draw_cell(self, r, c, prog, x, w, current):
        p, base = "g.%d.%d" % (r, c), 2000 + r * 100 + 10 + c * 10
        live = prog is None or prog["start"] <= self.now < prog["stop"]
        on = current and (prog is None or prog["start"] <= self.cursor < prog["stop"])
        self.setProperty(p + ".bg", CREAM if on else (RAISED if live else SURFACE))
        self.setProperty(p + ".on", "1" if on else "")
        if prog is None:
            title, sub = "No guide information", ""
        else:
            title = prog["title"] if w >= 56 else ""
            sub = "" if w <= 90 or L.is_filler(prog) else (L.left_text(prog["stop"] - self.now) if live else L.clock_s(prog["start"]))
        self.setProperty(p + ".t", title or " ")
        self.setProperty(p + ".s", sub)
        self.put(base, x, 0, w)
        for k in (1, 2, 3, 4):
            self.put(base + k, x + 16, 10 if k < 3 else 50, w - 28)
        if prog is not None and live:
            pct = min(1.0, max(0.0, (self.now - prog["start"]) / float(max(1, prog["stop"] - prog["start"]))))
            self.setProperty(p + ".bar", "1")
            self.put(base + 5, x, self.CELL - 5, max(2, w * pct))
        else:
            self.clearProperty(p + ".bar")

    CELL = 92

    def current(self):
        return self.list[self.row] if 0 <= self.row < len(self.list) else None

    def draw_info(self):
        if self.tuning:
            self.setProperty("info.meta", u"Tuning to %s…" % self.tuning)
            return
        ch = self.current()
        if ch is None:
            for key in ("meta", "title", "desc"):
                self.clearProperty("info." + key)
            return
        prog = L.programme_at(self.progs(ch), self.cursor)
        name = " ".join(x for x in [str(ch.get("num") or ""), ch.get("name", "")] if x)
        if ch.get("game"):
            p = ch["programmes"][0]
            self.setProperty("info.meta", L.DOT.join(x for x in [ch.get("num", ""), p["sub"], ch.get("channel") or ""] if x))
            self.setProperty("info.title", ch.get("name", ""))
            self.setProperty("info.desc", p["desc"])
            return
        if prog is None:
            self.setProperty("info.meta", name + ("  ·  Playing. OK for full screen" if self.tuned == str(ch["id"]) else ""))
            self.setProperty("info.title", ch.get("name", ""))
            self.setProperty("info.desc", "No guide information for this channel yet.")
            return
        live = prog["start"] <= self.now < prog["stop"]
        playing = self.tuned == str(ch["id"]) and live
        self.setProperty("info.meta", ("[COLOR %s][B]LIVE[/B][/COLOR]  ·  " % accent() if live else "") + name + "  ·  " +
                         L.clock_s(prog["start"]) + u" – " + L.clock_s(prog["stop"]) + ("  ·  Playing. OK for full screen" if playing else ""))
        self.setProperty("info.title", prog["title"])
        self.setProperty("info.desc", "No description available." if L.is_filler(prog) or not prog.get("desc") else prog["desc"])

    # -- input --

    def onFocus(self, control_id):
        self.rail_focus(control_id)
        if not self.ready:
            return
        if control_id == self.GRID and not self.list and self.pills:
            ids = [p["id"] for p in self.pills]  # nothing to move through: stay on the group's pill
            return self.setFocusId(801 + (ids.index(self.pill) if self.pill in ids else 0))
        self.redraw()

    def onClick(self, control_id):
        if self.rail_click(control_id):
            return
        if 801 <= control_id < 801 + len(self.pills):
            self.pill = self.pills[control_id - 801]["id"]
            self.saved_pill(self.pill)
            return self.filter()
        if control_id == self.GRID:
            return self.choose()
        if control_id == self.MINI and self.mini is not None:
            return self.full_screen()
        if control_id == self.LAST:
            return self.play_last()
        if control_id == self.JUMP:
            return self.jump()
        if control_id == self.GROUPS:
            return self.groups()

    tuning = None  # 0.4.9.6: the channel being tuned; OK again meanwhile does nothing (GuidePage.choose)

    def choose(self, ch=None):
        """OK on a channel: one channel at a time, with "Tuning to …" while it starts. 0.4.9.6 (owner, 2026-11-26:
        changing channels froze, and the presses made meanwhile landed at once): saving Recent and stopping the old
        channel happen off the remote's thread, and a second OK while one tunes is dropped. Back on the player's
        loading screen cancels."""
        if self.tuning:
            return V.log("guide: %s still tuning; press dropped" % self.tuning)
        ch = ch or self.current()
        if ch is None:
            return
        self.tuning = ch.get("channel") or ch.get("name") or "the channel"
        try:
            return self.tune(ch)
        finally:
            self.tuning = None
            if getattr(self, "list", None) is not None and self.ready:
                self.draw_info()

    def tune(self, ch):
        extra = {}
        if ch.get("game"):  # a game in the Sports group: its best channel, with both teams on the loading screen
            import mc_sports as S
            import mc_sports_page as SP
            game = ch["game"]
            if not ch.get("id"):
                return V.notify(S.no_channel_message(game, SP.wording()))
            if game.get("state") == "pre":
                return V.notify("%s starts at %s on %s" % (ch.get("name", ""), S.clock(game.get("start")), ch.get("channel") or ""))
            prog, extra = None, {"game": SP.for_loading(game)}
            ch = dict(ch, name=ch.get("channel") or ch.get("name", ""), logo="")
        else:
            prog = L.programme_at(self.progs(ch), self.cursor)
        if prog is not None and prog["start"] > self.now:
            name = " ".join(x for x in [str(ch.get("num") or ""), ch.get("name", "")] if x)
            return V.notify("%s starts at %s on %s" % (prog["title"], L.clock_s(prog["start"]), name))
        self.recent = [str(ch["id"])] + [i for i in self.recent if i != str(ch["id"])][:19]
        self.save_pref_later("recentChannels", list(self.recent))
        if getattr(self, "list", None) is not None and self.ready:
            self.draw_info()  # "Tuning to …" in the panel at the top until the player shows
        import mc_player as P
        alts = [a for a in L.alt_ids(ch).split(",") if a]
        now_title = prog["title"] if prog else (ch.get("game") or {}).get("title", "")
        if V.ADDON.getSetting("guide_mini") == "false":
            self.stop_mini(later=True)
            P.play_channel(self.api, ch["id"], ch.get("name", ""), alts, now_title, logo=ch.get("logo", ""), **extra)
            self.show_last()
            return self.back_to_grid()
        if self.tuned == str(ch["id"]) and self.mini is not None:
            return self.full_screen()
        self.stop_mini(later=True)  # the new channel's player waits for it (mc_player.PLAY_LOCK), the remote doesn't
        P.play_channel(self.api, ch["id"], ch.get("name", ""), alts, now_title, dock=True, logo=ch.get("logo", ""), **extra)
        self.show_last()
        self.adopt()  # Back from the full screen: the channel carries on in the mini player
        self.back_to_grid()

    # -- the mini player (web-v27/js/views/guide.js: what plays docks at the top; OK on it, full screen again) --

    mini = None
    tuned = None
    docked = None  # what the mini player shows: name, sub, live, channel, carry (mc_player.PlayerPage.picture)

    def adopt(self):
        """Take over a picture a closing player handed over (mc_pages.HANDOFF): it carries on in the mini player."""
        picture = pages.take_handoff()
        if picture is None:
            return False
        if self.mini is not None and self.mini is not picture["playback"]:
            self.mini.stop()
        self.mini = picture["playback"]
        self.mini.ui = MiniScreen(self)
        self.docked = picture
        self.tuned = str(picture["channel"]) if picture.get("live") and picture.get("channel") else None
        V.WINDOW.setProperty("mc.dock", "1")
        MP.moved(V.WINDOW)  # the mini player's small video control now sets where the next picture opens (mc_picture)
        self.setProperty("dock.name", picture.get("name") or "")
        self.mini_hold().reset()
        self.dock_tag()
        if getattr(self, "list", None) is not None and self.ready:
            self.redraw()
        return True

    def full_screen(self):
        """OK on the mini player (or on the channel it is showing): full screen; Back docks it again."""
        import mc_player as P
        picture, playback = self.docked or {}, self.mini
        self.mini = None  # the full screen has it now; it hands it back on Back
        P.PlayerPage.attach(self.api, playback, picture.get("name") or "", picture.get("sub") or "", picture.get("carry"))
        if not self.adopt():
            self.mini = playback
            self.stop_mini()
        self.back_to_grid()

    def back_to_grid(self):
        refocus(self, self.GRID, tries=10 if self.mini is None else 1)
        self.redraw()

    def stop_mini(self, later=False):
        """later: on its own thread (a new channel is about to start; Kodi's stop waits for the player)."""
        if self.mini is not None:
            self.mini.stop_later() if later else self.mini.stop()
        self.mini, self.tuned, self.docked = None, None, None
        self.mini_hold().reset()
        V.WINDOW.clearProperty("mc.dock")
        self.clearProperty("dock.name")
        self.clearProperty("dock.tag")

    def mini_failed(self, words=""):
        live = (self.docked or {}).get("live", True)
        if live and self.mini_hold().lost_hold() and self.mini_back_to_live():
            return
        self.stop_mini()
        V.notify(words or ("This channel isn't playing right now." if live else "This stopped playing."))
        self.redraw()

    # -- 0.4.9.6: Play and Pause on the mini player (owner, 2026-11-26: Play/Pause did nothing on live TV) --

    def mini_hold(self):
        h = getattr(self, "held", None)
        if h is None:
            h = self.held = LP.Hold()
        return h

    def dock_tag(self):
        """LIVE, NOW PLAYING or PAUSED (with the time) over the mini player. Kodi's own Player.Paused counts too: the
        iPhone remote pauses through Kodi, which the Guide never sees as a key."""
        if self.mini is None or not self.docked:
            return
        paused = bool(xbmc.getCondVisibility("Player.Paused"))
        hold = self.mini_hold()
        hold.follow("paused" if paused else "playing")
        if paused:
            tag = LP.paused_note(hold.paused_at, L.clock_s).upper() if self.docked.get("live") else "PAUSED"
        else:
            tag = "LIVE" if self.docked.get("live") else "NOW PLAYING"
        self.setProperty("dock.tag", tag)

    def mini_paused(self, a):
        """Pause, Play/Pause or Play with the mini player on: as full screen (mc_live_pause.toggle), off the remote's
        thread. Returns the thread."""
        import mc_player as P
        mini, live = self.mini, (self.docked or {}).get("live")

        def run():
            state = LP.toggle(mini.player, a, P.KODI_PAUSE_WAIT, lambda: xbmc.getCondVisibility("Player.Paused"),
                              closing=lambda: self.mini is not mini)
            if self.mini is not mini:
                return
            if state == "refused" and live:
                V.log("live pause refused (mini player)")
                V.notify(LP.REFUSED)
            self.dock_tag()
        th = threading.Thread(target=run)
        th.daemon = True
        th.start()
        return th

    def mini_back_to_live(self):
        """The docked channel couldn't hold the pause: the same channel again from now in the mini player, with "Back
        to live". False when it can't be found (the usual "isn't playing" note then)."""
        import mc_player as P
        cid = str((self.docked or {}).get("channel") or "")
        ch = next((c for c in getattr(self, "channels", []) or [] if str(c.get("id")) == cid), None)
        if not cid:
            return False
        name = (self.docked or {}).get("name") or (ch or {}).get("name", "")
        alts = [x for x in L.alt_ids(ch).split(",") if x] if ch else []
        V.log("guide: the docked channel couldn't hold the pause; back to live")
        self.mini_hold().reset()
        old = self.mini
        pb = P.Playback(MiniScreen(self))
        self.mini = pb
        if old is not None:
            old.cancelled = True  # the new one replaces it in Kodi (mc_player.PLAY_LOCK)
        V.notify(LP.BACK_TO_LIVE)

        def start():
            try:
                feeds = P.live_feeds(self.api, cid, name, alts)
            except (SignedOut, ServerError, OSError, ValueError):
                feeds = []
            if self.mini is not pb:
                return
            if not feeds:
                return self.mini_failed()
            pb.start(feeds, P.LIVE_STAGES)
        th = threading.Thread(target=start)
        th.daemon = True
        th.start()
        self.dock_tag()
        return True

    # -- 0.4.9: last channel, jump to a time, hide groups --

    def last(self):
        """The channel watched before the one on now (the account's recentChannels, newest first), from the lineup."""
        import mc_sports as S
        cid = S.last_channel(self.recent, self.tuned)
        return next((c for c in self.channels if str(c["id"]) == cid), None) if cid else None

    def show_last(self):
        ch = self.last()
        if ch is None:
            return self.clearProperty("last")
        self.setProperty("last", "Last: " + (ch.get("name") or ""))

    def play_last(self):
        ch = self.last()
        if ch is None:
            return V.notify("No other channel watched yet.")
        self.choose(ch)

    def jump(self):
        import mc_guide_tools as GT
        times = GT.jump_times(time.time())
        i = xbmcgui.Dialog().select("Jump to", [label for label, _ in times])
        if i is None or i < 0:
            return
        at, now = times[i][1], time.time()
        self.start = L.window_start(max(at, now) if i == 0 else at)
        self.cursor = now if i == 0 else at
        self.setFocusId(self.GRID)
        self.redraw()

    def groups(self):
        """Which Live TV categories show (the website's Settings, Channel categories), saved to the account."""
        import mc_guide_tools as GT
        if not self.categories:
            return V.notify("No channel categories yet.")
        picked = xbmcgui.Dialog().multiselect("Live TV categories: %s" % GT.shown_count(self.categories, self.hidden),
                                              [c["name"] for c in self.categories],
                                              preselect=GT.shown_positions(self.categories, self.hidden))
        if picked is None:
            return
        hidden = GT.hidden_after(self.categories, picked)
        if set(hidden) == self.hidden:
            return
        self.hidden = set(hidden)
        self.save_pref("hiddenCategories", hidden)
        self.channels = [c for c in self.lineup if c["category"] not in self.hidden]
        self.draw_pills()
        ids = [p["id"] for p in self.pills]
        if self.pill not in ids:
            self.pill = ids[0] if ids else "all"
        self.filter()
        self.show_last()

    def save_pref_later(self, key, value):
        """save_pref on its own thread (0.4.9.6): a slow server held up the press that chose a channel."""
        th = threading.Thread(target=self.save_pref, args=(key, value))
        th.daemon = True
        th.start()
        return th

    def save_pref(self, key, value):
        try:
            self.api.call("PUT", "/api/prefs", body={"prefs": {key: {"value": value, "updatedAt": int(time.time() * 1000)}}})
        except (ServerError, SignedOut, OSError):
            pass

    def toggle_favorite(self):
        ch = self.current()
        if ch is None or ch.get("game"):
            return
        cid = str(ch["id"])
        if cid in self.favorites:
            self.favorites = [f for f in self.favorites if f != cid]
            V.notify("Removed %s from Favorites" % ch.get("name", ""))
        else:
            self.favorites = self.favorites + [cid]
            V.notify("Added %s to Favorites" % ch.get("name", ""))
        self.save_pref("favoriteChannels", sorted(self.favorites))
        if self.pill == "fav":
            return self.filter()
        self.redraw()

    def rail_leaving(self):
        self.stop_mini()  # another page from the menu: the mini player stops, as Back does

    def onAction(self, action):
        a = action.getId()
        if self.rail_action(a):
            return
        if a in BACK:
            self.stop_mini()
            return self.close()
        if a == REMOTE_0:
            return self.play_last()
        if a in LP.KEYS and self.mini is not None:
            return self.mini_paused(a)
        if self.getFocusId() != self.GRID or not self.list:
            return
        if a == 3:  # up
            if self.row > 0:
                self.row -= 1
                return self.redraw()
            if self.pills:
                ids = [p["id"] for p in self.pills]
                return self.setFocusId(801 + (ids.index(self.pill) if self.pill in ids else 0))
        elif a == 4:  # down
            self.row = min(len(self.list) - 1, self.row + 1)
            self.redraw()
        elif a in (1, 2):  # left, right
            was = (self.cursor, self.start)
            self.cursor, self.start = L.move_time(self.progs(self.current()), self.cursor, self.start, time.time(), 1 if a == 2 else -1)
            if a == 1 and self.cursor > was[0] - 60:
                return self.rail_open()  # the earliest hour already: Left opens the menu (0.4.9.6)
            self.redraw()
        elif a in (5, 6):  # page up, page down
            step = self.G["rows"] * (1 if a == 6 else -1)
            self.row = max(0, min(len(self.list) - 1, self.row + step))
            self.redraw()
        elif a in (117, 11):  # context menu, info: favorite
            self.toggle_favorite()


class MiniScreen(object):
    """What the Guide's mini player shows while it works: nothing but the picture; a failure says so in a note."""

    def __init__(self, guide):
        self.guide = guide

    def stage(self, pct, words, detail):
        pass

    def toast(self, words):
        V.notify(words)

    def started(self, feed):
        pass

    def failed(self):
        self.guide.mini_failed()

    def ended(self):
        self.guide.mini_failed(self.words())

    def stopped(self):
        if self.guide.mini is not None and not self.guide.mini.cancelled:
            self.guide.mini_failed(self.words())

    def words(self):
        return "The channel stopped." if (self.guide.docked or {}).get("live", True) else "It finished playing."


# ---- Sports (a list with details beside it) ----------------------------------------------------------------

class ListPage(xbmcgui.WindowXMLDialog):
    @classmethod
    def open(cls, api, screen):
        w = cls("mediacenter-list.xml", V.HERE, "Default", "1080i")
        w.api, w.screen = api, screen
        pages.modal(w)
        del w

    def onInit(self):
        self.tabs = [("all", "All games"), ("live", "Live now"), ("mine", "My Teams")]
        self.setProperty("heading", "Sports")
        current = "all"
        for i in range(1, 5):
            if i <= len(self.tabs):
                self.setProperty("tab.%d" % i, self.tabs[i - 1][1])
            else:
                self.clearProperty("tab.%d" % i)
        self.load(current)

    def load(self, tab):
        control = self.getControl(50)
        control.reset()
        self.clearProperty("empty")
        busy(True)
        try:
            items = self.games(tab)
        except (ServerError, SignedOut, OSError):
            items = []
            self.setProperty("empty", "Couldn't load this right now. Try again in a moment.")
        busy(False)
        control.addItems(items)
        if not items and not self.getProperty("empty"):
            self.setProperty("empty", "No games for your teams right now." if tab == "mine" else "Nothing on right now.")
        self.setFocusId(50 if items else 101)

    def games(self, tab):
        games = (V.sports_answer(self.api) or {}).get("games") or []
        if tab == "live":
            games = [g for g in games if g.get("state") == "in"]
        elif tab == "mine":
            games = [g for g in games if g.get("mine")]
        out = []
        for g in games:
            li = xbmcgui.ListItem(L.score_line(g) or L.matchup(g), L.when(g))
            chans = g.get("channels") or []
            li.setProperties({"num": g.get("league") or "", "id": str(g.get("id")),
                              "eyebrow": ("LIVE · " if g.get("state") == "in" else "") + (g.get("league") or ""),
                              "detail": "\n".join(p for p in [L.matchup(g), L.when(g), "", ("Watch on " + chans[0]["name"]) if chans else "No channel is showing this game yet"] if p is not None)})
            out.append(li)
        return out

    def onClick(self, control_id):
        if 101 <= control_id <= 104:
            return self.load(self.tabs[control_id - 101][0])
        if control_id == 50:
            li = self.getControl(50).getSelectedItem()
            if li is None:
                return
            return watch_game(self.api, li.getProperty("id"))

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()


# ---- start -----------------------------------------------------------------------------------------------------------

RUNNING = "mediacenter.app.open"
WELCOME_PLOT = "Sign in to see your movies, shows, live TV and sports."


def legal():
    """Settings > Legal: the open-source notices, the only place the box names the software it is built on."""
    import os
    with open(os.path.join(V.HERE, "resources", "data", "legal.txt"), encoding="utf-8") as f:
        xbmcgui.Dialog().textviewer("Legal", f.read())


KODI_DIALOGS = ("selectdialog", "yesnodialog", "okdialog", "textviewer", "contextmenu", "virtualkeyboard")


def close_kodi_dialogs():
    """Kodi's own lists and questions close too when the TV button leaves a page (they answer as if cancelled)."""
    for name in KODI_DIALOGS:
        xbmc.executebuiltin("Dialog.Close(%s)" % name)


def run(goto=""):
    import mc_updates as lifecycle
    if lifecycle.installing(V.WINDOW):
        return
    # goto: a page asked for from outside (the iPhone remote's TV button: script.mediacenter open=guide). A running
    # app is told through a Home property that its follower thread watches (mc_pages); a new app goes there once open.
    if goto == pages.MENU and not V.WINDOW.getProperty(RUNNING):
        goto = ""  # 0.4.9.6: the TV button's one press with the app closed just opens it
    if goto in pages.PAGES:
        V.WINDOW.setProperty(pages.WANT, goto)
    # The skin's Home and the service can both ask at start-up; only one app opens.
    if V.WINDOW.getProperty(RUNNING):
        return
    if not goto:
        V.WINDOW.clearProperty(pages.WANT)  # an ask left over from an app that has since closed
    V.WINDOW.setProperty(RUNNING, "1")
    w = None
    try:
        T.ensure(V.ADDON, V.WINDOW)  # the theme's colours before the first page draws (the service syncs it with the account)
        w = App("mediacenter-home.xml", V.HERE, "Default", "1080i")
        w.doModal()
    finally:
        try:
            if w is not None:
                w.stop_following()
            import mc_relay
            mc_relay.stop_local()
        finally:
            V.WINDOW.clearProperty(RUNNING)
