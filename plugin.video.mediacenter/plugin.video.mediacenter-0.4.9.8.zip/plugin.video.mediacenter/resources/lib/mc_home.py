# mediaCENTER for Kodi 0.4.9.3: Home in the website's look (web-v27/js/views/home-tv.js, the website's Home on a
# computer and a TV). What this file adds to mc_app's Home:
#   - The Featured poster: the top of Home shows one featured title at a time and turns to the next every 8 seconds,
#     as the website's does; Play and "•••" act on the title shown. It no longer follows the highlighted card (owner,
#     2026-11-26: a "Featured" title over every row and a Featured row were confusing): each card names itself under
#     its picture, as the website's cards do, and there is no Featured row.
#   - The cards' shapes, one per row (Window.Property(row.N.shape), drawn by kodi/tools/make_windows.py home_row):
#     "" posters, "wide" Continue Watching (the picture across, the bar inside, the name and what's left under it),
#     "top" Top 10 today (the big number at the poster's lower left), "game" My Teams (Sports' team-colour cards).
#   - The season's row: the films design/experience.json names for the month (pi.seasonal: Holiday Movies in November
#     and December), looked up by name and year through /meta/batch, the lookup the website's cards use.
#   - The app's clock (the pill's date and time, the greeting, the season's month): the server's time and the time zone
#     the server sees the connection in, not the box's own clock, which a Pi may not have set (see now()).
# Nothing here is needed for Home to work: a lookup that fails leaves its pictures or its row out.

import datetime
import email.utils
import json
import re
import threading
import time

import xbmc
import xbmcgui

import mc_logic as L
import mc_views as V
from mc_api import Api, SignedOut, ServerError

ERRORS = (ServerError, SignedOut, OSError, ValueError)
TURN = 8  # seconds between featured titles (home-tv.js TURN_MS)
FEATURED = 8  # titles the featured poster turns through (home-tv.js useFeatured)
SEASONAL_TTL = 12 * 3600  # a season's lookup is kept half a day
PART = 6  # /meta/batch asks six at a time, as everywhere else
NO_DIALOG = 9999  # Kodi's answer when no dialog (another mediaCENTER page) is open
IN_BACKGROUND = True  # pictures land after Home shows; tests switch it off to see them land
SHAPES = ("", "wide", "top", "game")


def later(job):
    if not IN_BACKGROUND:
        return job()
    t = threading.Thread(target=job)
    t.daemon = True
    t.start()
    return t


def batch(api, queries):
    """/meta/batch for any number of lookups, six to a call and the calls side by side (Home waits for the slowest,
    not their sum). The answers in the queries' order; None where a call failed."""
    parts = [queries[i:i + PART] for i in range(0, len(queries), PART)]
    answers = [None] * len(parts)

    def ask(n):
        try:
            got = api.get("/meta/batch", q=json.dumps(parts[n], separators=(",", ":")))
            answers[n] = got if isinstance(got, list) else []
        except ERRORS:
            answers[n] = []

    threads = [threading.Thread(target=ask, args=(n,)) for n in range(len(parts))]
    for t in threads:
        t.daemon = True
        t.start()
    for t in threads:
        t.join(20)
    out = []
    for part, got in zip(parts, answers):
        got = got or []
        out.extend(got[i] if i < len(got) else None for i in range(len(part)))
    return out


# ---- the app's clock ---------------------------------------------------------------------------------------------------
# A Pi keeps no time with the power off: LibreELEC sets the clock from the internet after it starts, and its time zone
# stays at UTC unless someone sets it. Until then Kodi's own date and time are wrong (and the pill's date showed nothing
# in 0.4.9.2, a Kodi label that read the comma in "ddd, mmm d" as two dates). So Home uses the app's clock: the server's
# time (the HTTP Date on every answer, mc_api.Api.server_time) when the box's clock is more than five minutes off, and
# the time zone the server places the connection in (/api/roku/home "clock") when the box's zone was never set (reads
# UTC). Nothing here changes the box's settings.

WRONG = 300  # seconds: a box clock this far from the server's is wrong
_ZONE = {"offset": None, "name": ""}  # minutes from UTC where the connection is, from the server


def set_zone(answer):
    c = answer.get("clock") if isinstance(answer, dict) else None
    if isinstance(c, dict) and isinstance(c.get("offset"), int) and not isinstance(c.get("offset"), bool) \
            and -840 <= c["offset"] <= 840:
        _ZONE.update(offset=c["offset"], name=str(c.get("zone") or ""))


def skew(heard=None):
    """Seconds to add to the box's clock: 0 while it agrees with the server's (within WRONG)."""
    heard = Api.server_time if heard is None else heard
    if not heard:
        return 0.0
    try:
        server = email.utils.parsedate_to_datetime(heard[0]).timestamp()
    except (TypeError, ValueError, IndexError, OverflowError):
        return 0.0
    off = server - heard[1]
    return off if abs(off) > WRONG else 0.0


def now(box=None):
    """The date and time where the person is, by the app's clock."""
    t = (time.time() if box is None else box) + skew()
    mine = datetime.datetime.fromtimestamp(t)
    if _ZONE["offset"] is None:
        return mine
    utc = datetime.datetime.fromtimestamp(t, datetime.timezone.utc).replace(tzinfo=None)
    if mine == utc:  # the box reads UTC: its zone was never set, so the connection's zone
        return utc + datetime.timedelta(minutes=_ZONE["offset"])
    return mine  # someone set the box's zone: theirs wins


def twenty_four():
    try:
        return "%H" in xbmc.getRegion("time")
    except Exception:
        return False


def show_clock(win):
    win.setProperty("clock", L.clock_line(now(), twenty_four()))


# ---- the season's row --------------------------------------------------------------------------------------------------

def look_up(api, wanted):
    """The season's films by name and year; an answer that isn't the film asked for is left out."""
    answers = batch(api, [{"type": "movie", "title": w["title"], "year": w["year"]} for w in wanted])
    out, seen = [], set()
    for w, a in zip(wanted, answers):
        if not L.same_film(w, a):
            continue
        t = dict(a, type="movie")
        if not t.get("title"):
            t["title"] = w["title"]
        card = L.title_of(t)
        if card and card["poster"] and card["tmdb"] not in seen:
            seen.add(card["tmdb"])
            out.append(t)
    return out


def seasonal(api, today=None):
    """(title, [title]) for Home's seasonal row: Holiday Movies in November and December, Halloween Movies in October,
    a genre row (Family Picks) the rest of the year."""
    s = L.seasonal_row(today or now().date(), (V.experience().get("app") or {}).get("seasonal"))
    if s["titles"]:
        name = "seasonal-" + re.sub(r"[^a-z]", "", s["title"].lower())
        found = V.cached(name, SEASONAL_TTL, lambda: look_up(api, s["titles"]))
        if not found:
            V.drop_cache(name)  # a lookup that failed is asked again next time, not kept for half a day
        return s["title"], L.titles_of(found)
    try:
        items = (api.get("/meta/row", type="movie", row=s["row"]) or {}).get("items")
    except ServerError:
        items = []
    return s["title"], L.titles_of(items)


# ---- Continue Watching's wide pictures -------------------------------------------------------------------------------

_WIDE = {}  # "type:tmdb" -> the title's wide picture, kept while the app is open


def _key(li):
    return "%s:%s" % (li.getProperty("type"), li.getProperty("tmdb"))


def wide_pictures(api, cards):
    """The wide picture on each Continue Watching card: the title's backdrop (the history keeps a poster or an
    episode's picture, which is the wrong shape). Cards keep what they have until it lands."""
    need = []
    for li in cards:
        url = _WIDE.get(_key(li))
        if url:
            li.setArt({"landscape": url})
        elif _key(li) not in _WIDE:
            need.append(li)
    if not need:
        return

    def work():
        answers = batch(api, [{"type": li.getProperty("type"), "tmdb": li.getProperty("tmdb")} for li in need])
        for li, a in zip(need, answers):
            if not isinstance(a, dict):
                continue  # failed: asked again next time
            url = L.picture(a.get("backdrop") or a.get("card") or "", "w780")
            _WIDE[_key(li)] = url
            if url:
                li.setArt({"landscape": url})
    later(work)


# ---- the featured poster ---------------------------------------------------------------------------------------------

class Featured(object):
    """The titles at the top of Home, one at a time (home-tv.js Hero): FEATURED, the title's logo (or its name),
    "2022 · Series", Play and "•••", the dots."""

    def __init__(self, titles):
        self.titles = list(titles)[:FEATURED]  # the server sends those with a picture (/api/roku/home)
        self.at = 0
        self.logos = {}

    def current(self):
        return self.titles[self.at % len(self.titles)] if self.titles else None

    def step(self, by=1):
        if self.titles:
            self.at = (self.at + by) % len(self.titles)

    def show(self, win):
        """Put the current title on the page; Play and "•••" act on it (win.hero_item)."""
        import mc_app
        t = self.current()
        if t is None:
            return win.hero(None)
        win.hero_item = mc_app.title_card(t)
        win.setProperty("hero.eyebrow", "FEATURED")
        win.setProperty("hero.title", t["name"])
        win.setProperty("hero.meta", L.featured_line(t))
        win.clearProperty("hero.plot")
        win.setProperty("hero.fanart", t["backdrop"])
        logo = self.logos.get(t["tmdb"], "")
        if logo:
            win.setProperty("hero.logo", logo)
        else:
            win.clearProperty("hero.logo")
        win.setProperty("hero.dots", L.dots(len(self.titles), self.at))

    def fetch_logos(self, api, win):
        """The titles' logos (the website shows the logo in place of the name), asked once, after Home shows."""
        titles = list(self.titles)
        if not titles:
            return

        def work():
            for t, a in zip(titles, batch(api, [{"type": t["type"], "tmdb": t["tmdb"]} for t in titles])):
                logo = L.picture((a or {}).get("logo") or "", "w500") if isinstance(a, dict) else ""
                if logo:
                    self.logos[t["tmdb"]] = logo
            if win.featured is self and win.screen == "home":
                self.show(win)
        later(work)


class Turner(object):
    """Turns the featured poster every TURN seconds while Home is on screen, as the website's, and keeps the pill's
    clock current. It waits while the
    highlight is on Play or "•••" (so Play starts the title the person was looking at), while another page or the
    player is in front, and stops when Home closes."""

    def __init__(self, win):
        self.win = win
        self.stopped = None

    def start(self):
        if self.stopped is not None and not self.stopped.is_set():
            return
        stopped = self.stopped = threading.Event()
        t = threading.Thread(target=self.run, args=(stopped,))
        t.daemon = True
        t.start()

    def stop(self):
        if self.stopped is not None:
            self.stopped.set()

    def run(self, stopped):
        monitor = xbmc.Monitor()
        while not stopped.is_set():
            if monitor.waitForAbort(TURN) or stopped.is_set():
                return
            try:
                if self.win.screen == "home":
                    show_clock(self.win)
            except Exception as e:
                V.log("clock skipped: %s" % type(e).__name__)
            try:
                if may_turn(self.win):
                    self.win.featured.step()
                    self.win.featured.show(self.win)
            except Exception as e:  # never take the app down for a picture
                V.log("featured turn skipped: %s" % type(e).__name__)


def may_turn(win):
    import mc_app
    featured = getattr(win, "featured", None)
    if win.screen != "home" or featured is None or len(featured.titles) < 2:
        return False
    if win.getFocusId() in (mc_app.PLAY, mc_app.INFO):
        return False
    dialog = getattr(xbmcgui, "getCurrentWindowDialogId", None)
    if dialog is not None and dialog() != NO_DIALOG:
        return False
    return not xbmc.getCondVisibility("Player.HasVideo")


# ---- the greeting, typed (0.4.9.6) -------------------------------------------------------------------------------------
# The website types "> Good morning, Dru" one letter at a time with a white block cursor blinking after it (home-tv.js
# Greeting). Kodi has no typing animation, so the words go into the label a letter at a time from a thread; the
# cursor is drawn by the window (make_windows.home_window) whenever Window.Property(cursor) is set.

TYPE_STEP = 0.045  # seconds between letters (the website's 45 ms)
_TYPING = {"n": 0}  # which typing is current: a newer greeting, or a page that sets its own, stops an older one


def type_greeting(win, text):
    """Home's greeting, typed. The same words already on screen aren't typed again (Home is drawn again when Continue
    Watching appears or empties). Tests (IN_BACKGROUND off) get the whole line at once."""
    _TYPING["n"] += 1
    mine = _TYPING["n"]
    win.setProperty("cursor", "1")
    win.setProperty("greeting.words", text)  # the whole line at once, for anything that reads it while it types
    if not text or win.getProperty("greeting") == text or not IN_BACKGROUND:
        return win.setProperty("greeting", text)
    win.setProperty("greeting", "")

    def work():
        monitor = xbmc.Monitor()
        for n in range(1, len(text) + 1):
            if _TYPING["n"] != mine or getattr(win, "screen", "home") != "home":
                return
            win.setProperty("greeting", text[:n])
            if monitor.waitForAbort(TYPE_STEP):
                return win.setProperty("greeting", text)
    later(work)


def stop_greeting(win, words=""):
    """Another page's heading in the greeting's place (Library): no typing, no cursor."""
    _TYPING["n"] += 1
    win.clearProperty("cursor")
    win.setProperty("greeting.words", words)
    win.setProperty("greeting", words)


# ---- the Games row (0.4.9.6) -------------------------------------------------------------------------------------------
# The plan (8.5, items 11 and 12): Home's "My Teams" row becomes Games: one row, your teams' games first (MY TEAM),
# then every other game live or on later today, live first. Each card is the Sports page's team-colour card with the
# teams' logos (small ESPN copies, mc_sports.small_logo) and their letters only where a game has no logo; a time, LIVE
# or CLOSE GAME at the top left; MY TEAM at the top right; one line at the foot: "Jets at Dolphins · CBS 10" or
# "Q3 4:12 · ESPN". OK on a live or upcoming game plays its channel with both teams on the loading screen; a final
# opens its stats (mc_sports_page.open_game). The games come from /api/sports/active (which carries the logos) joined
# with /api/roku/sports, as on the Sports page; asked beside Home's other rows, not after them.

GAMES_TITLE = "Games"
GAMES_SUB = "Your teams first, then today's games"
GAMES_MAX = 16  # cards in the row: a Pi 3 draws a handful of logos at a time
GAMES_WAIT = 8  # seconds Home waits for the games; without them the row is the Roku answer's games, or none


def zone_shift():
    """Seconds from the box's UTC clock to the person's wall clock (the app's clock, now())."""
    t = time.time() + skew()
    utc = datetime.datetime.fromtimestamp(t, datetime.timezone.utc).replace(tzinfo=None)
    return (now() - utc).total_seconds()


def local(ms, shift=None):
    """A game's start (milliseconds since 1970) as the person's wall-clock time."""
    shift = zone_shift() if shift is None else shift
    return datetime.datetime.fromtimestamp(float(ms) / 1000.0, datetime.timezone.utc).replace(tzinfo=None) + \
        datetime.timedelta(seconds=shift)


def clock12(when):
    return "%d:%02d %s" % (when.hour % 12 or 12, when.minute, "PM" if when.hour >= 12 else "AM")


def home_games(games, today, shift=0.0, limit=GAMES_MAX):
    """Home's Games row: my teams' games today (live, then later, then finished), then every other game live or
    starting later today, live first (close games first), each group by start time."""
    import mc_sports as S

    def day(g):
        return local(g["start"], shift).date() if g.get("start") else None

    def rank(g):
        state = {"in": 0, "pre": 1, "post": 2}.get(g.get("state"), 3)
        return (state, 0 if S.close_game(g) else 1, g.get("start") or 0)

    mine = [g for g in games if g.get("mine") and (g.get("state") == "in" or day(g) == today)]
    others = [g for g in games if not g.get("mine") and (g.get("state") == "in" or (g.get("state") == "pre" and day(g) == today))]
    return (sorted(mine, key=rank) + sorted(others, key=rank))[:limit]


def game_tag(game, shift=0.0, today=None):
    """The card's corner: CLOSE GAME, LIVE, FINAL, or the start by the app's clock ("7:00 PM", "SUN 1:00 PM")."""
    import mc_sports as S
    if game.get("state") != "pre" or not game.get("start"):
        return S.tag(game)
    when = local(game["start"], shift)
    if today is not None and when.date() != today:
        return "%s %s" % (when.strftime("%a").upper(), clock12(when))
    return clock12(when)


def game_strip(game):
    """The line at the card's foot: "Jets at Dolphins · CBS 10" before and after, "Q3 4:12 · ESPN" while live."""
    import mc_sports as S
    chans = game.get("channels") or []
    where = S.channel_name(chans[0].get("name")) if chans else (game.get("networks") or [""])[0]
    first = (game.get("detail") or "LIVE") if game.get("state") == "in" else (game.get("title") or S.title(game))
    name = game.get("title") or S.title(game)
    if name and where.endswith(S.DOT + name):
        where = where[:-len(S.DOT + name)]  # a league channel named for its game ("NBA 03 · Heat at Celtics")
    if game.get("state") == "post":
        first = "Final" + S.DOT + first
        where = ""
    return S.DOT.join(p for p in [first, where] if p)


def game_card(game, shift=0.0, today=None):
    """A Games card: the Sports page's team-colour card (mc_sports_page.card) as Home draws it."""
    import mc_sports_page
    li = mc_sports_page.card(game, "home")
    mine = bool(game.get("mine"))
    li.setProperties({"kind": "game", "shape": "game", "tag": game_tag(game, shift, today), "pin": "MY TEAM" if mine else "",
                      "league": "" if mine else (game.get("leagueLabel") or ""), "status": game_strip(game), "where": "",
                      "ball": "",  # no football field drawings anywhere (owner, Nov 26)
                      "plot": L.matchup(game), "meta": L.DOT.join(p for p in [game.get("leagueLabel", ""), game_tag(game, shift, today)] if p)})
    return li


class Ask(object):
    """One question to the server asked on its own thread while Home asks the rest (inline in tests)."""

    def __init__(self, job):
        self.value, self.error, self.done = None, None, threading.Event()

        def run():
            try:
                self.value = job()
            except Exception as e:  # handed to whoever waits
                self.error = e
            finally:
                self.done.set()
        later(run)

    def result(self, wait):
        if not self.done.wait(wait):
            raise ServerError("no answer in %d s" % wait)
        if self.error is not None:
            raise self.error
        return self.value


def ask_games(api):
    import mc_sports_page
    return Ask(lambda: mc_sports_page.load(api))


def games_row(asked, fallback=None):
    """(title, [cards], {id: game}) for Home's Games row. fallback: the /api/roku/home "teams" row, used when the
    games couldn't be read in time (those cards may lack logos until the server is updated)."""
    import mc_app
    try:
        games, _ = asked.result(GAMES_WAIT)
    except Exception as e:
        V.log("games row: %s" % type(e).__name__)
        games = None
    if games is not None:
        today = now().date()
        shift = zone_shift()
        chosen = home_games(games, today, shift)
        return GAMES_TITLE, [game_card(g, shift, today) for g in chosen], dict((str(g.get("id")), g) for g in chosen)
    items = (fallback or {}).get("items") or []
    return GAMES_TITLE, [mc_app.team_card(g) for g in items], {}


# ---- the featured title, full screen (0.4.9.6) -------------------------------------------------------------------------
# "•••" on the featured poster (the plan 8.3, item 7): the poster full screen, "FEATURED · 1 OF 6", the logo, the facts,
# the whole description, then Play now (plays at once from the best version, or resumes and says Resume), Show options
# (the title's page: versions, seasons and episodes, More like this) and + My List. Back returns to Home with the
# highlight where it was. Window: mediacenter-featured.xml (kodi/tools/home_windows.py).

PLAY_NOW, OPTIONS, MY_LIST = 301, 302, 303
BACK_KEYS = (9, 10, 92, 247)


def featured_facts(t, meta=None):
    """ "2025 · PG-13 · 2h 4m · IMDb 7.4 · Drama, Thriller" (a show: "2011 · TV-MA · 8 seasons · IMDb 9.2 · Drama")."""
    m = meta if isinstance(meta, dict) else {}
    parts = []
    year = str(t.get("year") or m.get("year") or "")[:4]
    if year.isdigit():
        parts.append(year)
    cert = str(m.get("certification") or t.get("certification") or "")
    if cert:
        parts.append(cert)
    if t.get("type") == "series":
        seasons = len(t.get("seasonList") or [])
        if seasons:
            parts.append("1 season" if seasons == 1 else "%d seasons" % seasons)
    else:
        try:
            runtime = int(t.get("runtime") or m.get("runtime") or 0)
        except (TypeError, ValueError):
            runtime = 0
        if runtime > 0:
            h, mins = divmod(runtime, 60)
            parts.append("%dh %dm" % (h, mins) if h else "%dm" % mins)
    rating = str(m.get("imdbRating") or t.get("rating") or "")
    if rating and rating not in ("0", "0.0", "N/A"):
        parts.append("IMDb " + rating)
    genres = []
    for g in m.get("genres") or []:
        name = g.get("name") if isinstance(g, dict) else g
        if name and str(name) not in genres:
            genres.append(str(name))
    if genres:
        parts.append(", ".join(genres[:2]))
    return L.DOT.join(parts)


def play_label(api, t, seasons=None):
    """(label, season, episode) for Play now: a film left part-way says Resume; a show resumes the episode left
    part-way ("Resume S1 E2"), else plays the next one."""
    import mc_player as P
    try:
        hist = (api.get("/api/history", limit=300) or {}).get("items") or []
    except (ServerError, SignedOut, OSError):
        hist = []
    try:
        if t.get("type") == "series":
            label, s, e, resume = P.play_target(hist, t["tmdb"], seasons or [1])
            return (label if resume else "Play now"), s, e
        row = next((h for h in hist if h.get("itemId") == L.history_key("movie", t["tmdb"])), None)
        part = bool(row) and not row.get("finished") and float(row.get("position") or 0) >= 30
        return ("Resume" if part else "Play now"), None, None
    except (TypeError, ValueError, KeyError, AttributeError):
        return "Play now", (1 if t.get("type") == "series" else None), (1 if t.get("type") == "series" else None)


class FeaturedPage(xbmcgui.WindowXMLDialog):
    @classmethod
    def open(cls, api, featured):
        import mc_pages as pages
        t = featured.current() if featured is not None else None
        if t is None:
            return
        w = cls("mediacenter-featured.xml", V.HERE, "Default", "1080i")
        w.api, w.t = api, dict(t)
        w.at, w.count = featured.at % len(featured.titles), len(featured.titles)
        w.logo = featured.logos.get(t["tmdb"], "")
        pages.modal(w)
        del w

    def onInit(self):
        t = self.t
        self.target = ("Play now", 1 if t["type"] == "series" else None, 1 if t["type"] == "series" else None)
        self.pins = None  # My List, once read (details)
        self.setProperty("eyebrow", "FEATURED%s%d OF %d" % (L.DOT, self.at + 1, self.count))
        self.setProperty("title", t.get("name", ""))
        self.setProperty("fanart", t.get("backdrop", ""))
        self.setProperty("plot", t.get("overview", ""))
        self.setProperty("facts", featured_facts(t))
        self.setProperty("play", self.target[0])
        self.setProperty("listlabel", "+ My List")
        if self.logo:
            self.setProperty("logo", self.logo)
        self.setFocusId(PLAY_NOW)
        later(self.details)  # what the poster didn't carry; the page is already up

    def details(self):
        t = self.t
        meta = {}
        try:
            full = L.title_of(dict((self.api.get("/api/roku/title", type=t["type"], tmdb=t["tmdb"]) or {}).get("title") or {},
                                   type=t["type"], tmdb=t["tmdb"]))
            if full:
                for k in ("runtime", "overview", "seasonList", "rating", "certification"):
                    if full.get(k) and not t.get(k):
                        t[k] = full[k]
                if len(full.get("overview") or "") > len(t.get("overview") or ""):
                    t["overview"] = full["overview"]
        except (ServerError, SignedOut, OSError, ValueError):
            pass
        try:
            meta = self.api.get("/meta/title", type=t["type"], tmdb=t["tmdb"]) or {}
        except (ServerError, SignedOut, OSError, ValueError):
            meta = {}
        self.setProperty("facts", featured_facts(t, meta))
        self.setProperty("plot", t.get("overview", ""))
        if not self.logo:
            logo = L.picture(meta.get("logo") or "", "w500") if isinstance(meta, dict) else ""
            if logo:
                self.logo = logo
                self.setProperty("logo", logo)
        self.target = play_label(self.api, t, [int(n) for n in t.get("seasonList") or [] if str(n).isdigit()] or [1])
        self.setProperty("play", self.target[0])
        try:
            self.pins = V.my_list(self.api) or []
        except (ServerError, SignedOut, OSError, ValueError):
            self.pins = None
        self.list_label()

    def list_label(self):
        self.setProperty("listlabel", "In My List" if L.is_pinned(self.pins or [], self.t) else "+ My List")

    def onClick(self, control_id):
        import mc_player as P
        t = self.t
        if control_id == PLAY_NOW:
            # Plays straight away from the best version (the plan: Play now); Show options is where versions are.
            P.play_title(self.api, t["type"], t["tmdb"], self.target[1], self.target[2], choose=False,
                         art={"name": t.get("name", ""), "backdrop": t.get("backdrop", ""), "logo": self.logo})
            import mc_app
            mc_app.refocus(self, PLAY_NOW)
            self.target = play_label(self.api, t, [int(n) for n in t.get("seasonList") or [] if str(n).isdigit()] or [1])
            return self.setProperty("play", self.target[0])
        if control_id == OPTIONS:
            import mc_app
            return mc_app.TitlePage.open(self.api, t["type"], t["tmdb"])
        if control_id == MY_LIST:
            if self.pins is None:  # not read yet: never write a list that would drop the rest of My List
                try:
                    self.pins = V.my_list(self.api) or []
                except (ServerError, SignedOut, OSError, ValueError):
                    return V.notify("Couldn't change My List right now.")
            self.pins, pinned = L.toggle_pin(self.pins, t)
            try:
                self.api.call("PUT", "/api/prefs", body={"prefs": {"myList": {"value": self.pins, "updatedAt": int(time.time() * 1000)}}})
                V.notify("Added to My List" if pinned else "Removed from My List")
            except (ServerError, SignedOut, OSError):
                V.notify("Couldn't change My List right now.")
            return self.list_label()

    def onAction(self, action):
        if action.getId() in BACK_KEYS:
            self.close()
