# mediaCENTER for Kodi: the pages that are open, and "go to" from outside the app (the iPhone remote's TV button).
#
# Every page of the app opens through modal() below, so the app knows which pages are open, top last. A press of the
# TV button runs script.mediacenter with open=guide while the app is already open; the launcher can't reach this
# Python, so it leaves the wish in a Home window property (WANT) and the app's own follower thread acts on it:
#   - the pages above the target close (a playing player hands its picture over instead of stopping: HANDOFF),
#   - nothing new opens on the way down, except the target,
#   - when the last page has closed, the target opens; with no page open at all, the follower opens it itself.
# The Guide picks up the handed-over picture in its mini player. Kept free of Kodi windows so it can be tested.
# 0.4.9.6: the TV button's one press asks for open=menu (two quick presses are open=guide, timed by the remote,
# service.mediacenter.remote tvcontrol.TvButton). The menu opens over the page that is showing, which stays open, and
# what plays carries on behind it (show_menu). The menu itself is OPENERS["menu"], set by the app's menu.

import threading

WANT = "mediacenter.goto"  # Window(Home) property set by script.mediacenter (default.py) for a running app
MENU = "menu"
PAGES = ("guide", MENU)  # what open=<page> may ask for
# 0.4.9.6: the left menu goes to any of its places from any page with it (mc_menu.Rail), the same way.
INSIDE = ("home", "movies", "shows", "guide", "sports", "search", "library", "settings")

STACK = []  # open pages, top last; each may have goto_name ("guide") and goto_close() (how it closes for a go-to)
GOTO = {"to": None}
OPENERS = {}  # page name -> function that opens it (set by mc_app once the app is up)
HANDOFF = {}  # a picture handed over by a closing player: playback, name, sub, live, channel, carry
LOCK = threading.Lock()


def name_of(page):
    return getattr(page, "goto_name", None)


def close_all():
    """Close modal pages from the top down when Kodi shuts down."""
    with LOCK:
        GOTO["to"] = None
        opened = list(STACK)
    for page in reversed(opened):
        try:
            page.close()
        except RuntimeError:
            pass


def modal(w):
    """Open a page (w.doModal) and keep track of it. While a go-to is under way only its target opens."""
    want = GOTO["to"]
    if want and name_of(w) != want:
        return False
    with LOCK:
        if want and name_of(w) == want:
            GOTO["to"] = None  # arrived
        STACK.append(w)
    try:
        w.doModal()
    finally:
        with LOCK:
            for i in range(len(STACK) - 1, -1, -1):
                if STACK[i] is w:
                    del STACK[i]
                    break
            want = GOTO["to"]
            if want and STACK and name_of(STACK[-1]) == want:
                GOTO["to"] = None  # back down to it: arrived
                want = None
            last = not STACK
    if want and last:
        arrive()
    return True


def arrive():
    """Open the go-to's target (it clears GOTO when it opens)."""
    opener = OPENERS.get(GOTO["to"])
    if opener is None:
        GOTO["to"] = None
        return
    try:
        opener()
    finally:
        GOTO["to"] = None


def go(page, allowed=True, close_dialogs=None, spawn=None, inside=False):
    """Go to a page from wherever the app is. allowed: False drops the wish (signed out, first-run setup). inside: asked
    from the app's own menu, which may name any of its places (INSIDE); the launcher may name only PAGES.
    Returns what was done: 'there', 'closing', 'opening' or 'ignored'."""
    if page not in (INSIDE if inside else PAGES) or not allowed or page not in OPENERS:
        return "ignored"
    with LOCK:
        pages = list(STACK)
        if any(getattr(p, "goto_blocks", False) for p in pages):
            return "ignored"  # first-run setup and sign-in finish first
        names = [name_of(p) for p in pages]
        if pages and names[-1] == page:
            return "there"
        GOTO["to"] = page
    if close_dialogs:
        close_dialogs()
    keep = len(names) - 1 - names[::-1].index(page) if page in names else -1
    above = pages[keep + 1:]
    if not above:
        (spawn or _spawn)(arrive)
        return "opening"
    for p in reversed(above):
        closer = getattr(p, "goto_close", None)
        try:
            (closer or p.close)()
        except RuntimeError:
            pass
    return "closing"


def show_menu(allowed=True, fallback=None, spawn=None):
    """The TV button's one press: the menu over whatever shows (OPENERS["menu"], run on its own thread so the follower
    keeps listening), or, with the menu already on top, the menu closes. Until the app has a menu to open, fallback()
    runs instead (the Guide, the single press before 0.4.9.6). Returns 'menu', 'closed', 'fallback' or 'ignored'."""
    if not allowed:
        return "ignored"
    with LOCK:
        pages = list(STACK)
        if any(getattr(p, "goto_blocks", False) for p in pages):
            return "ignored"  # first-run setup and sign-in finish first
        top = pages[-1] if pages else None
    if top is not None and name_of(top) == MENU:
        try:
            top.close()
        except RuntimeError:
            pass
        return "closed"
    opener = OPENERS.get(MENU)
    if opener is None:
        if fallback:
            fallback()
        return "fallback"
    (spawn or _spawn)(opener)
    return "menu"


def _spawn(fn):
    t = threading.Thread(target=fn)
    t.daemon = True
    t.start()


def hand_over(**picture):
    HANDOFF.clear()
    HANDOFF.update(picture)


def take_handoff():
    if not HANDOFF.get("playback"):
        HANDOFF.clear()
        return None
    picture = dict(HANDOFF)
    HANDOFF.clear()
    return picture


def wanted(window):
    """The page the launcher asked for (and forget the ask)."""
    page = window.getProperty(WANT)
    if page:
        window.clearProperty(WANT)
    return page if page in PAGES else ""


def follow(window, act, running, wait, shutdown=None):
    """The follower thread: while the app runs, act on the launcher's asks. wait(seconds) returns True to stop."""
    while running():
        page = wanted(window)
        if page:
            act(page)
        if wait(0.25):
            if shutdown:
                shutdown()
            return
