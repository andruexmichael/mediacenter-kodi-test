# mediaCENTER for Kodi: the hold menus (0.4.9.6; the design plan's "Hold menus", PI 3 App Design pages 6-7, items 13
# to 16). Holding OK on a card, or the menu key, opens a sheet over the dimmed page (mediacenter-hold.xml, written by
# kodi/tools/hold_windows.py): the bigger picture with its progress line, the full names, the facts, the whole
# description, then what can be done.
#
# How a hold reaches the app: Kodi's own keymaps turn a held OK into the menu key (ContextMenu, action 117): a keyboard's
# held Enter (<return mod="longpress">), a game controller's held A (<a holdtime="500">), and the menu key itself (a
# TV remote's Menu or Title key, a keyboard's C or Menu key, a controller's X). Nothing here waits on a timer, so a plain
# OK is never slower. Remotes that send no hold and have no menu key (the iPhone's Control Center remote) can't open it.
#
#   Continue Watching (Home, Library's In Progress): Resume, Start from the beginning, Go to show / Movie details,
#     Remove from Continue Watching (no "are you sure"; the account's history, so every device).
#   An episode on a show's page: the still, the full name, runtime and air date, the whole description, then Play
#     episode, or Resume and Start from the beginning (the website's episode sheet, web-v27/js/views/episode-sheet.js).

import datetime

import xbmc
import xbmcgui

import mc_logic as L
import mc_views as V
import mc_pages as pages
from mc_api import ServerError, SignedOut

ACTIONS, PICTURE = 50, 60
BACK = (9, 10, 92, 247)
FOOT = "Back closes."
NO_PLOT = "No description for this episode yet."  # the website's words
MONTHS_LONG = ("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November",
               "December")


# ---- the words (tested off the box) -----------------------------------------------------------------------------------

def long_date(iso):
    """ "2011-04-17" -> "April 17, 2011", as the website's episode sheet; anything else -> ""."""
    try:
        d = datetime.date(*(int(p) for p in str(iso or "")[:10].split("-")))
    except (TypeError, ValueError):
        return ""
    return "%s %d, %d" % (MONTHS_LONG[d.month - 1], d.day, d.year)


def minutes_left(seconds):
    """ "58 min left" under an hour (the design's words), "1h 20m left" over it (the website's cards)."""
    m = int(max(0, seconds) // 60)
    return "%d min left" % max(1, m) if m < 60 else L.time_left(seconds)


def episode_code(season, episode, name=""):
    """ "S1 · E3 · Lord Snow" """
    return L.DOT.join(p for p in ["S%s" % season, "E%s" % episode, name] if p)


def runtime_text(minutes):
    try:
        m = int(minutes or 0)
    except (TypeError, ValueError):
        return ""
    return "%d min" % m if m > 0 else ""


def find_episode(api, tmdb, season, episode):
    """One episode's details (/meta/episodes, else /api/roku/episodes), or {}."""
    for path in ("/meta/episodes", "/api/roku/episodes"):
        try:
            eps = (api.get(path, tmdb=tmdb, season=season) or {}).get("episodes") or []
        except (ServerError, SignedOut, OSError, ValueError):
            eps = []
        for e in eps:
            if isinstance(e, dict) and str(e.get("n")) == str(episode):
                return e
    return {}


def history_row(api, item_id):
    """The account's history row for one movie or episode, or None (it can't be read: None too)."""
    try:
        rows = (api.get("/api/history", limit=300) or {}).get("items") or []
    except (ServerError, SignedOut, OSError):
        return None
    return next((h for h in rows if isinstance(h, dict) and h.get("itemId") == item_id), None)


def part_way(row):
    """Seconds to resume from, or 0 (finished, not started, or under 30 seconds: the players' rule)."""
    if not row or row.get("finished"):
        return 0
    pos = float(row.get("position") or 0)
    return pos if pos >= 30 else 0


def continue_sheet(api, li):
    """What the Continue Watching hold shows for a card (mc_app.continue_card). The details the card doesn't carry (the
    description, runtime, air date, a bigger picture) are asked for here; the sheet still opens without them."""
    series = li.getProperty("type") == "series"
    tmdb = li.getProperty("tmdb")
    pos, dur = float(li.getProperty("position") or 0), float(li.getProperty("duration") or 0)
    left = minutes_left(dur - pos) if dur > pos else ""
    picture = li.getArt("landscape") or li.getArt("thumb") or li.getArt("poster")
    if series:
        season, episode = li.getProperty("season") or "1", li.getProperty("episode") or "1"
        e = find_episode(api, tmdb, season, episode)
        name = e.get("name") or li.getProperty("episodeName")
        facts = [runtime_text(e.get("runtime")), str(e.get("air") or e.get("air_date") or "")[:10], left]
        sheet = {"eyebrow": li.getLabel().upper(), "title": episode_code(season, episode, name), "plot": e.get("overview") or "",
                 "picture": L.picture(e.get("still"), "w780") if e.get("still") else picture}
        go = {"key": "show", "label": u"≡  Go to show", "label2": "seasons and episodes"}
    else:
        try:
            t = L.title_of(dict((api.get("/api/roku/title", type="movie", tmdb=tmdb) or {}).get("title") or {}, type="movie", tmdb=tmdb)) or {}
        except (ServerError, SignedOut, OSError, ValueError):
            t = {}
        runtime = t.get("runtime") or 0
        facts = [t.get("year", ""), ("%dh %dm" % divmod(runtime, 60) if runtime >= 60 else runtime_text(runtime)), left]
        sheet = {"eyebrow": "CONTINUE WATCHING", "title": li.getLabel(), "plot": t.get("overview", ""),
                 "picture": t.get("backdrop") or picture}
        go = {"key": "details", "label": u"≡  Movie details"}
    sheet.update(facts=L.DOT.join(p for p in facts if p), progress=(pos, dur) if pos and dur else None, actions=[
        {"key": "resume", "label": u"▶  Resume", "label2": ("from %s" % L.clock_text(pos)) if pos else ""},
        {"key": "start", "label": u"↩  Start from the beginning"},
        go,
        {"key": "remove", "label": u"✕  Remove from Continue Watching", "danger": True},
    ])
    return sheet


def episode_sheet(show, season, e, row=None, today=None):
    """What holding an episode on a show's page shows. e: the episode as /meta/episodes gives it; row: its history row."""
    n = e.get("n")
    air = str(e.get("air") or e.get("air_date") or "")[:10]
    later = bool(air) and air > (today or datetime.date.today().isoformat())
    facts = [runtime_text(e.get("runtime")), long_date(air)] + (["Not out yet"] if later else [])
    pos = part_way(row)
    dur = float((row or {}).get("duration") or 0)
    if later:
        actions = [{"key": "later", "label": "Not out yet", "off": True}]
    elif pos:
        actions = [{"key": "resume", "label": u"▶  Resume", "label2": "from %s" % L.clock_text(pos)},
                   {"key": "start", "label": u"↩  Start from the beginning"}]
    else:
        actions = [{"key": "play", "label": u"▶  Play episode"}]
    return {"eyebrow": (show or "").upper(), "title": episode_code(season, n, e.get("name") or "Episode %s" % n),
            "facts": L.DOT.join(p for p in facts if p), "plot": e.get("overview") or NO_PLOT,
            "picture": L.picture(e.get("still"), "w780") if e.get("still") else "", "actions": actions,
            "progress": (pos, dur) if pos and dur > pos else None}


def busy(on):
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)" if on else "Dialog.Close(busydialognocancel)")


# ---- the sheet --------------------------------------------------------------------------------------------------------

class HoldPage(xbmcgui.WindowXMLDialog):
    """Opened with ask(sheet); returns the chosen action's key, or None (Back)."""

    @classmethod
    def ask(cls, sheet):
        w = cls("mediacenter-hold.xml", V.HERE, "Default", "1080i")
        w.sheet, w.picked = sheet, None
        pages.modal(w)
        picked = w.picked
        del w
        return picked

    def onInit(self):
        s = self.sheet
        for k in ("eyebrow", "title", "facts", "plot"):
            self.setProperty(k, s.get(k) or "")
        self.setProperty("foot", FOOT)
        if s.get("progress"):
            self.setProperty("progress", "1")
        else:
            self.clearProperty("progress")
        picture = self.getControl(PICTURE)
        picture.reset()
        picture.addItem(self.picture_item(s))
        actions = self.getControl(ACTIONS)
        actions.reset()
        for a in s.get("actions") or []:
            row = xbmcgui.ListItem(a.get("label", ""), a.get("label2", ""))
            row.setProperties({"danger": "1" if a.get("danger") else "", "off": "1" if a.get("off") else ""})
            actions.addItem(row)
        actions.selectItem(0)
        self.setFocusId(ACTIONS)

    @staticmethod
    def picture_item(s):
        """The bigger picture, with the progress line under it read from ListItem.PercentPlayed (a new item: the card's own
        stays as it is on its row)."""
        li = xbmcgui.ListItem(s.get("title") or "")
        if s.get("picture"):
            li.setArt({"thumb": s["picture"]})
        if s.get("progress"):
            V.set_info(li, {"title": s.get("title") or "", "mediatype": "video"}, s["progress"])
        return li

    def onClick(self, cid):
        if cid != ACTIONS:
            return
        actions = self.sheet.get("actions") or []
        pos = self.getControl(ACTIONS).getSelectedPosition()
        if 0 <= pos < len(actions) and not actions[pos].get("off"):
            self.picked = actions[pos]["key"]
            self.close()

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()


# ---- what each choice does ----------------------------------------------------------------------------------------------

def continue_hold(api, li, ask=None):
    """Hold (or the menu key) on a Continue Watching card. Returns "removed" when it left Continue Watching, "played"
    or "opened" when something played or a page opened (so Continue Watching is asked for again), else None."""
    import mc_player as P
    ask = ask or HoldPage.ask
    busy(True)
    try:
        sheet = continue_sheet(api, li)
    finally:
        busy(False)
    key = ask(sheet)
    series = li.getProperty("type") == "series"
    tmdb = li.getProperty("tmdb")
    season = int(li.getProperty("season") or 1) if series else None
    episode = int(li.getProperty("episode") or 1) if series else None
    art = {"name": li.getLabel(), "backdrop": li.getArt("fanart") or li.getArt("landscape")}
    if key in ("resume", "start"):
        P.play_title(api, "series" if series else "movie", tmdb, season, episode, art=art,
                     resume=key == "resume", fresh=key == "start")
        return "played"
    if key in ("show", "details"):
        import mc_app
        mc_app.TitlePage.open(api, "series" if series else "movie", tmdb)
        return "opened"
    if key == "remove":
        import mc_watching
        try:
            mc_watching.remove(api, li.getProperty("itemId"), rows=[])
        except SignedOut:
            V.notify("Your session ended. Sign in again from Settings.")
            return None
        except (ServerError, OSError):
            V.notify("Could not remove saved progress. Please try again.")
            return None
        V.notify("Removed from Continue Watching")
        return "removed"
    return None


def take_out(control):
    """A removed card leaves its row at once; the highlight moves to the next card (the last card: the one before).
    Returns how many cards are left."""
    pos = control.getSelectedPosition()
    control.removeItem(pos)
    left = control.size()
    if left:
        control.selectItem(min(pos, left - 1))
    return left
