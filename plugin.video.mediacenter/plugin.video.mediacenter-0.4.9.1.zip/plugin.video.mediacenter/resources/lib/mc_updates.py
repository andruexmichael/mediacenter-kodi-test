"""Trusted update feed, bounded downloads and staged, rollback-capable installation.

The worker is copied to the profile before RunScript so replacing the add-on cannot remove its running code.
Account/profile data is never part of an update. No shell commands or remote installer scripts are run.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import ssl
import stat
import tempfile
import time
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

FEEDS = {
    'stable': 'https://watch.littlebirdtampa.com/kodi/',
    'test': 'https://raw.githubusercontent.com/andruexmichael/mediacenter-kodi-test/main/'
}
APP = 'plugin.video.mediacenter'
REMOTE = 'service.mediacenter.remote'
ALLOWED = (APP, 'script.mediacenter', 'skin.mediacenter', 'repository.mediacenter', 'repository.mediacenter.test', REMOTE)
NEEDED = (REMOTE,)  # parts the app needs: added by an update when they're not here yet (the app requires them)
LIMIT = 60 * 1024 * 1024
# Certificate lists to try when Python's own can't be found (LibreELEC keeps its list in /etc/ssl).
CA_FILES = ('/etc/ssl/cacert.pem', '/etc/ssl/certs/ca-certificates.crt', '/etc/pki/tls/certs/ca-bundle.crt')


def version(value):
    """1.2.3, or 1.2.3.4 for a quick fix between two releases (0.4.7.1 comes after 0.4.7 and before 0.4.8)."""
    if not re.fullmatch(r'\d{1,4}(\.\d{1,4}){2,3}', value or ''):
        raise ValueError('Invalid version')
    parts = tuple(map(int, value.split('.')))
    return parts + (0,) * (4 - len(parts))


def log(text):
    try:
        import xbmc
        xbmc.log('mediaCENTER update: %s' % text, xbmc.LOGINFO)
    except Exception:
        pass


def agent():
    """The name downloads go out under: "mediaCENTER-Kodi/0.4.9". The stable list (the website) refuses Python's own
    "Python-urllib" with HTTP 403 (owner's Pi, 2026-11-26) and answers when the app names itself."""
    ver = ''
    try:
        ver = ET.parse(str(Path(__file__).resolve().parents[2] / 'addon.xml')).getroot().get('version') or ''
    except (OSError, ET.ParseError, IndexError):
        pass
    if not ver:  # the installer runs from a copy in the profile folder: ask Kodi
        try:
            import xbmcaddon
            ver = xbmcaddon.Addon(APP).getAddonInfo('version') or ''
        except Exception:
            ver = ''
    return 'mediaCENTER-Kodi/%s' % ver if re.fullmatch(r'[\d.]{1,20}', ver) else 'mediaCENTER-Kodi'


def fetch_python(url, limit, context=None):
    request = urllib.request.Request(url, headers={'User-Agent': agent(), 'Accept': '*/*'})
    with urllib.request.urlopen(request, timeout=30, context=context) as response:
        if not any(response.geturl().startswith(base) for base in FEEDS.values()):
            raise ValueError('Untrusted redirect')
        return response.read(limit + 1)


def fetch_kodi(url, limit):
    """Kodi's own downloader, the one that installs add-ons: it works on boxes where Python can't check certificates."""
    import xbmcvfs
    f = xbmcvfs.File(url)
    try:
        data = bytes(f.readBytes(limit + 1))
    finally:
        f.close()
    if not data:
        raise OSError('Nothing downloaded')
    return data


def download(url, limit=LIMIT, kodi=fetch_kodi):
    """Python's downloader first, then with the box's own certificate list, then Kodi's downloader. Only the update
    addresses are ever asked for, and the size limit, the checksum and the package checks hold whichever one answers."""
    if not any(url.startswith(base) for base in FEEDS.values()):
        raise ValueError('Untrusted update address')
    try:
        data = fetch_python(url, limit)
    except ValueError:
        raise
    except Exception as first:
        data = None
        log('Python download failed (%s), trying the box\'s certificates' % type(first).__name__)
        for ca in CA_FILES:
            if not os.path.isfile(ca):
                continue
            try:
                data = fetch_python(url, limit, ssl.create_default_context(cafile=ca))
                break
            except ValueError:
                raise
            except Exception:
                pass
        if data is None:
            try:
                data = kodi(url, limit)
            except ImportError:
                raise first
            except ValueError:
                raise
            except Exception as e:
                log('Kodi download failed too (%s)' % type(e).__name__)
                raise first
    if len(data) > limit:
        raise ValueError('Update too large')
    return data


def waiting(running, have):
    """The newer version that's installed but not running yet (mediaCENTER only needs a restart), or ''."""
    on_disk = have.get(APP) if isinstance(have, dict) else have
    try:
        return on_disk if running and on_disk and version(on_disk) > version(running) else ''
    except ValueError:
        return ''


def installed(addons):
    """{add-on id: version} of our add-ons in Kodi's add-on folder."""
    out = {}
    for ident in ALLOWED:
        manifest = Path(addons) / ident / 'addon.xml'
        try:
            ver = ET.parse(str(manifest)).getroot().get('version')
            version(ver)
            out[ident] = ver
        except (OSError, ET.ParseError, ValueError):
            pass
    return out


def default_channel(have):
    """The update list this box was set up from: Test when the test repository is installed, otherwise Stable."""
    return 'test' if 'repository.mediacenter.test' in have and 'repository.mediacenter' not in have else 'stable'


def check(channel, have, fetch=download):
    """What the update list offers: {channel, version, available, notes, packages}. Add-ons that are installed here and
    newer in the list are in packages (the skin only goes where the skin is, so a Kodi 20 box never gets it), and so are
    the parts the app needs that aren't here yet (the iPhone remote, the first time)."""
    if isinstance(have, str):
        have = {APP: have}
    base = FEEDS[channel]
    xml = fetch(base + 'addons.xml', 1024 * 1024)
    checksum = fetch(base + 'addons.xml.md5', 128).decode().strip()
    if hashlib.md5(xml).hexdigest() != checksum:
        raise ValueError('Update list is changing; try again')
    root = ET.fromstring(xml)
    if root.tag != 'addons':
        raise ValueError('Invalid update list')
    listed = {}
    for addon in root:
        ident = addon.get('id')
        if ident not in ALLOWED:
            continue
        if ident in listed:
            raise ValueError('Duplicate add-on')
        ver = addon.get('version')
        version(ver)
        listed[ident] = ver
    if APP not in listed or 'script.mediacenter' not in listed:
        raise ValueError('Incomplete update')
    packages = [{'id': ident, 'version': ver} for ident, ver in listed.items()
                if (ident in have and version(ver) > version(have[ident])) or (ident in NEEDED and ident not in have)]
    notes = root.find("./addon[@id='%s']/extension/news" % APP)
    return {'channel': channel, 'version': listed[APP], 'available': bool(packages),
            'notes': (notes.text or '').strip() if notes is not None and (notes.text or '').strip()
            else 'Improvements to mediaCENTER. Your account and settings are kept.',
            'packages': packages}


def extract(data, folder, ident, ver):
    import io
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        entries = archive.infolist()
        if sum(e.file_size for e in entries) > 150 * 1024 * 1024 or len(entries) > 6000:
            raise ValueError('Expanded update too large')
        for e in entries:
            parts = e.filename.split('/')
            if parts[0] != ident or '..' in parts or '\\' in e.filename or any(p.startswith('.') for p in parts if p):
                raise ValueError('Unsafe update path')
            mode = e.external_attr >> 16
            if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)):
                raise ValueError('Unsafe update entry')
            if '/resources/data/sample/' in e.filename or e.filename.endswith('/session.json'):
                raise ValueError('Unexpected account or sample data')
        archive.extractall(folder)
    manifest = ET.parse(Path(folder) / ident / 'addon.xml').getroot()
    if manifest.get('id') != ident or manifest.get('version') != ver:
        raise ValueError('Package does not match update list')


def install(plan, addons, fetch=download, progress=lambda text: None, before_swap=lambda: None, after_swap=lambda: None):
    """Download and validate everything first; preserve original folders until all replacements succeed."""
    channel = plan['channel']
    base = FEEDS[channel]
    addons = Path(addons)
    if not plan['packages'] or len(plan['packages']) > len(ALLOWED) or len({p['id'] for p in plan['packages']}) != len(plan['packages']):
        raise ValueError('Invalid package list')
    staged = Path(tempfile.mkdtemp(prefix='.mediacenter-update-', dir=str(addons)))
    changed = []
    try:
        new, backup = staged / 'new', staged / 'backup'
        new.mkdir(); backup.mkdir()
        for package in plan['packages']:
            ident, ver = package['id'], package['version']
            if ident not in ALLOWED:
                raise ValueError('Unexpected add-on')
            version(ver)
            current = addons / ident / 'addon.xml'
            if current.exists() and version(ET.parse(str(current)).getroot().get('version')) >= version(ver):
                raise ValueError('Refusing to downgrade or reinstall an installed component')
            progress('Downloading mediaCENTER components…')
            extract(fetch(base + ident + '/' + ident + '-' + ver + '.zip'), new, ident, ver)
        before_swap()
        progress('Installing update. Keep the device powered on.')
        for package in plan['packages']:
            ident = package['id']
            target, saved = addons / ident, backup / ident
            existed = target.exists()
            if existed:
                os.replace(target, saved)
            changed.append((ident, existed))
            os.replace(new / ident, target)
        after_swap()
    except Exception:
        for ident, existed in reversed(changed):
            target = addons / ident
            if target.exists():
                shutil.rmtree(target)
            if existed:
                os.replace(staged / 'backup' / ident, target)
        raise
    finally:
        shutil.rmtree(staged, ignore_errors=True)


def add_needed(channel, addons, fetch=download, after_swap=lambda: None):
    """Add the parts the app needs that aren't here yet (the iPhone remote on a box that updated from 0.4.6, whose
    updater didn't know it), quietly and without touching the parts that are here. Returns the ids added."""
    plan = check(channel, installed(addons), fetch)
    plan['packages'] = [p for p in plan['packages'] if p['id'] in NEEDED and not (Path(addons) / p['id']).exists()]
    if not plan['packages']:
        return []
    install(plan, addons, fetch, after_swap=after_swap)
    return [p['id'] for p in plan['packages']]


# ---- updating by itself (0.4.9, owner: "the Pi app must update itself from now on") --------------------------------
# The service looks at the chosen update list soon after start and every few hours. When something newer is listed it
# waits until the box is idle (nothing playing, nobody pressing keys), then hands the plan to the same installer the
# Install button uses (worker(), from a copy in the profile folder), quietly. Every check above still holds, and the
# old version stays if anything fails. A version that failed, or that never came up after its restart, is written
# down and never tried again; a newer one is. Kodi's own add-on updates are not relied on (on the owner's Pi the app
# has an entry in Kodi's update_rules and the remote has no origin repository).

AUTO_FILE = 'auto-update.json'


def _key(package):
    return '%s@%s' % (package['id'], package['version'])


def auto_state(profile):
    try:
        with open(os.path.join(str(profile), AUTO_FILE)) as f:
            state = json.load(f)
        return state if isinstance(state, dict) else {}
    except (OSError, ValueError):
        return {}


def save_auto_state(profile, state):
    os.makedirs(str(profile), exist_ok=True)
    path = os.path.join(str(profile), AUTO_FILE)
    with open(path + '.new', 'w') as f:
        json.dump(state, f)
    os.replace(path + '.new', path)


def remember_failed(profile, packages):
    """Write down packages that could not be installed, so they are never tried again by themselves."""
    state = auto_state(profile)
    failed = [k for k in state.get('failed') or [] if isinstance(k, str)]
    for p in packages:
        if _key(p) not in failed:
            failed.append(_key(p))
    state['failed'] = failed[-50:]
    state.pop('trying', None)
    save_auto_state(profile, state)


class Auto(object):
    """When to look and when to install. now: time.time(); the service checks once a minute."""
    FIRST = 180          # seconds after start before the first look
    EVERY = 6 * 3600     # then a few times a day
    IDLE = 15 * 60       # nobody has pressed a key for this long

    def __init__(self, profile, now=None):
        self.profile = str(profile)
        self.plan = None
        self.next = (time.time() if now is None else now) + self.FIRST

    def settle(self, have):
        """At start: an install that was started last time either came up (all its parts are here at their versions)
        or it did not, and is written down as failed."""
        state = auto_state(self.profile)
        trying = state.get('trying')
        if not isinstance(trying, list):
            return None
        missed = []
        for p in trying:
            try:
                here = have.get(p['id'])
                if not here or version(here) < version(p['version']):
                    missed.append(p)
            except (KeyError, TypeError, ValueError, AttributeError):
                pass
        if missed:
            remember_failed(self.profile, trying)
            log('automatic update did not come up; it will not be tried again')
            return 'failed'
        state.pop('trying', None)
        save_auto_state(self.profile, state)
        return 'done'

    def failed(self):
        return set(auto_state(self.profile).get('failed') or [])

    def due(self, now):
        return now >= self.next

    def look(self, check, now):
        """check(): mc_updates.check for the chosen list. Keeps the plan when there is something new not failed before."""
        self.next = now + self.EVERY
        self.plan = None
        try:
            plan = check()
        except Exception as e:  # never addresses or messages in the log
            log('automatic check failed (%s)' % type(e).__name__)
            return None
        if auto_state(self.profile).get('trying') or not plan.get('available'):
            return None
        bad = self.failed()
        if any(_key(p) in bad for p in plan['packages']):
            log('automatic update skips a version that failed before')
            return None
        self.plan = plan
        return plan

    def ready(self, idle):
        if self.plan is None:
            return None
        if any(_key(p) in self.failed() for p in self.plan['packages']):
            self.plan = None
            return None
        return self.plan if idle() else None

    def start(self, plan):
        """Just before the installer runs: written down, so a box that never comes back with it does not loop."""
        state = auto_state(self.profile)
        state['trying'] = [{'id': p['id'], 'version': p['version']} for p in plan['packages']]
        save_auto_state(self.profile, state)
        self.plan = None


class UpdateDeferred(Exception):
    """The box was used again while an automatic update was downloading."""


def automatic_idle(player):
    import xbmc
    import xbmcgui
    return (not player.isPlaying() and xbmc.getGlobalIdleTime() >= Auto.IDLE and
            (xbmc.getSkinDir() == 'skin.mediacenter' or
             not xbmcgui.Window(10000).getProperty('mediacenter.app.open')))


STOP = 'mediacenter.update.stop'
SERVICE = 'mediacenter.service.running'
RUNNING_APP = 'mediacenter.app.open'


def stopping(window):
    return bool(window.getProperty(STOP))


def quiesce(window, wait, timeout=90, now=time.monotonic):
    """Leave the stop request set until installation finishes. Never replace files under live code.

    Older services have no SERVICE marker; their normal Kodi disable path remains the fallback.
    wait(seconds) returns True when Kodi is shutting down.
    """
    window.setProperty(STOP, '1')
    deadline = now() + timeout
    while window.getProperty(RUNNING_APP) or window.getProperty(SERVICE):
        if now() >= deadline or wait(0.25):
            raise RuntimeError('mediaCENTER is still closing')


def resume(window):
    window.clearProperty(STOP)


def worker(profile):
    import xbmc
    import xbmcgui
    import xbmcvfs
    profile = Path(profile)
    with open(profile / 'update-plan.json') as f:
        plan = json.load(f)
    window = xbmcgui.Window(10000)
    disabled = False
    requested_stop = False
    had_service = bool(window.getProperty(SERVICE))
    quiet = bool(plan.get('quiet'))  # started by the service (automatic update): no dialogs, the box is idle

    class Quiet(object):
        def create(self, *a): pass
        def update(self, *a): pass
        def close(self): pass
    dialog = Quiet() if quiet else xbmcgui.DialogProgress()
    dialog.create('mediaCENTER update', 'Preparing update…')
    def rpc(method, params):
        result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params})))
        if 'error' in result:
            raise RuntimeError('Could not update components')
        return result.get('result')
    def before():
        nonlocal disabled, requested_stop
        if quiet:
            import xbmcaddon
            addon = xbmcaddon.Addon(APP)
            channel = addon.getSetting('update_channel') or default_channel(
                installed(xbmcvfs.translatePath('special://home/addons')))
            if (addon.getSetting('auto_update') == 'false' or channel != plan['channel'] or
                    not automatic_idle(xbmc.Player())):
                raise UpdateDeferred()
        dialog.update(0, 'Closing mediaCENTER before installing…')
        requested_stop = True
        quiesce(window, xbmc.Monitor().waitForAbort)
        disabled = True  # a failed RPC can still have switched the add-on off
        rpc('Addons.SetAddonEnabled', {'addonid': APP, 'enabled': False})
    def after():
        xbmc.executebuiltin('UpdateLocalAddons', True)
        for ident in [p['id'] for p in plan['packages'] if p['id'] in NEEDED]:
            try:  # Kodi keeps a newly copied add-on switched off until it's turned on
                rpc('Addons.SetAddonEnabled', {'addonid': ident, 'enabled': True})
            except RuntimeError:
                pass  # the app still starts; Settings says the remote isn't running
        resume(window)
        rpc('Addons.SetAddonEnabled', {'addonid': APP, 'enabled': True})
    try:
        install(plan, xbmcvfs.translatePath('special://home/addons'),
                progress=lambda text: dialog.update(0, text), before_swap=before, after_swap=after)
        dialog.close()
        if xbmc.getSkinDir() == 'skin.mediacenter':
            xbmc.executebuiltin('RestartApp')  # the box restarts into mediaCENTER with every new part loaded
        elif not quiet:
            xbmc.executebuiltin('RunScript(script.mediacenter)')
        # Off the box an automatic update waits for the app to be opened again (it was closed while installing).
    except UpdateDeferred:
        state = auto_state(profile)
        state.pop('trying', None)
        save_auto_state(profile, state)
        dialog.close()
        log('automatic update deferred; the box or update settings changed')
    except Exception:
        # Restore a disabled app as well as its folders; never print URLs or exception messages.
        if requested_stop:
            resume(window)
        try:
            if disabled:
                xbmc.executebuiltin('UpdateLocalAddons', True)
                rpc('Addons.SetAddonEnabled', {'addonid': APP, 'enabled': True})
            elif requested_stop and had_service and not window.getProperty(SERVICE):
                # Shutdown timed out after the service exited but before the app closed.
                xbmc.executebuiltin('RunScript("%s")' % os.path.join(
                    xbmcvfs.translatePath('special://home/addons'), APP, 'service.py'))
        except Exception:
            pass
        dialog.close()
        if quiet:
            try:
                remember_failed(profile, plan.get('packages') or [])
            except Exception:
                pass
            log('automatic update could not finish; the previous version was kept')
        else:
            xbmcgui.Dialog().ok('mediaCENTER', 'The update could not finish. Your previous version and account have been kept. Try again later.')
        if requested_stop and not window.getProperty(RUNNING_APP) and (not quiet or xbmc.getSkinDir() == 'skin.mediacenter'):
            xbmc.executebuiltin('RunScript(script.mediacenter)')
    finally:
        if requested_stop:
            resume(window)
        (profile / 'update-plan.json').unlink(missing_ok=True)


if __name__ == '__main__':
    import sys
    worker(sys.argv[1])
