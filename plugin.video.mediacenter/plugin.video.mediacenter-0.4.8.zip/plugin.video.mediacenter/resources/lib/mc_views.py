# mediaCENTER for Kodi: every screen of the add-on, as Kodi lists.
#
# The menu and its order come from design/experience.json (copied into resources/data by kodi/build.py), so Kodi says
# the same as the web app: Home, Guide, Sports, Search, Library (Movies, Shows, My List, Live TV), then Settings.
# Each Home row is its own path (action=row&id=...), so a skin can show them as rows on its Home screen later.

import json
import os
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import mc_logic as L
import mc_sample
from mc_api import Api, Session, SignedOut, ServerError

ADDON = xbmcaddon.Addon("plugin.video.mediacenter")  # named: app.py runs as a plain script, with no add-on of its own
ADDON_ID = ADDON.getAddonInfo("id")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
HERE = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
WINDOW = xbmcgui.Window(10000)


def _running_version():
    try:
        import xml.etree.ElementTree as ET
        return ET.parse(os.path.join(HERE, "addon.xml")).getroot().get("version") or ""
    except Exception:
        return ""


# The version that's running, read when the app starts: Kodi can install a newer one while the app is open, and the
# new code only runs after a restart (Settings > Software update then offers Restart).
RUNNING = _running_version()

PLAYING_KEY = "mediacenter.playing"
HOME_TTL = 300  # seconds a Home answer is reused by its rows

# Rows of the Movies and Shows pages, as on the web (web-v27/js/views/vod.js TMDB_ROWS).
MOVIE_ROWS = [("new", "New"), ("genre:28", "Action"), ("genre:35", "Comedy"), ("genre:53", "Thriller"), ("genre:18", "Drama"),
              ("genre:878", "Science Fiction"), ("genre:27", "Horror"), ("genre:80", "Crime"), ("genre:10749", "Romance"),
              ("genre:16", "Animation"), ("genre:10751", "Family")]
SHOW_ROWS = [("new", "New Series"), ("network:213", "Netflix"), ("network:49", "HBO"), ("network:2552", "Apple TV"),
             ("network:1024", "Prime Video"), ("network:2739", "Disney+"), ("network:453", "Hulu"), ("network:88", "FX"),
             ("network:4330", "Paramount+"), ("network:3353", "Peacock"), ("network:174", "AMC")]


def experience():
    try:
        with open(os.path.join(HERE, "resources", "data", "experience.json"), "r") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {"menu": ["Home", "Guide", "Sports", "Apps", "Search", "Library"], "library": ["Movies", "Shows", "My List", "Live TV"]}


SAMPLE = mc_sample.folder(HERE)  # sample-data mode: test boxes only, never in a release (mc_sample.py)


def api():
    if SAMPLE:
        return mc_sample.SampleApi(SAMPLE)
    return Api(ADDON.getSetting("server") or None, Session(PROFILE))


def log(msg):
    xbmc.log("[mediaCENTER] " + msg, xbmc.LOGINFO)


def notify(text, ms=4000):
    xbmcgui.Dialog().notification("mediaCENTER", text, os.path.join(HERE, "icon.png"), ms)


class View(object):
    """One directory listing: the plugin's handle and address, plus helpers to add items."""

    def __init__(self, argv):
        self.base = argv[0]
        self.handle = int(argv[1])
        self.params = dict(urllib.parse.parse_qsl((argv[2] if len(argv) > 2 else "").lstrip("?")))
        self.api = api()

    def link(self, **params):
        return self.base + "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})

    # ---- items ----------------------------------------------------------------------------------------------------

    def item(self, label, params, folder=True, playable=False, art=None, info=None, menu=None, label2="", progress=None):
        li = xbmcgui.ListItem(label, label2)
        if art:
            li.setArt({k: v for k, v in art.items() if v})
        if info is not None or progress is not None:
            set_info(li, info or {}, progress)
        if playable:
            li.setProperty("IsPlayable", "true")
        if menu:
            li.addContextMenuItems(menu)
        xbmcplugin.addDirectoryItem(self.handle, self.link(**params), li, isFolder=folder)

    def end(self, content="", cache=False, sort=False):
        if content:
            xbmcplugin.setContent(self.handle, content)
        if sort:
            xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=cache)

    def fail(self):
        xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def title_item(self, t, pins=None):
        art = {"poster": t.get("poster"), "thumb": t.get("poster"), "fanart": t.get("backdrop"), "landscape": t.get("backdrop")}
        info = {"title": t["name"], "plot": t.get("overview", ""), "year": t.get("year"), "rating": t.get("rating"),
                "mpaa": t.get("certification"), "mediatype": "tvshow" if t["type"] == "series" else "movie"}
        label = t["name"] + (" (%s)" % t["year"] if t.get("year") else "")
        pinned = L.is_pinned(pins, t) if pins is not None else False
        menu = [("Remove from My List" if pinned else "Add to My List",
                 "RunPlugin(%s)" % self.link(action="pin", type=t["type"], tmdb=t["tmdb"]))]
        if t["type"] == "movie":
            menu.insert(0, ("Play", "PlayMedia(%s)" % self.link(action="play", type="movie", tmdb=t["tmdb"])))
            menu.insert(1, ("Choose a version", "PlayMedia(%s)" % self.link(action="play", type="movie", tmdb=t["tmdb"], choose=1)))
        self.item(label, {"action": "title", "type": t["type"], "tmdb": t["tmdb"]}, art=art, info=info, menu=menu)

    def titles(self, items, content="movies"):
        for t in items:
            self.title_item(t)
        self.end(content)

    def channel_item(self, ch, game=None, prefix=""):
        label = prefix + L.channel_label(ch)
        now = L.now_title(ch)
        plot = L.channel_plot(ch)
        if game:
            plot = (L.matchup(game) + "\n" + plot).strip()
        if ch.get("why"):
            plot = (L.why_line(ch["why"]) + "\n" + plot).strip()
        self.item(label + ("  [COLOR grey]%s[/COLOR]" % now if now else ""),
                  {"action": "play_live", "id": ch["id"], "name": ch.get("name", ""), "alts": L.alt_ids(ch)},
                  folder=False, playable=True, art={"thumb": ch.get("logo"), "icon": ch.get("logo")},
                  info={"title": ch.get("name", ""), "plot": plot, "mediatype": "video"})


def set_info(li, info, progress=None):
    """Video details on a list item, with Kodi 20+'s InfoTagVideo (falling back to setInfo on Kodi 19)."""
    tag = getattr(li, "getVideoInfoTag", None)
    if tag:
        v = tag()
        if info.get("title"):
            v.setTitle(info["title"])
        if info.get("plot"):
            v.setPlot(info["plot"])
        if info.get("year") and str(info["year"]).isdigit():
            v.setYear(int(info["year"]))
        if info.get("rating"):
            try:
                v.setRating(float(info["rating"]))
            except ValueError:
                pass
        if info.get("mpaa"):
            v.setMpaa(info["mpaa"])
        if info.get("mediatype"):
            v.setMediaType(info["mediatype"])
        if info.get("tvshowtitle"):
            v.setTvShowTitle(info["tvshowtitle"])
        if info.get("season") is not None:
            v.setSeason(int(info["season"]))
        if info.get("episode") is not None:
            v.setEpisode(int(info["episode"]))
        if info.get("duration"):
            v.setDuration(int(info["duration"]))
        if progress:
            v.setResumePoint(progress[0], progress[1])
    else:
        li.setInfo("video", {k: v for k, v in info.items() if v not in (None, "")})
        if progress:
            li.setProperty("ResumeTime", str(progress[0]))
            li.setProperty("TotalTime", str(progress[1]))


# ---- small cached answers ---------------------------------------------------------------------------------------------

def cached(name, ttl, fetch):
    path = os.path.join(PROFILE, "cache-%s.json" % name)
    try:
        if time.time() - os.path.getmtime(path) < ttl:
            with open(path, "r") as f:
                return json.load(f)
    except (OSError, ValueError):
        pass
    data = fetch()
    try:
        if not os.path.isdir(PROFILE):
            os.makedirs(PROFILE)
        with open(path, "w") as f:
            json.dump(data, f)
    except OSError:
        pass
    return data


def drop_cache(name):
    try:
        os.remove(os.path.join(PROFILE, "cache-%s.json" % name))
    except OSError:
        pass


def my_list(a):
    prefs = (a.get("/api/prefs") or {}).get("prefs") or {}
    value = (prefs.get("myList") or {}).get("value")
    return value if isinstance(value, list) else []


# ---- screens ---------------------------------------------------------------------------------------------------------

ICONS = {"Home": "DefaultAddonVideo.png", "Guide": "DefaultAddonPVRClient.png", "Sports": "DefaultAddonGame.png",
         "Search": "DefaultAddonsSearch.png", "Library": "DefaultVideoPlaylists.png", "Settings": "DefaultAddonProgram.png"}
ACTIONS = {"Home": "home", "Guide": "guide", "Sports": "sports", "Search": "search", "Library": "library"}


def root(v):
    if not v.api.signed_in:
        v.item("Sign in to mediaCENTER", {"action": "signin"}, folder=False, art={"icon": "DefaultUser.png"},
               info={"plot": "Sign in with your mediaCENTER username and password."})
        v.item("Settings", {"action": "settings"}, folder=False, art={"icon": ICONS["Settings"]})
        return v.end()
    for name in experience().get("menu", []):
        if name in ACTIONS:  # Apps (the streaming services' pages) comes in a later build
            v.item(name, {"action": ACTIONS[name]}, art={"icon": ICONS.get(name, "")})
    v.item("Settings", {"action": "account"}, art={"icon": ICONS["Settings"]})
    v.end()


def home_answer(a):
    return cached("home", HOME_TTL, lambda: a.get("/api/roku/home"))


def home(v):
    answer = home_answer(v.api) or {}
    rows = {r.get("id"): r for r in answer.get("rows", []) if isinstance(r, dict)}
    hero = L.titles_of(answer.get("hero"), 5)
    if hero:
        v.item("Featured", {"action": "row", "id": "hero"}, art={"fanart": hero[0]["backdrop"], "thumb": hero[0]["backdrop"]},
               info={"plot": ", ".join(t["name"] for t in hero)})
    v.item("Continue Watching", {"action": "row", "id": "continue"})
    if "teams" in rows:
        v.item(rows["teams"].get("title") or "My Teams", {"action": "row", "id": "teams"})
    for key in ("top",):
        if key in rows:
            v.item(rows[key].get("title") or "Top 10 today", {"action": "row", "id": key})
    row_id, row_title = L.seasonal_row()
    v.item(row_title, {"action": "mrow", "type": "movie", "row": row_id, "title": row_title})
    for key in ("movies", "shows"):
        if key in rows:
            v.item(rows[key].get("title"), {"action": "row", "id": key})
    v.item("My List", {"action": "mylist"})
    v.end()


def row(v):
    rid = v.params.get("id", "")
    if rid == "continue":
        return continue_watching(v)
    answer = home_answer(v.api) or {}
    if rid == "hero":
        return v.titles(L.titles_of(answer.get("hero")))
    found = next((r for r in answer.get("rows", []) if isinstance(r, dict) and r.get("id") == rid), None)
    if not found:
        return v.end()
    if found.get("kind") == "games":
        return games(v, found.get("items") or [])
    v.titles(L.titles_of(found.get("items")), "tvshows" if rid == "shows" else "movies")


def continue_watching(v):
    hist = (v.api.get("/api/history", limit=40, perShow=1) or {}).get("items")
    for h in L.continue_items(hist):
        label = h["name"]
        info = {"title": h["name"], "mediatype": "movie", "duration": h["duration"]}
        params = {"action": "play", "type": h["type"], "tmdb": h["tmdb"]}
        if h["type"] == "series":
            label += "  [COLOR grey]S%d E%d[/COLOR]" % (h["season"], h["episode"])
            info.update({"tvshowtitle": h["name"], "title": h["episodeName"] or h["name"], "season": h["season"],
                         "episode": h["episode"], "mediatype": "episode"})
            params.update({"season": h["season"], "episode": h["episode"]})
        info["plot"] = "%s left" % L.clock_text(h["duration"] - h["position"])
        v.item(label, params, folder=False, playable=True, art={"thumb": h["image"], "poster": h["image"]},
               info=info, progress=(h["position"], h["duration"]))
    v.end("videos")


def games(v, items):
    for g in items:
        label = L.game_label(g)
        if g.get("mine"):
            label = "[B]%s[/B]" % label
        plot = "\n".join([p for p in [L.matchup(g), L.when(g)] if p])
        chans = g.get("channels") or []
        if chans:
            plot += "\nWatch on " + chans[0].get("name", "")
        v.item(label, {"action": "game", "id": g.get("id"), "league": g.get("league", "")}, info={"title": label, "plot": plot})
    v.end("videos")


def sports_answer(a):
    return cached("sports", 60, lambda: a.get("/api/roku/sports"))


def sports(v):
    answer = sports_answer(v.api) or {}
    all_games = answer.get("games") or []
    if not all_games:
        v.item("No games right now", {"action": "sports"}, folder=False)
        return v.end()
    games(v, all_games)


def game(v):
    """One game: its best channel first ("Watch on ..."), then every channel that may carry it."""
    gid = v.params.get("id", "")
    found = next((g for g in (sports_answer(v.api) or {}).get("games", []) if str(g.get("id")) == gid), None)
    if not found:
        drop_cache("sports")
        found = next((g for g in (sports_answer(v.api) or {}).get("games", []) if str(g.get("id")) == gid), None)
    if not found:
        return v.end()
    for i, ch in enumerate(found.get("channels") or []):
        v.channel_item(dict(ch, num=0), found, prefix="Watch on " if i == 0 else "")
    if not found.get("channels"):
        v.item("No channel is showing this game yet", {"action": "game", "id": gid}, folder=False,
               info={"plot": L.matchup(found) + "\n" + L.when(found)})
    v.end("videos")


def guide(v):
    v.item("TV Guide", {"action": "tvguide"}, folder=False, art={"icon": "DefaultAddonPVRClient.png"},
           info={"plot": "Every channel with what's on now and later, on a timeline. Up and Down change channel while you watch."})
    v.item("Locals and Cable", {"action": "live", "list": "locals"})
    v.item("My Teams", {"action": "live", "list": "teams"}, info={"plot": "Channels that may carry your teams' games."})
    v.item("All channels", {"action": "categories"}, info={"plot": "Every channel in your lineup, by category."})
    v.end()


def live(v):
    lst = "teams" if v.params.get("list") == "teams" else "locals"
    answer = v.api.get("/api/roku/live", list=lst) or {}
    channels = answer.get("channels") or []
    if not channels and lst == "teams":
        v.item("No games for your teams right now. Pick your teams on the website.", {"action": "guide"}, folder=False)
    for ch in channels:
        v.channel_item(ch, ch.get("game"))
    v.end("videos")


XTREAM = {"username": "STAGING_TESTER", "password": "STAGING_PROXY"}


def categories(v):
    cats = cached("categories", 1800, lambda: v.api.get("/player_api.php", action="get_live_categories", **XTREAM)) or []
    for c in cats if isinstance(cats, list) else []:
        if isinstance(c, dict) and c.get("category_name"):
            v.item(str(c["category_name"]), {"action": "category", "id": c.get("category_id")})
    v.end(sort=True)


def category(v):
    streams = v.api.get("/player_api.php", action="get_live_streams", category_id=v.params.get("id", ""), **XTREAM) or []
    for ch in L.fold_lineup(streams):
        v.channel_item(ch)
    v.end("videos")


def library(v):
    targets = {"Movies": ("movies", None), "Shows": ("shows", None), "My List": ("mylist", None), "Live TV": ("guide", None)}
    for name in experience().get("library", []):
        if name in targets:
            v.item(name, {"action": targets[name][0]})
    v.end()


def rows_page(v, kind, rows):
    for rid, title in rows:
        v.item(title, {"action": "mrow", "type": kind, "row": rid, "title": title})
    v.end()


def mrow(v):
    kind = "series" if v.params.get("type") == "series" else "movie"
    answer = v.api.get("/meta/row", type=kind, row=v.params.get("row", "new")) or {}
    v.titles(L.titles_of(answer.get("items")), "tvshows" if kind == "series" else "movies")


def mylist(v):
    pins = my_list(v.api)
    items = L.titles_of(pins)
    if not items:
        v.item("Nothing in My List yet. Open a title and choose Add to My List.", {"action": "mylist"}, folder=False)
        return v.end()
    for t in items:
        v.title_item(t, pins)
    v.end("movies")


def title(v):
    """A title's page: Play (or seasons), Choose a version, My List and More like this."""
    kind = "series" if v.params.get("type") == "series" else "movie"
    tmdb = v.params.get("tmdb", "")
    answer = v.api.get("/api/roku/title", type=kind, tmdb=tmdb) or {}
    t = L.title_of(dict(answer.get("title") or {}, type=kind, tmdb=tmdb)) or {"tmdb": tmdb, "type": kind, "name": "", "year": "", "poster": "", "backdrop": "", "overview": "", "seasonList": []}
    # Richer details (age rating, IMDb score) when the metadata server has them.
    try:
        m = v.api.get("/meta/title", type=kind, tmdb=tmdb) or {}
        t["certification"] = str(m.get("certification") or t.get("certification") or "")
        t["rating"] = str(m.get("imdbRating") or t.get("rating") or "")
        t["imdb"] = str((m.get("ids") or {}).get("imdb") or m.get("imdb") or t.get("imdb") or "")
    except (ServerError, SignedOut):
        pass
    art = {"poster": t.get("poster"), "thumb": t.get("poster"), "fanart": t.get("backdrop"), "landscape": t.get("backdrop")}
    head = " ".join(p for p in [L.title_line(t), ("IMDb %s" % t["rating"]) if t.get("rating") else "", t.get("certification", "")] if p)
    info = {"title": t["name"], "plot": (head + "\n\n" + t.get("overview", "")).strip(), "year": t.get("year"), "rating": t.get("rating"),
            "mpaa": t.get("certification"), "mediatype": "movie" if kind == "movie" else "tvshow"}
    pins = my_list(v.api)
    if kind == "movie":
        v.item("Play", {"action": "play", "type": "movie", "tmdb": tmdb}, folder=False, playable=True, art=art, info=info)
        v.item("Choose a version", {"action": "play", "type": "movie", "tmdb": tmdb, "choose": 1}, folder=False, playable=True, art=art, info=info)
    else:
        for n in t.get("seasonList") or []:
            v.item("Season %d" % n, {"action": "season", "tmdb": tmdb, "season": n, "name": t["name"]}, art=art,
                   info=dict(info, title="Season %d" % n, mediatype="season", season=n))
    pinned = L.is_pinned(pins, t)
    v.item("Remove from My List" if pinned else "Add to My List", {"action": "pin", "type": kind, "tmdb": tmdb}, folder=False, art=art, info=info)
    v.item("More like this", {"action": "similar", "type": kind, "tmdb": tmdb}, art=art, info=info)
    xbmcplugin.setPluginCategory(v.handle, t["name"])
    v.end("movies" if kind == "movie" else "seasons")


def season(v):
    tmdb, n = v.params.get("tmdb", ""), int(v.params.get("season", "1"))
    name = v.params.get("name", "")
    answer = v.api.get("/api/roku/episodes", tmdb=tmdb, season=n) or {}
    for e in answer.get("episodes") or []:
        label = "%d. %s" % (e.get("n", 0), e.get("name") or "Episode %d" % e.get("n", 0))
        v.item(label, {"action": "play", "type": "series", "tmdb": tmdb, "season": n, "episode": e.get("n")}, folder=False, playable=True,
               info={"title": e.get("name", ""), "plot": e.get("overview", ""), "tvshowtitle": name, "season": n,
                     "episode": e.get("n", 0), "mediatype": "episode"},
               menu=[("Choose a version", "PlayMedia(%s)" % v.link(action="play", type="series", tmdb=tmdb, season=n, episode=e.get("n"), choose=1))])
    v.end("episodes")


def similar(v):
    kind = "series" if v.params.get("type") == "series" else "movie"
    answer = v.api.get("/meta/similar", type=kind, tmdb=v.params.get("tmdb", "")) or {}
    v.titles(L.titles_of(answer.get("items")), "tvshows" if kind == "series" else "movies")


def search(v):
    text = v.params.get("q")
    if not text:
        text = xbmcgui.Dialog().input("Search movies, shows, channels and teams")
        if not text or len(text.strip()) < 2:
            return v.fail()
        text = text.strip()
    answer = v.api.get("/api/roku/search", q=text) or {}
    for t in L.titles_of(answer.get("titles")):
        v.title_item(t)
    for ch in answer.get("channels") or []:
        v.channel_item(ch, prefix=u"Channel · ")
    for g in answer.get("games") or []:
        v.item(u"Game · " + L.game_label(g), {"action": "game", "id": g.get("id")}, info={"plot": L.matchup(g)})
    v.end("movies")


def account(v):
    info = v.api.check()
    who = (info or {}).get("displayName") or (info or {}).get("username") or v.api.username
    v.item("Signed in as %s" % who if who else "Not signed in", {"action": "account"}, folder=False, art={"icon": "DefaultUser.png"})
    v.item("Add-on settings", {"action": "settings"}, folder=False, art={"icon": ICONS["Settings"]})
    v.item("Sign out", {"action": "signout"}, folder=False, art={"icon": "DefaultIconError.png"})
    v.end()


# ---- actions (no list) -----------------------------------------------------------------------------------------------

def sign_in_flow(a):
    """Ask for the username and password (Kodi's keyboard, or the Kore phone app), sign in, keep only the session.
    Returns True when signed in."""
    d = xbmcgui.Dialog()
    username = d.input("mediaCENTER username")
    if not username:
        return False
    password = d.input("Password", option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not password:
        return False
    message = a.sign_in(username.strip(), password)
    password = None
    if message:
        d.ok("mediaCENTER", message)
        return False
    info = a.check()
    if not info:
        d.ok("mediaCENTER", "The session could not be established.")
        return False
    if info.get("emailVerificationRequired"):
        d.ok("mediaCENTER", "Confirm your email first at %s/access/verify-email, then come back." % a.base)
    notify("Signed in as %s" % (info.get("displayName") or info.get("username")))
    return True


def signin(v):
    if sign_in_flow(v.api):
        xbmc.executebuiltin("Container.Refresh")


def signout(v):
    if xbmcgui.Dialog().yesno("mediaCENTER", "Sign out of mediaCENTER on this device?"):
        v.api.sign_out()
        for name in ("home", "sports", "categories"):
            drop_cache(name)
        xbmc.executebuiltin("Container.Update(%s,replace)" % v.base)


def pin(v):
    kind = "series" if v.params.get("type") == "series" else "movie"
    tmdb = v.params.get("tmdb", "")
    answer = v.api.get("/api/roku/title", type=kind, tmdb=tmdb) or {}
    t = L.title_of(dict(answer.get("title") or {}, type=kind, tmdb=tmdb))
    if not t:
        return notify("Couldn't change My List.")
    pins, now_pinned = L.toggle_pin(my_list(v.api), t)
    v.api.call("PUT", "/api/prefs", body={"prefs": {"myList": {"value": pins, "updatedAt": int(time.time() * 1000)}}})
    notify(("Added %s to My List" if now_pinned else "Removed %s from My List") % t["name"])
    xbmc.executebuiltin("Container.Refresh")


def tvguide(v):
    """Set up Kodi's TV guide with mediaCENTER's channels (first time, or when the channel choice changed), then open it."""
    import mc_guide as G
    everything = ADDON.getSetting("guide_channels") == "1"
    marker = os.path.join(PROFILE, "guide", "ready")
    wanted = "all" if everything else "locals"
    ready = os.path.exists(marker) and open(marker).read().strip() == wanted
    if not ready:
        bar = xbmcgui.DialogProgress()
        bar.create("mediaCENTER", "Getting your channels and the guide ready...")
        bar.update(20)
        try:
            n, programmes = G.refresh(v.api, PROFILE, v.base, everything, log)
        except (ServerError, OSError) as e:
            bar.close()
            log("guide set-up failed: %s" % type(e).__name__)
            return xbmcgui.Dialog().ok("mediaCENTER", "Couldn't get the guide right now. Try again in a moment.")
        bar.update(70, "Setting up the TV guide (%d channels)..." % n)
        problem = G.set_up_pvr(PROFILE, xbmcvfs.translatePath)
        bar.close()
        if problem:
            return xbmcgui.Dialog().ok("mediaCENTER", problem)
        with open(marker, "w") as f:
            f.write(wanted)
        notify("TV guide ready: %d channels" % n)
        xbmc.sleep(3000)  # give Kodi a moment to load the channels
    xbmc.executebuiltin("ActivateWindow(TVGuide)")
