# mediaCENTER for Kodi: a small relay on this box (127.0.0.1) for the links that need the account's sign-in (0.4.8).
#
# Before 0.4.8 a link on our server that needs the session (TorBox versions, live channels through /relay/live) was
# handed to Kodi as "https://server/path|Cookie=...": Kodi writes every link it opens, with what follows the "|", into
# kodi.log, so the sign-in cookie landed in the log each time a video opened or failed (owner, 2026-11-26). Now Kodi gets
# "http://127.0.0.1:PORT/TOKEN/path" instead: this relay adds the cookie itself and passes the answer back as it comes,
# so the log only ever shows the box's own address. The cookie stays inside the add-on (its profile folder and memory).
#
#   - It listens on 127.0.0.1 only (nothing outside the box can reach it) and answers only under a random TOKEN made
#     each time it starts, only GET and HEAD, and only for playback paths on our own server (ALLOWED).
#   - Redirects are not followed: Kodi gets them as they are (TorBox's own file needs no cookie), and a redirect to our
#     own server is pointed back at the relay. HLS playlists have their links to our server pointed at the relay too.
#   - The service (service.py) runs it for as long as Kodi runs and leaves its address in the Home window property
#     PROP; a page that finds no service relay starts one in its own process (Relay.local).

import json
import re
import secrets
import socket
import ssl
import threading
import urllib.error
import urllib.parse
import urllib.request

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
except ImportError:  # pragma: no cover
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn

PROP = "mediacenter.relay"
ALLOWED = re.compile(r"^/(relay|live|movie|series|share|jellyfin|aio)/")
PASS_ON = ("Range", "If-Range", "Accept", "Accept-Encoding")  # Kodi's request headers that go on to our server
SEND_BACK = ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "Last-Modified", "ETag", "Cache-Control")
PLAYLIST_MAX = 4 * 1024 * 1024
CHUNK = 64 * 1024
UPSTREAM_TIMEOUT = 45


def rewrite_uri(uri, base, prefix):
    """A link inside a playlist or a redirect: ours goes through the relay; another site's, or a relative one, stays."""
    u = (uri or "").strip()
    if u.startswith(base + "/"):
        return prefix + u[len(base):]
    if u.startswith("/") and not u.startswith("//"):
        return prefix + u
    return uri


_ATTR = re.compile(r'URI="([^"]*)"')


def rewrite_playlist(text, base, prefix):
    """An HLS playlist with its links to our server pointed at the relay (segment lines and URI="..." attributes)."""
    out = []
    for line in text.splitlines():
        s = line.strip()
        if not s:
            out.append(line)
        elif s.startswith("#"):
            out.append(_ATTR.sub(lambda m: 'URI="%s"' % rewrite_uri(m.group(1), base, prefix), line))
        else:
            out.append(rewrite_uri(s, base, prefix))
    return "\n".join(out) + "\n"


def upstream_path(path, token):
    """The path on our server for a relay path, or None when the relay must refuse it (wrong token, not a playback path,
    or anything that tries to climb out)."""
    head = "/%s/" % token
    if not token or not path.startswith(head):
        return None
    rest = "/" + path[len(head):]
    plain = urllib.parse.unquote(rest.split("?", 1)[0])
    if ".." in plain or "//" in plain or "\\" in plain or not ALLOWED.match(plain):
        return None
    return rest


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class _Server(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class Relay(object):
    """The relay for one server. cookie() gives the current sign-in cookie ("name=value") or ""."""

    def __init__(self, base, cookie, user_agent="mediaCENTER-Kodi", device="kodi", opener=None):
        self.base = base.rstrip("/")
        self.cookie = cookie
        self.user_agent = user_agent
        self.device = device
        self.token = secrets.token_hex(12)
        self.server = None
        self.thread = None
        self.opener = opener or urllib.request.build_opener(
            _NoRedirect(), urllib.request.HTTPSHandler(context=ssl.create_default_context()))

    @property
    def prefix(self):
        return "http://127.0.0.1:%d/%s" % (self.server.server_address[1], self.token) if self.server else ""

    def start(self):
        relay = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.0"  # one answer per connection: the end of the body is the end of the connection

            def log_message(self, *args):  # nothing about requests goes to stderr (and so to kodi.log)
                pass

            def do_HEAD(self):
                relay.handle(self, head=True)

            def do_GET(self):
                relay.handle(self, head=False)

        self.server = _Server(("127.0.0.1", 0), Handler)
        self.thread = threading.Thread(target=self.server.serve_forever, name="mediacenter-relay")
        self.thread.daemon = True
        self.thread.start()
        return self.prefix

    def stop(self):
        if self.server:
            try:
                self.server.shutdown()
                self.server.server_close()
            except Exception:
                pass
            self.server = None

    def url(self, path):
        """The relay's link for a path on our server ("/relay/live/..../1.m3u8?x=1")."""
        return self.prefix + (path if path.startswith("/") else "/" + path)

    # -- one request from Kodi --

    def handle(self, h, head):
        path = upstream_path(h.path, self.token)
        if path is None:
            return self._reply(h, 403, b"")
        cookie = self.cookie() or ""
        if not cookie:
            return self._reply(h, 401, b"")
        headers = {"Cookie": cookie, "User-Agent": self.user_agent, "X-MC-Device": self.device}
        for k in PASS_ON:
            if h.headers.get(k):
                headers[k] = h.headers.get(k)
        req = urllib.request.Request(self.base + path, headers=headers, method="HEAD" if head else "GET")
        try:
            res = self.opener.open(req, timeout=UPSTREAM_TIMEOUT)
        except urllib.error.HTTPError as e:
            res = e  # an error answer (or a redirect, which is not followed) is passed on as it is
        except (OSError, ValueError):
            return self._reply(h, 502, b"")
        try:
            self._pass_on(h, res, head, path)
        except (OSError, ValueError):
            pass  # Kodi hung up (a seek, Stop): nothing to do
        finally:
            try:
                res.close()
            except Exception:
                pass

    def _pass_on(self, h, res, head, path):
        status = res.getcode() if hasattr(res, "getcode") else res.code
        rh = res.headers
        kind = (rh.get("Content-Type") or "").lower()
        playlist = "mpegurl" in kind or path.split("?", 1)[0].lower().endswith(".m3u8")
        if playlist and not head and 200 <= status < 300:
            body = res.read(PLAYLIST_MAX + 1)
            if len(body) <= PLAYLIST_MAX:
                text = rewrite_playlist(body.decode("utf-8", "replace"), self.base, self.prefix).encode("utf-8")
                return self._reply(h, status, text, rh.get("Content-Type") or "application/vnd.apple.mpegurl")
        h.send_response(status)
        for k in SEND_BACK:
            if rh.get(k):
                h.send_header(k, rh.get(k))
        if rh.get("Location"):
            h.send_header("Location", rewrite_uri(urllib.parse.urljoin(self.base + path, rh.get("Location")), self.base, self.prefix))
        h.end_headers()
        if head:
            return
        while True:
            chunk = res.read(CHUNK)
            if not chunk:
                return
            h.wfile.write(chunk)

    @staticmethod
    def _reply(h, status, body, kind="text/plain"):
        try:
            h.send_response(status)
            h.send_header("Content-Type", kind)
            h.send_header("Content-Length", str(len(body)))
            h.end_headers()
            if body and h.command != "HEAD":
                h.wfile.write(body)
        except (OSError, socket.error):
            pass


# ---- finding the relay from a page -------------------------------------------------------------------------------------

_local = {}


def announce(window, relay):
    """The service leaves the relay's address for the pages (the token is only good on this box, while Kodi runs)."""
    window.setProperty(PROP, json.dumps({"prefix": relay.prefix, "base": relay.base}))


def prefix_for(api, window=None):
    """The relay to use for this account's server: the service's when it runs for the same server, else one in this
    process (kept for as long as the process lives, reading the cookie from api)."""
    if window is not None:
        try:
            data = json.loads(window.getProperty(PROP) or "{}")
        except ValueError:
            data = {}
        if data.get("prefix") and data.get("base") == api.base:
            return data["prefix"]
    hit = _local.get(api.base)
    if hit is None or hit.server is None:
        hit = Relay(api.base, lambda: api.cookie)
        hit.start()
        _local[api.base] = hit
    else:
        hit.cookie = lambda: api.cookie
    return hit.prefix
