# mediaCENTER for Kodi: playing movies, episodes and live channels.
#
# Movies and episodes: GET /api/roku/play gives the versions the server found (TorBox, the library, the provider's
# own copy; signed links or paths on our server) and the account's Stremio add-ons, which this box asks itself (add-ons
# refuse our servers), the same way the Roku app does. The versions are ranked for this box (mc_logic.rank_versions):
# on a Raspberry Pi 3, H.264 up to 1080p first. "Choose a version" lists them; Play takes the best one.
# What is playing is left in a window property for service.py, which saves progress to /api/history.

import json
import threading

import xbmc
import xbmcgui
import xbmcplugin

import mc_logic as L
from mc_views import ADDON, WINDOW, PLAYING_KEY, notify, set_info, log
from mc_api import SignedOut, ServerError


def caps():
    pi = xbmc.getCondVisibility("System.Platform.Linux.RaspberryPi")
    max_res = {"0": "720p", "1": "1080p", "2": "2160p"}.get(ADDON.getSetting("max_res") or "1", "1080p")
    hevc_setting = ADDON.getSetting("hevc") or "auto"
    hevc = None if hevc_setting == "auto" else hevc_setting == "true"
    return L.device_caps(raspberry_pi=pi, max_res=max_res, hevc=hevc)


def gather(api, kind, tmdb, season=None, episode=None):
    """Every version for one movie or episode: the server's, then the account's add-ons' (asked in parallel)."""
    query = {"type": kind, "tmdb": tmdb}
    if kind == "series":
        query.update(season=season, episode=episode)
    answer = api.get("/api/roku/play", **query) or {}
    versions = list(answer.get("versions") or [])
    imdb = answer.get("imdb") or ""
    addons = [a for a in answer.get("addons") or [] if isinstance(a, dict) and str(a.get("base", "")).startswith("https://")]
    if imdb and addons:
        stream_id = imdb if kind == "movie" else "%s:%s:%s" % (imdb, season, episode)
        found = [[] for _ in addons]

        def ask(i, a):
            found[i] = L.addon_versions(api.addon_streams(a["base"], kind, stream_id))
        threads = [threading.Thread(target=ask, args=(i, a)) for i, a in enumerate(addons)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(35)
        for f in found:
            versions.extend(f)
    return versions, answer.get("name") or ""


def resolve(handle, url, li=None):
    li = li or xbmcgui.ListItem(path=url)
    li.setPath(url)
    xbmcplugin.setResolvedUrl(handle, True, li)


def fail(handle, message):
    notify(message, 6000)
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())


def play(v):
    kind = "series" if v.params.get("type") == "series" else "movie"
    tmdb = v.params.get("tmdb", "")
    season = int(v.params["season"]) if v.params.get("season") else None
    episode = int(v.params["episode"]) if v.params.get("episode") else None
    choose = v.params.get("choose") == "1"
    progress = xbmcgui.DialogProgressBG()
    progress.create("mediaCENTER", "Finding the best version...")
    try:
        versions, name = gather(v.api, kind, tmdb, season, episode)
        info_answer = v.api.get("/api/roku/title", type=kind, tmdb=tmdb) or {}
    except SignedOut:
        progress.close()
        return fail(v.handle, "Sign in to mediaCENTER again.")
    except ServerError as e:
        progress.close()
        return fail(v.handle, "Couldn't reach mediaCENTER (%s)." % e.status)
    progress.close()
    ranked, hidden = L.rank_versions(versions, caps())
    log("play %s: %d versions, %d playable here, %d hidden" % (kind, len(versions), len(ranked), hidden))
    if not ranked:
        msg = "No version of this title plays on this device yet."
        if hidden:
            msg += " (%d need a stronger box.)" % hidden
        return fail(v.handle, msg)
    pick = ranked[0]
    if choose:
        labels = []
        for x in ranked:
            label = L.version_label(x)
            if x.get("level") == "maybe":
                label += "  [COLOR grey](may stutter)[/COLOR]"
            labels.append(xbmcgui.ListItem(label, L.PROVIDERS.get(x.get("provider"), "") + ("  " + x.get("name", "") if x.get("name") else "")))
        i = xbmcgui.Dialog().select("Choose a version" + (" (%d hidden)" % hidden if hidden else ""), labels, useDetails=True)
        if i < 0:
            return xbmcplugin.setResolvedUrl(v.handle, False, xbmcgui.ListItem())
        pick = ranked[i]
    url = v.api.kodi_url(pick["url"], cookie=bool(pick.get("cookie")))
    t = L.title_of(dict(info_answer.get("title") or {}, type=kind, tmdb=tmdb)) or {"tmdb": tmdb, "type": kind, "name": name or "", "poster": ""}
    if not t.get("name"):
        t["name"] = name or "mediaCENTER"
    episode_name = ""
    if kind == "series":
        try:
            eps = (v.api.get("/api/roku/episodes", tmdb=tmdb, season=season) or {}).get("episodes") or []
            episode_name = next((e.get("name", "") for e in eps if e.get("n") == episode), "")
        except (ServerError, SignedOut):
            pass
    entry = L.history_entry(t, season, episode, episode_name)
    resume = resume_point(v, entry["itemId"])
    li = xbmcgui.ListItem(path=url)
    li.setArt({"poster": t.get("poster"), "thumb": t.get("poster"), "fanart": t.get("backdrop")})
    info = {"title": episode_name or t["name"], "mediatype": "episode" if kind == "series" else "movie", "plot": t.get("overview", "")}
    if kind == "series":
        info.update(tvshowtitle=t["name"], season=season, episode=episode)
    set_info(li, info)
    if pick.get("container") == "m3u8" or ".m3u8" in url.split("|")[0]:
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
    WINDOW.setProperty(PLAYING_KEY, json.dumps({"entry": entry, "resume": resume}))
    resolve(v.handle, url, li)


def resume_point(v, item_id):
    """Where to start: ask "Resume from 12:34" when this title was left part-way (the same row every app uses)."""
    if v.params.get("fresh") == "1":
        return 0
    try:
        hist = (v.api.get("/api/history", limit=300) or {}).get("items") or []
    except (ServerError, SignedOut):
        return 0
    row = next((h for h in hist if h.get("itemId") == item_id), None)
    if not row or row.get("finished") or float(row.get("position") or 0) < 30:
        return 0
    pos = float(row["position"])
    i = xbmcgui.Dialog().contextmenu(["Resume from %s" % L.clock_text(pos), "Start from the beginning"])
    return pos if i == 0 else 0


def play_live(v):
    """A live channel through the relay. When the channel has backup feeds (alts=ID,ID from the game or the Guide) and
    the main one gives no playlist, the first one that does plays instead, as the web player switches on its own."""
    feeds = [v.params.get("id", "")] + [a for a in v.params.get("alts", "").split(",") if a.isdigit()][:5]
    try:
        chosen = feeds[0]
        if len(feeds) > 1:
            for k, sid in enumerate(feeds):
                ok = v.api.live_plays(sid)
                if ok is None and k == 0:
                    break  # no answer in time: let the player try the main feed itself
                if ok:
                    chosen = sid
                    if k:
                        notify("Trying a backup feed")
                    break
            else:
                return fail(v.handle, "This channel isn't playing right now.")
        url = v.api.live_url(chosen)
    except (ValueError, ServerError):
        return fail(v.handle, "This channel can't be played.")
    except SignedOut:
        return fail(v.handle, "Sign in to mediaCENTER again.")
    li = xbmcgui.ListItem(v.params.get("name", "Live TV"), path=url)
    li.setMimeType("application/vnd.apple.mpegurl")
    li.setContentLookup(False)
    set_info(li, {"title": v.params.get("name", "Live TV"), "mediatype": "video"})
    WINDOW.clearProperty(PLAYING_KEY)  # live TV has no progress to save
    resolve(v.handle, url, li)
