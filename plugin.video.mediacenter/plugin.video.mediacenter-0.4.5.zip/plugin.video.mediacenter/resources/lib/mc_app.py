# mediaCENTER for Kodi: the app itself, full screen in mediaCENTER's own look (resources/skins/Default/1080i,
# written by kodi/tools/make_windows.py). It works like the web app: a sidebar (design/experience.json "pi": Home, Movies,
# TV Shows, Guide, Sports, Search, Library, Settings), a hero picture that follows the highlighted title, and poster rows.
# Movies and TV Shows are pages like the Roku's (genres down the left, rows from /api/browse); Search is a page with
# letters on screen and results as you type. Everything plays in mediaCENTER's own player (mc_player, 0.4.5) on top of
# the page it was started from, so Back after a film returns to that page as it was.

import datetime
import threading
import os
import time
import urllib.parse

import xbmc
import xbmcgui

import mc_logic as L
import mc_views as V
from mc_api import SignedOut, ServerError

PLUGIN = "plugin://plugin.video.mediacenter/"
NAV, PLAY, INFO, BUTTONS, ROWS = 9000, 201, 202, 200, 1000
ROW_IDS = list(range(501, 509))
BACK = (9, 10, 92, 247)  # parent dir, previous menu, back, back (remote)
MOVES = (1, 2, 3, 4, 5, 6)  # left, right, up, down, page up, page down
SCREENS = {"Home": "home", "Movies": "movies", "TV Shows": "shows", "Guide": "guide", "Sports": "sports", "Search": "search",
           "Library": "library", "Settings": "settings"}


def colors():
    """The token colours (resources/data/colors.json, written by kodi/tools/make_windows.py from design/tokens.json)."""
    import json
    import os
    try:
        with open(os.path.join(V.HERE, "resources", "data", "colors.json"), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


COLORS = colors()
SURFACE, RAISED, CREAM, ACCENT, CARD = (COLORS.get(k, d) for k, d in (
    ("surface", "FF17171A"), ("raised", "FF232327"), ("cream", "FFF5F5F7"), ("accent", "FFE51C23"), ("card", "12FFFFFF")))


def menu():
    """The sidebar, in the order design/experience.json gives ("pi" menu); names this app has no screen for are left out."""
    names = (V.experience().get("app") or {}).get("menu") or ["Home", "Movies", "TV Shows", "Guide", "Sports", "Search", "Library", "Settings"]
    out = [(SCREENS[n], n) for n in names if n in SCREENS]
    if not any(k == "settings" for k, _ in out):
        out.append(("settings", "Settings"))
    return out


MENU = menu()


def link(**params):
    return PLUGIN + "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})


def play(**params):
    xbmc.executebuiltin("PlayMedia(%s)" % link(**params))


def refocus(win, control_id, tries=30):
    """Put the highlight back after the player closes. The page shows again only once the picture has gone, and Kodi
    ignores focus on a hidden control, so this waits for that (up to 3 seconds)."""
    for _ in range(tries):
        if not xbmc.getCondVisibility("Player.HasVideo"):
            win.setFocusId(control_id)
            if win.getFocusId() == control_id:
                return True
        xbmc.sleep(100)
    win.setFocusId(control_id)
    return False


def busy(on):
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)" if on else "Dialog.Close(busydialognocancel)")


# ---- what the cards hold ---------------------------------------------------------------------------------------------

def title_card(t):
    li = xbmcgui.ListItem(t["name"], t.get("year", ""))
    li.setArt({"poster": t.get("poster"), "fanart": t.get("backdrop")})
    li.setProperties({"kind": "title", "type": t["type"], "tmdb": t["tmdb"], "plot": t.get("overview", ""),
                      "meta": L.DOT.join(p for p in [t.get("year", ""), "Movie" if t["type"] == "movie" else "TV Show"] if p)})
    return li


def continue_card(h):
    li = xbmcgui.ListItem(h["name"], "S%d E%d" % (h["season"], h["episode"]) if h["type"] == "series" else L.clock_text(h["duration"] - h["position"]) + " left")
    li.setArt({"poster": h["image"]})
    V.set_info(li, {"title": h["name"], "mediatype": "movie"}, (h["position"], h["duration"]))
    li.setProperties({"kind": "continue", "type": h["type"], "tmdb": h["tmdb"], "season": str(h.get("season") or ""),
                      "episode": str(h.get("episode") or ""), "progress": str(int(h["progress"] * 100)),
                      "eyebrow": "S%d E%d" % (h["season"], h["episode"]) if h["type"] == "series" else "",
                      "meta": ("S%d E%d · " % (h["season"], h["episode"]) if h["type"] == "series" else "") + "%s left" % L.clock_text(h["duration"] - h["position"])})
    return li


def game_card(g):
    head = L.score_line(g) or L.matchup(g)
    li = xbmcgui.ListItem(head, L.when(g))
    chans = g.get("channels") or []
    li.setProperties({"kind": "game", "id": str(g.get("id")), "eyebrow": ("LIVE · " if g.get("state") == "in" else "") + (g.get("league") or ""),
                      "plot": "\n".join(p for p in [L.matchup(g), L.when(g), ("Watch on " + chans[0]["name"]) if chans else "No channel is showing this game yet"] if p),
                      "meta": L.DOT.join(p for p in [g.get("league", ""), L.when(g)] if p)})
    return li


def channel_card(ch):
    li = xbmcgui.ListItem(ch.get("name", ""), L.now_title(ch))
    li.setProperties({"kind": "channel", "id": str(ch.get("id")), "eyebrow": "CHANNEL %s" % ch["num"] if ch.get("num") else "CHANNEL",
                      "plot": L.channel_plot(ch), "meta": "Live TV"})
    return li


# ---- Home and the other row pages ------------------------------------------------------------------------------------

class App(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(App, self).__init__(*args, **kwargs)
        self.api = V.api()
        self.screen = "home"
        self.rows = {}
        self.hero_item = None
        self.started = False

    def onInit(self):
        if self.started:
            return
        self.started = True
        try:
            import mc_opening
            mc_opening.Opening.show()  # the Apple TV's opening: posters from last time, the mark, the name
        except Exception as e:  # never keep the app from opening
            V.log("opening skipped: %s" % type(e).__name__)
        from mc_device import DevicePage, on_device
        if on_device() and V.ADDON.getSetting("setup_complete") != "true":
            DevicePage.open(self.api, first_run=True)  # first run on the box: network, remote, sign in
        nav = self.getControl(NAV)
        nav.reset()
        media = os.path.join(V.HERE, "resources", "skins", "Default", "media")
        items = []
        for key, name in MENU:
            li = xbmcgui.ListItem(name)
            icon = os.path.join(media, "icon_%s.png" % key)
            li.setProperty("icon", icon if os.path.isfile(icon) else "")
            items.append(li)
        nav.addItems(items)
        info = None
        try:
            info = self.api.check()
        except (ServerError, OSError):
            pass
        if info:
            self.setProperty("account", info.get("displayName") or info.get("username") or "")
        if self.api.signed_in:
            self.show("home")
        else:
            self.welcome()

    # -- signed out --

    def welcome(self):
        """Signed out: the app opens and says so. The keyboard comes up only when the person picks Sign in."""
        self.setProperty("greeting", "")
        self.setProperty("hero.title", "Welcome to mediaCENTER")
        self.setProperty("hero.plot", "Sign in to see your movies, shows, live TV and sports.")
        self.getControl(PLAY).setLabel("Sign in")
        self.getControl(INFO).setVisible(False)
        self.mark("home")
        self.setFocusId(PLAY)

    def sign_in(self):
        """Sign in: the phone sign-in page (a QR code and a short code), with the TV keyboard one row down."""
        try:
            from mc_device import DevicePage
            DevicePage.open(self.api, section="signin")
            if not self.api.signed_in:
                return
            info = self.api.check()
        except (ServerError, OSError):
            return xbmcgui.Dialog().ok("mediaCENTER", "Can't reach mediaCENTER right now. Check the internet connection and try again.")
        self.setProperty("account", (info or {}).get("displayName") or (info or {}).get("username") or "")
        self.getControl(PLAY).setLabel("Play")
        self.getControl(INFO).setVisible(True)
        self.show("home")

    # -- screens --

    def mark(self, screen):
        nav = self.getControl(NAV)
        for i, (key, _) in enumerate(MENU):
            nav.getListItem(i).setProperty("active", "1" if key == screen else "")

    def show(self, screen):
        if screen == "guide":
            return GuidePage.open(self.api)
        if screen == "sports":
            return ListPage.open(self.api, screen)
        if screen in ("movies", "shows"):
            return BrowsePage.open(self.api, "movie" if screen == "movies" else "series")
        if screen == "search":
            return SearchPage.open(self.api)
        if screen == "settings":
            return self.settings()
        rows = []
        try:
            busy(True)
            if screen == "home":
                rows = self.home_rows()
            elif screen == "library":
                rows = self.library_rows()
        except SignedOut:
            busy(False)
            self.api.forget()
            xbmcgui.Dialog().ok("mediaCENTER", "Your session ended. Sign in again.")
            return self.close()
        except (ServerError, OSError):
            rows = []
            self.setProperty("empty", "Can't reach mediaCENTER right now. Check the internet connection and try again.")
        finally:
            busy(False)
        self.screen = screen
        self.mark(screen)
        self.fill(rows)
        if screen == "home":
            who = self.getProperty("account")
            self.setProperty("greeting", L.greeting(datetime.datetime.now().hour) + (", " + who if who else ""))
        else:
            self.setProperty("greeting", {"library": "Library"}.get(screen, ""))

    def fill(self, rows):
        rows = [r for r in rows if r[1]][:len(ROW_IDS)]
        self.rows = {}
        for i, lid in enumerate(ROW_IDS):
            control = self.getControl(lid)
            control.reset()
            if i < len(rows):
                title, items = rows[i]
                control.addItems(items)
                self.setProperty("row.%d.title" % (i + 1), title)
                self.rows[lid] = title
            else:
                self.clearProperty("row.%d.title" % (i + 1))
        if rows:
            self.clearProperty("empty")
            self.hero(rows[0][1][0])
            self.setFocusId(ROW_IDS[0])
        else:
            self.hero(None)
            if not self.getProperty("empty"):
                self.setProperty("empty", "Nothing here yet.")
            self.setFocusId(NAV)

    def hero(self, li):
        if li is None:
            for k in ("hero.title", "hero.plot", "hero.meta", "hero.fanart"):
                self.clearProperty(k)
            self.hero_item = None
            return
        self.hero_item = li
        self.setProperty("hero.title", li.getLabel())
        self.setProperty("hero.plot", li.getProperty("plot"))
        self.setProperty("hero.meta", li.getProperty("meta"))
        fanart = li.getArt("fanart")
        if fanart:
            self.setProperty("hero.fanart", fanart)

    def home_rows(self):
        answer = V.home_answer(self.api) or {}
        found = {r.get("id"): r for r in answer.get("rows", []) if isinstance(r, dict)}
        history = (self.api.get("/api/history", limit=40, perShow=1) or {}).get("items")
        rows = [("Featured", [title_card(t) for t in L.titles_of(answer.get("hero"), 5)]),
                ("Continue Watching", [continue_card(h) for h in L.continue_items(history)])]
        if "teams" in found:
            rows.append((found["teams"].get("title") or "My Teams", [game_card(g) for g in found["teams"].get("items") or []]))
        if "top" in found:
            rows.append((found["top"].get("title") or "Top 10 today", [title_card(t) for t in L.titles_of(found["top"].get("items"))]))
        seasonal_id, seasonal_title = L.seasonal_row()
        try:
            seasonal = L.titles_of((self.api.get("/meta/row", type="movie", row=seasonal_id) or {}).get("items"))
        except ServerError:
            seasonal = []
        rows.append((seasonal_title, [title_card(t) for t in seasonal]))
        for key in ("movies", "shows"):
            if key in found:
                rows.append((found[key].get("title"), [title_card(t) for t in L.titles_of(found[key].get("items"))]))
        rows.append(("My List", [title_card(t) for t in L.titles_of(V.my_list(self.api))]))
        try:
            import mc_opening
            mc_opening.remember([li.getArt("poster") for _, items in rows for li in items])
        except Exception:
            pass
        return rows

    def library_rows(self):
        def first(kind, row_id):
            try:
                return L.titles_of((self.api.get("/meta/row", type=kind, row=row_id) or {}).get("items"))
            except ServerError:
                return []
        return [("My List", [title_card(t) for t in L.titles_of(V.my_list(self.api))]),
                ("Movies · New", [title_card(t) for t in first("movie", "new")]),
                ("TV Shows · New Series", [title_card(t) for t in first("series", "new")]),
                ("Movies · Action", [title_card(t) for t in first("movie", "genre:28")]),
                ("Movies · Comedy", [title_card(t) for t in first("movie", "genre:35")]),
                ("TV Shows · Netflix", [title_card(t) for t in first("series", "network:213")]),
                ("TV Shows · HBO", [title_card(t) for t in first("series", "network:49")]),
                ("Movies · Family", [title_card(t) for t in first("movie", "genre:10751")])]

    def settings(self):
        """Settings: mediaCENTER's own page (mc_device). Home is drawn again only when the account changed."""
        from mc_device import DevicePage
        result = DevicePage.open(self.api)
        if result in ("exit", "update"):
            return self.close()
        if result == "signed_out" or not self.api.signed_in:
            self.setProperty("account", "")
            self.fill([])  # the last account's rows go too
            self.clearProperty("empty")
            return self.welcome()
        if result == "signed_in":
            try:
                info = self.api.check() or {}
            except (ServerError, OSError):
                info = {}
            self.setProperty("account", info.get("displayName") or self.api.username)
            self.getControl(PLAY).setLabel("Play")
            self.getControl(INFO).setVisible(True)
            self.show("home")

    # -- input --

    def onClick(self, control_id):
        if not self.api.signed_in:
            if control_id == NAV and MENU[self.getControl(NAV).getSelectedPosition()][0] == "settings":
                return self.settings()
            if control_id in (NAV, PLAY):
                return self.sign_in()
            return
        if control_id == NAV:
            key = MENU[self.getControl(NAV).getSelectedPosition()][0]
            if key == "library":
                return self.library_menu()
            return self.show(key)
        if control_id in (PLAY, INFO) and self.hero_item is not None:
            return self.open_item(self.hero_item, play_now=control_id == PLAY)
        if control_id in ROW_IDS:
            li = self.getControl(control_id).getSelectedItem()
            if li is not None:
                self.open_item(li)

    def library_menu(self):
        choice = xbmcgui.Dialog().select("Library", ["Everything", "Movies", "TV Shows", "My List", "Live TV"])
        if choice == 0:
            self.show("library")
        elif choice == 1:
            BrowsePage.open(self.api, "movie")
        elif choice == 2:
            BrowsePage.open(self.api, "series")
        elif choice == 3:
            self.show("library")
        elif choice == 4:
            GuidePage.open(self.api)

    def open_item(self, li, play_now=False):
        return open_item(self.api, li, play_now, win=self)

    def onAction(self, action):
        a = action.getId()
        if a in BACK:
            focus = self.getFocusId()
            if focus in ROW_IDS or focus in (PLAY, INFO, BUTTONS, ROWS):
                return self.setFocusId(NAV)
            if self.screen != "home":
                return self.show("home")
            from mc_device import on_device
            if on_device():
                # On the box, Home is where Back ends: there is nothing behind mediaCENTER. Restart and Turn off are in
                # Settings.
                return self.setFocusId(NAV)
            if xbmcgui.Dialog().yesno("mediaCENTER", "Exit mediaCENTER?", nolabel="Stay", yeslabel="Exit"):
                self.close()
            return
        if a in MOVES:
            focus = self.getFocusId()
            if focus in ROW_IDS:
                li = self.getControl(focus).getSelectedItem()
                if li is not None:
                    self.hero(li)


def open_item(api, li, play_now=False, win=None):
    """Selecting a card anywhere: a title opens its page (Play on a movie plays), the rest play. win: the page it was
    chosen on, which gets its highlight back after playing."""
    focus = win.getFocusId() if win is not None else None
    result = _open_item(api, li, play_now)
    if win is not None and focus and (li.getProperty("kind") != "title" or play_now):
        refocus(win, focus)
    return result


def _open_item(api, li, play_now=False):
    import mc_player as P
    kind = li.getProperty("kind")
    if kind == "title":
        if play_now and li.getProperty("type") == "movie":
            return P.play_title(api, "movie", li.getProperty("tmdb"))
        return TitlePage.open(api, li.getProperty("type"), li.getProperty("tmdb"))
    if kind == "continue":
        if li.getProperty("type") == "series":
            return P.play_title(api, "series", li.getProperty("tmdb"), int(li.getProperty("season") or 1), int(li.getProperty("episode") or 1))
        return P.play_title(api, "movie", li.getProperty("tmdb"))
    if kind == "game":
        return watch_game(api, li.getProperty("id"))
    if kind == "channel":
        return P.play_channel(api, li.getProperty("id"), li.getLabel(), now_title=li.getLabel2())


def put_rows(win, rows):
    """Fill a page's poster rows (501..508) from [(title, [ListItem])]; returns how many rows have posters."""
    rows = [r for r in rows if r[1]][:len(ROW_IDS)]
    for i, lid in enumerate(ROW_IDS):
        control = win.getControl(lid)
        control.reset()
        if i < len(rows):
            control.addItems(rows[i][1])
            if rows[i][0]:
                win.setProperty("row.%d.title" % (i + 1), rows[i][0])
            else:
                win.clearProperty("row.%d.title" % (i + 1))
        else:
            win.clearProperty("row.%d.title" % (i + 1))
    show_details(win, rows[0][1][0] if rows else None)
    return len(rows)


def show_details(win, li):
    """The highlighted poster's name and details along the bottom of the Movies, TV Shows and Search pages."""
    win.setProperty("focus.title", li.getLabel() if li is not None else "")
    win.setProperty("focus.meta", (li.getProperty("meta") or li.getLabel2()) if li is not None else "")


class RowsPage(xbmcgui.WindowXMLDialog):
    """What the Movies, TV Shows and Search pages share: poster rows on the right, Back to the left side, then out."""
    SIDE = 60

    def onClick(self, control_id):
        if control_id in ROW_IDS:
            li = self.getControl(control_id).getSelectedItem()
            if li is not None:
                open_item(self.api, li, win=self)

    def onAction(self, action):
        a = action.getId()
        focus = self.getFocusId()
        if a in BACK:
            if focus in ROW_IDS or focus == ROWS or focus in WORD_KEYS:
                return self.setFocusId(self.SIDE)
            return self.close()
        if a in MOVES and focus in ROW_IDS:
            show_details(self, self.getControl(focus).getSelectedItem())


# ---- Movies and TV Shows (as on the Roku: genres down the left, rows from /api/browse) --------------------------------

def browse_rows(answer):
    return [(r.get("title") or "", [title_card(t) for t in L.titles_of(r.get("items"))]) for r in (answer or {}).get("rows") or [] if isinstance(r, dict)]


def genre_rows(name, items, per_row=7):
    """A genre's titles as rows that fill the screen, the genre's name on the first."""
    cards = [title_card(t) for t in L.titles_of(items, per_row * len(ROW_IDS))]
    return [(name if i == 0 else "", cards[i:i + per_row]) for i in range(0, len(cards), per_row)]


class BrowsePage(RowsPage):
    SIDE = 60

    @classmethod
    def open(cls, api, kind):
        w = cls("mediacenter-browse.xml", V.HERE, "Default", "1080i")
        w.api, w.kind = api, kind
        w.doModal()
        del w

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started = True
        self.setProperty("heading", "Movies" if self.kind == "movie" else "TV Shows")
        self.page_rows, self.genres = [], []
        busy(True)
        try:
            answer = self.api.get("/api/browse", kind=self.kind) or {}
            self.page_rows = browse_rows(answer)
            self.genres = [g for g in answer.get("genres") or [] if isinstance(g, dict) and g.get("id")]
        except SignedOut:
            self.setProperty("empty", "Your session ended. Sign in again from Settings.")
        except (ServerError, OSError):
            self.setProperty("empty", "Couldn't load this page. Try again in a moment.")
        finally:
            busy(False)
        try:
            import mc_opening
            mc_opening.remember([li.getArt("poster") for _, items in self.page_rows for li in items])
        except Exception:
            pass
        chips = self.getControl(60)
        chips.reset()
        chips.addItems([xbmcgui.ListItem("All")] + [xbmcgui.ListItem(g.get("name", "")) for g in self.genres])
        self.draw(self.page_rows, 0, "")

    def draw(self, rows, chip, sub):
        chips = self.getControl(60)
        for i in range(chips.size()):
            chips.getListItem(i).setProperty("active", "1" if i == chip else "")
        self.setProperty("sub", sub)
        if put_rows(self, rows):
            self.clearProperty("empty")
            self.setFocusId(ROW_IDS[0])
        else:
            if not self.getProperty("empty"):
                self.setProperty("empty", "Nothing here right now.")
            self.setFocusId(60)

    def onClick(self, control_id):
        if control_id != 60:
            return RowsPage.onClick(self, control_id)
        i = self.getControl(60).getSelectedPosition()
        if i == 0:
            self.clearProperty("empty")
            return self.draw(self.page_rows, 0, "")
        if i - 1 >= len(self.genres):
            return
        genre = self.genres[i - 1]
        name = genre.get("name", "")
        busy(True)
        try:
            items = (self.api.get("/api/browse", kind=self.kind, genre=str(genre["id"])) or {}).get("items")
        except (ServerError, SignedOut, OSError):
            items = None
        finally:
            busy(False)
        if items is None:
            return self.setProperty("sub", "Couldn't load %s. Try again in a moment." % name)
        rows = genre_rows(name, items)
        if not rows:
            return self.setProperty("sub", "Nothing in %s right now." % name)
        self.clearProperty("empty")
        self.draw(rows, i, name)


# ---- Search (its own page: letters on screen, results as you type) ---------------------------------------------------

KEYS = [chr(c) for c in range(ord("a"), ord("z") + 1)] + [str(d) for d in range(10)]
WORD_KEYS = {71: "Space", 72: "Delete", 73: "Clear"}  # the buttons under the letters
HINT = "Search movies, shows, channels and teams."


class SearchPage(RowsPage):
    SIDE = 70
    WAIT = 0.6  # seconds after the last letter before searching, as on the Roku; 0 searches at once (tests)

    @classmethod
    def open(cls, api):
        w = cls("mediacenter-search.xml", V.HERE, "Default", "1080i")
        w.api = api
        w.doModal()
        del w

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started = True
        self.query, self.ticket, self.lock = "", 0, threading.Lock()
        self.setProperty("heading", "Search")
        self.setProperty("query", "")
        keys = self.getControl(70)
        keys.reset()
        keys.addItems([xbmcgui.ListItem(k) for k in KEYS])
        self.before_typing()
        self.setFocusId(70)

    def before_typing(self):
        """Nothing typed yet: Top 10 today from Home (as the Roku shows), or just the hint."""
        self.setProperty("status", HINT)
        top = []
        try:
            found = {r.get("id"): r for r in (V.home_answer(self.api) or {}).get("rows", []) if isinstance(r, dict)}
            if "top" in found:
                top = [(found["top"].get("title") or "Top 10 today", [title_card(t) for t in L.titles_of(found["top"].get("items"), 10)])]
        except (ServerError, SignedOut, OSError):
            pass
        put_rows(self, top)

    def press(self, key):
        if key == "Space":
            self.query = (self.query + " ") if self.query and not self.query.endswith(" ") else self.query
        elif key == "Delete":
            self.query = self.query[:-1]
        elif key == "Clear":
            self.query = ""
        else:
            self.query = (self.query + key)[:60]
        self.setProperty("query", self.query)
        self.ticket += 1
        if self.WAIT:
            timer = threading.Timer(self.WAIT, self.search, args=(self.ticket,))
            timer.daemon = True
            timer.start()
        else:
            self.search(self.ticket)

    def search(self, ticket):
        """Runs for the newest letters only; an answer that comes back after more typing is dropped."""
        if ticket != self.ticket:
            return
        q = self.query.strip()
        if not q:
            return self.before_typing()
        if len(q) < 2:
            self.setProperty("status", "Keep typing…")
            return
        self.setProperty("status", "Searching…")
        try:
            answer = self.api.get("/api/roku/search", q=q) or {}
        except SignedOut:
            answer, status = None, "Your session ended. Sign in again from Settings."
        except (ServerError, OSError):
            answer, status = None, "Can't reach mediaCENTER right now. Check the internet connection and try again."
        with self.lock:
            if ticket != self.ticket:
                return
            if answer is None:
                put_rows(self, [])
                return self.setProperty("status", status)
            rows = [("Movies and Shows", [title_card(t) for t in L.titles_of(answer.get("titles"))]),
                    ("Live TV", [channel_card(c) for c in answer.get("channels") or []]),
                    ("Teams and games", [game_card(g) for g in answer.get("games") or []])]
            found = put_rows(self, rows)
            self.setProperty("status", "" if found else u"Nothing found for “%s”." % q)

    def onClick(self, control_id):
        if control_id == 70:
            i = self.getControl(70).getSelectedPosition()
            if 0 <= i < len(KEYS):
                self.press(KEYS[i])
            return
        if control_id in WORD_KEYS:
            return self.press(WORD_KEYS[control_id])
        return RowsPage.onClick(self, control_id)


def watch_game(api, game_id):
    """A game: the channel most likely showing it first, then every other channel that may carry it."""
    answer = V.sports_answer(api) or {}
    game = next((g for g in answer.get("games", []) if str(g.get("id")) == str(game_id)), None)
    chans = (game or {}).get("channels") or []
    if not chans:
        return xbmcgui.Dialog().ok("mediaCENTER", "No channel is showing this game yet.")
    labels = [("Watch on " if i == 0 else "") + c.get("name", "") + ("  [COLOR grey]%s[/COLOR]" % L.why_line(c.get("why")) if c.get("why") else "")
              for i, c in enumerate(chans)]
    i = xbmcgui.Dialog().select(L.matchup(game) or "Watch", labels)
    if i >= 0:
        import mc_player as P
        P.play_channel(api, chans[i]["id"], chans[i].get("name", ""), [a for a in L.alt_ids(chans[i]).split(",") if a], L.matchup(game))


# ---- a title's page --------------------------------------------------------------------------------------------------

class TitlePage(xbmcgui.WindowXMLDialog):
    @classmethod
    def open(cls, api, kind, tmdb):
        w = cls("mediacenter-title.xml", V.HERE, "Default", "1080i")
        w.api, w.kind, w.tmdb = api, kind, tmdb
        w.doModal()
        del w

    def onInit(self):
        busy(True)
        try:
            answer = self.api.get("/api/roku/title", type=self.kind, tmdb=self.tmdb) or {}
            t = L.title_of(dict(answer.get("title") or {}, type=self.kind, tmdb=self.tmdb)) or {"name": "", "type": self.kind, "tmdb": self.tmdb}
            try:
                m = self.api.get("/meta/title", type=self.kind, tmdb=self.tmdb) or {}
                t["certification"] = str(m.get("certification") or "")
                t["rating"] = str(m.get("imdbRating") or t.get("rating") or "")
            except ServerError:
                pass
            self.t = t
            self.pins = V.my_list(self.api)
            similar = L.titles_of((self.api.get("/meta/similar", type=self.kind, tmdb=self.tmdb) or {}).get("items"))
        except (ServerError, SignedOut, OSError):
            busy(False)
            xbmcgui.Dialog().ok("mediaCENTER", "Couldn't load this title right now.")
            return self.close()
        busy(False)
        parts = [L.title_line(t)]
        if t.get("rating"):
            parts.append("IMDb %s" % t["rating"])
        if t.get("certification"):
            parts.append(t["certification"])
        self.setProperty("title", t.get("name", ""))
        self.setProperty("meta", L.DOT.join(p for p in parts if p))
        self.setProperty("plot", t.get("overview", ""))
        self.setProperty("poster", t.get("poster", ""))
        self.setProperty("fanart", t.get("backdrop", ""))
        self.update_list_label()
        if self.kind == "series":
            self.setProperty("series", "1")
            self.seasons = [int(n) for n in t.get("seasonList") or []] or [1]
            seasons = self.getControl(401)
            seasons.addItems([xbmcgui.ListItem("Season %d" % n) for n in self.seasons])
            self.update_play_label()
            self.load_season(self.target[1] if self.target[1] in self.seasons else self.seasons[0])
        else:
            self.update_play_label()
            self.getControl(501).addItems([title_card(x) for x in similar])
        self.setFocusId(301)

    def update_play_label(self):
        """Play on a show: the episode left part-way, else the next one, else the first (owner, 2026-11-25: "Play S1 E1"
        always played the first). On a movie left part-way it says Resume."""
        try:
            hist = (self.api.get("/api/history", limit=300) or {}).get("items") or []
        except (ServerError, SignedOut, OSError):
            hist = []
        import mc_player as P
        if self.kind == "series":
            self.target = P.play_target(hist, self.tmdb, getattr(self, "seasons", [1]))
            self.setProperty("play", self.target[0])
            return
        row = next((h for h in hist if h.get("itemId") == L.history_key("movie", self.tmdb)), None)
        part = row and not row.get("finished") and float(row.get("position") or 0) >= 30
        self.target = ("Resume" if part else "Play", None, None, bool(part))
        self.setProperty("play", self.target[0])

    def update_list_label(self):
        self.setProperty("listlabel", "Remove from My List" if L.is_pinned(self.pins, self.t) else "Add to My List")

    def load_season(self, n):
        """A season's episodes with their pictures (/meta/episodes, as the web's episode cards; /api/roku/episodes when
        that has nothing): "N. name", then "S1 E1 · 45 min · Mar 3, 2024" or when it airs, and the description."""
        self.season = n
        eps = []
        try:
            eps = (self.api.get("/meta/episodes", tmdb=self.tmdb, season=n) or {}).get("episodes") or []
        except (ServerError, SignedOut, OSError):
            eps = []
        if not eps:
            try:
                eps = (self.api.get("/api/roku/episodes", tmdb=self.tmdb, season=n) or {}).get("episodes") or []
            except (ServerError, SignedOut, OSError):
                eps = []
        control = self.getControl(402)
        control.reset()
        today = datetime.date.today().isoformat()
        for e in eps:
            num = int(e.get("n") or 0)
            air = str(e.get("air") or "")[:10]
            later = bool(air) and air > today
            facts = ["S%d E%d" % (n, num)]
            if e.get("runtime"):
                facts.append("%s min" % e["runtime"])
            if air:
                facts.append(("Airs " if later else "") + L.date_text(air))
            li = xbmcgui.ListItem("%d. %s" % (num, e.get("name") or "Episode %d" % num), L.DOT.join(facts))
            li.setArt({"thumb": L.picture(e.get("still"), "w300") if e.get("still") else ""})
            li.setProperties({"episode": str(num), "plot": (e.get("overview") or "")[:220], "later": "1" if later else "",
                              "tag": "Not out yet" if later else ""})
            control.addItem(li)

    def play_and_return(self, season=None, episode=None, choose=False):
        """Play on top of this page; when it ends the page is still here, with its labels brought up to date."""
        import mc_player as P
        focus = self.getFocusId()
        P.play_title(self.api, self.kind, self.tmdb, season, episode, choose=choose)
        self.update_play_label()
        refocus(self, focus or 301)

    def onClick(self, control_id):
        if control_id in (301, 302):
            if self.kind == "series":
                return self.play_and_return(self.target[1], self.target[2], choose=control_id == 302)
            return self.play_and_return(choose=control_id == 302)
        if control_id == 303:
            self.pins, pinned = L.toggle_pin(self.pins, self.t)
            try:
                self.api.call("PUT", "/api/prefs", body={"prefs": {"myList": {"value": self.pins, "updatedAt": int(time.time() * 1000)}}})
                V.notify(("Added to My List" if pinned else "Removed from My List"))
            except (ServerError, SignedOut, OSError):
                V.notify("Couldn't change My List right now.")
            return self.update_list_label()
        if control_id == 401:
            label = self.getControl(401).getSelectedItem().getLabel()
            return self.load_season(int(label.split()[-1]))
        if control_id == 402:
            li = self.getControl(402).getSelectedItem()
            if li is None:
                return
            if li.getProperty("later"):
                return V.notify("This episode isn't out yet.")
            return self.play_and_return(self.season, int(li.getProperty("episode")))
        if control_id == 501:
            li = self.getControl(501).getSelectedItem()
            self.close()
            return TitlePage.open(self.api, li.getProperty("type"), li.getProperty("tmdb"))

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()



# ---- Guide (the web app's guide: channels down, two and a half hours across) -----------------------------------------

class GuidePage(xbmcgui.WindowXMLDialog):
    """web-v27/js/views/guide.js as the Roku draws it (roku/components/screens/GuideScreen.brs), in mediaCENTER's own
    window instead of Kodi's TV guide: the channel groups as pills (Local first, All, Favorites, Recent, then the
    provider's groups), the half-hour ruler with a line at now, six channel rows with logos, and what the highlighted
    programme is about at the top. Up and Down move between channels, Left and Right from show to show (the hours move
    at the edge). OK on a show on now plays the channel; on a later one it says when it starts. The context menu key
    adds or removes a favorite (shared with the other apps through /api/prefs, as favoriteChannels)."""
    GRID, PILLS = 300, 800
    G = {"left": 96, "chw": 380, "ruler": 392, "rows": 6, "cells": 8, "pills": 30}
    G["width"] = 1920 - 48 - G["left"] - G["chw"]
    PPM = G["width"] / (L.GUIDE_SPAN / 60.0)
    ready = False  # Kodi can report focus before onInit has loaded anything

    @classmethod
    def open(cls, api):
        w = cls("mediacenter-guide.xml", V.HERE, "Default", "1080i")
        w.api = api
        w.doModal()
        del w

    def onInit(self):
        self.now = time.time()
        self.start = L.window_start(self.now)
        self.cursor = self.now
        self.row, self.top = 0, 0
        self.placed = {}
        self.channels, self.list, self.guide, self.categories = [], [], {}, []
        self.favorites, self.recent, self.hidden = [], [], set()
        busy(True)
        try:
            self.load()
        except SignedOut:
            self.setProperty("empty", "Your session ended. Sign in again.")
        except (ServerError, OSError, ValueError):
            self.setProperty("empty", "Couldn't load the TV guide. Try again in a moment.")
        finally:
            busy(False)
        self.pills = L.category_pills([c for c in self.categories if c["id"] not in self.hidden]) if self.channels else []
        for n in range(1, self.G["pills"] + 1):
            if n <= len(self.pills):
                self.setProperty("pill.%d" % n, self.pills[n - 1]["name"])
            else:
                self.clearProperty("pill.%d" % n)
        saved = self.saved_pill()
        ids = [p["id"] for p in self.pills]
        self.pill = saved if saved in ids else (ids[0] if ids else "all")
        if ids and self.pill != ids[0] and not L.channels_for(self.channels, self.pill, self.favorites, self.recent):
            self.pill = ids[0]  # nothing in the group last chosen (an empty Recent): start on the first group
        self.ready = True
        self.filter()
        self.setFocusId(self.GRID if self.list else (801 if self.pills else self.GRID))

    @staticmethod
    def saved_pill(value=None):
        """The pill last chosen, kept on this box (guide_cat on the web and the Roku)."""
        import os
        path = os.path.join(V.PROFILE, "guide-pill.txt")
        try:
            if value is None:
                with open(path, encoding="utf-8") as f:
                    return f.read().strip()
            if not os.path.isdir(V.PROFILE):
                os.makedirs(V.PROFILE)
            with open(path, "w", encoding="utf-8") as f:
                f.write(value)
        except OSError:
            return ""
        return value

    def load(self):
        streams = self.api.get("/player_api.php", action="get_live_streams", **V.XTREAM) or []
        cats = self.api.get("/player_api.php", action="get_live_categories", **V.XTREAM) or []
        self.categories = [{"id": str(c.get("category_id")), "name": str(c.get("category_name") or "")} for c in cats if isinstance(c, dict)]
        self.channels = L.fold_lineup(streams)
        prefs = {}
        try:
            prefs = (self.api.get("/api/prefs") or {}).get("prefs") or {}
        except (ServerError, OSError):
            pass
        value = lambda key: (prefs.get(key) or {}).get("value") if isinstance(prefs.get(key), dict) else None
        self.favorites = [str(i) for i in value("favoriteChannels") or []]
        self.recent = [str(i) for i in value("recentChannels") or []]
        self.hidden = set(str(i) for i in value("hiddenCategories") or [])
        self.channels = [c for c in self.channels if c["category"] not in self.hidden]
        small = {}
        try:
            small = L.guide_table(self.api.get("/api/roku/guide"))
        except (ServerError, OSError):
            pass
        import os
        import mc_guide
        self.guide = L.merge_guides(small, mc_guide.read_guide(os.path.join(V.PROFILE, "guide", "guide.xml"), self.now))

    # -- what is shown --

    def filter(self):
        self.list = L.channels_for(self.channels, self.pill, self.favorites, self.recent)
        self.row, self.top = 0, 0
        for n, p in enumerate(self.pills, 1):
            self.setProperty("pill.%d.bg" % n, ACCENT if p["id"] == self.pill else CARD)
        self.setProperty("count", "%d channel%s" % (len(self.list), "" if len(self.list) == 1 else "s") if self.channels else "")
        if self.channels and not self.list:
            self.setProperty("empty", {"fav": "No favorites yet. Press the menu key on a channel to add it to Favorites.",
                                       "recent": "Nothing watched yet."}.get(self.pill, "No channels. Try another group."))
        elif self.channels:
            self.clearProperty("empty")
        self.redraw()

    def progs(self, ch):
        return self.guide.get(ch.get("epgId") or "", [])

    def put(self, cid, x, y, w):
        """Move a control only when its place changes (each call to Kodi costs time on a Pi)."""
        if self.placed.get(cid) != (x, y, w):
            self.placed[cid] = (x, y, w)
            control = self.getControl(cid)
            control.setPosition(int(x), int(y))
            control.setWidth(max(1, int(w)))

    def redraw(self):
        g = self.G
        self.now = time.time()
        if self.start + L.GUIDE_SPAN < self.now:
            self.start = L.window_start(self.now)
        self.setProperty("day", L.day_text(max(self.cursor, self.start)))
        for i in range(6):
            t = self.start + i * L.HALF_HOUR
            if i < 5:
                self.setProperty("ruler.%d" % i, L.clock_s(t))
                self.put(3000 + i, g["left"] + g["chw"] + (t - self.start) / 60.0 * self.PPM + 8, g["ruler"], 200)
            else:
                self.clearProperty("ruler.%d" % i)
        away = self.start != L.window_start(self.now)
        self.setProperty("nowpill", ACCENT if away else RAISED)
        self.setProperty("nowtext", "Now")
        if self.list and self.start <= self.now < self.start + L.GUIDE_SPAN:
            self.setProperty("nowline", "1")
            self.put(3020, g["left"] + g["chw"] + (self.now - self.start) / 60.0 * self.PPM, g["ruler"], 3)
        else:
            self.clearProperty("nowline")
        if self.row < self.top:
            self.top = self.row
        if self.row >= self.top + g["rows"]:
            self.top = self.row - g["rows"] + 1
        on_grid = self.getFocusId() == self.GRID
        for r in range(g["rows"]):
            i = self.top + r
            self.draw_row(r, self.list[i] if i < len(self.list) else None, on_grid and i == self.row)
        self.draw_info()

    def draw_row(self, r, ch, current):
        g, p = self.G, "g.%d" % r
        if ch is None:
            for key in ("name", "num", "logo", "badge", "on", "fav"):
                self.clearProperty("%s.%s" % (p, key))
            for c in range(g["cells"]):
                self.clear_cell(r, c)
            return
        self.setProperty(p + ".name", ch.get("name", ""))
        self.setProperty(p + ".num", str(ch.get("num") or ""))
        self.setProperty(p + ".logo", L.picture(ch.get("logo"), "w185"))
        self.setProperty(p + ".badge", L.badge_text(ch.get("name", "")))
        self.setProperty(p + ".chbg", "29FFFFFF" if current else SURFACE)
        self.setProperty(p + ".on", "1" if current else "")
        self.setProperty(p + ".fav", "1" if str(ch["id"]) in self.favorites else "")
        cells = []
        for prog in self.progs(ch):
            box = L.place(prog, self.start, self.PPM)
            if box:
                cells.append((prog, box))
        if not cells:
            cells = [(None, (0, g["width"] - 6))]
        for c in range(g["cells"]):
            if c >= len(cells):
                self.clear_cell(r, c)
                continue
            prog, (x, w) = cells[c]
            self.draw_cell(r, c, prog, x, w, current)

    def clear_cell(self, r, c):
        p = "g.%d.%d" % (r, c)
        for key in ("t", "s", "on", "bar"):
            self.clearProperty("%s.%s" % (p, key))

    def draw_cell(self, r, c, prog, x, w, current):
        p, base = "g.%d.%d" % (r, c), 2000 + r * 100 + 10 + c * 10
        live = prog is None or prog["start"] <= self.now < prog["stop"]
        on = current and (prog is None or prog["start"] <= self.cursor < prog["stop"])
        self.setProperty(p + ".bg", CREAM if on else (RAISED if live else SURFACE))
        self.setProperty(p + ".on", "1" if on else "")
        if prog is None:
            title, sub = "No guide information", ""
        else:
            title = prog["title"] if w >= 56 else ""
            sub = "" if w <= 90 or L.is_filler(prog) else (L.left_text(prog["stop"] - self.now) if live else L.clock_s(prog["start"]))
        self.setProperty(p + ".t", title or " ")
        self.setProperty(p + ".s", sub)
        self.put(base, x, 0, w)
        for k in (1, 2, 3, 4):
            self.put(base + k, x + 16, 10 if k < 3 else 50, w - 28)
        if prog is not None and live:
            pct = min(1.0, max(0.0, (self.now - prog["start"]) / float(max(1, prog["stop"] - prog["start"]))))
            self.setProperty(p + ".bar", "1")
            self.put(base + 5, x, self.CELL - 5, max(2, w * pct))
        else:
            self.clearProperty(p + ".bar")

    CELL = 92

    def current(self):
        return self.list[self.row] if 0 <= self.row < len(self.list) else None

    def draw_info(self):
        ch = self.current()
        if ch is None:
            for key in ("meta", "title", "desc"):
                self.clearProperty("info." + key)
            return
        prog = L.programme_at(self.progs(ch), self.cursor)
        name = " ".join(x for x in [str(ch.get("num") or ""), ch.get("name", "")] if x)
        if prog is None:
            self.setProperty("info.meta", name + ("  ·  Playing. OK again for full screen" if self.tuned == str(ch["id"]) else ""))
            self.setProperty("info.title", ch.get("name", ""))
            self.setProperty("info.desc", "No guide information for this channel yet.")
            return
        live = prog["start"] <= self.now < prog["stop"]
        playing = self.tuned == str(ch["id"]) and live
        self.setProperty("info.meta", ("[COLOR %s][B]LIVE[/B][/COLOR]  ·  " % ACCENT if live else "") + name + "  ·  " +
                         L.clock_s(prog["start"]) + u" – " + L.clock_s(prog["stop"]) + ("  ·  Playing. OK again for full screen" if playing else ""))
        self.setProperty("info.title", prog["title"])
        self.setProperty("info.desc", "No description available." if L.is_filler(prog) or not prog.get("desc") else prog["desc"])

    # -- input --

    def onFocus(self, control_id):
        if not self.ready:
            return
        if control_id == self.GRID and not self.list and self.pills:
            ids = [p["id"] for p in self.pills]  # nothing to move through: stay on the group's pill
            return self.setFocusId(801 + (ids.index(self.pill) if self.pill in ids else 0))
        self.redraw()

    def onClick(self, control_id):
        if 801 <= control_id < 801 + len(self.pills):
            self.pill = self.pills[control_id - 801]["id"]
            self.saved_pill(self.pill)
            return self.filter()
        if control_id == self.GRID:
            return self.choose()

    def choose(self):
        ch = self.current()
        if ch is None:
            return
        prog = L.programme_at(self.progs(ch), self.cursor)
        if prog is not None and prog["start"] > self.now:
            name = " ".join(x for x in [str(ch.get("num") or ""), ch.get("name", "")] if x)
            return V.notify("%s starts at %s on %s" % (prog["title"], L.clock_s(prog["start"]), name))
        self.recent = [str(ch["id"])] + [i for i in self.recent if i != str(ch["id"])][:19]
        self.save_pref("recentChannels", self.recent)
        import mc_player as P
        alts = [a for a in L.alt_ids(ch).split(",") if a]
        now_title = prog["title"] if prog else ""
        if V.ADDON.getSetting("guide_mini") == "false":
            self.stop_mini()
            P.play_channel(self.api, ch["id"], ch.get("name", ""), alts, now_title)
            return self.back_to_grid()
        if self.tuned == str(ch["id"]) and self.mini is not None:
            return self.full_screen(ch, now_title)
        self.tune(ch, alts)

    # -- the mini player (web-v27/js/views/guide.js: a channel chosen in the Guide plays docked; again, full screen) --

    mini = None
    tuned = None

    def tune(self, ch, alts):
        import mc_player as P
        self.stop_mini()
        self.tuned = str(ch["id"])
        V.WINDOW.setProperty("mc.dock", "1")
        self.setProperty("dock.name", " ".join(x for x in [str(ch.get("num") or ""), ch.get("name", "")] if x))
        self.mini = P.Playback(MiniScreen(self))
        try:
            feeds = P.live_feeds(self.api, ch["id"], ch.get("name", ""), alts)
        except SignedOut:
            return self.mini_failed("Your session ended. Sign in again from Settings.")
        if len(feeds) == 1:
            feeds[0]["check"] = None
        self.mini.start(feeds, P.LIVE_STAGES)
        self.redraw()

    def full_screen(self, ch, now_title):
        import mc_player as P
        name = " ".join(x for x in [str(ch.get("num") or ""), ch.get("name", "")] if x)
        result = P.PlayerPage.attach(self.api, self.mini, name, now_title)
        if result == "docked" and self.mini is not None and self.mini.playing:
            self.mini.ui = MiniScreen(self)
            V.WINDOW.setProperty("mc.dock", "1")
        else:
            self.stop_mini()
        self.back_to_grid()

    def back_to_grid(self):
        refocus(self, self.GRID, tries=10 if self.mini is None else 1)
        self.redraw()

    def stop_mini(self):
        if self.mini is not None:
            self.mini.stop()
        self.mini, self.tuned = None, None
        V.WINDOW.clearProperty("mc.dock")
        self.clearProperty("dock.name")

    def mini_failed(self, words=""):
        self.stop_mini()
        V.notify(words or "This channel isn't playing right now.")
        self.redraw()

    def save_pref(self, key, value):
        try:
            self.api.call("PUT", "/api/prefs", body={"prefs": {key: {"value": value, "updatedAt": int(time.time() * 1000)}}})
        except (ServerError, SignedOut, OSError):
            pass

    def toggle_favorite(self):
        ch = self.current()
        if ch is None:
            return
        cid = str(ch["id"])
        if cid in self.favorites:
            self.favorites = [f for f in self.favorites if f != cid]
            V.notify("Removed %s from Favorites" % ch.get("name", ""))
        else:
            self.favorites = self.favorites + [cid]
            V.notify("Added %s to Favorites" % ch.get("name", ""))
        self.save_pref("favoriteChannels", sorted(self.favorites))
        if self.pill == "fav":
            return self.filter()
        self.redraw()

    def onAction(self, action):
        a = action.getId()
        if a in BACK:
            self.stop_mini()
            return self.close()
        if self.getFocusId() != self.GRID or not self.list:
            return
        if a == 3:  # up
            if self.row > 0:
                self.row -= 1
                return self.redraw()
            if self.pills:
                ids = [p["id"] for p in self.pills]
                return self.setFocusId(801 + (ids.index(self.pill) if self.pill in ids else 0))
        elif a == 4:  # down
            self.row = min(len(self.list) - 1, self.row + 1)
            self.redraw()
        elif a in (1, 2):  # left, right
            self.cursor, self.start = L.move_time(self.progs(self.current()), self.cursor, self.start, time.time(), 1 if a == 2 else -1)
            self.redraw()
        elif a in (5, 6):  # page up, page down
            step = self.G["rows"] * (1 if a == 6 else -1)
            self.row = max(0, min(len(self.list) - 1, self.row + step))
            self.redraw()
        elif a in (117, 11):  # context menu, info: favorite
            self.toggle_favorite()


class MiniScreen(object):
    """What the Guide's mini player shows while it works: nothing but the picture; a failure says so in a note."""

    def __init__(self, guide):
        self.guide = guide

    def stage(self, pct, words, detail):
        pass

    def toast(self, words):
        V.notify(words)

    def started(self, feed):
        pass

    def failed(self):
        self.guide.mini_failed()

    def ended(self):
        self.guide.mini_failed("The channel stopped.")

    def stopped(self):
        if self.guide.mini is not None and not self.guide.mini.cancelled:
            self.guide.mini_failed("The channel stopped.")


# ---- Sports (a list with details beside it) ----------------------------------------------------------------

class ListPage(xbmcgui.WindowXMLDialog):
    @classmethod
    def open(cls, api, screen):
        w = cls("mediacenter-list.xml", V.HERE, "Default", "1080i")
        w.api, w.screen = api, screen
        w.doModal()
        del w

    def onInit(self):
        self.tabs = [("all", "All games"), ("live", "Live now"), ("mine", "My Teams")]
        self.setProperty("heading", "Sports")
        current = "all"
        for i in range(1, 5):
            if i <= len(self.tabs):
                self.setProperty("tab.%d" % i, self.tabs[i - 1][1])
            else:
                self.clearProperty("tab.%d" % i)
        self.load(current)

    def load(self, tab):
        control = self.getControl(50)
        control.reset()
        self.clearProperty("empty")
        busy(True)
        try:
            items = self.games(tab)
        except (ServerError, SignedOut, OSError):
            items = []
            self.setProperty("empty", "Couldn't load this right now. Try again in a moment.")
        busy(False)
        control.addItems(items)
        if not items and not self.getProperty("empty"):
            self.setProperty("empty", "No games for your teams right now." if tab == "mine" else "Nothing on right now.")
        self.setFocusId(50 if items else 101)

    def games(self, tab):
        games = (V.sports_answer(self.api) or {}).get("games") or []
        if tab == "live":
            games = [g for g in games if g.get("state") == "in"]
        elif tab == "mine":
            games = [g for g in games if g.get("mine")]
        out = []
        for g in games:
            li = xbmcgui.ListItem(L.score_line(g) or L.matchup(g), L.when(g))
            chans = g.get("channels") or []
            li.setProperties({"num": g.get("league") or "", "id": str(g.get("id")),
                              "eyebrow": ("LIVE · " if g.get("state") == "in" else "") + (g.get("league") or ""),
                              "detail": "\n".join(p for p in [L.matchup(g), L.when(g), "", ("Watch on " + chans[0]["name"]) if chans else "No channel is showing this game yet"] if p is not None)})
            out.append(li)
        return out

    def onClick(self, control_id):
        if 101 <= control_id <= 104:
            return self.load(self.tabs[control_id - 101][0])
        if control_id == 50:
            li = self.getControl(50).getSelectedItem()
            if li is None:
                return
            return watch_game(self.api, li.getProperty("id"))

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()


# ---- start -----------------------------------------------------------------------------------------------------------

RUNNING = "mediacenter.app.open"


def legal():
    """Settings > Legal: the open-source notices, the only place the box names the software it is built on."""
    import os
    with open(os.path.join(V.HERE, "resources", "data", "legal.txt"), encoding="utf-8") as f:
        xbmcgui.Dialog().textviewer("Legal", f.read())


def run():
    # The skin's Home and the service can both ask at start-up; only one app opens.
    if V.WINDOW.getProperty(RUNNING):
        return
    V.WINDOW.setProperty(RUNNING, "1")
    try:
        w = App("mediacenter-home.xml", V.HERE, "Default", "1080i")
        w.doModal()
        del w
    finally:
        V.WINDOW.clearProperty(RUNNING)
