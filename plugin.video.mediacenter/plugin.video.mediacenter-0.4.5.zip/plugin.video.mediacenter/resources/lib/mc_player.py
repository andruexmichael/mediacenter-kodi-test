# mediaCENTER for Kodi: the player, in mediaCENTER's own screen (0.4.5).
#
# Every movie, episode and channel plays here, never through Kodi's own player screens:
#   - a loading screen like the web's TitleLoading (web-v27/js/player.js): the steps with how far along it is, and a
#     rotating line from design/experience.json "loading";
#   - each link is checked before the player opens it (mc_api.link_works / live_plays), links that failed on this box
#     are remembered (mc_versions.FailedLinks) and the next source is tried by itself, as web-v27/js/playvod.js does;
#   - Kodi's "One or more items failed to play" box is closed before it shows; mediaCENTER says what happened and
#     offers what to do next;
#   - controls like the web player and the Roku's PlayerScreen: title and clock at the top, the bar and the buttons at
#     the bottom, Left/Right to skip 10 seconds; Up Next after an episode.
#
# The picture is drawn by a videowindow control in this page (windowed playback), so the page that opened the player
# stays where it was underneath: Back after a film or a channel returns to the same title page or Guide position (owner,
# 2026-11-25: it used to drop to Home). The Guide uses the same Playback for its mini player.
#
# Progress is saved by service.py as before: PLAYING_KEY says what is playing and where to start.

import json
import os
import threading
import time

try:
    import queue
except ImportError:  # pragma: no cover
    import Queue as queue

import xbmc
import xbmcgui

import mc_logic as L
import mc_versions as MV
import mc_views as V
from mc_api import SignedOut, ServerError

# The web's loading steps (player.js TitleLoading), as (percent, words).
STAGES = [(0, "Finding your title"), (15, "Checking the available links"), (25, "Picking the best source"),
          (40, "Connecting to the stream"), (65, "Buffering the first scenes"), (90, "Starting playback")]
LIVE_STAGES = [(0, "Finding the channel"), (15, "Checking the feed"), (40, "Connecting to the stream"),
               (65, "Buffering"), (90, "Starting playback")]
START_WAIT = 45  # seconds a link gets to show a picture before the next one is tried
HUD_SECONDS = 5
UP_NEXT_SECONDS = 10
CACHE_SECONDS = 600  # versions found for a title are reused for 10 minutes (the versions page and the player share them)

VOD_FAILED = "This version didn't start."
LIVE_FAILED = "This channel isn't playing right now."

# Kodi action ids
LEFT, RIGHT, UP, DOWN, SELECT = 1, 2, 3, 4, 7
BACK = (9, 10, 92, 247)
PAUSE, STOP, NEXT_ITEM, PREV_ITEM, FORWARD, REWIND, PLAYPAUSE, PLAY = 12, 13, 14, 15, 77, 78, 229, 68
MENU_KEYS = (11, 117)  # info, context menu

# Control ids in mediacenter-player.xml (kodi/tools/make_windows.py player_window)
HUD = 600
B_BACK10, B_PLAYPAUSE, B_FWD10, B_NEXT, B_AUDIO, B_SUBS, B_VERSIONS = 601, 602, 603, 604, 605, 606, 607
ERR = 700
E_OTHER, E_RETRY, E_NEXT, E_CLOSE = 701, 702, 703, 704
ASK = 800
A_RESUME, A_START = 801, 802
UPNEXT = 900
U_PLAY, U_CANCEL = 901, 902

HOME_PROPS = ("mc.dock", "mc.full")


# ---- pure helpers (tested off the box) ---------------------------------------------------------------------------------

def stage_text(stages, pct):
    """The step a percentage is at, and every step marked done, now or to come (✓ ● ○ on the screen)."""
    current = 0
    for i, (p, _) in enumerate(stages):
        if pct >= p:
            current = i
    return [(words, "done" if i < current else "now" if i == current else "todo") for i, (_, words) in enumerate(stages)]


MARK = {"done": u"✓", "now": u"●", "todo": u"○"}


def loading_lines(kind):
    lines = ((V.experience().get("loading") or {}).get("live" if kind == "live" else "movie") or {}).get("lines") or []
    return lines or [u"Starting in a moment…"]


def next_episode(season, episode, episodes_of, seasons):
    """The episode after (season, episode): the next in the season, else the next season's first. episodes_of(n) gives
    that season's episode numbers (aired ones only). Returns (season, episode) or None."""
    eps = sorted(int(n) for n in episodes_of(season) or [])
    later = [n for n in eps if n > int(episode)]
    if later:
        return int(season), later[0]
    for s in sorted(int(x) for x in seasons or []):
        if s > int(season):
            nxt = sorted(int(n) for n in episodes_of(s) or [])
            if nxt:
                return s, nxt[0]
    return None


def play_target(history, tmdb, seasons):
    """What Play does on a show's page, as on the web (vod.js): the episode left part-way ("Resume S1 E2"), else the one
    after the last one finished ("Play S1 E3"), else the first ("Play S1 E1"). Returns (label, season, episode, resume)."""
    first = (sorted(int(s) for s in seasons or [1]) or [1])[0]
    rows = [h for h in history or [] if str(h.get("seriesId") or "") == "tmdb-%s" % tmdb and h.get("season") is not None]
    if not rows:
        return "Play S%d E1" % first, first, 1, False
    last = max(rows, key=lambda h: (float(h.get("updatedAt") or 0), int(h.get("season") or 0), int(h.get("episode") or 0)))
    s, e = int(last["season"]), int(last["episode"])
    if not last.get("finished") and float(last.get("position") or 0) >= 30:
        return "Resume S%d E%d" % (s, e), s, e, True
    if last.get("finished"):
        return "Play S%d E%d" % (s, e + 1), s, e + 1, False
    return "Play S%d E%d" % (s, e), s, e, False


def split_versions(versions, caps):
    """(versions this box plays, best first; versions it may not play)."""
    ranked, _ = L.rank_versions(versions, caps)
    others = [v for v in versions or [] if L.play_level(v, caps) == "no"]
    return ranked, others


_found = {}


def found_versions(api, kind, tmdb, season=None, episode=None, now=time.time):
    """Every version of a title (mc_play.gather), kept for 10 minutes so the versions page and the player agree."""
    import mc_play
    key = (kind, str(tmdb), str(season or ""), str(episode or ""))
    hit = _found.get(key)
    if hit and now() - hit[0] < CACHE_SECONDS:
        return hit[1], hit[2]
    versions, name = mc_play.gather(api, kind, tmdb, season, episode)
    _found[key] = (now(), versions, name)
    return versions, name


def forget_found():
    _found.clear()


def busy(on):
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)" if on else "Dialog.Close(busydialognocancel)")


def failed_links():
    return MV.FailedLinks(V.PROFILE)


# ---- Playback: one try after another, with Kodi's own messages kept off the screen ---------------------------------------

class Watcher(xbmc.Player):
    def __init__(self, owner):
        super(Watcher, self).__init__()
        self.owner = owner

    def onAVStarted(self):
        self.owner.event("started")

    def onPlayBackError(self):
        self.owner.event("error")

    def onPlayBackStopped(self):
        self.owner.event("stopped")

    def onPlayBackEnded(self):
        self.owner.event("ended")


def close_kodi_messages():
    """Kodi's own "failed to play" box and its busy spinner: closed as soon as they appear (the rig showed this keeps
    them off the screen). Returns True when the failure box was there."""
    seen = False
    if xbmc.getCondVisibility("Window.IsActive(okdialog)"):
        xbmc.executebuiltin("Dialog.Close(okdialog,true)")
        seen = True
    if xbmc.getCondVisibility("Window.IsActive(busydialog)"):
        xbmc.executebuiltin("Dialog.Close(busydialog,true)")
    return seen


class Playback(object):
    """Plays a list of feeds in order until one shows a picture. ui gets: stage(pct, words, detail), toast(words),
    started(feed), failed(), ended(), stopped(). Feeds are dicts: url, li, key (for FailedLinks), check (a function
    giving True/False/None, or None to skip the check), entry (what service.py saves, or None), resume."""

    def __init__(self, ui, windowed=True):
        self.ui = ui
        self.windowed = windowed
        self.q = queue.Queue()
        self.player = Watcher(self)
        self.cancelled = False
        self.playing = None  # the feed that is showing
        self.thread = None
        self.remembered = []

    def event(self, name):
        self.q.put(name)

    def drain(self):
        while True:
            try:
                self.q.get_nowait()
            except queue.Empty:
                return

    def start(self, feeds, stages=STAGES):
        self.cancelled = False
        self.thread = threading.Thread(target=self.run, args=(list(feeds), stages))
        self.thread.daemon = True
        self.thread.start()

    def stop(self):
        """Stop playing and stop trying (Back, Close, leaving the Guide)."""
        self.cancelled = True
        self.playing = None
        V.WINDOW.clearProperty(V.PLAYING_KEY)
        try:
            if self.player.isPlaying():
                self.player.stop()
        except RuntimeError:
            pass

    def remember(self, feed, why):
        if feed.get("key"):
            failed_links().remember(feed["key"], why)
            self.remembered.append(feed["key"])

    def run(self, feeds, stages):
        n = len(feeds)
        for i, feed in enumerate(feeds):
            if self.cancelled:
                return
            check = feed.get("check")
            if check is not None:
                self.ui.stage(stages[1][0], stages[1][1], "%d of %d" % (i + 1, n) if n > 1 else "")
                ok = check()
                if self.cancelled:
                    return
                if ok is False:
                    V.log("link %d of %d does not answer; next" % (i + 1, n))
                    self.remember(feed, "dead")
                    continue
            if i:
                self.ui.toast("Trying the next source")
            result = self.try_one(feed, stages)
            if result == "started":
                return self.watch(feed)
            if self.cancelled:
                return
            V.log("link %d of %d did not start (%s)" % (i + 1, n, result))
            self.remember(feed, "couldn't be played" if result == "failed" else "temporary")
        if not self.cancelled:
            self.ui.failed()

    def try_one(self, feed, stages):
        if self.player.isPlaying():
            self.player.stop()
            end = time.time() + 3
            while self.player.isPlaying() and time.time() < end:
                xbmc.sleep(50)
        self.drain()
        self.ui.stage(stages[-3][0], stages[-3][1], "")
        if feed.get("entry"):
            V.WINDOW.setProperty(V.PLAYING_KEY, json.dumps({"entry": feed["entry"], "resume": feed.get("resume") or 0}))
        else:
            V.WINDOW.clearProperty(V.PLAYING_KEY)
        self.player.play(feed["url"], feed["li"], self.windowed)
        began, buffering = time.time(), False
        while time.time() - began < START_WAIT:
            if self.cancelled:
                return "cancelled"
            if close_kodi_messages():
                return "failed"
            try:
                e = self.q.get(timeout=0.05)
            except queue.Empty:
                e = None
            if e == "started":
                self.playing = feed
                return "started"
            if e in ("error", "stopped", "ended"):
                # Stopping before any picture is how Kodi says a link failed (onPlayBackError rarely comes).
                end = time.time() + 1.5
                while time.time() < end:  # its "failed to play" box comes a moment later
                    close_kodi_messages()
                    xbmc.sleep(50)
                return "failed"
            if not buffering and time.time() - began > 2:
                buffering = True
                self.ui.stage(stages[-2][0], stages[-2][1], "")
        self.player.stop()
        return "timeout"

    def watch(self, feed):
        self.ui.stage(100, "", "")
        self.ui.started(feed)
        while not self.cancelled:
            try:
                e = self.q.get(timeout=0.25)
            except queue.Empty:
                close_kodi_messages()
                continue
            if self.cancelled:
                return
            if e == "ended":
                self.playing = None
                return self.ui.ended()
            if e in ("stopped", "error"):
                self.playing = None
                return self.ui.stopped()


# ---- feeds for movies, episodes and channels ---------------------------------------------------------------------------

def vod_feeds(api, versions, pick, t, season, episode, episode_name, resume):
    """The links to try for a movie or episode (mc_versions.feeds), each checked first."""
    failed = failed_links()
    entry = L.history_entry(t, season, episode, episode_name)
    out = []
    for v in MV.feeds(versions, pick, failed.has):
        url = api.kodi_url(v["url"], cookie=bool(v.get("cookie")))
        li = xbmcgui.ListItem(episode_name or t.get("name", ""), path=url)
        li.setArt({"poster": t.get("poster"), "thumb": t.get("poster"), "fanart": t.get("backdrop")})
        info = {"title": episode_name or t.get("name", ""), "mediatype": "episode" if t.get("type") == "series" else "movie",
                "plot": t.get("overview", "")}
        if t.get("type") == "series":
            info.update(tvshowtitle=t.get("name", ""), season=season, episode=episode)
        V.set_info(li, info)
        if v.get("container") == "m3u8" or ".m3u8" in url.split("|")[0]:
            li.setMimeType("application/vnd.apple.mpegurl")
            li.setContentLookup(False)
        out.append({"url": url, "li": li, "key": MV.link_key(v), "version": v, "entry": entry, "resume": resume,
                    "check": (lambda u=url: api.link_works(u)[0])})
    return out


def live_feeds(api, channel_id, name, alts):
    """A channel and its backup feeds (up to five), each checked first, as the web player switches by itself."""
    out = []
    for sid in [str(channel_id)] + [a for a in (alts or []) if str(a).isdigit()][:5]:
        try:
            url = api.live_url(sid)
        except ValueError:
            continue
        li = xbmcgui.ListItem(name or "Live TV", path=url)
        li.setMimeType("application/vnd.apple.mpegurl")
        li.setContentLookup(False)
        V.set_info(li, {"title": name or "Live TV", "mediatype": "video"})
        out.append({"url": url, "li": li, "key": "", "entry": None, "resume": 0, "id": sid,
                    "check": (lambda s=sid: api.live_plays(s))})
    return out


# ---- the player page ---------------------------------------------------------------------------------------------------

class PlayerPage(xbmcgui.WindowXMLDialog):
    """The full-screen player (mediacenter-player.xml). Opened with one of the classmethods below."""

    @classmethod
    def movie(cls, api, kind, tmdb, season=None, episode=None, pick=None, fresh=False):
        w = cls("mediacenter-player.xml", V.HERE, "Default", "1080i")
        w.setup(api, "vod")
        w.kind, w.tmdb, w.season, w.episode, w.pick, w.fresh = kind, str(tmdb), season, episode, pick, fresh
        w.doModal()
        result = w.result
        del w
        return result

    @classmethod
    def live(cls, api, channel_id, name="", alts=None, now_title=""):
        w = cls("mediacenter-player.xml", V.HERE, "Default", "1080i")
        w.setup(api, "live")
        w.channel_id, w.channel_name, w.alts, w.now_title = str(channel_id), name, list(alts or []), now_title
        w.doModal()
        result = w.result
        del w
        return result

    @classmethod
    def attach(cls, api, playback, name="", now_title=""):
        """Full screen for what the Guide's mini player is showing; Back returns to the Guide with it still playing."""
        w = cls("mediacenter-player.xml", V.HERE, "Default", "1080i")
        w.setup(api, "live")
        w.attached, w.playback = True, playback
        w.channel_name, w.now_title = name, now_title
        w.doModal()
        result = w.result
        del w
        return result

    def setup(self, api, mode):
        self.api, self.mode = api, mode
        self.attached = False
        self.playback = None
        self.result = "closed"
        self.layer = ""
        self.t = {}
        self.hud_until = 0
        self.ask_event = threading.Event()
        self.ask_answer = None
        self.upnext_target = None
        self.upnext_cancel = threading.Event()
        self.feeds, self.versions, self.others = [], [], []
        self.ticker = None
        self.closing = False
        self.season = self.episode = None
        self.episode_name = ""

    # -- layers --

    def show_layer(self, name, focus=None):
        self.layer = name
        self.setProperty("layer", name)
        if focus:
            self.setFocusId(focus)

    def stage(self, pct, words, detail):
        if pct >= 100:
            self.clearProperty("loading")
            return
        stages = LIVE_STAGES if self.mode == "live" else STAGES
        self.setProperty("loading", "1")
        if self.layer not in ("", "loading"):
            return
        self.show_layer("loading")
        self.setProperty("load.pct", str(int(pct)))
        try:
            self.getControl(510).setPercent(pct)
        except RuntimeError:
            pass
        self.setProperty("load.text", (words + u"…") if words else "")
        self.setProperty("load.detail", (u"%s · %s" % (words, detail)) if detail else "")
        self.setProperty("load.when", "%d%% · %ds" % (int(pct), int(time.time() - self.began)))
        for i, (text, state) in enumerate(stage_text(stages, pct), 1):
            self.setProperty("step.%d" % i, u"%s  %s" % (MARK[state], text))
            self.setProperty("step.%d.state" % i, state)
        for i in range(len(stages) + 1, 7):
            self.clearProperty("step.%d" % i)

    def toast(self, words):
        self.setProperty("toast", words)
        stamp = time.time()
        self.toast_at = stamp

        def clear():
            if getattr(self, "toast_at", 0) == stamp:
                self.clearProperty("toast")
        timer = threading.Timer(3.5, clear)
        timer.daemon = True
        timer.start()

    def started(self, feed):
        self.clearProperty("loading")
        self.show_layer("")
        self.setProperty("playing", "1")
        self.show_hud()

    def failed(self):
        self.clearProperty("loading")
        self.clearProperty("playing")
        live = self.mode == "live"
        self.setProperty("err.title", LIVE_FAILED if live else VOD_FAILED)
        self.setProperty("err.reason", "None of its feeds answered. Try again in a few minutes, or pick another channel." if live else
                         "mediaCENTER tried %d source%s for this title and none of them started. Another version may work, "
                         "or try again in a few minutes." % (len(self.feeds), "" if len(self.feeds) == 1 else "s"))
        self.setProperty("err.other", "" if live or not self.versions else "1")
        self.show_layer("error", E_OTHER if self.getProperty("err.other") else E_RETRY)

    def ended(self):
        self.clearProperty("playing")
        if self.mode == "vod" and self.kind == "series":
            nxt = self.find_next()
            if nxt:
                return self.up_next(nxt)
        self.finish("ended")

    def stopped(self):
        self.clearProperty("playing")
        self.finish("stopped")

    def finish(self, why):
        self.result = why
        self.closing = True
        self.close()

    # -- opening --

    def onInit(self):
        if getattr(self, "started_once", False):
            return
        self.started_once = True
        self.began = time.time()
        for k in HOME_PROPS:
            V.WINDOW.clearProperty(k)
        V.WINDOW.setProperty("mc.full", "1")
        self.setProperty("mode", self.mode)
        # The Homebridge remote (homebridge/homebridge-mediacenter-tv) reads this to switch to its playback buttons.
        self.setProperty("heading", "Player")
        self.lines = loading_lines(self.mode)
        if self.attached:
            self.playback.ui = self
            self.setProperty("title", self.channel_name)
            self.setProperty("sub", self.now_title)
            self.setProperty("live", "1")
            self.setProperty("playing", "1")
            self.show_layer("")
            self.show_hud()
        else:
            self.playback = Playback(self)
            self.show_layer("loading")
            self.stage(0, (LIVE_STAGES if self.mode == "live" else STAGES)[0][1], "")
            self.worker = threading.Thread(target=self.prepare_live if self.mode == "live" else self.prepare_vod)
            self.worker.daemon = True
            self.worker.start()
        self.ticker = threading.Thread(target=self.tick)
        self.ticker.daemon = True
        self.ticker.start()

    def tick(self):
        """Once a second: the rotating loading line, the time on the loading screen, and hiding the controls."""
        k = 0
        while not self.closing:
            time.sleep(1)
            k += 1
            if self.getProperty("loading"):
                self.setProperty("load.line", self.lines[(k // 2) % len(self.lines)])
                self.setProperty("load.when", "%s%% · %ds" % (self.getProperty("load.pct") or "0", int(time.time() - self.began)))
            if self.layer == "hud" and time.time() > self.hud_until:
                self.hide_hud()

    def prepare_live(self):
        self.setProperty("live", "1")
        self.setProperty("title", self.channel_name)
        self.setProperty("sub", self.now_title)
        self.setProperty("load.title", self.channel_name)
        self.setProperty("load.sub", self.now_title or "Live TV")
        try:
            self.feeds = live_feeds(self.api, self.channel_id, self.channel_name, self.alts)
        except SignedOut:
            return self.signed_out()
        if not self.feeds:
            return self.failed()
        if len(self.feeds) == 1:
            self.feeds[0]["check"] = None  # one feed: the player tries it straight away
        self.playback.start(self.feeds, LIVE_STAGES)

    def prepare_vod(self):
        import mc_play
        kind, tmdb = self.kind, self.tmdb
        try:
            info = self.api.get("/api/roku/title", type=kind, tmdb=tmdb) or {}
            t = L.title_of(dict(info.get("title") or {}, type=kind, tmdb=tmdb)) or {"tmdb": tmdb, "type": kind, "name": "", "poster": ""}
            self.t = t
            self.setProperty("load.fanart", t.get("backdrop") or "")
            self.setProperty("load.title", t.get("name", ""))
            if kind == "series":
                self.episode_name = self.episode_title(self.season, self.episode)
                self.setProperty("load.sub", u"Season %s · Episode %s" % (self.season, self.episode) +
                                 (u" · " + self.episode_name if self.episode_name else ""))
            self.stage(STAGES[1][0], STAGES[1][1], "")
            versions, name = found_versions(self.api, kind, tmdb, self.season, self.episode)
        except SignedOut:
            return self.signed_out()
        except (ServerError, OSError) as e:
            V.log("play: versions not found (%s)" % type(e).__name__)
            versions, name = [], ""
        if self.closing:
            return
        if not t.get("name"):
            t["name"] = name or "mediaCENTER"
            self.setProperty("load.title", t["name"])
        self.versions, self.others = split_versions(versions, mc_play.caps())
        V.log("play %s: %d versions, %d play here" % (kind, len(versions), len(self.versions)))
        self.set_titles()
        if not self.versions:
            self.setProperty("err.title", "No versions for this title yet." if not versions else "This title doesn't play on this box yet.")
            self.setProperty("err.reason", "Try again later: new versions are found all the time." if not versions else
                             "%d version%s need a stronger box than this one." % (len(self.others), "" if len(self.others) == 1 else "s"))
            self.setProperty("err.other", "")
            self.clearProperty("loading")
            return self.show_layer("error", E_CLOSE)
        resume = 0 if self.fresh else self.ask_resume()
        if resume is None or self.closing:
            return
        self.stage(STAGES[2][0], STAGES[2][1], "")
        self.feeds = vod_feeds(self.api, self.versions, self.pick, t, self.season, self.episode, self.episode_name, resume)
        self.playback.start(self.feeds, STAGES)

    def episode_title(self, season, episode):
        try:
            eps = (self.api.get("/api/roku/episodes", tmdb=self.tmdb, season=season) or {}).get("episodes") or []
        except (ServerError, SignedOut, OSError):
            return ""
        self.eps_cache = getattr(self, "eps_cache", {})
        self.eps_cache[int(season)] = eps
        return next((e.get("name", "") for e in eps if int(e.get("n") or 0) == int(episode)), "")

    def set_titles(self):
        t = self.t
        if self.kind == "series":
            self.setProperty("title", t.get("name", ""))
            self.setProperty("sub", u"S%s · E%s%s" % (self.season, self.episode, (u" · " + self.episode_name) if self.episode_name else ""))
            self.setProperty("series", "1")
        else:
            self.setProperty("title", t.get("name", ""))
            self.setProperty("sub", L.title_line(t))
            self.clearProperty("series")

    def ask_resume(self):
        """Resume or start over, asked in mediaCENTER's own screen. Returns seconds, or None when Back was pressed."""
        try:
            hist = (self.api.get("/api/history", limit=300) or {}).get("items") or []
        except (ServerError, SignedOut, OSError):
            return 0
        item_id = L.history_key(self.kind, self.tmdb, self.season, self.episode)
        row = next((h for h in hist if h.get("itemId") == item_id), None)
        if not row or row.get("finished") or float(row.get("position") or 0) < 30:
            return 0
        pos = float(row["position"])
        self.setProperty("ask.resume", "Resume from %s" % L.clock_text(pos))
        self.ask_event.clear()
        self.clearProperty("loading")
        self.show_layer("ask", A_RESUME)
        self.ask_event.wait()
        if self.ask_answer is None:
            return None
        self.show_layer("loading")
        self.setProperty("loading", "1")
        return pos if self.ask_answer == "resume" else 0

    def signed_out(self):
        self.clearProperty("loading")
        self.setProperty("err.title", "Your session ended.")
        self.setProperty("err.reason", "Sign in again from Settings, then play this again.")
        self.setProperty("err.other", "")
        self.show_layer("error", E_CLOSE)

    # -- Up Next --

    def find_next(self):
        try:
            seasons = (self.t or {}).get("seasonList") or []
            if not seasons:
                info = self.api.get("/api/roku/title", type="series", tmdb=self.tmdb) or {}
                seasons = (info.get("title") or {}).get("seasonList") or [self.season]
            cache = getattr(self, "eps_cache", {})

            def numbers(s):
                if int(s) not in cache:
                    cache[int(s)] = (self.api.get("/api/roku/episodes", tmdb=self.tmdb, season=s) or {}).get("episodes") or []
                return [e.get("n") for e in cache[int(s)] if e.get("n")]
            self.eps_cache = cache
            return next_episode(self.season, self.episode, numbers, seasons)
        except (ServerError, SignedOut, OSError, ValueError):
            return None

    def up_next(self, target):
        s, e = target
        name = next((x.get("name", "") for x in getattr(self, "eps_cache", {}).get(int(s), []) if int(x.get("n") or 0) == e), "")
        self.upnext_target = target
        self.setProperty("upnext.title", u"S%d · E%d%s" % (s, e, (u" · " + name) if name else ""))
        self.setProperty("upnext.show", self.t.get("name", ""))
        self.setProperty("upnext.fanart", self.t.get("backdrop") or "")
        self.upnext_cancel.clear()
        self.show_layer("upnext", U_PLAY)

        def count():
            for left in range(UP_NEXT_SECONDS, 0, -1):
                if self.upnext_cancel.is_set() or self.closing:
                    return
                self.setProperty("upnext.count", "UP NEXT · %d" % left)
                time.sleep(1)
            if not self.upnext_cancel.is_set() and not self.closing:
                self.play_next()
        th = threading.Thread(target=count)
        th.daemon = True
        th.start()

    def play_next(self, target=None):
        target = target or self.upnext_target or self.find_next()
        if not target:
            return V.notify("This is the last episode.")
        self.upnext_cancel.set()
        if self.playback:
            self.playback.stop()
        self.season, self.episode = target
        self.pick, self.fresh = None, True
        self.playback = Playback(self)
        self.began = time.time()
        self.show_layer("loading")
        self.setProperty("loading", "1")
        self.worker = threading.Thread(target=self.prepare_vod)
        self.worker.daemon = True
        self.worker.start()

    # -- the controls --

    def show_hud(self, seconds=HUD_SECONDS):
        self.hud_until = time.time() + seconds
        if self.layer != "hud":
            self.setProperty("pp", "Play" if xbmc.getCondVisibility("Player.Paused") else "Pause")
            self.show_layer("hud", B_PLAYPAUSE)

    def hide_hud(self):
        if self.layer == "hud":
            self.show_layer("")
            self.setFocusId(HUD + 99)  # an invisible button, so OK on a hidden control does nothing

    def seek(self, seconds):
        p = self.playback.player if self.playback else None
        if not p or not p.isPlaying() or self.mode == "live":
            return
        try:
            p.seekTime(max(0, p.getTime() + seconds))
        except RuntimeError:
            pass
        self.show_hud()

    def toggle_pause(self):
        if self.playback:
            self.playback.player.pause()
        xbmc.sleep(150)
        self.setProperty("pp", "Play" if xbmc.getCondVisibility("Player.Paused") else "Pause")
        self.show_hud()

    def choose_stream(self, audio):
        p = self.playback.player if self.playback else None
        if not p or not p.isPlaying():
            return
        try:
            names = p.getAvailableAudioStreams() if audio else p.getAvailableSubtitleStreams()
        except RuntimeError:
            names = []
        names = [n or "Track %d" % (i + 1) for i, n in enumerate(names or [])]
        if audio:
            if not names:
                return V.notify("This version has one sound track.")
            i = xbmcgui.Dialog().select("Audio", names)
            if i >= 0:
                p.setAudioStream(i)
        else:
            i = xbmcgui.Dialog().select("Subtitles", ["Off"] + names)
            if i == 0:
                p.showSubtitles(False)
            elif i > 0:
                p.setSubtitleStream(i - 1)
                p.showSubtitles(True)
        self.show_hud()

    def other_version(self):
        """Choose another version: the versions page, then the player starts again with that one first."""
        if self.mode != "vod" or not self.versions:
            return
        import mc_versions_page as VP
        pick = VP.VersionsPage.choose(self.versions, self.others, title=self.t.get("name", ""),
                                      subtitle=self.getProperty("sub") if self.kind == "series" else "")
        if pick is None:
            return self.show_hud() if self.getProperty("playing") else None
        if self.playback:
            self.playback.stop()
        self.pick = pick
        self.playback = Playback(self)
        self.began = time.time()
        self.show_layer("loading")
        self.setProperty("loading", "1")
        self.feeds = vod_feeds(self.api, self.versions, pick, self.t, self.season, self.episode, self.episode_name, 0)
        self.playback.start(self.feeds, STAGES)

    def retry(self, skip_first=False):
        """Retry: the same sources again, checked again. Try the next source: the first one goes to the back."""
        self.playback = Playback(self)
        self.began = time.time()
        self.show_layer("loading")
        self.setProperty("loading", "1")
        feeds = self.feeds[1:] + self.feeds[:1] if skip_first else self.feeds
        self.playback.start(feeds, LIVE_STAGES if self.mode == "live" else STAGES)

    def leave(self):
        """Back with nothing on screen: stop and go back where the player was opened from (the Guide keeps its mini
        player when the full screen came from it)."""
        self.closing = True
        if self.attached:
            self.result = "docked"
        else:
            self.upnext_cancel.set()
            self.ask_answer = None
            self.ask_event.set()
            if self.playback:
                self.playback.stop()
            self.result = "stopped"
        self.close()

    def onClick(self, cid):
        if cid == B_BACK10:
            return self.seek(-10)
        if cid == B_FWD10:
            return self.seek(10)
        if cid == B_PLAYPAUSE:
            return self.toggle_pause()
        if cid == B_NEXT:
            return self.play_next()
        if cid in (B_AUDIO, B_SUBS):
            return self.choose_stream(cid == B_AUDIO)
        if cid in (B_VERSIONS, E_OTHER):
            return self.other_version()
        if cid == E_RETRY:
            return self.retry()
        if cid == E_NEXT:
            return self.retry(skip_first=True)
        if cid == E_CLOSE:
            return self.leave()
        if cid in (A_RESUME, A_START):
            self.ask_answer = "resume" if cid == A_RESUME else "start"
            return self.ask_event.set()
        if cid == U_PLAY:
            return self.play_next()
        if cid == U_CANCEL:
            self.upnext_cancel.set()
            return self.finish("ended")

    def onAction(self, action):
        a = action.getId()
        layer = self.layer
        if a in BACK:
            if layer == "hud":
                return self.hide_hud()
            if layer == "upnext":
                self.upnext_cancel.set()
                return self.finish("ended")
            return self.leave()
        if a == STOP:
            return self.leave()
        if layer in ("loading", "error", "ask", "upnext"):
            return
        if a in (PAUSE, PLAYPAUSE, PLAY):
            return self.toggle_pause()
        if a == FORWARD:
            return self.seek(30)
        if a == REWIND:
            return self.seek(-30)
        if a == NEXT_ITEM and self.mode == "vod" and self.kind == "series":
            return self.play_next()
        if layer == "hud":
            self.hud_until = time.time() + HUD_SECONDS
            return
        if a == LEFT:
            return self.seek(-10)
        if a == RIGHT:
            return self.seek(10)
        if a in (UP, DOWN, SELECT) or a in MENU_KEYS:
            return self.show_hud()

    def close(self):
        self.closing = True
        V.WINDOW.clearProperty("mc.full")
        xbmcgui.WindowXMLDialog.close(self)


# ---- what the other pages call -----------------------------------------------------------------------------------------

def play_title(api, kind, tmdb, season=None, episode=None, choose=False, fresh=False):
    """Play a movie or an episode from any page; with choose, the versions page comes first."""
    pick = None
    if choose:
        import mc_play
        import mc_versions_page as VP
        busy(True)
        try:
            versions, _ = found_versions(api, kind, tmdb, season, episode)
        except SignedOut:
            busy(False)
            return xbmcgui.Dialog().ok("mediaCENTER", "Your session ended. Sign in again from Settings.")
        except (ServerError, OSError):
            versions = []
        finally:
            busy(False)
        ranked, others = split_versions(versions, mc_play.caps())
        pick = VP.VersionsPage.choose(ranked, others)
        if pick is None:
            return None
    return PlayerPage.movie(api, kind, tmdb, season, episode, pick=pick, fresh=fresh)


def play_channel(api, channel_id, name="", alts=None, now_title=""):
    return PlayerPage.live(api, channel_id, name, alts, now_title)
