# mediaCENTER for Kodi: "Choose a version" (mediacenter-versions.xml), like the web's link sheet
# (web-v27/js/views/linksheet.js) and the Roku's VersionsScreen: the best match first ("Play this version"), then the other
# versions with how good they look, how big they are, whether they start right away and their sound. Versions that failed
# on this box lately are left out (with "Show them anyway"), and so are the ones this box can't play.

import xbmcgui

import mc_versions as MV
import mc_views as V

LIST, SHOW_FAILED, SHOW_OTHERS = 50, 61, 62
BACK = (9, 10, 92, 247)


def items_for(rows, best=True):
    """ListItems for picker rows (mc_versions.rows_for): label = the facts line ("Full HD · 2.10 GB"), label2 = whether it
    starts right away and the sound, and the badges, file name and where it comes from as properties."""
    out = []
    for k, r in enumerate(rows):
        info, v = r["info"], r["version"]
        ready = (MV.READY_TEXT if best and k == 0 else MV.READY_SHORT).get(info["ready"], "")
        mark = info["mark"].get("text") or ""
        li = xbmcgui.ListItem(MV.facts_line(info), MV.DOT.join(p for p in [ready, mark] if p))
        li.setProperties({"badges": MV.source_badges(v), "name": (v.get("name") or "").split("\n")[0][:90], "place": r["place"],
                          "best": "1" if best and k == 0 else "", "eyebrow": "BEST MATCH" if best and k == 0 else "",
                          "hidden": "1" if r.get("hidden") else "", "failed": "1" if r.get("failed") else ""})
        out.append(li)
    return out


class VersionsPage(xbmcgui.WindowXMLDialog):
    @classmethod
    def choose(cls, ranked, others=(), title="", subtitle=""):
        """Returns the chosen version (a dict from the server's list) or None."""
        w = cls("mediacenter-versions.xml", V.HERE, "Default", "1080i")
        w.ranked, w.others_in, w.title, w.subtitle = list(ranked), list(others), title, subtitle
        w.pick = None
        w.doModal()
        pick = w.pick
        del w
        return pick

    def onInit(self):
        if getattr(self, "started", False):
            return
        self.started = True
        failed = MV.FailedLinks(V.PROFILE)
        self.rows, self.gone, self.others = MV.rows_for(self.ranked, failed=failed.has, hidden_versions=self.others_in)
        for r in self.gone:
            r["failed"] = True
        self.showing_failed = self.showing_others = False
        self.setProperty("heading", "Choose a version")
        self.setProperty("subheading", MV.DOT.join(p for p in [self.title, self.subtitle] if p))
        self.draw()

    def shown(self):
        rows = list(self.rows)
        if self.showing_failed:
            rows += self.gone
        if self.showing_others:
            rows += self.others
        return rows

    def draw(self):
        rows = self.shown()
        control = self.getControl(LIST)
        control.reset()
        control.addItems(items_for(rows))
        n_gone, n_others = len(self.gone), len(self.others)
        self.setProperty("failed.note", "" if self.showing_failed or not n_gone else
                         "%d left out: %s failed here lately" % (n_gone, "it" if n_gone == 1 else "they"))
        self.setProperty("others.note", "" if self.showing_others or not n_others else
                         "%d more can't play on this device" % n_others)
        if not rows:
            self.setProperty("empty", "No versions for this title yet.")
            self.setFocusId(SHOW_OTHERS if n_others else LIST)
        else:
            self.clearProperty("empty")
            self.setFocusId(LIST)

    def onClick(self, cid):
        if cid == LIST:
            i = self.getControl(LIST).getSelectedPosition()
            rows = self.shown()
            if 0 <= i < len(rows):
                self.pick = rows[i]["version"]
                self.close()
        elif cid == SHOW_FAILED:
            self.showing_failed = True
            self.draw()
        elif cid == SHOW_OTHERS:
            self.showing_others = True
            self.draw()

    def onAction(self, action):
        if action.getId() in BACK:
            self.close()
