# mediaCENTER for Kodi: the iPhone remote built into the box (the add-on service.mediacenter.remote), as Settings and
# first-run setup show it. The remote is a separate service that runs while Kodi runs; the two talk through Home window
# properties (service.mediacenter.remote/resources/lib/bridge.py has the list). The pairing code is never in one of
# them: it is only in the remote's own file (pairing-window.json, readable by this box's Kodi only), which is read here
# to show the code on the TV while the iPhone pairing page is open. It is never logged.

import json
import time

ASK, STATUS, PAIRED, PAIRING = ("mediacenter.remote." + k for k in ("ask", "status", "paired", "pairing"))
CODE_FILE = "special://profile/addon_data/service.mediacenter.remote/state/pairing-window.json"
DOCKER = "docker rm -f mediacenter-remote"


def ask(window, what):
    """Ask the remote for something: pair (a new pairing code), on or off."""
    window.setProperty(ASK, what)


def paired(window):
    try:
        return max(0, int(window.getProperty(PAIRED) or 0))
    except ValueError:
        return 0


def state(window):
    return window.getProperty(STATUS) or ""


def summary(window):
    """The short line under "iPhone remote"."""
    s, n = state(window), paired(window)
    if s == "on":
        return "On, %d iPhone%s paired" % (n, "" if n == 1 else "s") if n else "On, no iPhone paired yet"
    return {"off": "Off", "starting": "Starting…", "in use": "Waiting for the old remote to be removed",
            "broken": "Not working right now", "missing": "Not working right now"}.get(s, "Not running")


def explain(window):
    """What the iPhone remote page says about it, on the right."""
    s = state(window)
    steps = ("Use your iPhone's own remote and keyboard with this box, with nothing to install on the iPhone.\n\n"
             "1. Choose Pair an iPhone. A four-digit code shows here.\n"
             "2. On the iPhone, open Control Center and tap the remote.\n"
             "3. At the top, choose mediaCENTER TV, then type the code.\n\n"
             "The iPhone needs to be on the same Wi-Fi as this box.")
    if s == "in use":
        return ("The remote that ran in Docker on this box is still running, so this one can't start.\n\n"
                "Remove the old one over SSH with:\n%s\n\nthen restart the box. You'll pair your iPhone once more." % DOCKER)
    if s in ("broken", "missing"):
        return "The iPhone remote couldn't start. Restart the box and try again.\n\n" + steps
    if s == "":
        return "The iPhone remote isn't running on this box yet. It comes with the next mediaCENTER update."
    return steps


def read_code(path, now=None):
    """(the four-digit code, when it stops working) from the remote's file, or None when no code is open."""
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        pin, until = str(data.get("pin", "")), float(data.get("expires_at", 0))
    except (OSError, ValueError, TypeError, AttributeError):
        return None
    if len(pin) != 4 or not pin.isdigit() or until <= (now or time.time()):
        return None
    return pin, until


def spaced(pin):
    return " ".join(pin)


def until_text(until):
    clock = time.strftime("%I:%M %p", time.localtime(until)).lstrip("0")
    return "Works until %s" % clock
