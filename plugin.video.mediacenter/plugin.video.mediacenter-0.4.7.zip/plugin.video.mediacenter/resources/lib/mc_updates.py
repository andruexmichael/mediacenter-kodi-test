"""Trusted update feed, bounded downloads and staged, rollback-capable installation.

The worker is copied to the profile before RunScript so replacing the add-on cannot remove its running code.
Account/profile data is never part of an update. No shell commands or remote installer scripts are run.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import tempfile
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

FEEDS = {
    'stable': 'https://watch.littlebirdtampa.com/kodi/',
    'test': 'https://raw.githubusercontent.com/andruexmichael/mediacenter-kodi-test/main/'
}
APP = 'plugin.video.mediacenter'
REMOTE = 'service.mediacenter.remote'
ALLOWED = (APP, 'script.mediacenter', 'skin.mediacenter', 'repository.mediacenter', 'repository.mediacenter.test', REMOTE)
NEEDED = (REMOTE,)  # parts the app needs: added by an update when they're not here yet (the app requires them)
LIMIT = 60 * 1024 * 1024


def version(value):
    if not re.fullmatch(r'\d{1,4}\.\d{1,4}\.\d{1,4}', value or ''):
        raise ValueError('Invalid version')
    return tuple(map(int, value.split('.')))


def download(url, limit=LIMIT):
    if not any(url.startswith(base) for base in FEEDS.values()):
        raise ValueError('Untrusted update address')
    with urllib.request.urlopen(url, timeout=30) as response:
        if not any(response.geturl().startswith(base) for base in FEEDS.values()):
            raise ValueError('Untrusted redirect')
        data = response.read(limit + 1)
        if len(data) > limit:
            raise ValueError('Update too large')
        return data


def installed(addons):
    """{add-on id: version} of our add-ons in Kodi's add-on folder."""
    out = {}
    for ident in ALLOWED:
        manifest = Path(addons) / ident / 'addon.xml'
        try:
            ver = ET.parse(str(manifest)).getroot().get('version')
            version(ver)
            out[ident] = ver
        except (OSError, ET.ParseError, ValueError):
            pass
    return out


def default_channel(have):
    """The update list this box was set up from: Test when the test repository is installed, otherwise Stable."""
    return 'test' if 'repository.mediacenter.test' in have and 'repository.mediacenter' not in have else 'stable'


def check(channel, have, fetch=download):
    """What the update list offers: {channel, version, available, notes, packages}. Add-ons that are installed here and
    newer in the list are in packages (the skin only goes where the skin is, so a Kodi 20 box never gets it), and so are
    the parts the app needs that aren't here yet (the iPhone remote, the first time)."""
    if isinstance(have, str):
        have = {APP: have}
    base = FEEDS[channel]
    xml = fetch(base + 'addons.xml', 1024 * 1024)
    checksum = fetch(base + 'addons.xml.md5', 128).decode().strip()
    if hashlib.md5(xml).hexdigest() != checksum:
        raise ValueError('Update list is changing; try again')
    root = ET.fromstring(xml)
    if root.tag != 'addons':
        raise ValueError('Invalid update list')
    listed = {}
    for addon in root:
        ident = addon.get('id')
        if ident not in ALLOWED:
            continue
        if ident in listed:
            raise ValueError('Duplicate add-on')
        ver = addon.get('version')
        version(ver)
        listed[ident] = ver
    if APP not in listed or 'script.mediacenter' not in listed:
        raise ValueError('Incomplete update')
    packages = [{'id': ident, 'version': ver} for ident, ver in listed.items()
                if (ident in have and version(ver) > version(have[ident])) or (ident in NEEDED and ident not in have)]
    notes = root.find("./addon[@id='%s']/extension/news" % APP)
    return {'channel': channel, 'version': listed[APP], 'available': bool(packages),
            'notes': (notes.text or '').strip() if notes is not None and (notes.text or '').strip()
            else 'Improvements to mediaCENTER. Your account and settings are kept.',
            'packages': packages}


def extract(data, folder, ident, ver):
    import io
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        entries = archive.infolist()
        if sum(e.file_size for e in entries) > 150 * 1024 * 1024 or len(entries) > 6000:
            raise ValueError('Expanded update too large')
        for e in entries:
            parts = e.filename.split('/')
            if parts[0] != ident or '..' in parts or '\\' in e.filename or any(p.startswith('.') for p in parts if p):
                raise ValueError('Unsafe update path')
            mode = e.external_attr >> 16
            if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) not in (0, stat.S_IFREG, stat.S_IFDIR)):
                raise ValueError('Unsafe update entry')
            if '/resources/data/sample/' in e.filename or e.filename.endswith('/session.json'):
                raise ValueError('Unexpected account or sample data')
        archive.extractall(folder)
    manifest = ET.parse(Path(folder) / ident / 'addon.xml').getroot()
    if manifest.get('id') != ident or manifest.get('version') != ver:
        raise ValueError('Package does not match update list')


def install(plan, addons, fetch=download, progress=lambda text: None, before_swap=lambda: None, after_swap=lambda: None):
    """Download and validate everything first; preserve original folders until all replacements succeed."""
    channel = plan['channel']
    base = FEEDS[channel]
    addons = Path(addons)
    if not plan['packages'] or len(plan['packages']) > len(ALLOWED) or len({p['id'] for p in plan['packages']}) != len(plan['packages']):
        raise ValueError('Invalid package list')
    staged = Path(tempfile.mkdtemp(prefix='.mediacenter-update-', dir=str(addons)))
    changed = []
    try:
        new, backup = staged / 'new', staged / 'backup'
        new.mkdir(); backup.mkdir()
        for package in plan['packages']:
            ident, ver = package['id'], package['version']
            if ident not in ALLOWED:
                raise ValueError('Unexpected add-on')
            version(ver)
            current = addons / ident / 'addon.xml'
            if current.exists() and version(ET.parse(str(current)).getroot().get('version')) >= version(ver):
                raise ValueError('Refusing to downgrade or reinstall an installed component')
            progress('Downloading mediaCENTER components…')
            extract(fetch(base + ident + '/' + ident + '-' + ver + '.zip'), new, ident, ver)
        before_swap()
        progress('Installing update. Keep the device powered on.')
        for package in plan['packages']:
            ident = package['id']
            target, saved = addons / ident, backup / ident
            existed = target.exists()
            if existed:
                os.replace(target, saved)
            changed.append((ident, existed))
            os.replace(new / ident, target)
        after_swap()
    except Exception:
        for ident, existed in reversed(changed):
            target = addons / ident
            if target.exists():
                shutil.rmtree(target)
            if existed:
                os.replace(staged / 'backup' / ident, target)
        raise
    finally:
        shutil.rmtree(staged, ignore_errors=True)


def add_needed(channel, addons, fetch=download, after_swap=lambda: None):
    """Add the parts the app needs that aren't here yet (the iPhone remote on a box that updated from 0.4.6, whose
    updater didn't know it), quietly and without touching the parts that are here. Returns the ids added."""
    plan = check(channel, installed(addons), fetch)
    plan['packages'] = [p for p in plan['packages'] if p['id'] in NEEDED and not (Path(addons) / p['id']).exists()]
    if not plan['packages']:
        return []
    install(plan, addons, fetch, after_swap=after_swap)
    return [p['id'] for p in plan['packages']]


def worker(profile):
    import xbmc
    import xbmcgui
    import xbmcvfs
    profile = Path(profile)
    with open(profile / 'update-plan.json') as f:
        plan = json.load(f)
    dialog = xbmcgui.DialogProgress()
    dialog.create('mediaCENTER update', 'Preparing update…')
    def rpc(method, params):
        result = json.loads(xbmc.executeJSONRPC(json.dumps({'jsonrpc':'2.0','id':1,'method':method,'params':params})))
        if 'error' in result:
            raise RuntimeError('Could not update components')
        return result.get('result')
    def before():
        rpc('Addons.SetAddonEnabled', {'addonid': APP, 'enabled': False})
    def after():
        xbmc.executebuiltin('UpdateLocalAddons', True)
        for ident in [p['id'] for p in plan['packages'] if p['id'] in NEEDED]:
            try:  # Kodi keeps a newly copied add-on switched off until it's turned on
                rpc('Addons.SetAddonEnabled', {'addonid': ident, 'enabled': True})
            except RuntimeError:
                pass  # the app still starts; Settings says the remote isn't running
        rpc('Addons.SetAddonEnabled', {'addonid': APP, 'enabled': True})
    try:
        install(plan, xbmcvfs.translatePath('special://home/addons'),
                progress=lambda text: dialog.update(0, text), before_swap=before, after_swap=after)
        dialog.close()
        xbmcgui.Dialog().ok('mediaCENTER', 'Update installed. mediaCENTER will restart.')
        if xbmc.getSkinDir() == 'skin.mediacenter':
            xbmc.executebuiltin('RestartApp')  # the box restarts into mediaCENTER with every new part loaded
        else:
            xbmc.executebuiltin('RunScript(script.mediacenter)')
    except Exception:
        # Restore a disabled app as well as its folders; never print URLs or exception messages.
        try:
            xbmc.executebuiltin('UpdateLocalAddons', True)
            rpc('Addons.SetAddonEnabled', {'addonid': APP, 'enabled': True})
        except Exception:
            pass
        dialog.close()
        xbmcgui.Dialog().ok('mediaCENTER', 'The update could not finish. Your previous version and account have been kept. Try again later.')
    finally:
        (profile / 'update-plan.json').unlink(missing_ok=True)


if __name__ == '__main__':
    import sys
    worker(sys.argv[1])
