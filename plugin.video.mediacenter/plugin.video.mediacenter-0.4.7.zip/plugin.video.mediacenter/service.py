# mediaCENTER for Kodi: the background service. While a mediaCENTER movie or episode plays it saves progress to
# /api/history every 30 seconds and when playback stops, so Continue Watching matches the phone, the Apple TV and the
# web. It also jumps to the resume point chosen in mc_play.resume_point once the video has started, and puts in the
# iPhone remote (service.mediacenter.remote) from the update list when the box doesn't have it yet.

import json
import os
import sys

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("plugin.video.mediacenter")  # named, so it never depends on who started it
sys.path.insert(0, os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")), "resources", "lib"))

from mc_api import Api, Session  # noqa: E402
import mc_launch  # noqa: E402
import mc_sample  # noqa: E402

PLAYING_KEY = "mediacenter.playing"
SAVE_EVERY = 30


def api():
    sample = mc_sample.folder(xbmcvfs.translatePath(ADDON.getAddonInfo("path")))
    if sample:
        return mc_sample.SampleApi(sample)
    return Api(ADDON.getSetting("server") or None, Session(xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))))


def save(entry, position, duration):
    if not entry or duration <= 0 or position < 0:
        return
    body = dict({k: v for k, v in entry.items() if v is not None}, position=int(min(position, duration)), duration=int(duration))
    try:
        api().call("POST", "/api/history", body=body, timeout=10)
    except Exception as e:  # never let a failed save stop playback
        xbmc.log("[mediaCENTER] progress not saved: %s" % type(e).__name__, xbmc.LOGINFO)


class Player(xbmc.Player):
    def __init__(self):
        super(Player, self).__init__()
        self.reset()

    def reset(self):
        self.entry = None
        self.position = 0.0
        self.duration = 0.0
        self.last_save = 0.0

    def onAVStarted(self):
        raw = xbmcgui.Window(10000).getProperty(PLAYING_KEY)
        xbmcgui.Window(10000).clearProperty(PLAYING_KEY)
        if not raw:
            self.reset()
            return
        try:
            data = json.loads(raw)
        except ValueError:
            return
        self.entry = data.get("entry")
        resume = float(data.get("resume") or 0)
        if resume > 0:
            self.seekTime(resume)
        self.position = resume
        self.last_save = resume

    def finish(self):
        if self.entry:
            save(self.entry, self.position, self.duration)
        self.reset()

    def onPlayBackStopped(self):
        self.finish()

    def onPlayBackEnded(self):
        self.position = self.duration
        self.finish()

    def tick(self):
        if not self.entry or not self.isPlayingVideo():
            return
        try:
            self.position = self.getTime()
            self.duration = self.getTotalTime() or self.duration
        except RuntimeError:
            return
        if abs(self.position - self.last_save) >= SAVE_EVERY:
            self.last_save = self.position
            save(self.entry, self.position, self.duration)


def refresh_guide():
    """Every few hours, fetch the channels and the guide again for Kodi's TV guide (once the Guide set it up)."""
    import mc_guide as G
    profile = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not G.due(profile):
        return
    try:
        a = api()
        if not a.signed_in:
            return
        n, programmes = G.refresh(a, profile, "plugin://plugin.video.mediacenter/", ADDON.getSetting("guide_channels") == "1")
        xbmc.log("[mediaCENTER] guide refreshed: %d channels, %d programmes" % (n, programmes), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log("[mediaCENTER] guide not refreshed: %s" % type(e).__name__, xbmc.LOGINFO)


def sleep_timer():
    """The power menu's sleep timer (mc_power): a notice a minute before, then playback stops and the TV turns off."""
    import mc_power
    try:
        mc_power.tick(xbmcgui.Window(10000), xbmc.executebuiltin,
                      lambda method, params: json.loads(xbmc.executeJSONRPC(json.dumps(
                          {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}))).get("result"),
                      lambda text: xbmcgui.Dialog().notification("mediaCENTER", text))
    except Exception as e:  # never stop the service
        xbmc.log("[mediaCENTER] sleep timer: %s" % type(e).__name__, xbmc.LOGINFO)


def add_remote():
    """Put in the iPhone remote if this box doesn't have it yet (it came after the updater on some boxes). Quiet: it
    tries again later if the update list can't be reached. Returns True once there's nothing left to add."""
    import mc_updates as U
    addons = xbmcvfs.translatePath("special://home/addons")
    if os.path.isdir(os.path.join(addons, U.REMOTE)):
        return True
    channel = ADDON.getSetting("update_channel") or U.default_channel(U.installed(addons))

    def turn_on():
        xbmc.executebuiltin("UpdateLocalAddons", True)
        for ident in U.NEEDED:
            xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
                                            "params": {"addonid": ident, "enabled": True}}))
    try:
        added = U.add_needed(channel, addons, after_swap=turn_on)
    except Exception as e:  # never print addresses or messages from the update list
        xbmc.log("[mediaCENTER] iPhone remote not added yet: %s" % type(e).__name__, xbmc.LOGINFO)
        return False
    if added:
        xbmc.log("[mediaCENTER] added: %s" % ", ".join(added), xbmc.LOGINFO)
    return True


if __name__ == "__main__":
    monitor = xbmc.Monitor()
    player = Player()
    if ADDON.getSetting("autostart") != "false" and not monitor.waitForAbort(4):
        # A mediaCENTER box opens straight into the app (owner, 2026-11-25: plug and play). On the box, mediaCENTER's
        # start-up picture and look are put in place first (mc_boot); the mediaCENTER look opens the app itself from
        # its Home. Anywhere else (or while the look is being switched to) the service opens it.
        import mc_boot  # noqa: E402
        here = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
        try:
            state = mc_boot.prepare(monitor, here, xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), ADDON.getAddonInfo("version"))
        except Exception as e:  # never keep the app from opening
            xbmc.log("[mediaCENTER] start-up steps skipped: %s" % type(e).__name__, xbmc.LOGINFO)
            state = ""
        if state:
            xbmc.log("[mediaCENTER] mediaCENTER look: %s" % state, xbmc.LOGINFO)
        if state != "switching" and xbmc.getSkinDir() != "skin.mediacenter":
            xbmc.executebuiltin(mc_launch.open_app(here))
    seconds = 0
    remote_here = False
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
        player.tick()
        seconds += 1
        if seconds % 600 == 30 and not player.isPlayingVideo():  # look every 10 minutes, never during a film
            refresh_guide()
        if not remote_here and seconds % 600 == 45 and not player.isPlayingVideo():
            remote_here = add_remote()
        sleep_timer()
